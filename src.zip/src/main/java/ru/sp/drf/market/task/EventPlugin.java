package ru.sp.drf.market.task;

import org.springframework.scheduling.annotation.Async;
import ru.sp.drf.market.dataloader.fias.BulkStoreListener;
import ru.sp.drf.market.dataloader.fias.StoreEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public abstract class EventPlugin {

    private final ReadWriteLock readWriteLock = new ReentrantReadWriteLock(true);
    protected final Lock readLock = readWriteLock.readLock();
    protected final Lock writeLock = readWriteLock.writeLock();
    private List<BulkStoreListener> bulkStoreListeners = new ArrayList<>();
    private List<PostProcessingListener> postProcessingListeners = new ArrayList<>();

    public BulkStoreListener registerBulkStoreListener(BulkStoreListener listener) {
        // Lock the list of listeners for writing
        this.writeLock.lock();
        try {
            // Add the listener to the list of registered listeners
            this.bulkStoreListeners.add(listener);
        } finally {
            // Unlock the writer lock
            this.writeLock.unlock();
        }
        return listener;
    }

    public PostProcessingListener registerPostProcessingListener(PostProcessingListener listener) {
        // Lock the list of listeners for writing
        this.writeLock.lock();
        try {
            // Add the listener to the list of registered listeners
            this.postProcessingListeners.add(listener);
        } finally {
            // Unlock the writer lock
            this.writeLock.unlock();
        }
        return listener;
    }

    public void unregisterBulkStoreListener(BulkStoreListener listener) {
        // Lock the list of listeners for writing
        this.writeLock.lock();
        try {
            // Remove the listener from the list of the registered listeners
            this.bulkStoreListeners.remove(listener);
        } finally {
            // Unlock the writer lock
            this.writeLock.unlock();
        }
    }

    public void unregisterPostProcessingListener(PostProcessingListener listener) {
        // Lock the list of listeners for writing
        this.writeLock.lock();
        try {
            // Remove the listener from the list of the registered listeners
            this.postProcessingListeners.remove(listener);
        } finally {
            // Unlock the writer lock
            this.writeLock.unlock();
        }
    }

    @Async
    public void notifyBulkStore(StoreEvent event) {
        // Lock the list of listeners for reading
        this.readLock.lock();
        try {
            // Notify each of the listeners in the list of registered listeners
            this.bulkStoreListeners.forEach(listener -> listener.onStore(event));
        } finally {
            // Unlock the reader lock
            this.readLock.unlock();
        }
    }

    @Async
    public void notifyPostProcessing() {
        // Lock the list of listeners for reading
        this.readLock.lock();
        try {
            // Notify each of the listeners in the list of registered listeners
            this.postProcessingListeners.forEach(listener -> listener.onAfterLoad());
        } finally {
            // Unlock the reader lock
            this.readLock.unlock();
        }
    }

}
