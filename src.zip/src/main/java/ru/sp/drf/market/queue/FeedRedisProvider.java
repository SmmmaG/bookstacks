package ru.sp.drf.market.queue;

import org.redisson.api.RTopic;
import org.redisson.api.RedissonClient;
import org.springframework.stereotype.Service;
import ru.domrf.rem.dto.bus.EventBusConfig;
import ru.domrf.rem.dto.bus.processes.ProcessAction;
import ru.domrf.rem.dto.bus.processes.ProcessActionMessage;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.RedisConfiguration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.inject.Inject;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

@Service
public class FeedRedisProvider {

    private static final CustomLogger LOG = CustomLogger.getLogger();
    private RTopic topic;
    @Inject
    private RedissonClient redisson;

    @PostConstruct
    public void init() {
        this.topic = redisson.getTopic(RedisConfiguration.getKeyPrefix() + EventBusConfig.REM_EVENT_BUS_TOPIC);
    }

    public void firePostProcessingEvent(ProcessAction action) {
        ProcessActionMessage actionMessage = new ProcessActionMessage(action);
        try {
            long subscribeCount = this.topic.publish(actionMessage);
            LOG.debug("Action Event sent to subscribes count:" + subscribeCount);
        } catch (Exception e) {
            LOG.error("Error action: " + action.getActionCode() + "with param:" + action.getId(), e);
        }
    }

    @PreDestroy
    public void close() {
        if (isValid(this.topic)) {
            this.topic.removeAllListeners();
        }
        if (isValid(this.redisson) && !this.redisson.isShutdown()) {
            this.redisson.shutdown();
        }
    }
}
