package ru.sp.drf.market.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import ru.domrf.rem.domain.admin.Feed;

import java.util.List;
import java.util.UUID;

public interface FeedRepository extends CrudRepository<Feed, UUID> {

    @Query(value = "SELECT f FROM Feed f WHERE f.active=true AND f.actual=true")
    List<Feed> findAllActive();
}
