package ru.sp.drf.market.service;

import org.springframework.stereotype.Service;
import ru.domrf.rem.domain.admin.EventLog;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.sp.drf.market.repository.EventLogsRepository;

import javax.transaction.Transactional;

@Service
public class FeedEventLogService {


    private final EventLogsRepository repository;

    public FeedEventLogService(EventLogsRepository repository) {
        this.repository = repository;
    }

    public EventLog save (EventLog log){
        return repository.save(log);
    }

    @Transactional
    public void delete (FeedLog log){
        repository.deleteEvents(log.getId());
    }

}
