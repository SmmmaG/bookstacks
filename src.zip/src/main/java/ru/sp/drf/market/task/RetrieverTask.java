package ru.sp.drf.market.task;

import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.domrf.rem.utilities.LoggedClass;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class RetrieverTask implements Runnable {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    //TODO есть ли необходимость делать так?
    public RetrieverTask() {
    }

    @Override
    public void run() {
        LOG.info("Start photo retriever");
        try {
            URL url = new URL(FeedServiceConfig.PHOTO_RETRIEVER_SERVICE_URL + "/api/execute");
            HttpURLConnection conns = (HttpURLConnection) url.openConnection();
            conns.setRequestMethod("POST");
            BufferedReader rd = new BufferedReader(new InputStreamReader(conns.getInputStream(), "UTF-8"));
            rd.close();
        } catch (Exception e) {
            LOG.error(e);
        }
    }
}
