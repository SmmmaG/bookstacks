package ru.sp.drf.market.service;

import org.springframework.stereotype.Service;
import ru.domrf.rem.domain.Complex;
import ru.sp.drf.market.repository.ComplexRepository;

import javax.persistence.Tuple;
import java.util.List;

@Service
public class ComplexService extends AbstractService{

    private final ComplexRepository repository;

    public ComplexService(ComplexRepository repository) {
        this.repository = repository;
    }

    public List<Tuple> findAllWithoutCoordinates(){
        return repository.findAllWithoutCoordinates();
    }

    public Complex save(Complex complex){
        return repository.save(complex);
    }
}
