
package ru.sp.drf.market.exchange.domclick;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for profits_mainType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="profits_mainType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="profit_main" type="{}profit_mainType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "profits_mainType", propOrder = {
    "profitMain"
})
public class ProfitsMainType {

    @XmlElement(name = "profit_main", required = true)
    protected ProfitMainType profitMain;

    /**
     * Gets the value of the profitMain property.
     * 
     * @return
     *     possible object is
     *     {@link ProfitMainType }
     *     
     */
    public ProfitMainType getProfitMain() {
        return profitMain;
    }

    /**
     * Sets the value of the profitMain property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProfitMainType }
     *     
     */
    public void setProfitMain(ProfitMainType value) {
        this.profitMain = value;
    }

}
