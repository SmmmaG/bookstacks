package ru.sp.drf.market.dataloader.fias.strategy;

import ru.domrf.rem.domain.admin.FeedLog;
import ru.sp.drf.market.config.loaders.FiasConfig;
import ru.sp.drf.market.model.fias.DataRow;
import ru.sp.drf.market.utilities.ElasticBulkClient;

import java.util.List;

import static ru.sp.drf.market.config.loaders.FiasConfig.ADDRESS_FIELDS_FOR_UPDATE;
import static ru.domrf.rem.utilities.LoggedClass.logDebug;

public class UpdateAddressElasticCommand extends OperationCommand {

    @Override
    public void execute(List<DataRow> datas, FeedLog feedLog) {
        logDebug("Making update index to " + FiasConfig.getElasticUrl());
        updateIndex(datas,ADDRESS_FIELDS_FOR_UPDATE, feedLog);
    }

    protected void updateIndex(List<DataRow> datas, String[] attributes, FeedLog feedLog) {
        ElasticBulkClient.loadForUpdateToElastic(sliceLoader, datas, feedLog, attributes);
    }

}
