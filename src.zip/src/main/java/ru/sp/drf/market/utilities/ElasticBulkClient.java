package ru.sp.drf.market.utilities;

import org.apache.http.HttpHost;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.DocWriteResponse;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.support.replication.ReplicationResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.domain.admin.FeedLogStatuses;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.elastic.BasicSlicer;
import ru.sp.drf.market.dataloader.fias.XmlLoader;
import ru.sp.drf.market.config.loaders.FiasConfig;
import ru.sp.drf.market.exception.ElasticLoaderException;
import ru.sp.drf.market.model.BasicItem;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import static ru.sp.drf.market.config.loaders.FiasConfig.JSON_REQUEST_HEADER_CONTENT_TYPE;
import static ru.sp.drf.market.utilities.HelperUtils.isValid;

public class ElasticBulkClient {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    static final String DIR_REPOSITORY = "dbscr/fias/elastic/";

    private static final int LIMIT = 100;


    public static ResponseEntity<String> save(String url, String data, HttpHeaders headers) {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        HttpEntity requestEntity = new HttpEntity(data, headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, requestEntity, String.class);
        return response;
    }


    public static ResponseEntity<String> isAlive(String url, HttpHeaders headers) {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        HttpEntity requestEntity = new HttpEntity(headers);
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.HEAD, requestEntity, String.class);
        return response;
    }


    public static void createIndex(String fileName, String indexName) {
        HttpEntity requestEntity;
        ResponseEntity<String> response;
        RestTemplate restTemplate = new RestTemplate();

        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", JSON_REQUEST_HEADER_CONTENT_TYPE);
        requestEntity = new HttpEntity(buildRequest(fileName), headers);
        LOG.debug("Making create index to " + FiasConfig.getElasticUrl());
        response = restTemplate.exchange(FiasConfig.getElasticUrl() + "/" + FiasConfig.getElasticDbPrefix() + indexName, HttpMethod.PUT, requestEntity, String.class);
        if (!response.getStatusCode().equals(HttpStatus.OK)) {
            LOG.info("ERROR : {}", response.getBody());
        } else {
            LOG.info("Index {} created", indexName);
        }


    }

    protected static String buildRequest(String fileName) {
        StringBuffer sb = new StringBuffer();
        sb.append(getSettingAnalyzerAutoComplete());
        sb.insert(sb.lastIndexOf("}") - 1, ",");
        sb.insert(sb.lastIndexOf("}") - 1, "\"mappings\":");
//        String requestBody = buildUpdateRequestBody("hunspell/" + fileName);
        String requestBody = buildUpdateRequestBody(fileName);
        if (!isValid(requestBody)) {
            throw new ElasticLoaderException("ERROR : create index elasticsearch. Request body is empty");
        }
        sb.insert(sb.lastIndexOf("}") - 1, requestBody);
        return sb.toString();
    }


    public static boolean existsIndex(String indexName) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response;
        try {
            response = restTemplate.exchange(FiasConfig.getElasticUrl() + "/" + FiasConfig.getElasticDbPrefix() + indexName, HttpMethod.HEAD, null, String.class);
            if (!response.getStatusCode().equals(HttpStatus.OK)) {
                LOG.info("Index {} not exists {}", indexName , FiasConfig.getElasticUrl());
                return false;
            } else {
                return true;
            }
        } catch (Exception e) {
            LOG.error("Cannot exchange existsIndex {}", FiasConfig.getElasticUrl() + "/" + FiasConfig.getElasticDbPrefix() + indexName, e);
        }
        return false;
    }

    public static void deleteIndex(String indexName) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response;
        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        LOG.debug("Making delete index to " + FiasConfig.getElasticUrl());
        try {
            response = restTemplate.exchange(FiasConfig.getElasticUrl() + "/" + FiasConfig.getElasticDbPrefix() + indexName, HttpMethod.DELETE, null, String.class);
            if (!response.getStatusCode().equals(HttpStatus.OK)) {
                LOG.error("ERROR : {}", response.toString());
            } else {
                LOG.info("Index {} deleted", indexName);
            }
        } catch (Exception e) {
            LOG.error("Cannot exchange deleteIndex {}", FiasConfig.getElasticUrl() + "/" + FiasConfig.getElasticDbPrefix() + indexName, e);
        }
    }


    private static String getSettingAnalyzer() {
        return streamToString(DIR_REPOSITORY + "settings/analyzer-setting.json");
    }

    private static String getSettingAnalyzerAutoComplete() {
        return streamToString(DIR_REPOSITORY + "settings/autocomplete-setting.json");
    }


    private static String buildUpdateRequestBody(String fileName) {
        return streamToString(DIR_REPOSITORY + fileName);
    }

    private static String removeFirstAndLast(String value) {
        return (value != null && !value.isEmpty()) ? value.substring(1).substring(0, value.length() - 2) : "";
    }

    private static String streamToString(String filePath) {
        InputStream schemaStream = XmlLoader.class.getClassLoader().getResourceAsStream(filePath);
        byte[] buffer;
        try {
            buffer = new byte[schemaStream.available()];
            schemaStream.read(buffer);
            return new String(buffer, "UTF-8");

        } catch (IOException e) {
            LOG.error(e);
        } finally {
            try {
                schemaStream.close();
            } catch (IOException e) {
                LOG.error(e);
            }
        }

        return null;

    }

    public static void loadToElastic(BasicSlicer loader, List<? extends BasicItem> items, FeedLog feedLog) {
        int count = 0;
        String bulkUrl = FiasConfig.getElasticUrl() + "/_bulk";
        for (BasicItem item : items) {
            count++;
            loader.addItemForCreate(item);
            if (count > LIMIT) {
                LOG.info("Making bulk create index to {}", bulkUrl);
                ElasticBulkClient.save(loader.getRequest(), feedLog);
                count = 0;
                loader.clear();
            }
        }
        if (loader.hasRequest()) {
            ElasticBulkClient.save(loader.getRequest(), feedLog);
        }
    }

    public static void loadForUpdateToElastic(BasicSlicer loader, List<? extends BasicItem> items, FeedLog feedLog, String[] attributes) {
        int count = 0;
        String bulkUrl = FiasConfig.getElasticUrl() + "/_bulk";
        for (BasicItem item : items) {
            count++;
            loader.addItemForUpdate(item, attributes);
            if (count > LIMIT) {
                LOG.info("Making bulk update index to {}", bulkUrl);
                ElasticBulkClient.save(loader.getRequest(), feedLog);
                count = 0;
                loader.clear();
            }
        }
        if (loader.hasRequest()) {
            ElasticBulkClient.save(loader.getRequest(), feedLog);
        }
    }


    public static void save(BulkRequest request, FeedLog feedLog) {
        BulkResponseListener listener = new BulkResponseListener();
        listener.setFeedLog(feedLog);
        RestHighLevelClient client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost(FiasConfig.getElasticHost(), Integer.valueOf(FiasConfig.getElasticPort()), FiasConfig.getElasticProtocol())));
        client.bulkAsync(request, RequestOptions.DEFAULT, listener);

    }

    private static class BulkResponseListener implements ActionListener<BulkResponse> {

        FeedLog feedLog;

        @Override
        public void onResponse(BulkResponse response) {
            try {
                for (BulkItemResponse itemResponse : response.getItems()) {
                    showIndexResponse(itemResponse);
                }
            } catch (Exception e) {
                LOG.error("Cannot showIndexResponse", e);
                onFailure(e);
            }
        }

        private void showIndexResponse(BulkItemResponse bulkItemResponse) {
            String index = bulkItemResponse.getIndex();
            String id = bulkItemResponse.getId();
            if (bulkItemResponse.getResponse() != null) {
                if (bulkItemResponse.getResponse().getResult() == DocWriteResponse.Result.CREATED) {
                    LOG.debug("Index {} created items - OK", index );
                } else if (bulkItemResponse.getResponse().getResult() == DocWriteResponse.Result.UPDATED) {
                    LOG.debug("Index {} updated - OK", index);
                }
                ReplicationResponse.ShardInfo shardInfo = bulkItemResponse.getResponse().getShardInfo();
                if (shardInfo.getTotal() != shardInfo.getSuccessful()) {
                    LOG.info("shardInfo.getTotal() != shardInfo.getSuccessful()");
                }
                if (shardInfo.getFailed() > 0) {
                    for (ReplicationResponse.ShardInfo.Failure failure :
                            shardInfo.getFailures()) {
                        String reason = failure.reason();
                        String errorMessage = "Load fail for index " + index + " Item id: " + id + ", Cause: " + reason;
                        LOG.error(errorMessage);
                        if (Objects.nonNull(feedLog) && !feedLog.getStatus().equals(LoadLogger.getFeedStatuses().get(FeedLogStatuses.ERROR))) {
                            try {
                                feedLog.setStatus(LoadLogger.getFeedStatuses().get(FeedLogStatuses.ERROR));
                                LoadLogger.writeScriptLog(new ScriptResult(errorMessage, -1, errorMessage, new Date().getTime()),
                                        feedLog, true, FeedEventTypes.Executing);
                                LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
                            } catch (SQLException e) {
                                LOG.error("Cannot set load status", e);
                            }
                        }
                    }
                }
            } else {
                String errorMessage = "Load fail for index " + index + " Item id: " + id + ", Cause: " + bulkItemResponse.getFailure();
                LOG.error(errorMessage);
                if (Objects.nonNull(feedLog) && !feedLog.getStatus().equals(LoadLogger.getFeedStatuses().get(FeedLogStatuses.ERROR))) {
                    try {
                        feedLog.setStatus(LoadLogger.getFeedStatuses().get(FeedLogStatuses.ERROR));
                        LoadLogger.writeScriptLog(new ScriptResult(errorMessage, -1, errorMessage, new Date().getTime()),
                                feedLog, true, FeedEventTypes.Executing);
                        LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
                    } catch (SQLException e) {
                        LOG.error("Cannot set load status", e);
                    }

                }
            }

        }

        @Override
        public void onFailure(Exception e) {
            LOG.error("Unexpected exception", e);
        }

        public FeedLog getFeedLog() {
            return feedLog;
        }

        public void setFeedLog(FeedLog feedLog) {
            this.feedLog = feedLog;
        }
    }
}
