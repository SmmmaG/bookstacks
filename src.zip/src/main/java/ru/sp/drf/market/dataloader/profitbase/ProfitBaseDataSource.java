package ru.sp.drf.market.dataloader.profitbase;

import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptExecutor;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.exchange.profitbase.*;
import ru.sp.drf.market.repository.sql.SQLDataSource;
import ru.sp.drf.market.repository.sql.SQLProfitbase;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static ru.sp.drf.market.dataloader.MarketDataSource.getConnection;
import static ru.sp.drf.market.utilities.HelperUtils.isValid;

public class ProfitBaseDataSource extends SQLDataSource implements AtomicOperation {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    private ContextLoader contextLoader = new ContextLoader();

    public ProfitBaseDataSource() throws SQLException {
        super(getConnection());
    }

    @Override
    public ContextLoader getContextLoader() {
        return this.contextLoader;
    }

    public void prepareTables(FeedLog feedLog) throws IOException, SQLException {
        LOG.info("Create temporary tables");
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER);

        ScriptResult resultCreate = scriptExecutor.executeScript(
                "profitbase/create-tables");
        LoadLogger.writeScriptLog(
                resultCreate,
                feedLog,
                false,
                FeedEventTypes.Prep_Temp_tbls);
    }


    public UUID addComplex(ComplexesItem complex) throws SQLException {
        LOG.info("Inserting complex id=" + complex.getComplexId());
        UUID uuid = UUID.randomUUID();
        try (PreparedStatement ps = connection.prepareStatement(SQLProfitbase.addComplex.getSQL())) {
            ps.setObject(1, uuid);
            ps.setString(2, String.valueOf(complex.getComplexId()));
            ps.setString(3, complex.getTitle());
            ps.setString(4, complex.getType());
            ps.setString(5, complex.getRegion());
            ps.setString(6, complex.getDistrict());
            ps.setString(7, complex.getLocality());
            ps.setString(8, complex.getDeveloper());
            ps.setString(9, complex.getDevelopersBrand());
            ps.setString(10, complex.getBanks());
            ps.setString(11, complex.getCurrency());
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted complex id=" + complex.getComplexId() + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Can't INSERT complex " + complex.getComplexId());
            }
        }
    }

    public UUID addHouse(HousesItem house, UUID complexUUId) throws SQLException {
        UUID uuid = UUID.randomUUID();
        try (PreparedStatement ps = connection.prepareStatement(SQLProfitbase.addHouse.getSQL())) {
            ps.setObject(1, uuid);
            ps.setString(2, String.valueOf(house.getHouseId()));
            ps.setString(3, String.valueOf(house.getComplexId()));
            ps.setString(4, house.getName());
            if (isValid(house.getQuarterEnd())) {
                ps.setInt(5, house.getQuarterEnd().getYear());
                ps.setInt(6, house.getQuarterEnd().getQuarter());
            } else {
                ps.setNull(5, Types.INTEGER);
                ps.setNull(6, Types.INTEGER);
            }
            ps.setInt(7, house.getMinFloors());
            ps.setInt(8, house.getMaxFloors());
            ps.setString(9, house.getBuildingNumber());
            if (isValid(house.getAddress())) {
                ps.setString(10, house.getAddress().getFull());
                ps.setString(11, house.getAddress().getLocality());
                ps.setString(12, house.getAddress().getDistrict());
                ps.setString(13, house.getAddress().getRegion());
                ps.setString(14, house.getAddress().getStreet());
                ps.setString(15, house.getAddress().getNumber());
            } else {
                ps.setNull(10, Types.VARCHAR);
                ps.setNull(11, Types.VARCHAR);
                ps.setNull(12, Types.VARCHAR);
                ps.setNull(13, Types.VARCHAR);
                ps.setNull(14, Types.VARCHAR);
                ps.setNull(15, Types.VARCHAR);
            }
            ps.setString(16, house.getHouseType());
            ps.setString(17, house.getFacing());
            ps.setString(18, house.getMaterial());
            ps.setString(19, house.getBuildingState());
            ps.setInt(20, house.getMinPrice());
            ps.setInt(21, house.getMinPriceArea());
            ps.setString(22, house.getImage());
            if (isValid(house.getCurrency())) {
                ps.setString(23, house.getCurrency().getCode());
                ps.setString(24, house.getCurrency().getSymbol());
                ps.setString(25, house.getCurrency().getTitle());
                ps.setString(26, house.getCurrency().getShortName());
                ps.setInt(27, house.getCurrency().getUnicodeSymbol());
            } else {
                ps.setNull(23, Types.VARCHAR);
                ps.setNull(24, Types.VARCHAR);
                ps.setNull(25, Types.VARCHAR);
                ps.setNull(26, Types.VARCHAR);
                ps.setNull(27, Types.INTEGER);

            }
            if (isValid(house.getSalesStart())) {
                ps.setTimestamp(28, new Timestamp(house.getSalesStart().toBeginDate().getTime()));
            } else {
                ps.setNull(28, Types.TIMESTAMP);

            }
            if (isValid(house.getSalesEnd())) {
                ps.setTimestamp(29, new Timestamp(house.getSalesEnd().toEndDate().getTime()));
            } else {
                ps.setNull(29, Types.TIMESTAMP);
            }
            if (isValid(house.getHouseBadges())) {
                HouseBadge houseBadge = house.getHouseBadges().get(0);
                ps.setString(30, houseBadge.getLabel());
                ps.setString(31, houseBadge.getColor());
                ps.setString(32, houseBadge.getIcon());
            } else {
                ps.setNull(30, Types.VARCHAR);
                ps.setNull(31, Types.VARCHAR);
                ps.setNull(32, Types.VARCHAR);
            }
            ps.setObject(33, complexUUId);
            ps.setObject(34, house.getActiveFlatsCount());
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted house id=" + house.getHouseId() + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT house " + house.getHouseId());
            }

        }
    }

    public UUID addAppartment(AppartmentsItem appartment, UUID houseUUId) throws SQLException, ParseException {
        LOG.info("appartments = " + appartment);
        UUID uuid = UUID.randomUUID();
        try (PreparedStatement ps = connection.prepareStatement(SQLProfitbase.addAppartment.getSQL())) {
            ps.setObject(1, uuid);
            ps.setString(2, String.valueOf(appartment.getFlatId()));
            ps.setString(3, String.valueOf(appartment.getHouseId()));
            ps.setString(4, appartment.getComplexName());
            ps.setString(5, appartment.getFlatNumber());
            ps.setInt(6, appartment.getRoomsAmount());
            ps.setInt(7, appartment.getFloor());
            ps.setString(8, appartment.getSectionName());
            ps.setBoolean(9, appartment.isStudio());
            ps.setBoolean(10, appartment.isFreeLayout());
            ps.setString(11, appartment.getPropertyType());
            if (isValid(appartment.getArea())) {
                ps.setObject(12, appartment.getArea().getAreaTotal());
                ps.setObject(13, appartment.getArea().getAreaEstimated());
                ps.setObject(14, appartment.getArea().getAreaLiving());
                ps.setObject(15, appartment.getArea().getAreaKitchen());
                ps.setObject(16, appartment.getArea().getAreaBalcony());
                ps.setObject(17, appartment.getArea().getAreaWithoutBalcony());

            } else {
                ps.setNull(12, Types.DOUBLE);
                ps.setNull(13, Types.DOUBLE);
                ps.setNull(14, Types.DOUBLE);
                ps.setNull(15, Types.DOUBLE);
                ps.setNull(16, Types.DOUBLE);
                ps.setNull(17, Types.DOUBLE);

            }
            ps.setString(18, appartment.getStatus());
            if (isValid(appartment.getSpecialOffersIds()))
                ps.setString(19, appartment.convertSpecialOffersIdstoString());
            else
                ps.setNull(19, Types.VARCHAR);
            ps.setObject(20, houseUUId);
            if (isValid(appartment.getPrice()))
                ps.setObject(21, appartment.getPrice().getValue());
            else
                ps.setNull(21, Types.INTEGER);
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted apartment id=" + appartment.getFlatId() + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT apartment " + appartment.getFlatId());
            }
        }
    }

    private void setupParameter(PreparedStatement statement, int index, Object value, int type) throws SQLException {
        if (isValid(value))
            statement.setObject(index, value, type);
        else
            statement.setNull(index, type);
    }

    public UUID addComplexPhoto(PhotosItem photo, UUID complexId, int complexIntId) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(SQLProfitbase.addComplexPhoto.getSQL())) {
            UUID uuid = UUID.randomUUID();
            ps.setObject(1, uuid);
            ps.setString(2, photo.getUrl());
            ps.setString(3, String.valueOf(complexIntId));
            ps.setObject(4, complexId);
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted complex photo id=" + uuid + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT photo " + uuid);
            }
        }
    }

    public UUID addHousePhoto(PhotosItem photo, UUID houseId, int houseIntId) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(SQLProfitbase.addHousePhoto.getSQL())) {
            UUID uuid = UUID.randomUUID();
            ps.setObject(1, uuid);
            ps.setString(2, photo.getUrl());
            ps.setString(3, String.valueOf(houseIntId));
            ps.setObject(4, houseId);
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted houses photo id=" + uuid + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT photo " + uuid);
            }
        }
    }

    public List<UUID> addApprovedCreditProducts(List<String> approvedCreditProducts, UUID houseUUID, int houseId) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement(SQLProfitbase.addApprovedCreditProduct.getSQL())) {
            ps.setString(3, String.valueOf(houseId));
            ps.setObject(4, houseUUID);
            int productCount = 0;
            List<UUID> productsIds = new ArrayList();
            for (String creditProduct : approvedCreditProducts) {
                UUID uuid = UUID.randomUUID();
                productsIds.add(uuid);
                ps.setObject(1, uuid);
                ps.setString(2, creditProduct);
                productCount += ps.executeUpdate();
            }
            if (productCount == approvedCreditProducts.size()) {
                LOG.info("Inserted approvedCreditProducts " + productsIds + " result=" + productCount);
                return productsIds;
            } else {
                throw new SQLException("Cant INSERT approvedCreditProducts " + approvedCreditProducts);
            }
        }
    }

    public void storeData(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, 1800);
        UUID feedUuid = feedLog.getFeed().getId();
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLProfitbase.getTempComplexCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLProfitbase.getTempBuildCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Build);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLProfitbase.getTempFlatCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/region-insert"), feedLog, true, FeedEventTypes.Add_Regoin);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/city-insert"), feedLog, true, FeedEventTypes.Add_City);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/district-update"), feedLog, true, FeedEventTypes.Upd_District);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/district-insert"), feedLog, true, FeedEventTypes.Add_District);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/developer/contact-developer-update"), feedLog, true, FeedEventTypes.Upd_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/developer/contact-developer-insert"), feedLog, true, FeedEventTypes.Add_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/developer/developer-update"), feedLog, true, FeedEventTypes.Upd_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/developer/developer-insert"), feedLog, true, FeedEventTypes.Add_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/address-complex-update"), feedLog, true, FeedEventTypes.Upd_Cmpx_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/address-complex-insert"), feedLog, true, FeedEventTypes.Add_Cmpx_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/address-building-update"), feedLog, true, FeedEventTypes.Upd_Build_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/address-building-insert"), feedLog, true, FeedEventTypes.Add_Build_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("profitbase/complex/complex-stage-1-tmp-create", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/complex/complex-stage-2-update", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Upd_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/complex/complex-stage-3-insert", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Add_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/complex/complex-stage-4-cross-insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Cmpx_Feed);
        scriptExecutor.executeInsUpd("profitbase/complex/complex-stage-5-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("profitbase/complex/complex-photo-stage-1-tmp-create", new Object[]{feedUuid,feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLProfitbase.updateDocumentPhotoComplex.getSQL()), feedLog, true, FeedEventTypes.Upd_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/complex/complex-photo-stage-2-document-photo-insert"), feedLog, true, FeedEventTypes.Add_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/complex/complex-photo-stage-3-complex-document-photo-insert"), feedLog, true, FeedEventTypes.Asgn_Photo_Cmpx);
        scriptExecutor.executeInsUpd("profitbase/complex/complex-photo-stage-4-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("profitbase/building/building-stage-1-tmp-create", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/building/building-stage-2-update", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/building/building-stage-3-insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/building/building-stage-4-cross-insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Build_Feed);
        scriptExecutor.executeInsUpd("profitbase/building/building-stage-5-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("profitbase/building/building-photo-stage-1-tmp-create", new Object[]{feedUuid,feedUuid}), feedLog, true, FeedEventTypes.Prep_Building_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLProfitbase.updateDocumentPhotoBuilding.getSQL()), feedLog, true, FeedEventTypes.Upd_Photo_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/building/building-photo-stage-2-document-photo-insert"), feedLog, true, FeedEventTypes.Add_Photo_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("profitbase/flat/flat-stage-1-tmp-create", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/flat/flat-stage-2-update", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/flat/flat-stage-3-insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/flat/flat-stage-4-cross-insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Flat_Feed);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/flat/prices-insert"), feedLog, true, FeedEventTypes.Add_Prices);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("profitbase/flat/flat-prices-update", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Upd_Prices);
        scriptExecutor.executeInsUpd("profitbase/flat/flat-stage-5-tmp-drop");
    }

}
