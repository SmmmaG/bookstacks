package ru.sp.drf.market.utilities;

import ru.domrf.rem.domain.admin.Feed;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.domain.admin.FeedLogStatuses;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.UUID;

public class HelperUtils {
    public static boolean isValid(Collection data) {
        return data != null && !data.isEmpty();
    }

    public static boolean isValid(Object[] data) {
        return data != null && data.length > 0;
    }

    public static boolean isValid(Object data) {
        return data != null;
    }

    public static String formatName(String name) {
        if (name == null)
            return null;
        return name.replaceAll("(?:\\n|\\r)", " ").replaceAll("\"", "'");
    }

    public static String getValue(String value) {
        return value != null ? value : "";
    }

    public static String getValue(Integer value) {
        return value != null ? String.valueOf(value) : "";
    }

    public static String getValue(UUID value) {
        return value != null ? value.toString() : "";
    }

    public static boolean isInStatus(Feed feed, FeedLogStatuses status) {
        return isValid(feed.getStatus()) &&
                feed.getStatus().getCode().equalsIgnoreCase(status.getStatus());
    }

    public static boolean canRunFeed(Feed feed) {
        if (isValid(feed.getUploadDate()) &&
                isInStatus(feed, FeedLogStatuses.OK) &&
                isValid(feed.getFrequency())) {
            Calendar cl = Calendar.getInstance();
            cl.setTime(feed.getUploadDate());
            cl.add(Calendar.DAY_OF_MONTH, feed.getFrequency());
            Date currentDate = new Date();
            return cl.getTime().getTime() < currentDate.getTime();
        }
        return true;
    }

}
