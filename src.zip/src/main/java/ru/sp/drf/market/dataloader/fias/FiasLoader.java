package ru.sp.drf.market.dataloader.fias;

import ru.domrf.rem.domain.admin.FeedLogStatuses;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.FeedLoader;
import ru.sp.drf.market.config.loaders.FiasConfig;
import ru.sp.drf.market.exception.DownloadFeedException;
import ru.sp.drf.market.exception.FeedException;
import ru.sp.drf.market.repository.FiasAddressObjectRepository;
import ru.sp.drf.market.utilities.BigFileChunkReader;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

import static ru.sp.drf.market.dataloader.MarketDataSource.getConnection;
import static ru.sp.drf.market.config.loaders.FiasConfig.BUFF_SIZE;
import static ru.sp.drf.market.config.loaders.FiasConfig.FEED_FIAS_DELTA;
import static ru.sp.drf.market.config.loaders.FiasConfig.FEED_FIAS_MAIN;
import static ru.sp.drf.market.config.loaders.FiasConfig.FIAS_DOWNLOADS_TMP_DIR;
import static ru.sp.drf.market.config.loaders.FiasConfig.OBJECTS_FILE;
import static ru.sp.drf.market.config.loaders.FiasConfig.OBJECT_TAG_START;
import static ru.sp.drf.market.config.loaders.FiasConfig.PARTS_COUNT;
import static ru.sp.drf.market.config.loaders.FiasConfig.TAG_STOP;
import static ru.sp.drf.market.utilities.HelperUtils.isValid;


public class FiasLoader extends FeedLoader {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private FiasAddressObjectRepository repository;

    public FiasLoader(FiasAddressObjectRepository repository) {
        this.repository = repository;
    }


    public boolean isServerReachable(String url) {
        try {
            URL urlServer = new URL(url);
            HttpURLConnection urlConn = (HttpURLConnection) urlServer.openConnection();
            urlConn.setConnectTimeout(3000); //<- 3Seconds Timeout
            urlConn.connect();
            if (urlConn.getResponseCode() == 200) {
                return true;
            } else {
                LOG.warn("The address {} is not accessible", url);
                return false;
            }
        } catch (MalformedURLException e1) {
            LOG.warn("The address {} is not accessible", url, e1);
            return false;
        } catch (IOException e) {
            LOG.error("Unexpected exception for url {}", url, e);
            return false;
        }
    }

    @Override
    protected boolean executeTasks() throws Exception {
        //todo comment by test mode
        operation.setAutoCommit(true);

        onPrepare(); //does nothing
        onDownload(); // download file and split if needed
        onParse(); // parse xml files and add to elastic
        onLoad(); // load fias address objects
        return true;
    }


    @Override
    protected void executeDisableTasks() throws Exception {
    }

    @Override
    public void onPrepare() throws Exception {
        LOG.info("on schema clear ");
        operation.prepareTables(feedLog);
    }


    public void onDownload() throws FeedException {
        LOG.info("Starting downloading...");
        try {

            String fiasUrl = findWorkingUrl();
            if (fiasUrl == null) {
                LOG.error("Cannot determine what to download!");
                xmlFile = null;
                return;
            }

            File archiveFromFIAS;
            String downloadDir = FiasConfig.getDataPath() + "/" + FIAS_DOWNLOADS_TMP_DIR;
            File dir = new File(downloadDir);

// for test procedure
            if (FiasConfig.getDownLoadedFile() != null && !FiasConfig.getDownLoadedFile().isEmpty()) {
                archiveFromFIAS = new File(downloadDir + "/" + FiasConfig.getDownLoadedFile());
                if (dir.listFiles() != null && dir.listFiles().length == 1) {
                    unrar(archiveFromFIAS);
                }
                xmlFile = getFileForProcessing(archiveFromFIAS);
                LOG.info("Extracted " + xmlFile.getName());
                LOG.info("Finish downloading...");
            } else {
// clear tmp dir
                if (dir.exists())
                    clearDir(dir);
                dir.mkdir();
                archiveFromFIAS = readFromURL("objects", ".rar", fiasUrl, FIAS_DOWNLOADS_TMP_DIR);
                if (archiveFromFIAS != null) {
                    if (unrar(archiveFromFIAS)) {
                        xmlFile = getFileForProcessing(archiveFromFIAS);
                        if (xmlFile != null) {
                            LOG.info("Extracted " + xmlFile.getName());
                            LOG.info("Finish downloading...");
                        } else {
                            LOG.error("File doesn't unpacked: " + archiveFromFIAS.getName());
                            LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
                        }
                    }
                } else {
                    LOG.error("File doesn't received: " + fiasUrl);
                    LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
                    xmlFile = null;
                }
            }
        } catch (Exception e) {
            xmlFile = null;
            try {
                LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
            } catch (SQLException e1) {
                LOG.error("Unexpected exception", e1);
            }
        }
    }

    private File getFileForProcessing(File file) {
        String unpackageDir = file.getParent();
        File dir = new File(unpackageDir);
        File[] filesList = dir.listFiles(pathname -> !pathname.isDirectory() &&
                pathname.getName().toLowerCase().endsWith(".xml") &&
                pathname.getName().toLowerCase().startsWith(OBJECTS_FILE));
        if (filesList != null && filesList.length > 0) {
            return filesList[0];
        }
        return null;
    }

    private boolean clearDir(File file) {

        File[] flist = null;

        if (file == null) {
            return false;
        }

        if (file.isFile()) {
            return file.delete();
        }

        if (!file.isDirectory()) {
            return false;
        }

        flist = file.listFiles();
        if (isValid(flist)) {
            for (File f : flist) {
                if (!clearDir(f)) {
                    return false;
                }
            }
        }

        return file.delete();
    }

    private String findWorkingUrl() {

        SimpleDateFormat format = new SimpleDateFormat("YYYYMMdd");
        LocalDate now = LocalDate.now();
        LocalDate lastDay = LocalDate.now();
        String file = null;
        switch (feedLog.getFeed().getCode()) {
            case FEED_FIAS_MAIN:
                file = FiasConfig.getMainFile();
                break;
            case FEED_FIAS_DELTA:
                if (FiasConfig.isLoadDelta())
                    file = FiasConfig.getDeltaFile();
                break;
        }
        if (file != null) {
            do {
                String urlStr = getFiasUrl() +
                        format.format(
                                Date.from(
                                        lastDay.atStartOfDay().
                                                atZone(ZoneId.systemDefault())
                                                .toInstant()
                                )
                        ) + "/" + file;

                try {
                    if (isServerReachable(urlStr)) {
                        return urlStr;
                    }
                } catch (Exception e) {
                    return null;
                }
                lastDay = lastDay.minusDays(1);
                // no file found in last three months - something really wrong
            } while (!now.minusMonths(3).isAfter(lastDay));
        }
        return null;
    }


    @Override
    public void onParse() throws FeedException {

        // read db table and store data to ElasticSearch
        if (this.xmlFile == null) {
            URL url = null;
            try {
                url = new URL(feedLog.getFeed().getUrl());
                LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
            } catch (Exception e) {
                LOG.error("Unexpected exception", e);
            }
            throw new DownloadFeedException("Error download file by url: " + url);
        }
        try {
            List<File> files = Collections.singletonList(xmlFile);
            boolean isMainFeed = feedLog.getFeed().getCode().equalsIgnoreCase(FEED_FIAS_MAIN);
            if (isMainFeed) { // in case of loading really big file - split it
                LOG.info("File too big to process - need to split it.");
                final long partSize = xmlFile.length() / PARTS_COUNT;
                files = splitFile(xmlFile, partSize);
                LOG.info("Split process completed.");
            }
            int id = 1;
            for (File f : files) {
                XmlLoader loader = new XmlLoader();
                loader.registerBulkStoreListener(new BulkStoreListener() {
                    @Override
                    public void onStore(StoreEvent event) {
                        storeAddresses(event.getScript());
                    }
                });
                loader.execute(f);
            }

        } catch (Exception e) {
            LOG.error("Unexpected exception", e);
        }
    }


    private boolean storeAddresses(final String script) {
        try {
            if (script != null) {
                new Thread(() -> {
                    try {
                        operation.storeData(feedLog, script);
                    } catch (Exception e) {
                        LOG.error("Error execute script", e);
                    }
                }).start();
            }


        } catch (Exception e) {
            LOG.error("Error load fias feed by url: " + feedLog.getFeed().getUrl(), e);
        }
        return false;
    }


    @Override
    public void onLoad() throws Exception {
        LOG.info("onLoad feedLog: " + feedLog);
        operation.storeData(feedLog);
    }


    @Override
    public void onAfter() {
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void initConnection() throws Exception {
        operation = new FiasDataSource(getConnection(), repository);
    }

    @Override
    public void onValidate() {
    }


    private List<File> splitFile(File file, final long partSize) throws IOException {
        List<File> result = new ArrayList<>();
        BigFileChunkReader reader = new BigFileChunkReader(file, BUFF_SIZE);
        int count = 1;
        long size = 0;
        String chunk = "";
        String fileName = file.getAbsolutePath();
        File f = new File(fileName + "." + count);
        result.add(f);
        int parseableChunkStart;
        int parseableChunkStop;

        BufferedWriter writer = new BufferedWriter(new FileWriter(f));
        while (reader.hasNextChunk()) {
            chunk = chunk.concat(reader.getNextChunk());
            parseableChunkStart = chunk.indexOf(OBJECT_TAG_START);
            parseableChunkStop = chunk.lastIndexOf(TAG_STOP) + 2;
            String parseableChunk = chunk.substring(parseableChunkStart, parseableChunkStop);
            chunk = chunk.substring(parseableChunkStop);
            size += parseableChunk.length();
            writer.write(parseableChunk);
            if (size >= partSize) {
                writer.close();
                size = 0;
                count++;
                f = new File(fileName + "." + count);
                result.add(f);
                writer = new BufferedWriter(new FileWriter(f));
            }
        }
        writer.close();
        return result;
    }

    private boolean unrar(File archiveFromFIAS) {
        LOG.info("Start extracting file from archive...");
        Process process = null;
        try {
            String[] env = {};
            process = Runtime.getRuntime().exec("rar e -y " + archiveFromFIAS.getAbsolutePath(), env, archiveFromFIAS.getParentFile());
            LOG.info(getProcessInfo(process));
            if (process.getErrorStream() != null) {
                LOG.error(getProcessError(process));
            }
            int exitCode = process.waitFor();

            if (exitCode != 0) {
                LOG.error(getProcessError(process));
            } else {
                LOG.info("Finish extracting file from archive...");
                return true;
            }

        } catch (Exception e) {
            LOG.error("Error while unpacking archive: " + e.getMessage());
        } finally {
            if (Objects.nonNull(process))
                process.destroy();
        }
        LOG.error("Expected .xml file was not found");
        return false;
    }

    private String getProcessError(Process process) {
        if (process.getErrorStream() != null) {
            try (Scanner scanner = new Scanner(process.getErrorStream(), StandardCharsets.UTF_8.name())) {
                if (scanner.useDelimiter("\\A").hasNext())
                    return scanner.useDelimiter("\\A").next();
            } catch (Exception e) {
                LOG.error("Unexpected exception", e);
            }
        }
        return "Error description not exist";
    }

    private String getProcessInfo(Process process) {
        if (process.getInputStream() != null) {
            try (Scanner scanner = new Scanner(process.getInputStream(), StandardCharsets.UTF_8.name())) {
                if (scanner.useDelimiter("\\A").hasNext())
                    return scanner.useDelimiter("\\A").next();
            } catch (Exception e) {
                LOG.error("Unexpected exception", e);
            }
        }
        return "Info description not exist";
    }

    private String getFiasUrl() {
        return (feedLog.getFeed().getUrl() != null) ? feedLog.getFeed().getUrl() : FiasConfig.getFiasUrl();
    }

}
