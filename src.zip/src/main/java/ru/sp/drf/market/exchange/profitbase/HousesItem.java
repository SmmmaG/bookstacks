package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import ru.sp.drf.market.exchange.QuarterDeadline;

import javax.annotation.Generated;
import java.util.*;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class HousesItem extends Storable<ComplexesItem, UUID> {


    @JsonProperty("id")
    private int houseId;

    @JsonProperty("projectId")
    private int complexId;

    @JsonProperty("projectName")
    private String complexName;

    @JsonProperty("title")
    private String name;

    @JsonProperty("developmentStartQuarter")
    private QuarterDeadline quarterStart;
    @JsonProperty("developmentEndQuarter")
    private QuarterDeadline quarterEnd;

    @JsonProperty("minFloors")
    private int minFloors;
    @JsonProperty("maxFloors")
    private int maxFloors;


    @JsonProperty("number")
    private String buildingNumber;

/*
    @JsonProperty("coords")
    private Coords coords;
*/

    @JsonProperty("address")
    private AddressLoc address;

    @JsonProperty("type")
    private String houseType;

    @JsonProperty("facing")
    private String facing;

    @JsonProperty("material")
    private String material;

    @JsonProperty("buildingState")
    private String buildingState;

    @JsonProperty("minPrice")
    private int minPrice;
    @JsonProperty("minPriceArea")
    private int minPriceArea;

    @JsonProperty("image")
    private String image;

    @JsonProperty("currency")
    private Currency currency;

    @JsonProperty("salesStart")
    private QuarterDeadline salesStart;

    @JsonProperty("salesEnd")
    private QuarterDeadline salesEnd;

    @JsonProperty("houseBadges")
    private List<HouseBadge> houseBadges;

    @JsonProperty("propertyCount")
    private int activeFlatsCount;

    @JsonIgnore
    private UUID houseUUId;

    public int getHouseId() {
        return houseId;
    }

    public void setHouseId(int houseId) {
        this.houseId = houseId;
    }

    public int getComplexId() {
        return complexId;
    }

    public void setComplexId(int complexId) {
        this.complexId = complexId;
    }

    public String getComplexName() {
        return complexName;
    }

    public void setComplexName(String complexName) {
        this.complexName = complexName;
    }

    public QuarterDeadline getQuarterStart() {
        return quarterStart;
    }

    public void setQuarterStart(QuarterDeadline quarterStart) {
        this.quarterStart = quarterStart;
    }

    public QuarterDeadline getQuarterEnd() {
        return quarterEnd;
    }

    public void setQuarterEnd(QuarterDeadline quarterEnd) {
        this.quarterEnd = quarterEnd;
    }

    public int getMinFloors() {
        return minFloors;
    }

    public void setMinFloors(int minFloors) {
        this.minFloors = minFloors;
    }

    public int getMaxFloors() {
        return maxFloors;
    }

    public void setMaxFloors(int maxFloors) {
        this.maxFloors = maxFloors;
    }

    public String getBuildingNumber() {
        return buildingNumber;
    }

    public void setBuildingNumber(String buildingNumber) {
        this.buildingNumber = buildingNumber;
    }

    public AddressLoc getAddress() {
        return address;
    }

    public void setAddress(AddressLoc address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHouseType() {
        return houseType;
    }

    public void setHouseType(String houseType) {
        this.houseType = houseType;
    }

    public String getFacing() {
        return facing;
    }

    public void setFacing(String facing) {
        this.facing = facing;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getBuildingState() {
        return buildingState;
    }

    public void setBuildingState(String buildingState) {
        this.buildingState = buildingState;
    }

    public int getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(int minPrice) {
        this.minPrice = minPrice;
    }

    public int getMinPriceArea() {
        return minPriceArea;
    }

    public void setMinPriceArea(int minPriceArea) {
        this.minPriceArea = minPriceArea;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public QuarterDeadline getSalesStart() {
        return salesStart;
    }

    public void setSalesStart(QuarterDeadline salesStart) {
        this.salesStart = salesStart;
    }

    public QuarterDeadline getSalesEnd() {
        return salesEnd;
    }

    public void setSalesEnd(QuarterDeadline salesEnd) {
        this.salesEnd = salesEnd;
    }

    public List<HouseBadge> getHouseBadges() {
        return houseBadges;
    }

    public void setHouseBadges(List<HouseBadge> houseBadges) {
        this.houseBadges = houseBadges;
    }

    public UUID getHouseUUId() {
        return houseUUId;
    }

    public void setHouseUUId(UUID houseUUId) {
        this.houseUUId = houseUUId;
    }

    public void setActiveFlatsCount(int activeFlatsCount) {
        this.activeFlatsCount = activeFlatsCount;
    }

    public int getActiveFlatsCount() {
        return activeFlatsCount;
    }


    @Override
    public UUID save(ComplexesItem complexesItem, AtomicOperation operation) throws Exception {
        UUID houseUUId = operation.addHouse(this, complexesItem.getComplexUUId());
        if (complexesItem.getBanks() != null && !complexesItem.getBanks().isEmpty()) {
            operation.addApprovedCreditProducts(Arrays.asList(complexesItem.getBanks().split(",")), houseUUId, houseId);
        }
        if (this.image != null && !this.image.isEmpty()) {
            PhotosItem photo = new PhotosItem();
            photo.setUrl(image);
            operation.addComplexPhoto(photo, complexesItem.getComplexUUId(), complexesItem.getComplexId());
            operation.addHousePhoto(photo, houseUUId, houseId);

        }
        this.setHouseUUId(houseUUId);
        return houseUUId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HousesItem)) return false;
        HousesItem that = (HousesItem) o;
        return houseId == that.houseId &&
                complexId == that.complexId &&
                complexName == that.complexName &&
                minFloors == that.minFloors &&
                maxFloors == that.maxFloors &&
                minPrice == that.minPrice &&
                minPriceArea == that.minPriceArea &&
                activeFlatsCount == that.activeFlatsCount &&
                Objects.equals(name, that.name) &&
                Objects.equals(quarterStart, that.quarterStart) &&
                Objects.equals(quarterEnd, that.quarterEnd) &&
                Objects.equals(buildingNumber, that.buildingNumber) &&
                Objects.equals(address, that.address) &&
                Objects.equals(houseType, that.houseType) &&
                Objects.equals(facing, that.facing) &&
                Objects.equals(material, that.material) &&
                Objects.equals(buildingState, that.buildingState) &&
                Objects.equals(image, that.image) &&
                Objects.equals(currency, that.currency) &&
                Objects.equals(salesStart, that.salesStart) &&
                Objects.equals(salesEnd, that.salesEnd) &&
                Objects.equals(houseBadges, that.houseBadges) &&
                Objects.equals(houseUUId, that.houseUUId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(houseId, complexId, complexName, name, quarterStart, quarterEnd, minFloors, maxFloors, buildingNumber, address, houseType, facing, material, buildingState, minPrice, minPriceArea, image, currency, salesStart, salesEnd, houseBadges, activeFlatsCount, houseUUId);
    }

    @Override
    public String toString() {
        return "HousesItem{" +
                "houseId=" + houseId +
                ", complexId=" + complexId +
                ", complexName=" + complexName +
                ", name='" + name + '\'' +
                ", quarterStart=" + quarterStart +
                ", quarterEnd=" + quarterEnd +
                ", minFloors=" + minFloors +
                ", maxFloors=" + maxFloors +
                ", buildingNumber='" + buildingNumber + '\'' +
                ", address=" + address +
                ", houseType='" + houseType + '\'' +
                ", facing='" + facing + '\'' +
                ", material='" + material + '\'' +
                ", buildingState='" + buildingState + '\'' +
                ", minPrice=" + minPrice +
                ", minPriceArea=" + minPriceArea +
                ", image='" + image + '\'' +
                ", currency=" + currency +
                ", salesStart=" + salesStart +
                ", salesEnd=" + salesEnd +
                ", houseBadges=" + houseBadges +
                ", activeFlatsCount=" + activeFlatsCount +
                ", houseUUId=" + houseUUId +
                '}';
    }
}