package ru.sp.drf.market.service;

import org.springframework.stereotype.Service;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.sp.drf.market.dataloader.MarketDataSource;
import ru.sp.drf.market.repository.FeedLogRepository;
import ru.sp.drf.market.repository.sql.SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@Service
public class FeedLogService {


    private final FeedLogRepository repository;

    public FeedLogService(FeedLogRepository repository) {
        this.repository = repository;
    }

    public FeedLog save (FeedLog log){
        return repository.save(log);
    }

    public void delete (FeedLog log){
        repository.delete(log);
    }

    public void setExpiredFeedLogsAsError() throws SQLException {
        try (Connection conn = MarketDataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL.setExpiredFeedLogsAsError.getSQL())){
            ps.executeUpdate();
        }
    }
}
