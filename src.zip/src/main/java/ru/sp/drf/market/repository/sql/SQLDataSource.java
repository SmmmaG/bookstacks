package ru.sp.drf.market.repository.sql;

import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.LoggedClass;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptExecutor;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.UUID;

public abstract class SQLDataSource {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    protected Connection connection;
    private String schemaName;

    public SQLDataSource(Connection connection) {
        this.connection = connection;
        this.schemaName = null;
    }

    public SQLDataSource(final Connection connection, final String schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
    }

    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    public abstract void prepareTables(FeedLog feedLog) throws Exception;

    public abstract void storeData(FeedLog feedLog) throws Exception;

    public void storeData(FeedLog feedLog, String script) throws Exception {
        LOG.debug("Start execute script");
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, schemaName);
        ScriptResult result = scriptExecutor.executeDirectScript(script);
        LOG.debug("Finish execute script");
    }

    public void disableData(FeedLog feedLog) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, schemaName);
        UUID feedUuid = feedLog.getFeed().getId();
        ScriptResult result = scriptExecutor.executeScript("before-load",
                new Object[]{feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Del_Old_Feed_Data);
    }

    public void recalculation(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, schemaName);
        UUID feedUuid = feedLog.getFeed().getId();
        //  STATISTIC RECALCULATION
        ScriptResult result = scriptExecutor.executeScript("statistic-recalculate",
                new Object[]{feedUuid, feedUuid, feedUuid, feedUuid});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.RecalculationStatistics);
        //  RECALCULATE COMPLEX GEOMETRY
        result = scriptExecutor.executeInsUpd("complex geometry calculate", new Object[]{feedUuid});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Recalculation_Cmpx_Geom);
        //  DISTRICTS REORGANIZATION
        result = scriptExecutor.executeScript("district reorganization");
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Recalculation_District);
        //  DISABLE INACTIVE IMAGES
        result = scriptExecutor.executeQuery(SQL.setDisableInactivePhotos.getSQL());
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Disbl_Inactive_Photo);
        //  UPDATE COMPLEX HAS PHOTO FLAG
        scriptExecutor.executeScript("update-has-photo-flag", new Object[]{feedUuid, feedUuid});
    }


    public void commit() throws SQLException {
        if (this.connection != null)
            this.connection.commit();

    }

    public void setAutoCommit(boolean flag) throws SQLException {
        if (this.connection != null)
            this.connection.setAutoCommit(flag);

    }

    public void rollback() throws SQLException {
        if (this.connection != null)
            this.connection.rollback();

    }

    public void close() throws SQLException {
        if (this.connection != null)
            this.connection.close();

    }
}
