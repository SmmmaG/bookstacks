package ru.sp.drf.market.exchange.profitbase;

public abstract class Storable<PARENT, ENTITY> {
    abstract ENTITY save(PARENT parent, AtomicOperation dataSourse) throws Exception;
}
