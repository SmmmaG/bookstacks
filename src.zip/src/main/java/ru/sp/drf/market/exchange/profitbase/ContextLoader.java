package ru.sp.drf.market.exchange.profitbase;

import java.util.HashMap;
import java.util.Map;

public class ContextLoader {


    private Map<Integer, ComplexesItem> complexCache = new HashMap<>();
    private Map<Integer, HousesItem> houseCache = new HashMap<>();

    public void putComplex(Integer id, ComplexesItem item) {
        complexCache.put(id, item);
    }

    public void putHouse(Integer id, HousesItem item) {
        houseCache.put(id, item);
    }

    public HousesItem getHouseById(Integer key) {
        return houseCache.get(key);
    }

    public ComplexesItem getComplexById(Integer key) {
        return complexCache.get(key);
    }
}
