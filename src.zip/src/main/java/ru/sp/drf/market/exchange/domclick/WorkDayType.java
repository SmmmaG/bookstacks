
package ru.sp.drf.market.exchange.domclick;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for work_dayType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="work_dayType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="day">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="пн"/>
 *               &lt;enumeration value="вт"/>
 *               &lt;enumeration value="ср"/>
 *               &lt;enumeration value="чт"/>
 *               &lt;enumeration value="пт"/>
 *               &lt;enumeration value="сб"/>
 *               &lt;enumeration value="вс"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="open_at">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="09:00"/>
 *               &lt;enumeration value="9:00 "/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="close_at">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="21:00"/>
 *               &lt;enumeration value=" 21:00"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "work_dayType", propOrder = {
    "day",
    "openAt",
    "closeAt"
})
public class WorkDayType {

    @XmlElement(required = true)
    protected String day;
    @XmlElement(name = "open_at", required = true)
    protected String openAt;
    @XmlElement(name = "close_at", required = true)
    protected String closeAt;

    /**
     * Gets the value of the day property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDay() {
        return day;
    }

    /**
     * Sets the value of the day property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDay(String value) {
        this.day = value;
    }

    /**
     * Gets the value of the openAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpenAt() {
        return openAt;
    }

    /**
     * Sets the value of the openAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpenAt(String value) {
        this.openAt = value;
    }

    /**
     * Gets the value of the closeAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCloseAt() {
        return closeAt;
    }

    /**
     * Sets the value of the closeAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCloseAt(String value) {
        this.closeAt = value;
    }

}
