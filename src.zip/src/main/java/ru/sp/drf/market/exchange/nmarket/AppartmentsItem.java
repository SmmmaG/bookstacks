package ru.sp.drf.market.exchange.nmarket;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
public class AppartmentsItem extends Storable<Object,UUID>{

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

	@JsonProperty("rooms")
	private String rooms;

	@JsonProperty("houseId")
	private int houseId;

	@JsonProperty("appNumber")
	private String appNumber;

	@JsonProperty("datePriceUpdate")
	private String datePriceUpdate;

	@JsonProperty("widgetId")
	private String widgetId;

	@JsonProperty("sLiving")
	private double sLiving;

	@JsonProperty("sKitchen")
	private double sKitchen;

	@JsonProperty("planUrl")
	private String planUrl;

	@JsonProperty("section")
	private String section;

	@JsonProperty("type")
	private String type;

	@JsonProperty("wc")
	private String wc;

	@JsonProperty("balcony")
	private String balcony;

	@JsonProperty("baseAmount")
	private int baseAmount;

	@JsonProperty("amountUnit")
	private String amountUnit;

	@JsonProperty("objectType")
	private int objectType;

	@JsonProperty("sRooms")
	private String sRooms;

	@JsonProperty("ceilingHeight")
	private double ceilingHeight;

	@JsonProperty("minimalAmount")
	private int minimalAmount;

	@JsonProperty("id")
	private int id;

	@JsonProperty("sAll")
	private double sAll;

	@JsonProperty("floor")
	private String floor;

	@JsonProperty("sellerType")
	private String sellerType;

	@JsonProperty("decoration")
	private String decoration;

	@JsonProperty("status")
	private String status;

	public void setRooms(String rooms){
		this.rooms = rooms;
	}

	public String getRooms(){
		return rooms;
	}

	public void setHouseId(int houseId){
		this.houseId = houseId;
	}

	public int getHouseId(){
		return houseId;
	}

	public void setAppNumber(String appNumber){
		this.appNumber = appNumber;
	}

	public String getAppNumber(){
		return appNumber;
	}

	public void setDatePriceUpdate(String datePriceUpdate){
		this.datePriceUpdate = datePriceUpdate;
	}

	public String getDatePriceUpdate(){
		return datePriceUpdate;
	}

	public void setWidgetId(String widgetId){
		this.widgetId = widgetId;
	}

	public String getWidgetId(){
		return widgetId;
	}

	public void setSLiving(double sLiving){
		this.sLiving = sLiving;
	}

	public double getSLiving(){
		return sLiving;
	}

	public void setSKitchen(double sKitchen){
		this.sKitchen = sKitchen;
	}

	public double getSKitchen(){
		return sKitchen;
	}

	public void setPlanUrl(String planUrl){
		this.planUrl = planUrl;
	}

	public String getPlanUrl(){
		return planUrl;
	}

	public void setSection(String section){
		this.section = section;
	}

	public String getSection(){
		return section;
	}

	public void setType(String type){
		this.type = type;
	}

	public String getType(){
		return type;
	}

	public void setWc(String wc){
		this.wc = wc;
	}

	public String getWc(){
		return wc;
	}

	public void setBalcony(String balcony){
		this.balcony = balcony;
	}

	public String getBalcony(){
		return balcony;
	}

	public void setBaseAmount(int baseAmount){
		this.baseAmount = baseAmount;
	}

	public int getBaseAmount(){
		return baseAmount;
	}

	public void setAmountUnit(String amountUnit){
		this.amountUnit = amountUnit;
	}

	public String getAmountUnit(){
		return amountUnit;
	}

	public void setObjectType(int objectType){
		this.objectType = objectType;
	}

	public int getObjectType(){
		return objectType;
	}

	public void setSRooms(String sRooms){
		this.sRooms = sRooms;
	}

	public String getSRooms(){
		return sRooms;
	}

	public void setCeilingHeight(double ceilingHeight){
		this.ceilingHeight = ceilingHeight;
	}

	public double getCeilingHeight(){
		return ceilingHeight;
	}

	public void setMinimalAmount(int minimalAmount){
		this.minimalAmount = minimalAmount;
	}

	public int getMinimalAmount(){
		return minimalAmount;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public void setSAll(double sAll){
		this.sAll = sAll;
	}

	public double getSAll(){
		return sAll;
	}

	public void setFloor(String floor){
		this.floor = floor;
	}

	public String getFloor(){
		return floor;
	}

	public void setSellerType(String sellerType){
		this.sellerType = sellerType;
	}

	public String getSellerType(){
		return sellerType;
	}

	public void setDecoration(String decoration){
		this.decoration = decoration;
	}

	public String getDecoration(){
		return decoration;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getStatus(){
		return status;
	}

	public Timestamp getDatePriceUpdateStamp() throws ParseException {
		String date = datePriceUpdate;
		if (datePriceUpdate.length()==19){
			datePriceUpdate=datePriceUpdate+".000";
		}
		return new Timestamp(sdf.parse(datePriceUpdate).getTime());
	}

	@Override
	public UUID save(Object parent, AtomicOperation dataSourse) throws Exception {
		UUID appartmentId = dataSourse.addAppartment(this);
		return appartmentId;
	}

	@Override
 	public String toString(){
		return 
			"AppartmentsItem{" + 
			"rooms = '" + rooms + '\'' + 
			",houseId = '" + houseId + '\'' + 
			",appNumber = '" + appNumber + '\'' + 
			",datePriceUpdate = '" + datePriceUpdate + '\'' + 
			",widgetId = '" + widgetId + '\'' + 
			",sLiving = '" + sLiving + '\'' + 
			",sKitchen = '" + sKitchen + '\'' + 
			",planUrl = '" + planUrl + '\'' + 
			",section = '" + section + '\'' + 
			",type = '" + type + '\'' + 
			",wc = '" + wc + '\'' + 
			",balcony = '" + balcony + '\'' + 
			",baseAmount = '" + baseAmount + '\'' + 
			",amountUnit = '" + amountUnit + '\'' + 
			",objectType = '" + objectType + '\'' + 
			",sRooms = '" + sRooms + '\'' + 
			",ceilingHeight = '" + ceilingHeight + '\'' + 
			",minimalAmount = '" + minimalAmount + '\'' + 
			",id = '" + id + '\'' + 
			",sAll = '" + sAll + '\'' + 
			",floor = '" + floor + '\'' + 
			",sellerType = '" + sellerType + '\'' + 
			",decoration = '" + decoration + '\'' + 
			",status = '" + status + '\'' + 
			"}";
		}
}