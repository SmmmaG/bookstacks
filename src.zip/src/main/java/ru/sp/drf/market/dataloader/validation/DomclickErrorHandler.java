package ru.sp.drf.market.dataloader.validation;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.FileLoader;
import ru.sp.drf.market.dto.validation.ValidationStatisticsDto;

import java.io.File;
import java.io.IOException;

@Component
public class DomclickErrorHandler extends ErrorHandler {

    public DomclickErrorHandler() {
    }

    public DomclickErrorHandler(FeedLog feedLog, File file) {
        super(feedLog,file);
    }

    @Override
    public ValidationStatisticsDto countStatistics () throws IOException {
        ValidationStatisticsDto statistics  = new ValidationStatisticsDto();
        String fullFeed = FileLoader.getFullFeed(file);
        statistics.setFlatsCount(StringUtils.countMatches(fullFeed, "<flat>"));
        statistics.setBuildingsCount(StringUtils.countMatches(fullFeed, "<building>"));
        statistics.setComplexesCount(StringUtils.countMatches(fullFeed, "<complex>"));
        return statistics;
    }
}
