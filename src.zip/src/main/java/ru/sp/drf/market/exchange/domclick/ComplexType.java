
package ru.sp.drf.market.exchange.domclick;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for complexType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="complexType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="108347"/>
 *               &lt;enumeration value="108344"/>
 *               &lt;enumeration value="110394"/>
 *               &lt;enumeration value="110619"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="name">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="ЖК "ВавиловДОМ""/>
 *               &lt;enumeration value="ЖК "Фестиваль Парк""/>
 *               &lt;enumeration value="ЖК Квартал на Никулинской"/>
 *               &lt;enumeration value="ЖК FoRest"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="latitude" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="longitude" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="address">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="город Москва Вавилова улица"/>
 *               &lt;enumeration value="город Москва 2Г микрорайон"/>
 *               &lt;enumeration value="город Москва Никулинская, мкр. 2А улица"/>
 *               &lt;enumeration value="город Москва Чоботовская улица"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="buildings" type="{}buildingsType"/>
 *         &lt;element name="sales_info" type="{}sales_infoType"/>
 *         &lt;element name="description_main" type="{}description_mainType"/>
 *         &lt;element name="profits_main" type="{}profits_mainType"/>
 *         &lt;element name="developer" type="{}developerType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "complexType", propOrder = {
    "id",
    "name",
    "latitude",
    "longitude",
    "address",
    "buildings",
    "salesInfo",
    "descriptionMain",
    "profitsMain",
    "developer"
})
public class ComplexType {

    @XmlElement(required = true)
    protected String id;
    @XmlElement(required = true)
    protected String name;
    @XmlElement(required = true)
    protected String latitude;
    @XmlElement(required = true)
    protected String longitude;
    @XmlElement(required = true)
    protected String address;
    @XmlElement(required = true)
    protected BuildingsType buildings;
    @XmlElement(name = "sales_info", required = true)
    protected SalesInfoType salesInfo;
    @XmlElement(name = "description_main", required = true)
    protected DescriptionMainType descriptionMain;
    @XmlElement(name = "profits_main", required = true)
    protected ProfitsMainType profitsMain;
    @XmlElement(required = true)
    protected DeveloperType developer;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the latitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * Sets the value of the latitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLatitude(String value) {
        this.latitude = value;
    }

    /**
     * Gets the value of the longitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLongitude() {
        return longitude;
    }

    /**
     * Sets the value of the longitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLongitude(String value) {
        this.longitude = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddress(String value) {
        this.address = value;
    }

    /**
     * Gets the value of the buildings property.
     * 
     * @return
     *     possible object is
     *     {@link BuildingsType }
     *     
     */
    public BuildingsType getBuildings() {
        return buildings;
    }

    /**
     * Sets the value of the buildings property.
     * 
     * @param value
     *     allowed object is
     *     {@link BuildingsType }
     *     
     */
    public void setBuildings(BuildingsType value) {
        this.buildings = value;
    }

    /**
     * Gets the value of the salesInfo property.
     * 
     * @return
     *     possible object is
     *     {@link SalesInfoType }
     *     
     */
    public SalesInfoType getSalesInfo() {
        return salesInfo;
    }

    /**
     * Sets the value of the salesInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link SalesInfoType }
     *     
     */
    public void setSalesInfo(SalesInfoType value) {
        this.salesInfo = value;
    }

    /**
     * Gets the value of the descriptionMain property.
     * 
     * @return
     *     possible object is
     *     {@link DescriptionMainType }
     *     
     */
    public DescriptionMainType getDescriptionMain() {
        return descriptionMain;
    }

    /**
     * Sets the value of the descriptionMain property.
     * 
     * @param value
     *     allowed object is
     *     {@link DescriptionMainType }
     *     
     */
    public void setDescriptionMain(DescriptionMainType value) {
        this.descriptionMain = value;
    }

    /**
     * Gets the value of the profitsMain property.
     * 
     * @return
     *     possible object is
     *     {@link ProfitsMainType }
     *     
     */
    public ProfitsMainType getProfitsMain() {
        return profitsMain;
    }

    /**
     * Sets the value of the profitsMain property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProfitsMainType }
     *     
     */
    public void setProfitsMain(ProfitsMainType value) {
        this.profitsMain = value;
    }

    /**
     * Gets the value of the developer property.
     * 
     * @return
     *     possible object is
     *     {@link DeveloperType }
     *     
     */
    public DeveloperType getDeveloper() {
        return developer;
    }

    /**
     * Sets the value of the developer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeveloperType }
     *     
     */
    public void setDeveloper(DeveloperType value) {
        this.developer = value;
    }

}
