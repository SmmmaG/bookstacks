package ru.sp.drf.market.dataloader;

import ru.sp.drf.market.dto.validation.ValidationResultDto;
import ru.sp.drf.market.exception.UndefinedFeedHandlerException;
import ru.sp.drf.market.repository.sql.SQLDataSource;

import javax.transaction.NotSupportedException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Objects;


public class TempFeedLoader<T extends SQLDataSource> extends XmlFeedLoader {

    public static String TEMP_LOADER_URL_PREFIX = "TEMP:";

    @Override
    public boolean executeTasks() throws Exception {
        return false;
    }

    @Override
    public void executeDisableTasks() throws Exception {
    }


    @Override
    public void onPrepare() throws Exception {
    }


    @Override
    public void onValidate() throws Exception {
    }


    @Override
    public void onParse() throws Exception {
    }

    @Override
    public void onLoad() throws Exception {
    }


    @Override
    public void onAfter() throws Exception {
    }


    @Override
    public void onDisable() throws IOException, SQLException {
    }

    @Override
    public void initConnection() throws Exception {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TempFeedLoader that = (TempFeedLoader) o;
        return Objects.equals(feedLog, that.feedLog);
    }

    @Override
    public int hashCode() {
        return Objects.hash(feedLog);
    }

    @Override
    public String toString() {
        return "FeedLoader{" +
                "feedLog=" + feedLog +
                '}';
    }

    @Override
    public ValidationResultDto onSchemeValidation() throws Exception {
       return null;
    }

    @Override
    public ValidationResultDto executeValidateTask() throws Exception {
        try {
            FeedLoader newLoader = FeedBroker.getXmlLoader(xmlFile);
            if (!(newLoader instanceof XmlFeedLoader)) {
                throw new UndefinedFeedHandlerException("Loader validation not supported");
            }
            newLoader.setFeedLog(feedLog);
            ((XmlFeedLoader) newLoader).xmlFile = this.xmlFile;
            return ((XmlFeedLoader) newLoader).executeValidate();
        } catch (Exception e) {
            FeedBroker.deleteFeedLog(feedLog);
            throw e;
        }
    }

    @Override
    public String getSchemaNamePrefix() {
        return null;
    }

    @Override
    protected void onCreateTempSchema(String schemaName) throws IOException, SQLException {
    }

    @Override
    protected void onRemoveTempSchema(String schemaName) throws IOException, SQLException {
    }
}
