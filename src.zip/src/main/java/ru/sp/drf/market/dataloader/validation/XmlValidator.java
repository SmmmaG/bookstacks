package ru.sp.drf.market.dataloader.validation;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class XmlValidator {

    public static void validate(File tmpFile, DefaultHandler handler, String resourceName) throws SAXException, IOException {

        Source xmlFile = new StreamSource(new BufferedReader(new FileReader(tmpFile)));

        SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema = factory.newSchema(Thread.currentThread().getContextClassLoader().getResource(resourceName));
        factory.setErrorHandler(handler);

        Validator validator = schema.newValidator();
        validator.setErrorHandler(handler);

        validator.validate(xmlFile);

    }

}
