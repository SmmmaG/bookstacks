package ru.sp.drf.market.task.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

public class ValidationTask {
    private List<RuleExecutor> executors = new ArrayList();

    public ValidationTask(RuleExecutor... executors) {
        if (isValid(executors)) {
            this.executors = Arrays.asList(executors);
        }
    }

    public void addExecutor(RuleExecutor executor) {
        executors.add(executor);
    }

    public void execute(){
        for (RuleExecutor executor: executors){
            executor.execute();
        }
    }
}
