package ru.sp.drf.market.task;

import com.fasterxml.jackson.databind.ObjectMapper;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptExecutor;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.dataloader.MarketDataSource;
import ru.sp.drf.market.exchange.geocode.Geocode;
import ru.sp.drf.market.repository.sql.SQLGeocoder;
import ru.sp.drf.market.service.AddressService;
import ru.sp.drf.market.service.ComplexService;
import ru.sp.drf.market.utilities.Geocoder;

import javax.persistence.Tuple;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Filling complexes coordinates by region, city and complex name
 */
public class FillComplexLocationTask implements Runnable {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private final ComplexService complexService;
    private final AddressService addressService;

    public FillComplexLocationTask(ComplexService complexService, AddressService addressService) {
        this.complexService = complexService;
        this.addressService = addressService;
    }

    @Override
    public void run() {

        List<Tuple> complexes = complexService.findAllWithoutCoordinates();
        for (Tuple complex : complexes) {
            geocodeComplex(complex);
        }
        ScriptExecutor scriptExecutor = null;
        try {
            scriptExecutor = new ScriptExecutor(MarketDataSource.getConnection(), FeedServiceConfig.RESOURCE_LOADER);
            scriptExecutor.executeScript("set-missing-building-coordinate-from-complex");
            scriptExecutor.executeScript("all complex geometry calculate");
        } catch (SQLException e) {
            LOG.error("Unexpected sql exception", e);
        } catch (IOException e) {
            LOG.error("Unexpected exception", e);
        }
    }

    private void geocodeComplex(Tuple complex) {
        UUID complexId = (UUID) complex.get(0);
        try (Connection conn = MarketDataSource.getConnection();
             PreparedStatement psAdd = conn.prepareStatement(SQLGeocoder.addComplexGeocode.getSQL());
             PreparedStatement psGet = conn.prepareStatement(SQLGeocoder.getComplexGeocode.getSQL());
             PreparedStatement psUpdAddress = conn.prepareStatement(SQLGeocoder.updAddress.getSQL());
        ) {
            psGet.setObject(1, complexId);
            try (ResultSet rsGet = psGet.executeQuery()) {
                String complexName = ((String) complex.get(1)).replace("ЖК ", "").replace("Жилой комплекс ", "");
                String geocodeStr = null;
                while (rsGet.next()) {
                    geocodeStr = rsGet.getString("json");
                }
                if (Objects.isNull(geocodeStr)) {

                    String searchString = String.valueOf(complex.get(5)) + " " +
                            (Objects.nonNull(complex.get(3)) ? (String.valueOf(complex.get(4)) + " " +
                                    (Objects.isNull(complex.get(4)) ? "" : String.valueOf(complex.get(5)))) : "") +
                            ", ЖК " + complexName;
                    LOG.info("launch {}", searchString);

                    String text = URLEncoder.encode(searchString, StandardCharsets.UTF_8.toString());
                    String urlStr = "https://search-maps.yandex.ru/v1/?apikey=" + FeedServiceConfig.YANDEX_ORGANIZATION_APIKEY
                            + "&lang=ru_RU&type=biz&results=500&text=" + text;
                    geocodeStr = Geocoder.getGeocode(urlStr);

                    psAdd.setObject(1, complexId);
                    psAdd.setString(2, geocodeStr);
                    psAdd.executeUpdate();
                }

                geocodeStr = geocodeStr.replace("Ё", "Е").replace("ё", "е");

                ObjectMapper mapper = new ObjectMapper();
                Geocode geocode = mapper.readValue(geocodeStr, Geocode.class);

                Geocode.ElementWithName JKelement = new Geocode.ElementWithName("Жилой комплекс");
                Set<Geocode.Feature> featureSet =
                        geocode.getFeatures()
                                .stream()
                                .filter(feature -> feature.getProperties().getCompanyMetaData().categories.contains(JKelement))
                                .collect(Collectors.toSet());
                if (featureSet.size() > 0) {
                    Geocode.Feature feature = featureSet.stream()
                            .filter(f -> f.properties.companyMetaData.name.toLowerCase().contains(complexName.toLowerCase()))
                            .findFirst()
                            .orElse(null);
                    if (feature == null)
                        feature = (Geocode.Feature) featureSet.toArray()[0];

                    psUpdAddress.setDouble(1, feature.geometry.coordinates[1]);
                    psUpdAddress.setDouble(2, feature.geometry.coordinates[0]);
                    psUpdAddress.setObject(3, complex.get(2));
                    psUpdAddress.executeUpdate();

                }
            }
        } catch (Exception e) {
            LOG.error("Unexpected exception", e);
        }
    }
}
