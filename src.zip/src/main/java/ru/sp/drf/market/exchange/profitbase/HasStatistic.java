package ru.sp.drf.market.exchange.profitbase;

public interface HasStatistic {
    StatisticByRooms getStatisticByRooms();
}
