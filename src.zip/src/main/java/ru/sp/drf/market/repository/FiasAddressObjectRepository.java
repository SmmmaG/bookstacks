package ru.sp.drf.market.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import ru.domrf.rem.domain.address.Address;
import ru.sp.drf.market.model.fias.DataRow;

import java.util.List;
import java.util.UUID;

@Repository
public interface FiasAddressObjectRepository extends JpaRepository<Address, UUID> {


    @Query(value = "SELECT ad.aoguid as id, " +
            "ad.address," +
            "ad.regionid, " +
            "ad.cityid,"+
            "ad.shortname as prefix,"+
            "ad.parentguid as parentId,"+
            "ad.formalname as \"name\","+
            "ad.aolevel as \"level\" "+
            "FROM fias.fias_addressobjects ad WHERE ad.aolevel IN (?1) AND ad.regioncode=?2",
            countQuery = "SELECT count(*) FROM fias.fias_addressobjects ad WHERE ad.aolevel IN (?1) AND ad.regioncode=?2",
            nativeQuery = true )
    Page<DataRow> findAddressObjectByLevel(Integer[] level, String regionCode, Pageable pageable);

    @Query (value = "SELECT distinct ad.regioncode from fias.fias_addressobjects ad ORDER by ad.regioncode", nativeQuery = true )
    List<String> getRegionCodes();

}


