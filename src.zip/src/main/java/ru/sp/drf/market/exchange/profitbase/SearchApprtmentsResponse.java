package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;
import java.util.Objects;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchApprtmentsResponse implements Response {

    @JsonProperty("success")
    private String success;

    @JsonProperty("data")
    private List<AppartmentsItem> appartments;

    public void setAppartments(List<AppartmentsItem> appartments) {
        this.appartments = appartments;
    }

    public List<AppartmentsItem> getAppartments() {
        return appartments;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    @Override
    @JsonIgnore
    public void save(AtomicOperation operation) throws Exception {
        for (AppartmentsItem item : appartments) {
            item.save(operation.getContextLoader().getHouseById(item.getHouseId()), operation);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SearchApprtmentsResponse)) return false;
        SearchApprtmentsResponse that = (SearchApprtmentsResponse) o;
        return Objects.equals(appartments, that.appartments);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appartments);
    }

    @Override
    public String toString() {
        return "SearchApprtmentsResponse{" +
                "appartments=" + appartments +
                '}';
    }
}