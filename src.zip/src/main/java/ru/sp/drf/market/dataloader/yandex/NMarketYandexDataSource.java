package ru.sp.drf.market.dataloader.yandex;

import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptExecutor;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.IOException;
import java.sql.SQLException;


public class NMarketYandexDataSource extends YandexDataSource {

    public NMarketYandexDataSource() throws Exception {
        super();
    }

    public void storeData(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName(), 1800);

        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/yandex/Match-flats"), feedLog, true, FeedEventTypes.Asgn_Nmarket_Code);
    }

    @Override
    public void disableData(FeedLog feedLog) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("nmarket/yandex/Unmatch");
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Disbl_Nmarket_Codes);
    }

}
