package ru.sp.drf.market.dataloader.validation;

public enum ValidationEvents {
    IsXMLValidationError("Файл фида не является XML-файлом"),
    SSLValidationError("Произошла ошибка протокола SSL при попытке запроса файла фида"),
    FileNotFoundError("Неверная ссылка (Ошибка 404)"),
    FeedServerError("Ошибка на сервере поставщика (Ошибка 500)"),
    FeedServerSSLError("Ошибка на сервере поставщика (Ошибка SSL)"),
    DownloadTimeout("Время ожидания соединения истекло"),
    DownloadFileException("Ошибка загрузки файла"),
    DownloadFileEncodingException("Ошибка загрузки файла, неизвестная кодировка"),
    FileIsEmptyError("Пустой файл"),
    fieldLowPrice("Слишком низкая цена"),
    fieldRooms("Количество комнат"),
    fieldPrice("Цена"),
    fieldSquare("Площадь"),
    fieldFloor("Этаж"),
    fieldRenovation("Ремонт"),
    fieldPlan("План"),
    fieldReadyQuarter("Квартал окончания строительства"),
    fieldReadyYear("Год окончания строительства"),
    fieldBuildingState("Этап строительства"),
    fieldBuildingFloors("Этажность"),
    fieldAddress("Адрес"),
    fieldComplexNameAddress("Название комплекса + адрес"),
    fieldComplexName("Название комплекса"),
    fieldID("ID объекта"),
    fieldDeveloperName("Название застройщика"),
    fieldDeveloperPhone("Телефон застройщика"),
    fieldWrongDeveloperPhone("Неверный формат телефона застройщика"),
    fieldCoordinates("Координаты"),
    fieldWrongCoordinates("Координаты вне пределов РФ"),
    notUniqueBuildingId("Идентификаторы домов не уникальны"),
    notUniqueFlatId("Идентификаторы квартир не уникальны"),
    notUniqueComplexId("Идентификаторы жилых комплексов не уникальны"),
    noDataAfterValidation("Не осталось ни одного объекта после валидации"),
    checkFlatCountBeforeValidation("Проверка количества квартир до валидации"),
    checkFlatCountAfterValidation("Проверка количества квартир после валидации"),
    checkBuildCountBeforeValidation("Проверка количества домов до валидации"),
    checkBuildCountAfterValidation("Проверка количества домов после валидации"),
    checkComplexCountBeforeValidation("Проверка количества жилых комплексов до валидации"),
    checkComplexCountAfterValidation("Проверка количества жилых комплексов после валидации"),
    ;

    ValidationEvents(String message) {
        this.message = message;
    }

    private String message;

    public String getMessage() {
        return message;
    }
}
