package ru.sp.drf.market.dataloader.fias;

import org.springframework.scheduling.annotation.AsyncResult;
import org.xml.sax.InputSource;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.task.EventPlugin;
import ru.sp.drf.market.utilities.BigFileChunkReader;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.Future;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

public class XmlLoader extends EventPlugin {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private static final String XML_START_TAG = "<?xml version=\"1.0\" encoding=\"utf-8\"?><AddressObjects>";
    private static final String XML_STOP_TAG = "</AddressObjects>";
    private static final String OBJECT_TAG_START = "<Object ";
    private static final String TAG_STOP = "/>";
    private static final int BUFF_SIZE = 10 * 1024 * 1024;


    public XmlLoader() {
    }

    public void execute(final File file) {
        new Thread(() -> {
            try {
                loadFromFile(file);
            } catch (Exception e) {
                LOG.error("Error processing " + file.getName(), e);
            }
        }).start();

    }


    private Future<String> loadFromFile(File xmlFile) throws Exception {
        BigFileChunkReader reader = null;
        SAXParser saxParser;
        FiasXmlParserHandler handler;

        saxParser = SAXParserFactory.newInstance().newSAXParser();
        handler = new FiasXmlParserHandler();

        try {
            reader = new BigFileChunkReader(xmlFile, BUFF_SIZE);
            String chunk = "";
            int paresableChunkStart;
            int paresableChunkStop;

            DecimalFormat formatter = (DecimalFormat) NumberFormat.getInstance(Locale.US);
            DecimalFormatSymbols symbols = formatter.getDecimalFormatSymbols();

            symbols.setGroupingSeparator(' ');
            formatter.setDecimalFormatSymbols(symbols);

            while (reader.hasNextChunk()) {
                chunk = chunk.concat(reader.getNextChunk());
                paresableChunkStart = chunk.indexOf(OBJECT_TAG_START);
                paresableChunkStop = chunk.lastIndexOf(TAG_STOP) + 2;
                String parseableChunk = chunk.substring(paresableChunkStart, paresableChunkStop);
                InputSource input = new InputSource(new StringReader(XML_START_TAG + parseableChunk + XML_STOP_TAG));
                saxParser.parse(input, handler);
                chunk = chunk.substring(paresableChunkStop);
                notifyBulkStore(new StoreEvent(handler.getInsertScriptAddresses()));
                handler.clear();

            }
            LOG.info("File " + xmlFile.getName() + " processed ...");

            return new AsyncResult<String>(xmlFile.getName());
        } catch (IOException e) {
            LOG.error("Error while reading file: " + xmlFile.getName() + ". Details:" + e.getMessage(), e);
            throw new Exception("Unable to read file " + xmlFile.getName());
        } finally {
            if (isValid(reader)) {
                reader.close();
            }
        }

    }


}