package ru.sp.drf.market.utilities.actuator;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.domrf.rem.utilities.logs.CustomLogger;

@Component
@Endpoint(id = "alive-endpoint-simple")
public class AliveSimpleEndpoint {
    CustomLogger LOG = CustomLogger.getLogger();

    @ReadOperation
    public HttpStatus check() {
        LOG.info("Try to check AliveSimple");
        return HttpStatus.OK;
    }
}
