package ru.sp.drf.market.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import ru.domrf.rem.domain.address.Metro;
import ru.sp.drf.market.model.elastic.MetroData;

import java.util.List;
import java.util.UUID;

@Repository
public interface MetroRepository extends JpaRepository<Metro, UUID>{


    @Query("select new ru.sp.drf.market.model.elastic.MetroData(m.id, m.name, m.line.lineColor, m.line.city.code, m.line.city.id, m.location.city.fiasCode, m.location.region.id, m.location.region.fiasCode) " +
            "from Metro m " +
            "where m.actual=true")
    List<MetroData> findAllActive();

}