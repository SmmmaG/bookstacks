package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppartmentsItem extends Storable<HousesItem, UUID> {

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

    @JsonProperty("id")
    private int flatId;
    @JsonProperty("house_id")
    private int houseId;
    @JsonProperty("houseName")
    private String houseName;
    @JsonProperty("projectName")
    private String complexName;
    @JsonProperty("number")
    private String flatNumber;
    @JsonProperty("rooms_amount")
    private int roomsAmount;
    @JsonProperty("floor")
    private int floor;
    @JsonProperty("sectionName")
    private String sectionName;
    @JsonProperty("studio")
    private boolean studio;
    @JsonProperty("free_layout")
    private boolean freeLayout;
    @JsonProperty("propertyType")
    private String propertyType;
    @JsonProperty("area")
    private Area area;
    @JsonProperty("status")
    private String status;
    @JsonProperty("price")
    private Price price;

    @JsonProperty("specialOffersIds")
    List<Integer> specialOffersIds;

    @Override
    public UUID save(HousesItem parent, AtomicOperation dataSourse) throws Exception {
        UUID appartmentId = dataSourse.addAppartment(this, parent.getHouseUUId());
        return appartmentId;
    }

    public static SimpleDateFormat getSdf() {
        return sdf;
    }

    public static void setSdf(SimpleDateFormat sdf) {
        AppartmentsItem.sdf = sdf;
    }

    public int getFlatId() {
        return flatId;
    }

    public void setFlatId(int flatId) {
        this.flatId = flatId;
    }

    public int getHouseId() {
        return houseId;
    }

    public void setHouseId(int houseId) {
        this.houseId = houseId;
    }

    public String getHouseName() {
        return houseName;
    }

    public void setHouseName(String houseName) {
        this.houseName = houseName;
    }

    public String getComplexName() {
        return complexName;
    }

    public void setComplexName(String complexName) {
        this.complexName = complexName;
    }

    public String getFlatNumber() {
        return flatNumber;
    }

    public void setFlatNumber(String flatNumber) {
        this.flatNumber = flatNumber;
    }

    public int getRoomsAmount() {
        return roomsAmount;
    }

    public void setRoomsAmount(int roomsAmount) {
        this.roomsAmount = roomsAmount;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public boolean isStudio() {
        return studio;
    }

    public void setStudio(boolean studio) {
        this.studio = studio;
    }

    public boolean isFreeLayout() {
        return freeLayout;
    }

    public void setFreeLayout(boolean freeLayout) {
        this.freeLayout = freeLayout;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public void setPropertyType(String propertyType) {
        this.propertyType = propertyType;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Price getPrice() {
        return price;
    }

    public void setPrice(Price price) {
        this.price = price;
    }

    public List<Integer> getSpecialOffersIds() {
        return specialOffersIds;
    }

    public void setSpecialOffersIds(List<Integer> specialOffersIds) {
        this.specialOffersIds = specialOffersIds;
    }

    public String convertSpecialOffersIdstoString() {
        if (isValid(this.specialOffersIds)) {
            return this.specialOffersIds.stream().map(item -> String.valueOf(item))
                    .collect(Collectors.joining(","));
        } else
            return null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AppartmentsItem)) return false;
        AppartmentsItem that = (AppartmentsItem) o;
        return flatId == that.flatId &&
                houseId == that.houseId &&
                roomsAmount == that.roomsAmount &&
                floor == that.floor &&
                studio == that.studio &&
                freeLayout == that.freeLayout &&
                Objects.equals(houseName, that.houseName) &&
                Objects.equals(complexName, that.complexName) &&
                Objects.equals(flatNumber, that.flatNumber) &&
                Objects.equals(sectionName, that.sectionName) &&
                Objects.equals(propertyType, that.propertyType) &&
                Objects.equals(area, that.area) &&
                Objects.equals(status, that.status) &&
                Objects.equals(price, that.price) &&
                Objects.equals(specialOffersIds, that.specialOffersIds);
    }

    @Override
    public int hashCode() {
        return Objects.hash(flatId, houseId, houseName, complexName, flatNumber, roomsAmount, floor, sectionName, studio, freeLayout, propertyType, area, status, price, specialOffersIds);
    }
}