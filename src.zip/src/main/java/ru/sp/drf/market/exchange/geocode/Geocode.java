package ru.sp.drf.market.exchange.geocode;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Geocode {
    private List<Feature> features;

    public Geocode() {
    }

    public Geocode(List<Feature> features) {
        this.features = features;
    }

    @JsonProperty("features")
    public List<Feature> getFeatures() {
        return features;
    }

    public void setFeatures(List<Feature> features) {
        this.features = features;
    }

    @Override
    public String toString() {
        return "GeocodeOrganisation{" +
                "features=" + features +
                '}';
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Feature {

        public String type;
        public FeatureProperties properties;
        public FeatureGeometry geometry;

        public Feature() {
        }

        public Feature(String type, FeatureProperties properties, FeatureGeometry geometry) {
            this.type = type;
            this.properties = properties;
            this.geometry = geometry;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public FeatureProperties getProperties() {
            return properties;
        }

        public void setProperties(FeatureProperties properties) {
            this.properties = properties;
        }

        public FeatureGeometry getGeometry() {
            return geometry;
        }

        public void setGeometry(FeatureGeometry geometry) {
            this.geometry = geometry;
        }

        @Override
        public String toString() {
            return "Feature{" +
                    "type='" + type + '\'' +
                    ", properties=" + properties +
                    ", geometry=" + geometry +
                    '}';
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class FeatureProperties {
        public String name;
        public String description;
        public CompanyMetaData companyMetaData;

        public FeatureProperties() {
        }

        public FeatureProperties(String name, String description, CompanyMetaData companyMetaData) {
            this.name = name;
            this.description = description;
            this.companyMetaData = companyMetaData;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        @JsonProperty("CompanyMetaData")
        public CompanyMetaData getCompanyMetaData() {
            return companyMetaData;
        }

        public void setCompanyMetaData(CompanyMetaData companyMetaData) {
            this.companyMetaData = companyMetaData;
        }

        @Override
        public String toString() {
            return "FeatureProperties{" +
                    "name='" + name + '\'' +
                    ", description='" + description + '\'' +
                    ", companyMetaData=" + companyMetaData +
                    '}';
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class CompanyMetaData {
        public String id;
        public String name;
        public String address;
        public Set<ElementWithName> categories;

        public CompanyMetaData() {
        }

        public CompanyMetaData(String id, String name, String address, Set<ElementWithName> categories) {
            this.id = id;
            this.name = name;
            this.address = address;
            this.categories = categories;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        @JsonProperty("Categories")
        public Set<ElementWithName> getCategories() {
            return categories;
        }

        public void setCategories(Set<ElementWithName> categories) {
            this.categories = categories;
        }

        @Override
        public String toString() {
            return "CompanyMetaData{" +
                    "id='" + id + '\'' +
                    ", name='" + name + '\'' +
                    ", address='" + address + '\'' +
                    ", categories=" + categories +
                    '}';
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ElementWithName {
        public String name;

        public ElementWithName() {
        }

        public ElementWithName(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return "ElementWithName{" +
                    "name='" + name + '\'' +
                    '}';
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ElementWithName that = (ElementWithName) o;
            return Objects.equals(name, that.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name);
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class FeatureGeometry {
        public String type;
        public double[] coordinates;

        public FeatureGeometry() {
        }

        public FeatureGeometry(String type, double[] coordinates) {
            this.type = type;
            this.coordinates = coordinates;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public double[] getCoordinates() {
            return coordinates;
        }

        public void setCoordinates(double[] coordinates) {
            this.coordinates = coordinates;
        }

        @Override
        public String toString() {
            return "FeatureGeometry{" +
                    "type='" + type + '\'' +
                    ", coordinates=" + Arrays.toString(coordinates) +
                    '}';
        }
    }

}
