package ru.sp.drf.market.utilities.actuator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.domrf.rem.actuator.checks.CheckContext;
import ru.domrf.rem.actuator.checks.CheckRunner;
import ru.domrf.rem.actuator.checks.CheckerResultInfo;
import ru.domrf.rem.actuator.checks.PostgresQueriesHealthChecker;
import ru.domrf.rem.actuator.checks.PostgresSimpleHealthChecker;
import ru.domrf.rem.utilities.logs.CustomLogger;

import javax.sql.DataSource;

@Component
@Endpoint(id = "alive-endpoint-pg-full")
public class AlivePgFullEndpoint {
    CustomLogger LOG = CustomLogger.getLogger();
    DataSource postgresDataSource;
    PostgresSimpleHealthChecker postgresSimpleHealthChecker;
    PostgresQueriesHealthChecker postgresQueriesHealthChecker;
    ObjectMapper actuatorMapper;

    public AlivePgFullEndpoint(DataSource postgresDataSource,
                               PostgresSimpleHealthChecker postgresSimpleHealthChecker,
                               ObjectMapper actuatorMapper,
                               PostgresQueriesHealthChecker postgresQueriesHealthChecker) {
        this.postgresDataSource = postgresDataSource;
        this.actuatorMapper = actuatorMapper;
        this.postgresSimpleHealthChecker = postgresSimpleHealthChecker;
        this.postgresQueriesHealthChecker = postgresQueriesHealthChecker;
    }

    @ReadOperation
    public HttpStatus check() throws JsonProcessingException {
        LOG.info("Try to check AliveFull");
        CheckerResultInfo checkerResultInfo = new CheckRunner(ImmutableList.of(postgresQueriesHealthChecker)).runChecks(new CheckContext(postgresDataSource));
        LOG.info("Check result {}", actuatorMapper.writeValueAsString(checkerResultInfo));
        return HttpStatus.OK;
    }
}
