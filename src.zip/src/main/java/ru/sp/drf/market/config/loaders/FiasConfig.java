package ru.sp.drf.market.config.loaders;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
public class FiasConfig {

    public static final String[] ADDRESS_FIELDS_FOR_CREATE = new String[]{"address", "region_code", "city_code", "uuid", "name", "prefix", "parent_id", "actual_on", "country", "level"};
    public static final String[] ADDRESS_FIELDS_FOR_UPDATE = new String[]{"address", "region_code", "city_code"};

    public static final int PARTS_COUNT = 100;
    public static final int FETCH_SIZE = 100;
    public static final int BUFF_SIZE = 1024 * 1024;

    public static final String OBJECT_TAG_START = "<Object ";
    public static final String TAG_STOP = "/>";
    public static final String OBJECTS_FILE = "as_addrobj_";
    public static final String FIAS_DOWNLOADS_TMP_DIR = "fias-downloads";
    public static final String FEED_FIAS_MAIN = "fias_main";
    public static final String FEED_FIAS_DELTA = "fias_delta";
    public static final String FEED_XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";


    private static String elasticHost;
    private static String elasticPort;
    private static String elasticProtocol;
    private static String elasticDbPrefix;
    private static String driverClassName;
    private static String url;
    private static String username;
    private static String password;

    private static boolean clearElasticStore;

    private static boolean loadDelta;
    private static String downLoadedFile;

    private static String mainFile;
    private static String deltaFile;
    private static String fiasUrl;
    /**
     * Размер количества элементов АОС при обработке.
     */
    private static int fetchSize = FETCH_SIZE;
    /**
     * Путь для загружаемых из ФИАС архивов
     */
    private static String dataPath;

    public static String BULK_REQUEST_HEADER_CONTENT_TYPE = "application/x-ndjson";
    public static String JSON_REQUEST_HEADER_CONTENT_TYPE = "application/json";


    @Value("${spring.datasource.driver-class-name}")
    public void setDriverClassName(String driverClassName) {
        this.driverClassName = driverClassName;
    }

    @Value("${spring.datasource.url}")
    public void setUrl(String url) {
        this.url = url;
    }

    @Value("${spring.datasource.username}")
    public void setUsername(String username) {
        this.username = username;
    }

    @Value("${spring.datasource.password}")
    public void setPassword(String password) {
        this.password = password;
    }

    @Value("${elastic.host}")
    public void setElasticHost(String host) {
        this.elasticHost = host;
    }

    @Value("${elastic.port}")
    public void setElasticPort(String port) {
        this.elasticPort = port;
    }

    @Value("${elastic.protocol}")
    public static void setElasticProtocol(String elasticProtocol) {
        FiasConfig.elasticProtocol = elasticProtocol;
    }

    @Value("${spring.feedloader.fias.load-delta}")
    public void setLoadDelta(boolean loadDelta) {
        this.loadDelta = loadDelta;
    }

    @Value("${spring.feedloader.fias.clear-elastic-store}")
    public void setLoadMetro(boolean clearElasticStore) {
        this.clearElasticStore = clearElasticStore;
    }

    @Value("${spring.feedloader.fias.fetch-size}")
    public static void setFetchSize(int fetchSize) {
        FiasConfig.fetchSize = fetchSize;
    }

    @Value("${spring.feedloader.fias.downloaded-file}")
    public void setDownLoadedFile(String downLoadedFile) {
        this.downLoadedFile = downLoadedFile;
    }

    @Value("${spring.feedloader.fias.url}")
    public void setFiasUrl(String fiasUrl) {
        this.fiasUrl = fiasUrl;
    }

    @Value("${spring.feedloader.fias.main}")
    public void setMainFile(String mainFile) {
        this.mainFile = mainFile;
    }

    @Value("${spring.feedloader.fias.delta}")
    public void setDeltaFile(String deltaFile) {
        this.deltaFile = deltaFile;
    }

    @Value("${spring.feedloader.fias.data-path}")
    public void setDataPath(String dataPath) {
        this.dataPath = dataPath;
    }

    @Value("${elastic.db-prefix}")
    public void setElasticDbPrefix(String elasticDbPrefix) {
        this.elasticDbPrefix = elasticDbPrefix.replace("-", "_") + "_";
    }

    public static String getDriverClassName() {
        return driverClassName;
    }

    public static String getUsername() {
        return username;
    }

    public static String getPassword() {
        return password;
    }

    public static String getUrl() {
        return url;
    }

    public static String getFiasUrl() {
        return fiasUrl;
    }

    public static int getFetchSize() {
        return fetchSize;
    }

    public static boolean isClearElasticStore() {
        return clearElasticStore;
    }

    public static boolean isLoadDelta() {
        return loadDelta;
    }

    public static String getDownLoadedFile() {
        return downLoadedFile;
    }

    public static String getMainFile() {
        return mainFile;
    }

    public static String getDeltaFile() {
        return deltaFile;
    }

    public static String getDataPath() {
        return dataPath;
    }

    public static String getElasticDbPrefix() {
        return elasticDbPrefix;
    }

    public static String getElasticUrl() {
        return new StringBuffer("http://").append(getElasticHost()).append(":").append(getElasticPort()).toString();
    }

    public static String getElasticHost() {
        return elasticHost;
    }

    public static String getElasticPort() {
        return elasticPort;
    }

    public static String getElasticProtocol() {
        return elasticProtocol;
    }
}
