package ru.sp.drf.market.model.elastic;

import java.util.HashMap;
import java.util.Map;

public class SuggestContext {

    Map<String, Object> items = new HashMap<>();

    public Map<String, Object> getItems() {
        return items;
    }


    public void add(String category, Object... objects) {
        items.put(category, objects);
    }
}
