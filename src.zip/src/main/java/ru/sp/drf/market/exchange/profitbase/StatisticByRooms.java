package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatisticByRooms extends Storable<HasStatistic, List<UUID>> {

	@JsonProperty("1")
	private RoomCharacteristic roomCharacteristicOne;

	@JsonProperty("ст")
	private RoomCharacteristic roomCharacteristicStudia;

	@JsonProperty("2")
	private RoomCharacteristic roomCharacteristicTwo;

	@JsonProperty("3")
	private RoomCharacteristic roomCharacteristicThird;

	@JsonProperty("4")
	private RoomCharacteristic roomCharacteristicForth;

	@JsonProperty("4+")
	private RoomCharacteristic roomCharacteristicForthMore;

	public RoomCharacteristic getRoomCharacteristicOne() {
		return roomCharacteristicOne;
	}

	public void setRoomCharacteristicOne(RoomCharacteristic roomCharacteristicOne) {
		this.roomCharacteristicOne = roomCharacteristicOne;
	}

	public RoomCharacteristic getRoomCharacteristicStudia() {
		return roomCharacteristicStudia;
	}

	public void setRoomCharacteristicStudia(RoomCharacteristic roomCharacteristicStudia) {
		this.roomCharacteristicStudia = roomCharacteristicStudia;
	}

	public RoomCharacteristic getRoomCharacteristicTwo() {
		return roomCharacteristicTwo;
	}

	public void setRoomCharacteristicTwo(RoomCharacteristic roomCharacteristicTwo) {
		this.roomCharacteristicTwo = roomCharacteristicTwo;
	}

	public RoomCharacteristic getRoomCharacteristicThird() {
		return roomCharacteristicThird;
	}

	public void setRoomCharacteristicThird(RoomCharacteristic roomCharacteristicThird) {
		this.roomCharacteristicThird = roomCharacteristicThird;
	}

	public RoomCharacteristic getRoomCharacteristicForth() {
		return roomCharacteristicForth;
	}

	public void setRoomCharacteristicForth(RoomCharacteristic roomCharacteristicForth) {
		this.roomCharacteristicForth = roomCharacteristicForth;
	}

	public RoomCharacteristic getRoomCharacteristicForthMore() {
		return roomCharacteristicForthMore;
	}

	public void setRoomCharacteristicForthMore(RoomCharacteristic roomCharacteristicForthMore) {
		this.roomCharacteristicForthMore = roomCharacteristicForthMore;
	}

	@Override
	public List<UUID> save(HasStatistic itemWithStatistic, AtomicOperation dataSourse) throws Exception {
		return null;
	}


	@Override
 	public String toString(){
		return
			"StatisticByRooms{" +
			"1 = '" + roomCharacteristicOne + '\'' +
			", ст = '" + roomCharacteristicStudia + '\'' +
			", 2 = '" + roomCharacteristicTwo + '\'' +
			", 3 = '" + roomCharacteristicThird + '\'' +
			", 4 = '" + roomCharacteristicForth + '\'' +
			", 4+ = '" + roomCharacteristicForth + '\'' +
			"}";
		}
}