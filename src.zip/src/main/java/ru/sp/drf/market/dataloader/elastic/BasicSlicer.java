package ru.sp.drf.market.dataloader.elastic;

import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentFactory;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.loaders.FiasConfig;
import ru.sp.drf.market.model.BasicItem;
import ru.sp.drf.market.model.elastic.SuggestRequest;

import java.io.IOException;
import java.util.Map;

import static ru.sp.drf.market.model.elastic.Attributes.CONTEXTS;
import static ru.sp.drf.market.model.elastic.Attributes.SUGGEST_NAME;

public abstract class BasicSlicer<T extends BasicItem> {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    protected String indexName;
    protected BulkRequest request;

    protected BasicSlicer(String indexName) {
        this.indexName = indexName;
        this.request = new BulkRequest();
    }

    public void addItemForCreate(T item) {
        try {
            request.add(new IndexRequest(FiasConfig.getElasticDbPrefix() + indexName).id(item.getId().toString()).source(buildIndexBody(item.toMap())));
        } catch (IOException e) {
           LOG.error("Unexpected exception", e);
        }

    }

    public void addItemForUpdate(T item, String[] attributes) {
        try {
            request.add(new UpdateRequest(FiasConfig.getElasticDbPrefix() + indexName, item.getId().toString()).doc(buildIndexBody(item.toMap(attributes))));
        } catch (IOException e) {
           LOG.error("Unexpected exception", e);
        }

    }

    public BulkRequest getRequest() {
        return this.request;
    }

    public void clear() {
        request = new BulkRequest();
    }

    public boolean hasRequest() {
        return !request.requests().isEmpty();
    }

    protected XContentBuilder buildIndexBody(Map<String, Object> values) throws IOException {

        XContentBuilder builder = XContentFactory.jsonBuilder().startObject();
        for (Map.Entry<String, Object> entry : values.entrySet()) {
            if (entry.getKey().startsWith(SUGGEST_NAME)) {
                builder = builder.startObject(SUGGEST_NAME);
                SuggestRequest request = (SuggestRequest) entry.getValue();
                builder = builder.field("input", request.getNames());
                if (!request.getContext().getItems().isEmpty()) {
                    builder = builder.startObject(CONTEXTS);
                    for (Map.Entry<String, Object> category : request.getContext().getItems().entrySet()) {
                        builder = builder.field(category.getKey(), category.getValue());
                    }
                    builder = builder.endObject();
                }
                builder = builder.endObject();
            } else {
                builder = builder.field(entry.getKey(), entry.getValue());
            }
        }

        builder.endObject();
        return builder;


    }
}
