package ru.sp.drf.market.exchange.nmarket;

import java.util.List;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonProperty;

@Generated("com.robohorse.robopojogenerator")
public class SearchApprtmentsResponse implements Response{

	@JsonProperty("appartments")
	private List<AppartmentsItem> appartments;

	@JsonProperty("statistics")
	private Statistics statistics;

	public void setAppartments(List<AppartmentsItem> appartments){
		this.appartments = appartments;
	}

	public List<AppartmentsItem> getAppartments(){
		return appartments;
	}

	public void setStatistics(Statistics statistics){
		this.statistics = statistics;
	}

	@Override
	public Statistics getStatistics(){
		return statistics;
	}

	@Override
 	public String toString(){
		return 
			"SearchApprtmentsResponse{" + 
			"appartments = '" + appartments + '\'' + 
			",statistics = '" + statistics + '\'' + 
			"}";
		}
}