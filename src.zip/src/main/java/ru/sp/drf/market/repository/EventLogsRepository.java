package ru.sp.drf.market.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.domrf.rem.domain.admin.EventLog;

import java.util.Optional;
import java.util.UUID;

public interface EventLogsRepository extends CrudRepository<EventLog, UUID> {
    Optional<EventLog> findById (UUID uuid);

    @Modifying
    @Query("DELETE FROM EventLog e WHERE e.feedLog.id = :id")
    void deleteEvents(@Param("id") UUID id);
}
