package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.Objects;



@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressLoc {

    @JsonProperty("full")
    private String full;
    @JsonProperty("locality")
    private String locality;
    @JsonProperty("district")
    private String district;
    @JsonProperty("region")
    private String region;
    @JsonProperty("street")
    private String street;
    @JsonProperty("number")
    private String number;

    public String getFull() {
        return full;
    }

    public void setFull(String full) {
        this.full = full;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AddressLoc)) return false;
        AddressLoc that = (AddressLoc) o;
        return Objects.equals(full, that.full) &&
                Objects.equals(locality, that.locality) &&
                Objects.equals(district, that.district) &&
                Objects.equals(region, that.region) &&
                Objects.equals(street, that.street) &&
                Objects.equals(number, that.number);
    }

    @Override
    public int hashCode() {
        return Objects.hash(full, locality, district, region, street, number);
    }


}
