package ru.sp.drf.market.model.fias;

import ru.sp.drf.market.config.loaders.FiasConfig;

import java.text.SimpleDateFormat;
import java.util.Date;

import static ru.sp.drf.market.utilities.HelperUtils.formatName;
import static ru.sp.drf.market.utilities.HelperUtils.getValue;


public class AddressObject {

    private static final String pattern = "yyyy-MM-dd";
    private static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

    private String id;
    private String parentId;
    private String regionCode;
    private String areaCode;
    private String cityCode;
    private String cityAreaCode;
    private String placeCode;
    private String streetCode;
    private String formalName;
    private String officialName;
    private String objTypeName;
    private Integer objLevel;
    private Integer recordStatus;
    private boolean isAlive = false;
    private Integer divType;
    private String aoId;
    private String prevId;
    private String nextId;
    private String postalCode;
    private String okato;
    private String oktmo;
    private String autoCode;
    private String extCodeAutoCode;
    private String sextCode;
    private String code;
    private String plainCode;
    private Integer currStatus;
    private String ifnsfl;
    private String ifnsul;
    private String terrifnsfl;
    private String terrifnsul;
    private Integer actStatus;
    private Integer centStatus;
    private String startDate;
    private String endDate;
    private String updateDate;
    private String normDoc;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityAreaCode() {
        return cityAreaCode;
    }

    public void setCityAreaCode(String cityAreaCode) {
        this.cityAreaCode = cityAreaCode;
    }

    public String getPlaceCode() {
        return placeCode;
    }

    public void setPlaceCode(String placeCode) {
        this.placeCode = placeCode;
    }

    public String getStreetCode() {
        return streetCode;
    }

    public void setStreetCode(String streetCode) {
        this.streetCode = streetCode;
    }

    public String getFormalName() {
        return formalName;
    }

    public void setFormalName(String formalName) {
        this.formalName = formalName;
    }

    public String getOfficialName() {
        return officialName;
    }

    public void setOfficialName(String officialName) {
        this.officialName = officialName;
    }

    public String getObjTypeName() {
        return objTypeName;
    }

    public void setObjTypeName(String objTypeName) {
        this.objTypeName = objTypeName;
    }

    public Integer getObjLevel() {
        return objLevel;
    }

    public void setObjLevel(Integer objLevel) {
        this.objLevel = objLevel;
    }

    public Integer getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Integer recordStatus) {
        this.recordStatus = recordStatus;
    }

    public boolean isAlive() {
        return isAlive;
    }

    public void setAlive(boolean alive) {
        isAlive = alive;
    }

    public Integer getDivType() {
        return divType;
    }

    public void setDivType(Integer divType) {
        this.divType = divType;
    }


    public void setAoId(String aoId) {
        this.aoId = aoId;
    }

    public String getAoId() {
        return aoId;
    }

    public void setPrevId(String prevId) {
        this.prevId = prevId;
    }

    public String getPrevId() {
        return prevId;
    }

    public void setNextId(String nextId) {
        this.nextId = nextId;
    }

    public String getNextId() {
        return nextId;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setOkato(String okato) {
        this.okato = okato;
    }

    public String getOkato() {
        return okato;
    }

    public void setOktmo(String oktmo) {
        this.oktmo = oktmo;
    }

    public String getOktmo() {
        return oktmo;
    }

    public void setAutoCode(String autoCode) {
        this.autoCode = autoCode;
    }

    public String getAutoCode() {
        return autoCode;
    }

    public void setExtCodeAutoCode(String extCodeAutoCode) {
        this.extCodeAutoCode = extCodeAutoCode;
    }

    public String getExtCodeAutoCode() {
        return extCodeAutoCode;
    }

    public void setSextCode(String sextCode) {
        this.sextCode = sextCode;
    }

    public String getSextCode() {
        return sextCode;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setPlainCode(String plainCode) {
        this.plainCode = plainCode;
    }

    public String getPlainCode() {
        return plainCode;
    }

    public void setCurrStatus(Integer currStatus) {
        this.currStatus = currStatus;
    }

    public Integer getCurrStatus() {
        return currStatus;
    }

    public void setIfnsfl(String ifnsfl) {
        this.ifnsfl = ifnsfl;
    }

    public String getIfnsfl() {
        return ifnsfl;
    }

    public String getIfnsul() {
        return ifnsul;
    }

    public void setIfnsul(String ifnsul) {
        this.ifnsul = ifnsul;
    }

    public void setTerrifnsfl(String terrifnsfl) {
        this.terrifnsfl = terrifnsfl;
    }

    public String getTerrifnsfl() {
        return terrifnsfl;
    }

    public String getTerrifnsul() {
        return terrifnsul;
    }

    public void setTerrifnsul(String terrifnsul) {
        this.terrifnsul = terrifnsul;
    }

    public void setActStatus(Integer actStatus) {
        this.actStatus = actStatus;
    }

    public Integer getActStatus() {
        return actStatus;
    }

    public void setCentStatus(Integer centStatus) {
        this.centStatus = centStatus;
    }

    public Integer getCentStatus() {
        return centStatus;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(String updateDate) {
        this.updateDate = updateDate;
    }

    public void setNormDoc(String normDoc) {
        this.normDoc = normDoc;
    }

    public String getNormDoc() {
        return normDoc;
    }


    public String toBulkJsonString() {
        StringBuffer addons = new StringBuffer();
        switch (this.objLevel) {
            case 1:
                // регион
//                addons.append("\"region_code\": \"").append(regionCode).append("\", ");
                StringBuffer buffer = new StringBuffer(bulkJson("region", false, addons));
                if (objTypeName != null && objTypeName.equalsIgnoreCase("г")) {
                    addons.append(addRegionCodeAndCityCode(regionCode, cityCode));
                    buffer.append(bulkJson("city", true, addons));
                }
                return buffer.toString();
            case 3:
                //district
                addons.append(addRegionCodeAndCityCode(regionCode, cityCode));
                return bulkJson("district", false, addons);
            case 35:
            case 4:
            case 6:
                // населенный пункт
                addons.append(addRegionCodeAndCityCode(regionCode, cityCode));
                return bulkJson("city", true, addons);
            case 7:
                //street
                addons.append(addRegionCodeAndCityCode(regionCode, cityCode));
                return bulkJson("street", true, addons);

            default:// адрес - 65, 7, 75, 8, 9
                //todo last level only street
                return "";
/*
                addons.append("\"region_code\": \"").append(regionCode).append("\", ");
                addons.append("\"city_code\": \"").append(cityCode).append("\", ");
                addons.append("\"street_code\": \"").append(streetCode).append("\", ");


                return bulkJson("address", false, addons);
*/
        }

    }

    private String addRegionCodeAndCityCode(String regionCode, String cityCode) {
        StringBuffer result = new StringBuffer();
        result.append("\"region_code\": \"").append(getValue(regionCode)).append("\", ");
        result.append("\"city_code\": \"").append(getValue((cityCode))).append("\", ");
        return result.toString();
    }

    private String bulkJson(String level, boolean formalnameFirst, StringBuffer addons) {
        StringBuffer sb = new StringBuffer();
        String name, prefix = "";
/*
        if (formalnameFirst) {
            name = this.formalName + " " + this.objTypeName;
        } else {
            name = this.objTypeName + " " + this.formalName;
        }
*/
        name = this.formalName != null ? this.formalName.trim() : "";
        prefix = this.objTypeName;

        sb.append("{ \"index\": { \"_index\": \"").append(FiasConfig.getElasticDbPrefix() + "address").
                append("\", \"_id\": \"").append(this.id).append("\"} }\n");
        sb.append("{ \"actual_on\": \"").append(simpleDateFormat.format(new Date())).append("\", ");
        sb.append("\"country\": \"Россия\",");
        sb.append("\"name\": \"").append(formatName(getValue(name))).append("\",");
        sb.append("\"prefix\": \"").append(getValue(prefix)).append("\",");
        sb.append("\"parent_id\":\"").append(getValue(this.parentId)).append("\",");
        sb.append("\"level\":\"").append(getValue(level)).append("\",");
        sb.append(addons);
        sb.append("\"uuid\": \"").append(this.id).append("\"}\n");
        return sb.toString();
    }


    public String toSqlInsert() {
        StringBuffer sb = new StringBuffer();
        sb.append("INSERT INTO fias.fias_addressobjects (ACTSTATUS,AOGUID,AOID,AOLEVEL,AREACODE,AUTOCODE,CENTSTATUS,CITYCODE,CODE,CURRSTATUS,ENDDATE,FORMALNAME,IFNSFL,IFNSUL,\n" +
                "   NEXTID,OFFNAME,OKATO,OKTMO,OPERSTATUS,PARENTGUID,PLACECODE,PLAINCODE, POSTALCODE,PREVID,REGIONCODE,SHORTNAME,STARTDATE,\n" +
                "   STREETCODE,TERRIFNSFL,TERRIFNSUL,UPDATEDATE,CTARCODE,EXTRCODE,SEXTCODE,LIVESTATUS,NORMDOC) " +
                "VALUES(" + getObjectValue(this.actStatus) + "," +
                getStringValue(this.id) + "," +
                getStringValue(this.aoId) + "," +
                getObjectValue(this.objLevel) + "," +
                getStringValue(this.areaCode) + "," +
                getStringValue(this.autoCode) + "," +
                getObjectValue(this.centStatus) + "," +
                getStringValue(this.cityCode) + "," +
                getStringValue(this.code) + "," +
                getObjectValue(this.currStatus) + "," +
                getDateValue(this.endDate) + "," +
                getStringValue(this.formalName) + "," +
                getStringValue(this.ifnsfl) + "," +
                getStringValue(this.ifnsul) + "," +
                getStringValue(this.nextId) + "," +
                getStringValue(this.officialName) + "," +
                getStringValue(this.okato) + "," +
                getStringValue(this.oktmo) + "," +
                getObjectValue(this.recordStatus) + "," +
                getStringValue(this.parentId) + "," +
                getStringValue(this.placeCode) + "," +
                getStringValue(this.plainCode) + "," +
                getStringValue(this.postalCode) + "," +
                getStringValue(this.prevId) + "," +
                getStringValue(this.regionCode) + "," +
                getStringValue(this.objTypeName) + "," +
                getDateValue(this.startDate) + "," +
                getStringValue(this.streetCode) + "," +
                getStringValue(this.terrifnsfl) + "," +
                getStringValue(this.terrifnsul) + "," +
                getDateValue(this.updateDate) + "," +
                getStringValue(this.cityAreaCode) + "," +
                getStringValue(this.extCodeAutoCode) + "," +
                getStringValue(this.sextCode) + "," +
                getObjectValue(this.isAlive ? 1 : 0) + "," +
                getStringValue(this.normDoc) + ");\n");
        return sb.toString();
    }

    private String getObjectValue(Object value) {
        return value != null ? String.valueOf(value) : "null";
    }

    private String getStringValue(String value) {
        return value != null ? "'" + value + "'" : "null";
    }

    private String getDateValue(String value) {
        return value != null ? "'" + value + "'" : "null";
    }


}
