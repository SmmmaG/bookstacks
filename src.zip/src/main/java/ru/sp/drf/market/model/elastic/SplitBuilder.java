package ru.sp.drf.market.model.elastic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static ru.sp.drf.market.utilities.HelperUtils.formatName;
import static ru.sp.drf.market.utilities.HelperUtils.isValid;

public class SplitBuilder {

    private List<String> values;

    public SplitBuilder(String[] values) {
        this.values = Arrays.asList(values);
    }

    public static SplitBuilder split(String value, String delimeter) {
        return new SplitBuilder(value.split(delimeter));
    }

    public SplitBuilder split(String delimeter) {
        List<String> result = new ArrayList<>();
        if (isValid(this.values)) {
            this.values.stream().forEach(item -> {
                String[] items = item.split(delimeter);
                if (items.length > 0)
                    result.addAll(Arrays.asList(items));
                else
                    result.add(item);
            });
        }
        this.values = result;
        return this;
    }

    public String[] toArray() {
        return this.values.stream().map(item->formatName(item)).toArray(String[]::new);
    }
}
