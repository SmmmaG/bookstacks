package ru.sp.drf.market.exchange.nmarket;

import java.time.ZonedDateTime;

public class GetTokenResponse {
    private String access_token;
    private String token_type;
    private int expires_in;
    private String refresh_token;
    private String name;
    private String userName;
    private String userGuid;
    private int roles;
    private String accountType;
    private int regionGroupId;
    private String regionGroupName;
    private String issued;
    private String expires;
    private String refreshExpires;
    private double refresh_expires_in;


    public String getAccess_token() {
        return access_token;
    }

    public String getToken_type() {
        return token_type;
    }

    public int getExpires_in() {
        return expires_in;
    }

    public String getRefresh_token() {
        return refresh_token;
    }

    public String getName() {
        return name;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserGuid() {
        return userGuid;
    }

    public int getRoles() {
        return roles;
    }

    public String getAccountType() {
        return accountType;
    }

    public int getRegionGroupId() {
        return regionGroupId;
    }

    public String getRegionGroupName() {
        return regionGroupName;
    }

    public String getIssued() {
        return issued;
    }

    public boolean isOld() {
        ZonedDateTime localtime=ZonedDateTime.now();
        ZonedDateTime tokentime = ZonedDateTime.parse(issued+"+00:00");
        return localtime.compareTo(tokentime.plusSeconds(10000)) > 0;
    }

    public String getExpires() {
        return expires;
    }

    public String getRefreshExpires() {
        return refreshExpires;
    }

    public double getRefresh_expires_in() {
        return refresh_expires_in;
    }

    public String getAuthorization(){
        return new StringBuffer()
                .append(getToken_type())
                .append(" ")
                .append(getAccess_token()).toString();
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public void setToken_type(String token_type) {
        this.token_type = token_type;
    }

    public void setExpires_in(int expires_in) {
        this.expires_in = expires_in;
    }

    public void setRefresh_token(String refresh_token) {
        this.refresh_token = refresh_token;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserGuid(String userGuid) {
        this.userGuid = userGuid;
    }

    public void setRoles(int roles) {
        this.roles = roles;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public void setRegionGroupId(int regionGroupId) {
        this.regionGroupId = regionGroupId;
    }

    public void setRegionGroupName(String regionGroupName) {
        this.regionGroupName = regionGroupName;
    }

    public void setIssued(String issued) {
        this.issued = issued;
    }

    public void setExpires(String expires) {
        this.expires = expires;
    }

    public void setRefreshExpires(String refreshExpires) {
        this.refreshExpires = refreshExpires;
    }

    public void setRefresh_expires_in(double refresh_expires_in) {
        this.refresh_expires_in = refresh_expires_in;
    }

    @Override
    public String toString() {
        return "GetTokenResponse{" +
                "access_token='" + access_token + '\'' +
                ", token_type='" + token_type + '\'' +
                ", expires_in=" + expires_in +
                ", refresh_token='" + refresh_token + '\'' +
                ", name='" + name + '\'' +
                ", userName='" + userName + '\'' +
                ", userGuid='" + userGuid + '\'' +
                ", roles=" + roles +
                ", accountType='" + accountType + '\'' +
                ", regionGroupId=" + regionGroupId +
                ", regionGroupName='" + regionGroupName + '\'' +
                ", issued='" + issued + '\'' +
                ", expires='" + expires + '\'' +
                ", refreshExpires='" + refreshExpires + '\'' +
                ", refresh_expires_in=" + refresh_expires_in +
                '}';
    }
}