package ru.sp.drf.market.task.validation;

import ru.sp.drf.market.task.validation.rule.RuleValidation;

import java.util.List;

public abstract class RuleExecutor<T, TT> {
    protected T repository;
    protected TT root;
    protected List<RuleValidation> rules;

    public abstract void execute();
}
