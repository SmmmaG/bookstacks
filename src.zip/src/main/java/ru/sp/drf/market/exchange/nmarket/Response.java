package ru.sp.drf.market.exchange.nmarket;

public interface Response {
    Statistics getStatistics();
}
