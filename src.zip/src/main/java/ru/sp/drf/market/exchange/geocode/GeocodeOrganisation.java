package ru.sp.drf.market.exchange.geocode;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GeocodeOrganisation {
    
    private Response response;

    public GeocodeOrganisation() {
    }

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    public GeocodeOrganisation(Response response) {
        this.response = response;
    }

    @Override
    public String toString() {
        return "GeocodeOrganisation{" +
                "response=" + response +
                '}';
    }

    @JsonIgnore
    public Set<Component> getComponents() {
        Set<Component> components = new HashSet();

        getResponse().geoObjectCollection.featureMember.forEach(featureMember -> {
            featureMember.geoObject.metaDataProperty.geocoderMetaData.geocodeAddress.components.forEach(component -> components.add(component));
        });

        return components;
    }


    public static class Response {

        private GeoObjectCollection geoObjectCollection;

        public Response() {
        }

        public Response(GeoObjectCollection geoObjectCollection) {
            this.geoObjectCollection = geoObjectCollection;
        }

        @JsonProperty("GeoObjectCollection")
        public GeoObjectCollection getGeoObjectCollection() {
            return geoObjectCollection;
        }

        public void setGeoObjectCollection(GeoObjectCollection geoObjectCollection) {
            this.geoObjectCollection = geoObjectCollection;
        }

        @Override
        public String toString() {
            return "Response{" +
                    "geoObjectCollection=" + geoObjectCollection +
                    '}';
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GeoObjectCollection {

        List<GeoObjectItem> featureMember;

        public GeoObjectCollection() {
        }

        public GeoObjectCollection(List<GeoObjectItem> featureMember) {
            this.featureMember = featureMember;
        }

        public List<GeoObjectItem> getFeatureMember() {
            return featureMember;
        }

        public void setFeatureMember(List<GeoObjectItem> featureMember) {
            this.featureMember = featureMember;
        }

        @Override
        public String toString() {
            return "GeoObjectCollection{" +
                    "featureMember=" + featureMember +
                    '}';
        }
    }

    public static class GeoObjectItem {

        private GeoObject geoObject;

        public GeoObjectItem() {
        }

        @JsonProperty("GeoObject")
        public GeoObject getGeoObject() {
            return geoObject;
        }

        public void setGeoObject(GeoObject geoObject) {
            this.geoObject = geoObject;
        }

        public GeoObjectItem(GeoObject geoObject) {
            this.geoObject = geoObject;
        }

        @Override
        public String toString() {
            return "GeoObjectItem{" +
                    "geoObject=" + geoObject +
                    '}';
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GeoObject {

        private MetaDataProperty metaDataProperty;

        public GeoObject() {
        }

        public GeoObject(MetaDataProperty metaDataProperty) {
            this.metaDataProperty = metaDataProperty;
        }

        public MetaDataProperty getMetaDataProperty() {
            return metaDataProperty;
        }

        public void setMetaDataProperty(MetaDataProperty metaDataProperty) {
            this.metaDataProperty = metaDataProperty;
        }

        @Override
        public String toString() {
            return "GeoObject{" +
                    "metaDataProperty=" + metaDataProperty +
                    '}';
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MetaDataProperty {
        private GeocoderMetaData geocoderMetaData;

        public MetaDataProperty() {
        }

        public MetaDataProperty(GeocoderMetaData geocoderMetaData) {
            this.geocoderMetaData = geocoderMetaData;
        }

        @JsonProperty("GeocoderMetaData")
        public GeocoderMetaData getGeocoderMetaData() {
            return geocoderMetaData;
        }

        public void setGeocoderMetaData(GeocoderMetaData geocoderMetaData) {
            this.geocoderMetaData = geocoderMetaData;
        }

        @Override
        public String toString() {
            return "MetaDataProperty{" +
                    "geocoderMetaData=" + geocoderMetaData +
                    '}';
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GeocoderMetaData {

        private GeocodeAddress geocodeAddress;

        public GeocoderMetaData() {
        }

        public GeocoderMetaData(GeocodeAddress geocodeAddress) {
            this.geocodeAddress = geocodeAddress;
        }

        @JsonProperty("Address")
        public GeocodeAddress getGeocodeAddress() {
            return geocodeAddress;
        }

        public void setGeocodeAddress(GeocodeAddress geocodeAddress) {
            this.geocodeAddress = geocodeAddress;
        }

        @Override
        public String toString() {
            return "GeocoderMetaData{" +
                    "geocodeAddress=" + geocodeAddress +
                    '}';
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GeocodeAddress {
        List<Component> components;

        public GeocodeAddress() {
        }

        public GeocodeAddress(List<Component> components) {
            this.components = components;
        }

        @JsonProperty("Components")
        public List<Component> getComponents() {
            return components;
        }

        public void setComponents(List<Component> components) {
            this.components = components;
        }


        @Override
        public String toString() {
            return "GeocodeAddress{" +
                    "components=" + components +
                    '}';
        }
    }

    public  static class Component {
        public String kind;
        public String name;

        public Component() {
        }

        public Component(String kind, String name) {
            this.kind = kind;
            this.name = name;
        }

        public String getKind() {
            return kind;
        }

        public void setKind(String kind) {
            this.kind = kind;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            Component component = (Component) o;
            return Objects.equals(kind, component.kind) &&
                    Objects.equals(name, component.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(kind, name);
        }

        @Override
        public String toString() {
            return "Component{" +
                    "kind='" + kind + '\'' +
                    ", name='" + name + '\'' +
                    '}';
        }
    }
}