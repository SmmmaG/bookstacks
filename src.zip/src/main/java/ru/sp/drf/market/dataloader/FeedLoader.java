package ru.sp.drf.market.dataloader;

import ru.domrf.rem.domain.admin.DevelopEventLog;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.domain.admin.FeedLogStatuses;
import ru.domrf.rem.utilities.FileLoader;

import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.ScriptExecutor.ValidationResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.loaders.FiasConfig;
import ru.sp.drf.market.dataloader.validation.ValidationEvents;
import ru.sp.drf.market.exception.NoObjectsAfterValidationException;
import ru.sp.drf.market.repository.sql.SQLDataSource;
import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Date;
import java.util.Objects;


public abstract class FeedLoader<T extends SQLDataSource> {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    protected File xmlFile;

    protected long xmlFileSize = -1;

    protected boolean feedIsFullyLoaded = true;

    protected boolean feedIsEmpty = false;

    protected String handler_name;

    protected FeedLog feedLog;

    protected T operation;

    public final boolean execute() {
        boolean success = false;
        try {
            initConnection();
            LOG.info(this.getClass() + " task execute feedId=" + feedLog.getFeed().getId());
            LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.PROGRESS, true);

            success = executeTasks();

            if (Objects.nonNull(feedLog) && !feedLog.getStatus().equals(LoadLogger.getFeedStatuses().get(FeedLogStatuses.ERROR))) {
                if (feedIsEmpty)
                    LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.EMPTY, true);
                else if (feedIsFullyLoaded)
                    LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.OK, true);
                else
                    LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.PARTLY, true);
            }
            DevelopEventLog lastEvent = LoadLogger.writeScriptLog(new ScriptResult(null, -1, FeedLogStatuses.OK.getDescript(), new Date().getTime()),
                    feedLog, false, FeedEventTypes.Executing);
            LoadLogger.setLastFeedEvent(lastEvent, feedLog.getFeed());

            LOG.info(this.getClass().getSimpleName() + " task finish");
        } catch (Exception e) {
            try {
                if (!(e instanceof NoObjectsAfterValidationException))
                    LOG.info(e);
                operation.rollback();
                LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
                DevelopEventLog lastEvent = LoadLogger.writeScriptLog(new ScriptResult(e.getLocalizedMessage(), -1, e.getLocalizedMessage(), new Date().getTime()),
                        feedLog, false, FeedEventTypes.Executing);
                LoadLogger.setLastFeedEvent(lastEvent, feedLog.getFeed());
            } catch (Exception e1) {
                LOG.error(e1);
            }
        } finally {
            try {
                operation.close();
            } catch (SQLException ex) {
                LOG.error(ex);
            }
        }
        return success;
    }

    protected abstract boolean executeTasks() throws Exception;

    public final void executeDisable() {
        try {
            initConnection();
            LOG.info(this.getClass().getSimpleName() + " task executeDisable");
            LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.PROGRESS, false);

            executeDisableTasks();

            LOG.info(this.getClass().getSimpleName() + " task finish");
            LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.OK, false);

        } catch (Exception e) {
            try {
                LOG.error(e);
                operation.rollback();
                LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
                LoadLogger.writeScriptLog(new ScriptResult(e.getLocalizedMessage(), -1, e.getLocalizedMessage(), new Date().getTime()),
                        feedLog, false, FeedEventTypes.Executing);
            } catch (Exception e1) {
                LOG.error(e1);
            }
        } finally {
            try {
                operation.close();
            } catch (SQLException ex) {
                LOG.error(ex);
            }
        }
    }

    protected abstract void executeDisableTasks() throws Exception;


    public abstract void onPrepare() throws Exception;

    public abstract void onValidate() throws Exception;

    public abstract void onParse() throws Exception;

    public abstract void onLoad() throws Exception;

    public abstract void onAfter() throws Exception;

    public abstract void onDisable() throws IOException, SQLException;

    public void setFeedLog(FeedLog feedLog) {
        if (Objects.isNull(feedLog.getFeed().getHandler())) {
            this.handler_name = "temp-" + new Date().getTime();
        } else {
            this.handler_name = feedLog.getFeed().getHandler().getCode();
        }
        this.feedLog = feedLog;
    }

    public FeedLog getFeedLog() {
        return feedLog;
    }

    public abstract void initConnection() throws Exception;

    protected File readFromURL(String prefix, String suffix, String url, String tmpDir) throws KeyManagementException, NoSuchAlgorithmException {
        File tmpFile = null;
        try {
            if (tmpDir != null)
                tmpFile = File.createTempFile(prefix, suffix, new File(FiasConfig.getDataPath() + "/" + tmpDir));
            else
                tmpFile = File.createTempFile(prefix, suffix);
            LOG.info("Archive start downloading ...");
            String resultCode = FileLoader.saveUrl(tmpFile.toPath(), url, 60000, 60000);
            if ("0".equals(resultCode)) {
                LOG.info("Archive downloaded...");
                return tmpFile;
            }
        } catch (MalformedURLException e) {
            LOG.error("Malformed URL: {}", feedLog.getFeed().getUrl(), e);
            return null;
        } catch (IOException e) {
            LOG.error("Cannot : {}", feedLog.getFeed().getUrl(), e);
            return null;

        }
        return null;
    }

    protected void writeValidationLog(ValidationEvents message, FeedEventTypes event, int count, boolean afterValidation) throws SQLException {
        LoadLogger.writeValidationLog(
                new ValidationResult(
                        afterValidation && count == 0 ? ValidationEvents.noDataAfterValidation.getMessage() : null,
                        count,
                        message.getMessage()),
                feedLog,
                event);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FeedLoader that = (FeedLoader) o;
        return Objects.equals(feedLog, that.feedLog);
    }

    @Override
    public int hashCode() {
        return Objects.hash(feedLog);
    }

    @Override
    public String toString() {
        return "FeedLoader{" +
                "feedLog=" + feedLog +
                '}';
    }
}
