package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.Objects;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class HouseBadge {
    @JsonProperty("label")
    private String label;
    @JsonProperty("color")
    private String color;
    @JsonProperty("icon")
    private String icon;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HouseBadge)) return false;
        HouseBadge that = (HouseBadge) o;
        return Objects.equals(label, that.label) &&
                Objects.equals(color, that.color) &&
                Objects.equals(icon, that.icon);
    }

    @Override
    public int hashCode() {
        return Objects.hash(label, color, icon);
    }

    @Override
    public String toString() {
        return "HouseBadge{" +
                "label='" + label + '\'' +
                ", color='" + color + '\'' +
                ", icon='" + icon + '\'' +
                '}';
    }
}
