package ru.sp.drf.market.repository;

import org.springframework.data.repository.CrudRepository;
import ru.domrf.rem.domain.admin.FeedLogFile;

import java.util.UUID;

public interface FeedLogFileRepository  extends CrudRepository<FeedLogFile, UUID> {
}
