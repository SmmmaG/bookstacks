package ru.sp.drf.market.service;

/**
 * Абстрактный предок для сервисов
 * 
 * @since 2.0
 * @author Oleg Gerasimenko
 */
public abstract class AbstractService {

}
