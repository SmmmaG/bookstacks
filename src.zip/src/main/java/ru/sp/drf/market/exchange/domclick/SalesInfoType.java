
package ru.sp.drf.market.exchange.domclick;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for sales_infoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="sales_infoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sales_phone">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="+7 (495) 118-02-53"/>
 *               &lt;enumeration value="+74950213419"/>
 *               &lt;enumeration value="+7 (495) 152-70-45"/>
 *               &lt;enumeration value="+7 (495) 106-83-63"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="responsible_officer_phone">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="+79262661838"/>
 *               &lt;enumeration value="+79162447421"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="sales_address">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="г. Москва, ул. Вавилова, вл. 27-31"/>
 *               &lt;enumeration value="г. Москва, ул. Фестивальная, д. 27"/>
 *               &lt;enumeration value="улица Академика Анохина, рядом с домом 6 корп.4"/>
 *               &lt;enumeration value="Москва, пересечение Боровского шоссе и Чоботовской улицы"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="sales_latitude">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="55.6966070000"/>
 *               &lt;enumeration value="55.8574580000"/>
 *               &lt;enumeration value="55.6697690000"/>
 *               &lt;enumeration value="55.6429000000"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="sales_longitude">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="37.5704670000"/>
 *               &lt;enumeration value="37.4807300000"/>
 *               &lt;enumeration value="37.4688110000"/>
 *               &lt;enumeration value="37.3590730000"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="timezone" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="work_days" type="{}work_daysType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "sales_infoType", propOrder = {
    "salesPhone",
    "responsibleOfficerPhone",
    "salesAddress",
    "salesLatitude",
    "salesLongitude",
    "timezone",
    "workDays"
})
public class SalesInfoType {

    @XmlElement(name = "sales_phone", required = true)
    protected String salesPhone;
    @XmlElement(name = "responsible_officer_phone", required = true)
    protected String responsibleOfficerPhone;
    @XmlElement(name = "sales_address", required = true)
    protected String salesAddress;
    @XmlElement(name = "sales_latitude", required = true)
    protected String salesLatitude;
    @XmlElement(name = "sales_longitude", required = true)
    protected String salesLongitude;
    @XmlElement(required = true)
    protected String timezone;
    @XmlElement(name = "work_days", required = true)
    protected WorkDaysType workDays;

    /**
     * Gets the value of the salesPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesPhone() {
        return salesPhone;
    }

    /**
     * Sets the value of the salesPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesPhone(String value) {
        this.salesPhone = value;
    }

    /**
     * Gets the value of the responsibleOfficerPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponsibleOfficerPhone() {
        return responsibleOfficerPhone;
    }

    /**
     * Sets the value of the responsibleOfficerPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponsibleOfficerPhone(String value) {
        this.responsibleOfficerPhone = value;
    }

    /**
     * Gets the value of the salesAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesAddress() {
        return salesAddress;
    }

    /**
     * Sets the value of the salesAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesAddress(String value) {
        this.salesAddress = value;
    }

    /**
     * Gets the value of the salesLatitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesLatitude() {
        return salesLatitude;
    }

    /**
     * Sets the value of the salesLatitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesLatitude(String value) {
        this.salesLatitude = value;
    }

    /**
     * Gets the value of the salesLongitude property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesLongitude() {
        return salesLongitude;
    }

    /**
     * Sets the value of the salesLongitude property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesLongitude(String value) {
        this.salesLongitude = value;
    }

    /**
     * Gets the value of the timezone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTimezone() {
        return timezone;
    }

    /**
     * Sets the value of the timezone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTimezone(String value) {
        this.timezone = value;
    }

    /**
     * Gets the value of the workDays property.
     * 
     * @return
     *     possible object is
     *     {@link WorkDaysType }
     *     
     */
    public WorkDaysType getWorkDays() {
        return workDays;
    }

    /**
     * Sets the value of the workDays property.
     * 
     * @param value
     *     allowed object is
     *     {@link WorkDaysType }
     *     
     */
    public void setWorkDays(WorkDaysType value) {
        this.workDays = value;
    }

}
