package ru.sp.drf.market.queue;

import org.elasticsearch.common.Strings;
import org.redisson.api.listener.MessageListener;
import ru.domrf.rem.dto.bus.processes.ProcessActionMessage;
import ru.domrf.rem.utilities.logs.CustomLogger;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

public class EventBusListener implements MessageListener<ProcessActionMessage> {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    @Override
    public void onMessage(CharSequence channel, ProcessActionMessage msg) {
        if (msg.getObject() != null) {
            LOG.debug(String.join(", ",
                    "Action from redis key: ",
                    msg.getObject().getId().toString(),
                    "event:",
                    msg.getObject().getPhase().name(),
                    "action code:",
                    msg.getObject().getActionCode(),
                    "parameters:",
                    (isValid(msg.getObject().getParameters()) ? Strings.arrayToCommaDelimitedString(msg.getObject().getParameters().entrySet().stream().toArray()) : ""))
            );
        } else {
            LOG.debug("Empty response for messageId: ");
        }
    }
}

