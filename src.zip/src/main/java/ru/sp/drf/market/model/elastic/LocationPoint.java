package ru.sp.drf.market.model.elastic;

import java.io.Serializable;

import static ru.sp.drf.market.model.elastic.Attributes.POINT_TYPE;

public class LocationPoint implements Serializable {
    private String type = POINT_TYPE;
    private String[] coordinates;

    public LocationPoint() {
    }

    public LocationPoint(String[] coordinates) {
        this.coordinates = coordinates;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String[] getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(String[] coordinates) {
        this.coordinates = coordinates;
    }

}
