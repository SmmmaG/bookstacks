
package ru.sp.drf.market.exchange.domclick;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for flatType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="flatType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="flat_id" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="apartment" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="room">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="3"/>
 *               &lt;enumeration value="1"/>
 *               &lt;enumeration value="4"/>
 *               &lt;enumeration value="2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="floor" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="plan" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="balcony" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="renovation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="price" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="area" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="kitchen_area" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="living_area" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="window_view" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="bathroom" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "flatType", propOrder = {
    "flatId",
    "apartment",
    "room",
    "floor",
    "plan",
    "balcony",
    "renovation",
    "price",
    "area",
    "kitchenArea",
    "livingArea",
    "windowView",
    "bathroom"
})
public class FlatType {

    @XmlElement(name = "flat_id", required = true)
    protected String flatId;
    @XmlElement(required = true)
    protected String apartment;
    @XmlElement(required = true)
    protected String room;
    @XmlElement(required = true)
    protected String floor;
    @XmlElement(required = true)
    protected String plan;
    @XmlElement(required = true)
    protected String balcony;
    @XmlElement(required = true)
    protected String renovation;
    @XmlElement(required = true)
    protected String price;
    @XmlElement(required = true)
    protected String area;
    @XmlElement(name = "kitchen_area", required = true)
    protected String kitchenArea;
    @XmlElement(name = "living_area", required = true)
    protected String livingArea;
    @XmlElement(name = "window_view", required = true)
    protected String windowView;
    @XmlElement(required = true)
    protected String bathroom;

    /**
     * Gets the value of the flatId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlatId() {
        return flatId;
    }

    /**
     * Sets the value of the flatId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlatId(String value) {
        this.flatId = value;
    }

    /**
     * Gets the value of the apartment property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApartment() {
        return apartment;
    }

    /**
     * Sets the value of the apartment property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApartment(String value) {
        this.apartment = value;
    }

    /**
     * Gets the value of the room property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoom() {
        return room;
    }

    /**
     * Sets the value of the room property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoom(String value) {
        this.room = value;
    }

    /**
     * Gets the value of the floor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFloor() {
        return floor;
    }

    /**
     * Sets the value of the floor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFloor(String value) {
        this.floor = value;
    }

    /**
     * Gets the value of the plan property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPlan() {
        return plan;
    }

    /**
     * Sets the value of the plan property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPlan(String value) {
        this.plan = value;
    }

    /**
     * Gets the value of the balcony property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBalcony() {
        return balcony;
    }

    /**
     * Sets the value of the balcony property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBalcony(String value) {
        this.balcony = value;
    }

    /**
     * Gets the value of the renovation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRenovation() {
        return renovation;
    }

    /**
     * Sets the value of the renovation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRenovation(String value) {
        this.renovation = value;
    }

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrice(String value) {
        this.price = value;
    }

    /**
     * Gets the value of the area property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getArea() {
        return area;
    }

    /**
     * Sets the value of the area property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setArea(String value) {
        this.area = value;
    }

    /**
     * Gets the value of the kitchenArea property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKitchenArea() {
        return kitchenArea;
    }

    /**
     * Sets the value of the kitchenArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKitchenArea(String value) {
        this.kitchenArea = value;
    }

    /**
     * Gets the value of the livingArea property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLivingArea() {
        return livingArea;
    }

    /**
     * Sets the value of the livingArea property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLivingArea(String value) {
        this.livingArea = value;
    }

    /**
     * Gets the value of the windowView property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWindowView() {
        return windowView;
    }

    /**
     * Sets the value of the windowView property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWindowView(String value) {
        this.windowView = value;
    }

    /**
     * Gets the value of the bathroom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBathroom() {
        return bathroom;
    }

    /**
     * Sets the value of the bathroom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBathroom(String value) {
        this.bathroom = value;
    }

}
