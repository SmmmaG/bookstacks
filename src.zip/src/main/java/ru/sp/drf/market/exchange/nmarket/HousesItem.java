package ru.sp.drf.market.exchange.nmarket;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
public class HousesItem  extends  Storable<ComplexesItem,UUID> implements HasStatistic{

	@JsonProperty("houseInfo")
	private HouseInfo houseInfo;

	@JsonProperty("activeFlatsCount")
	private int activeFlatsCount;

	@JsonProperty("flatsCount")
	private int flatsCount;

	@JsonProperty("statisticByRooms")
	private StatisticByRooms statisticByRooms;

	private UUID houseUUId;

	public UUID getHouseUUId() {
		return houseUUId;
	}

	public void setHouseUUId(UUID houseUUId) {
		this.houseUUId = houseUUId;
	}

	public void setHouseInfo(HouseInfo houseInfo){
		this.houseInfo = houseInfo;
	}

	public HouseInfo getHouseInfo(){
		return houseInfo;
	}

	public void setActiveFlatsCount(int activeFlatsCount){
		this.activeFlatsCount = activeFlatsCount;
	}

	public int getActiveFlatsCount(){
		return activeFlatsCount;
	}

	public void setFlatsCount(int flatsCount){
		this.flatsCount = flatsCount;
	}

	public int getFlatsCount(){
		return flatsCount;
	}

	public void setStatisticByRooms(StatisticByRooms statisticByRooms){
		this.statisticByRooms = statisticByRooms;
	}

	@Override
	public StatisticByRooms getStatisticByRooms(){
		return statisticByRooms;
	}

	@Override
	public UUID save(ComplexesItem complexesItem, AtomicOperation dataSourse) throws Exception {
		UUID houseUUId = dataSourse.addHouse(this, complexesItem.getComplexUUId());
		this.setHouseUUId(houseUUId);
		statisticByRooms.save(this,dataSourse);
		dataSourse.addApprovedCreditProducts(houseInfo.getApprovedCreditProducts(),houseUUId,houseInfo.getHouseId());
		for(DiscountsItem discount : houseInfo.getDiscounts()){
			discount.save(this,dataSourse);
		}
		return houseUUId;
	}

	@Override
 	public String toString(){
		return 
			"HousesItem{" + 
			"houseInfo = '" + houseInfo + '\'' + 
			",activeFlatsCount = '" + activeFlatsCount + '\'' + 
			",flatsCount = '" + flatsCount + '\'' + 
			",statisticByRooms = '" + statisticByRooms + '\'' + 
			"}";
		}
}