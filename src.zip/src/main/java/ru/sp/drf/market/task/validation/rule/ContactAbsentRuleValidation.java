package ru.sp.drf.market.task.validation.rule;

import com.querydsl.core.types.Predicate;

public class ContactAbsentRuleValidation implements RuleValidation{

    @Override
    public Predicate toPredicate() {
        return null;
    }
}
