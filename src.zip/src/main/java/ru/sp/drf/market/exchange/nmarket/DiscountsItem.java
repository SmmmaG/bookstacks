package ru.sp.drf.market.exchange.nmarket;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
public class DiscountsItem extends Storable<HousesItem, UUID>{

	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

	@JsonProperty("dateBegin")
	private String dateBegin;

	@JsonProperty("name")
	private String name;

	@JsonProperty("description")
	private String description;

	@JsonProperty("dateEnd")
	private String dateEnd;

	public void setDateBegin(String dateBegin){
		this.dateBegin = dateBegin;
	}

	public String getDateBegin(){
		return dateBegin;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return description;
	}

	public void setDateEnd(String dateEnd){
		this.dateEnd = dateEnd;
	}

	public String getDateEnd(){
		return dateEnd;
	}

	public Timestamp getDateEndStamp () throws ParseException {
		return new Timestamp(sdf.parse(dateEnd).getTime());
	}

	public Timestamp getDateBeginStamp () throws ParseException {
		return new Timestamp(sdf.parse(dateBegin).getTime());
	}

	@Override
	public UUID save(HousesItem housesItem, AtomicOperation dataSource) throws Exception {
		return dataSource.addDiscount(this,housesItem.getHouseUUId(),housesItem.getHouseInfo().getHouseId());
	}
	@Override
 	public String toString(){
		return 
			"DiscountsItem{" + 
			"dateBegin = '" + dateBegin + '\'' + 
			",name = '" + name + '\'' + 
			",description = '" + description + '\'' + 
			",dateEnd = '" + dateEnd + '\'' + 
			"}";
		}
}