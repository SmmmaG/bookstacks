package ru.sp.drf.market.dataloader.profitbase;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.FeedLoader;
import ru.sp.drf.market.exchange.profitbase.*;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

@Component
public class ProfitbaseLoader extends FeedLoader<ProfitBaseDataSource> {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    private static String PROFITBASE_APP_TOKEN;
    private static String PROFITBASE_PREFIX_AUTH;
    private static String PROFITBASE_PAGE_SIZE;
    private static String PROFITBASE_PREFIX_COMPLEX;
    private static String PROFITBASE_PREFIX_BUILDING;
    private static String PROFITBASE_PREFIX_FLAT;
    private static String PROFITBASE_ACTIVITE_TOKEN = "activite-token";


    @Override
    protected boolean executeTasks() throws Exception {
        operation.setAutoCommit(false);
        onPrepare();
        onDisable();
        onParse();
        operation.commit();
        onLoad();
        onAfter();
        operation.commit();
        return true;
    }

    @Override
    protected void executeDisableTasks() throws Exception {
        operation.setAutoCommit(false);
        onDisable();
        onAfter();
        operation.commit();
    }

    @Override
    public void onPrepare() throws Exception {
        LOG.info("on clear old profitbase Tables");
        operation.prepareTables(feedLog);
    }

    @Override
    public void onValidate() {
        //NOT NEED FOR NMARKET
    }


    @Override
    public void onAfter() throws Exception {
        LOG.info("on post processing phase");
        operation.recalculation(feedLog);
    }


    @Override
    public void onParse() throws Exception {
        StringBuffer fullFeed = new StringBuffer();
        LOG.info("Find Complexes");
        String token = getToken().getAccessToken();

        String infoBlock = storeData(buildingUrl(feedLog.getFeed().getUrl(), PROFITBASE_PREFIX_COMPLEX, token), SearchComplexesResponse.class);
        fullFeed.append(infoBlock);
        LOG.info("Find Buildings");
        infoBlock = storeData(buildingUrl(feedLog.getFeed().getUrl(), PROFITBASE_PREFIX_BUILDING, token), SearchHousesResponse.class);
        fullFeed.append(infoBlock);
        LOG.info("Find Appartments");
        infoBlock = storeData(buildingUrl(feedLog.getFeed().getUrl(), PROFITBASE_PREFIX_FLAT, token), SearchApprtmentsResponse.class);
        fullFeed.append(infoBlock);
        LoadLogger.writeFeedFile(feedLog, fullFeed.toString().toCharArray());
    }

    private String buildingUrl(String baseUrl, String method, String token) {
        StringBuffer sb = new StringBuffer();
        String[] part = baseUrl.split("##");
        if (part.length > 0) {
            sb.append(part[0]);
        } else
            sb.append(baseUrl);
        sb.append(method);
        if (token != null) {
            sb.append("?access_token=");
            sb.append(token);

        } else {
            LOG.error("Authorize token is null");
        }

        return sb.toString();
    }

    private <P extends Response> String storeData(String urlPrefix, Class<P> responseClazz) throws Exception {
        int total = 1;
        StringBuffer pages = new StringBuffer();
        SinglePage page = getSinglePage(urlPrefix, responseClazz);
        pages.append(page.getPageContent());
        if (page.getResponseEntity().getStatusCodeValue() == 200) {
            P response = (P) page.getResponseEntity().getBody();
//TODO count loaded object
// total = response.getStatistics().getTotalPages();
            storeData(response, feedLog);
        } else {
            throw new Exception("Unexpected error on read request");
        }
        return pages.toString();
    }

    private void storeData(Response page, FeedLog feedLog) throws Exception {
        page.save(operation);
    }

    public GetTokenResponse getToken() throws IOException {
        HttpURLConnection connection = null;
        int responseCode = 0;
        try {
            if (isValid(feedLog.getFeed().getUrl())) {
                //Create connection
                String[] resources = feedLog.getFeed().getUrl().split("##");
                URL url = new URL(resources[0].concat(PROFITBASE_PREFIX_AUTH));

                String urlParameters = PROFITBASE_APP_TOKEN.replaceAll(PROFITBASE_ACTIVITE_TOKEN, extractActiviteCode(resources[1]));

                byte[] postData = urlParameters.getBytes(StandardCharsets.UTF_8);
                int postDataLength = postData.length;

                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
                connection.setRequestProperty("Content-Length", Integer.toString(postDataLength));
                connection.setDoOutput(true);
                //Send request
                DataOutputStream wr = new DataOutputStream(
                        connection.getOutputStream());
                wr.writeBytes(urlParameters);
                //Get Response
                responseCode = connection.getResponseCode();
                InputStream is = connection.getInputStream();
                BufferedReader rd = new BufferedReader(new InputStreamReader(is));
                StringBuffer response = new StringBuffer();
                String line;
                while ((line = rd.readLine()) != null) {
                    response.append(line);
                    response.append('\r');
                }
                rd.close();

                ObjectMapper mapper = new ObjectMapper();
                GetTokenResponse tokenResponse = mapper.readValue(response.toString(), GetTokenResponse.class);
                return tokenResponse;
            } else {
                LOG.error("URL is null to feeds resource. Feed id: " + feedLog.getFeed().getId() + " code: " + feedLog.getFeed().getCode());
                return null;
            }
        } catch (IOException io) {
            io.printStackTrace();
            throw new IOException("Token exception " + new StringBuffer().append(io.getMessage()).append(" with code ").append(responseCode).toString());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private String extractActiviteCode(String resource) {
        String[] params = resource.split("=");
        if (params.length > 1)
            return params[1];
        else return "";
    }


    public <P> SinglePage getSinglePage(String searchPrefix, Class<P> responseClazz) {
        HttpURLConnection connection = null;
        int responseCode = 0;
        String pageContent = null;
        try {
            //Create connection
            URL url = new URL(searchPrefix);
            LOG.info("Send ".concat(searchPrefix));
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.connect();
            //Get Response
            responseCode = connection.getResponseCode();
            InputStream is = connection.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuffer responseBody = new StringBuffer();
            String line;
            while ((line = rd.readLine()) != null) {
                responseBody.append(line);
                responseBody.append('\r');
            }
            rd.close();
            ObjectMapper mapper = new ObjectMapper();
            pageContent = responseBody.toString();
            pageContent = pageContent.replace("ё", "е").replace("Ё", "Е");
            P response = mapper.readValue(pageContent, responseClazz);

            return new SinglePage(pageContent, new ResponseEntity(response, HttpStatus.OK));
        } catch (IOException io) {
            io.printStackTrace();
            responseCode = responseCode == 200 ? 500 : responseCode;
            return new SinglePage(pageContent, new ResponseEntity(io.getMessage(), HttpStatus.valueOf(responseCode)));
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

    }


    @Override
    public void onLoad() throws Exception {
        LOG.info("onLoad feedLog = " + feedLog);
        operation.storeData(feedLog);

    }

    @Override
    public void onDisable() throws IOException, SQLException {
        LOG.info("on Disable old data");
        operation.disableData(feedLog);
    }

    private class SinglePage {
        private final String pageContent;
        private final ResponseEntity responseEntity;

        public SinglePage(String pageContent, ResponseEntity responseEntity) {
            this.pageContent = pageContent;
            this.responseEntity = responseEntity;
        }

        public String getPageContent() {
            return pageContent;
        }

        public ResponseEntity getResponseEntity() {
            return responseEntity;
        }
    }


    @Value("${spring.feedloader.profitbase.token}")
    public void setProfitbaseToken(String appToken) {
        PROFITBASE_APP_TOKEN = appToken;
    }

    @Value("${spring.feedloader.profitbase.url.auth-prefix}")
    public void setProfitbaseAuthUrl(String authPrefix) {
        PROFITBASE_PREFIX_AUTH = authPrefix;
    }

    @Value("${spring.feedloader.profitbase.url.complex-prefix}")
    public void setProfitbaseComplexUrl(String complexPrefix) {
        PROFITBASE_PREFIX_COMPLEX = complexPrefix;
    }

    @Value("${spring.feedloader.profitbase.url.building-prefix}")
    public void setProfitbasePrefixBuilding(String buildingPrefix) {
        PROFITBASE_PREFIX_BUILDING = buildingPrefix;
    }

    @Value("${spring.feedloader.profitbase.url.flat-prefix}")
    public void setProfitbasePrefixFlat(String flatPrefix) {
        PROFITBASE_PREFIX_FLAT = flatPrefix;
    }

    @Value("${spring.feedloader.nmarket.pagesize}")
    public void setNmarketPageSize(String nmarketPageSize) {
        PROFITBASE_PAGE_SIZE = nmarketPageSize;
    }

//    @Value("${spring.feedloader.nmarket.regions}")
//    public void setNmarketRegions(String[] nmarketRegions) {
//        PROFITBASE_REGIONS = nmarketRegions;
//    }


    @Override
    public void initConnection() throws Exception {
        operation = new ProfitBaseDataSource();
    }
}
