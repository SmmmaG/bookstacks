package ru.sp.drf.market.model.fias;


import ru.sp.drf.market.model.BasicItem;
import ru.sp.drf.market.model.elastic.SplitBuilder;
import ru.sp.drf.market.model.elastic.SuggestRequest;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static ru.sp.drf.market.config.loaders.FiasConfig .ADDRESS_FIELDS_FOR_CREATE;
import static ru.sp.drf.market.model.elastic.Attributes.*;
import static ru.sp.drf.market.model.elastic.Attributes.SUGGEST_NAME;
import static ru.sp.drf.market.utilities.HelperUtils.formatName;
import static ru.sp.drf.market.utilities.HelperUtils.getValue;

public interface DataRow extends BasicItem<UUID> {


    UUID getId();

    String getAddress();

    String getRegionid();

    String getCityid();

    UUID getParentId();

    String getName();

    String getPrefix();

    Integer getLevel();

    @Override
    default Map<String, Object> toMap(String... attributes) {
        Map<String, Object> result = new HashMap<>();
        for (String field : attributes) {
            switch (field) {
                case ADDRESS:
                    result.put(field, getValue(formatName(this.getAddress())));
                    break;
                case UUID:
                    result.put(field, this.getId().toString());
                    break;
                case REGION_CODE:
                    result.put(field, getValue(this.getRegionid()));
                    break;
                case CITY_CODE:
                    result.put(field, getValue(this.getCityid()));
                    break;
                case PREFIX_OAS:
                    result.put(field, getValue(this.getPrefix()));
                    break;
                case LEVEL_OAS:
                    result.put(field, AOLevel.findByCode(this.getLevel()).getType());
                    break;
                case NAME_OAS:
                    result.put(field, getValue(formatName(this.getName())));
                    break;
                case COUNTRY_OAS:
                    result.put(field, "Россия");
                    break;
                case PARENT_ID_OAS:
                    result.put(field, getValue(this.getParentId()));
                    break;
                case ACTUAL_ON:
                    result.put(field, new Date());
                    break;
                default:
                    result.put(field, "");
                    break;
            }
        }
        SuggestRequest request = new SuggestRequest(getValue((String) result.get(NAME)), SplitBuilder.split(getValue((String) result.get(NAME)), " ").split("-").toArray());
        request.getContext().add(CONTEXTS_AREA_CODE, result.get(REGION_CODE), result.get(CITY_CODE));
        request.getContext().add(LEVEL_OAS, result.get(LEVEL_OAS));
        result.put(SUGGEST_NAME, request);

        return result;

    }

    @Override
    default Map<String, Object> toMap() {
        return toMap(ADDRESS_FIELDS_FOR_CREATE);
    }
}
