
package ru.sp.drf.market.exchange.domclick;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.storefront.exchange.domclick package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Complexes_QNAME = new QName("", "complexes");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.storefront.exchange.domclick
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ComplexesType }
     * 
     */
    public ComplexesType createComplexesType() {
        return new ComplexesType();
    }

    /**
     * Create an instance of {@link ProfitsMainType }
     * 
     */
    public ProfitsMainType createProfitsMainType() {
        return new ProfitsMainType();
    }

    /**
     * Create an instance of {@link ComplexType }
     * 
     */
    public ComplexType createComplexType() {
        return new ComplexType();
    }

    /**
     * Create an instance of {@link WorkDayType }
     * 
     */
    public WorkDayType createWorkDayType() {
        return new WorkDayType();
    }

    /**
     * Create an instance of {@link SalesInfoType }
     * 
     */
    public SalesInfoType createSalesInfoType() {
        return new SalesInfoType();
    }

    /**
     * Create an instance of {@link DescriptionMainType }
     * 
     */
    public DescriptionMainType createDescriptionMainType() {
        return new DescriptionMainType();
    }

    /**
     * Create an instance of {@link DeveloperType }
     * 
     */
    public DeveloperType createDeveloperType() {
        return new DeveloperType();
    }

    /**
     * Create an instance of {@link WorkDaysType }
     * 
     */
    public WorkDaysType createWorkDaysType() {
        return new WorkDaysType();
    }

    /**
     * Create an instance of {@link FlatType }
     * 
     */
    public FlatType createFlatType() {
        return new FlatType();
    }

    /**
     * Create an instance of {@link FlatsType }
     * 
     */
    public FlatsType createFlatsType() {
        return new FlatsType();
    }

    /**
     * Create an instance of {@link ProfitMainType }
     * 
     */
    public ProfitMainType createProfitMainType() {
        return new ProfitMainType();
    }

    /**
     * Create an instance of {@link BuildingType }
     * 
     */
    public BuildingType createBuildingType() {
        return new BuildingType();
    }

    /**
     * Create an instance of {@link BuildingsType }
     * 
     */
    public BuildingsType createBuildingsType() {
        return new BuildingsType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ComplexesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "complexes")
    public JAXBElement<ComplexesType> createComplexes(ComplexesType value) {
        return new JAXBElement<ComplexesType>(_Complexes_QNAME, ComplexesType.class, null, value);
    }

}
