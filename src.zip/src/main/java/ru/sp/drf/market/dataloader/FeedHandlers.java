package ru.sp.drf.market.dataloader;

public enum FeedHandlers {
    Yandex("yandex"),
    Domclick("domclick"),
    Cian("cian"),
    Profitbase("profitbase"),
    NMarket("nmarket"),
    NMarketYandex("nmarket-yandex"),
    FIAS("fias");

    FeedHandlers(String handlerName) {
        this.handlerName = handlerName;
    }

    private String handlerName;

    public String getHandlerName() {
        return handlerName;
    }
}
