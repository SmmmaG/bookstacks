package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.Objects;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class ComplexesItem extends Storable<Object, UUID> {

    @JsonProperty("id")
    private int complexId;
    @JsonProperty("title")
    private String title;
    @JsonProperty("type")
    private String type;
    @JsonProperty("region")
    private String region;
    @JsonProperty("district")
    private String district;
    @JsonProperty("locality")
    private String locality;
    @JsonProperty("developer")
    private String developer;
    @JsonProperty("developer_brand")
    private String developersBrand;
    @JsonProperty("banks")
    private String banks;
    @JsonProperty("currency")
    private String currency;
    @JsonIgnore
    private UUID complexUUId;

    public int getComplexId() {
        return complexId;
    }

    public void setComplexId(int complexId) {
        this.complexId = complexId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public String getDevelopersBrand() {
        return developersBrand;
    }

    public void setDevelopersBrand(String developersBrand) {
        this.developersBrand = developersBrand;
    }

    public String getBanks() {
        return banks;
    }

    public void setBanks(String banks) {
        this.banks = banks;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }



    public UUID getComplexUUId() {
        return complexUUId;
    }

    public void setComplexUUId(UUID complexUUId) {
        this.complexUUId = complexUUId;
    }


    @Override
    public UUID save(Object parent, AtomicOperation dataSourse) throws Exception {
        UUID complexUUId = dataSourse.addComplex(this);
        this.setComplexUUId(complexUUId);
        return complexUUId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ComplexesItem)) return false;
        ComplexesItem that = (ComplexesItem) o;
        return complexId == that.complexId &&
                Objects.equals(title, that.title) &&
                Objects.equals(type, that.type) &&
                Objects.equals(region, that.region) &&
                Objects.equals(district, that.district) &&
                Objects.equals(locality, that.locality) &&
                Objects.equals(developer, that.developer) &&
                Objects.equals(developersBrand, that.developersBrand) &&
                Objects.equals(banks, that.banks) &&
                Objects.equals(currency, that.currency) &&
                Objects.equals(complexUUId, that.complexUUId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(complexId, title, type, region, district, locality, developer, developersBrand, banks, currency, complexUUId);
    }
}