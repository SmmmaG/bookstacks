package ru.sp.drf.market;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

@SpringBootApplication
@EnableScheduling
@EntityScan(basePackages = "ru.domrf.rem.domain.admin", basePackageClasses = ru.domrf.rem.domain.Complex.class)
public class Application {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(Application.class);
        Environment environment = app.run(args).getEnvironment();
        System.out.println("Environment:");
        printActiveProperties(environment);
    }

    private static void printActiveProperties(Environment environment) {

        System.out.println("************************* ACTIVE APP PROPERTIES ******************************");

        List<MapPropertySource> propertySources = new ArrayList<>();
        ((ConfigurableEnvironment) environment).getPropertySources().forEach(it -> {
            if (it instanceof MapPropertySource && it.getName().contains("applicationConfig")) {
                propertySources.add((MapPropertySource) it);
            }
        });

        propertySources.stream()
                .map(propertySource -> propertySource.getSource().keySet())
                .flatMap(Collection::stream)
                .distinct()
                .sorted()
                .forEach(key -> {
                    try {
                        System.out.println(key + "=" + environment.getProperty(key));
                    } catch (Exception e) {
                        System.out.println(key + " -> " + e.getMessage());
                    }
                });
        System.out.println("******************************************************************************");
    }
}
