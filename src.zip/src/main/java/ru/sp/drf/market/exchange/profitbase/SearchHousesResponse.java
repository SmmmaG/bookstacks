package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import ru.domrf.rem.utilities.logs.CustomLogger;

import javax.annotation.Generated;
import java.util.List;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchHousesResponse implements Response {

    private static final CustomLogger LOG = CustomLogger.getLogger();

    @JsonProperty("success")
    private String success;

    @JsonProperty("data")
    private List<HousesItem> houses;

    public List<HousesItem> getHouses() {
        return houses;
    }

    public void setHouses(List<HousesItem> houses) {
        this.houses = houses;
    }

    @Override
    public void save(AtomicOperation operation) throws Exception {
        for (HousesItem item : houses) {
            if (item.getComplexId() == 0) {
                LOG.info("Houseid=" + item);
            }
            UUID houseUUID = item.save(operation.getContextLoader().getComplexById(item.getComplexId()), operation);
            item.setHouseUUId(houseUUID);
            operation.getContextLoader().putHouse(item.getHouseId(), item);
        }


    }
}