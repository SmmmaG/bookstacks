package ru.sp.drf.market.dto.validation;

import ru.sp.drf.market.dataloader.validation.ErrorHandler;
import ru.sp.drf.market.dataloader.validation.ValidationMapKey;

import java.io.IOException;
import java.util.*;

public class ValidationResultDto {
    private int status;
    private ValidationStatisticsDto statistics;
    private List<ValidationErrorDto> errors;

    public ValidationResultDto(int status) {
        this.status = status;
        this.errors = new ArrayList();
    }

    public ValidationResultDto(ErrorHandler errorHandler) throws IOException {
        this.status = errorHandler.getValidationStatus();
        this.statistics = errorHandler.countStatistics();
        this.errors = new ArrayList();
        for (ValidationMapKey mapKey : errorHandler.getValidationMap().keySet()) {
            errors.add(new ValidationErrorDto(errors.size(),
                    mapKey.getMessage(),
                    errorHandler.getValidationMap().get(mapKey),null));
        }
    }

    public void addError(String message) {
        this.errors.add(new ValidationErrorDto(errors.size(), message));
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public ValidationStatisticsDto getStatistics() {
        return statistics;
    }

    public void setStatistics(ValidationStatisticsDto statistics) {
        this.statistics = statistics;
    }

    public List<ValidationErrorDto> getErrors() {
        return errors;
    }

    public void setErrors(List<ValidationErrorDto> errors) {
        this.errors = errors;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ValidationResultDto that = (ValidationResultDto) o;
        return status == that.status &&
                Objects.equals(statistics, that.statistics) &&
                Objects.equals(errors, that.errors);
    }

    @Override
    public int hashCode() {
        return Objects.hash(status, statistics, errors);
    }

    @Override
    public String toString() {
        return "ValidationResultDto{" +
                "status=" + status +
                ", statistics=" + statistics +
                ", errors=" + errors +
                '}';
    }
}
