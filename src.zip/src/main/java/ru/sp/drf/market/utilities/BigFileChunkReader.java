package ru.sp.drf.market.utilities;

import ru.domrf.rem.utilities.logs.CustomLogger;

import java.io.*;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

public class BigFileChunkReader {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    private char[] buffer;
    private String nextChunk;
    private BufferedReader bufReader;

    public BigFileChunkReader (File file, int chunkSize) throws IOException {
        FileReader textFileReader = new FileReader(file);
        bufReader = new BufferedReader(textFileReader);
        buffer = new char[chunkSize];
        nextChunk = readNextChunk();
    }

    public boolean hasNextChunk() {

        if (nextChunk == null) {
                nextChunk = readNextChunk();
        }
        return ( nextChunk != null );
    }

    public String getNextChunk() {

        if (nextChunk != null) {
            String s = nextChunk;
            nextChunk = readNextChunk();
            return s;
        }
        return null;
    }

    private String readNextChunk() {
        int numberOfCharsRead = 0;
        try {
            numberOfCharsRead = bufReader.read(buffer);
            if (numberOfCharsRead != -1 ) {
                return String.valueOf(buffer, 0, numberOfCharsRead);
            }
        } catch (IOException e) {
           LOG.error("Unexpected exception", e);
        }
        return null;
    }

    public void close(){
        if(isValid(this.bufReader)){
            try {
                this.bufReader.close();
            } catch (IOException e) {
               LOG.error("Unexpected exception", e);
            }
        }
    }
}
