package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.Objects;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Currency {

    @JsonProperty("code")
    private String code;
    @JsonProperty("symbol")
    private String symbol;
    @JsonProperty("title")
    private String title;
    @JsonProperty("shortName")
    private String shortName;
    @JsonProperty("unicodeSymbol")
    private int  unicodeSymbol;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public int getUnicodeSymbol() {
        return unicodeSymbol;
    }

    public void setUnicodeSymbol(int unicodeSymbol) {
        this.unicodeSymbol = unicodeSymbol;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Currency)) return false;
        Currency currency = (Currency) o;
        return unicodeSymbol == currency.unicodeSymbol &&
                Objects.equals(code, currency.code) &&
                Objects.equals(symbol, currency.symbol) &&
                Objects.equals(title, currency.title) &&
                Objects.equals(shortName, currency.shortName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, symbol, title, shortName, unicodeSymbol);
    }

    @Override
    public String toString() {
        return "Currency{" +
                "code='" + code + '\'' +
                ", symbol=" + symbol +
                ", title='" + title + '\'' +
                ", shortName='" + shortName + '\'' +
                ", unicodeSymbol=" + unicodeSymbol +
                '}';
    }
}
