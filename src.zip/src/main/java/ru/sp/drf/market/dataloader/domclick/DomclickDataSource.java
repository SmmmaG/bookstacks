package ru.sp.drf.market.dataloader.domclick;

import ru.domrf.rem.utilities.ScriptExecutor.ScriptRunner;
import ru.sp.drf.market.repository.sql.SQL;
import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptExecutor;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.dataloader.validation.ValidationEvents;
import ru.sp.drf.market.repository.BatchOperation;
import ru.sp.drf.market.repository.sql.SQLDataSource;
import ru.sp.drf.market.repository.sql.SQLDomclick;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.IOException;
import java.sql.SQLException;
import java.util.UUID;

import static ru.sp.drf.market.dataloader.MarketDataSource.getConnection;

public class DomclickDataSource extends SQLDataSource implements BatchOperation {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    public DomclickDataSource() throws Exception {
        super(getConnection());
    }

    public void prepareSchemForValidation(FeedLog feedLog) throws IOException, SQLException {
        LOG.info("Create temporary tables");
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript(
                "create_schema", new Object[]{getSchemaName()});

        LoadLogger.writeScriptLog(result, feedLog, false, FeedEventTypes.Prep_Temp_schema);
    }

    public void prepareTables(FeedLog feedLog) throws IOException, SQLException {
        LOG.info("Create temporary tables");
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript(
                "domclick/main/truncate-tables");

        LoadLogger.writeScriptLog(result, feedLog, false, FeedEventTypes.Prep_Temp_tbls);
    }


    public void storeData(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName(), 1800);
        UUID feedUuid = feedLog.getFeed().getId();
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLDomclick.getTempComplexCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLDomclick.getTempBuildCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Build);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLDomclick.getTempFlatCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/parking-type-insert"), feedLog, true, FeedEventTypes.Add_Parking_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/developer/contact-developer-update"), feedLog, true, FeedEventTypes.Upd_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/developer/contact-developer-insert"), feedLog, true, FeedEventTypes.Add_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/developer/logo-photo-update"), feedLog, true, FeedEventTypes.Upd_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/developer/logo-photo-insert"), feedLog, true, FeedEventTypes.Add_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/developer/developer-update"), feedLog, true, FeedEventTypes.Upd_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/developer/developer-insert"), feedLog, true, FeedEventTypes.Add_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/balcony-type-update"), feedLog, true, FeedEventTypes.Upd_Balcony_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/balcony-type-insert"), feedLog, true, FeedEventTypes.Add_Balcony_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/address-complex-update"), feedLog, true, FeedEventTypes.Upd_Cmpx_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/address-complex-insert"), feedLog, true, FeedEventTypes.Add_Cmpx_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/address-building-update"), feedLog, true, FeedEventTypes.Upd_Build_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/address-building-insert"), feedLog, true, FeedEventTypes.Add_Build_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/advantage-insert"), feedLog, true, FeedEventTypes.Add_Advantage);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("domclick/main/complex/complex-stage-1-tmp-create", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/complex/complex-stage-2-update", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Upd_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/complex/complex-stage-3-insert", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Add_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/complex/complex-stage-4-cross-insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Cmpx_Feed);
        scriptExecutor.executeInsUpd("domclick/main/complex/complex-stage-5-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("domclick/main/complex/complex-photo-stage-1-tmp-create", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLDomclick.updateDocumentPhotoComplex.getSQL()), feedLog, true, FeedEventTypes.Upd_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/complex/complex-photo-stage-2-document-photo-insert"), feedLog, true, FeedEventTypes.Add_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/complex/complex-photo-stage-3-complex-document-photo-insert"), feedLog, true, FeedEventTypes.Asgn_Photo_Cmpx);
        scriptExecutor.executeInsUpd("domclick/main/complex/complex-photo-stage-4-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("domclick/main/building/building-stage-1-tmp-create", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/building/building-stage-2-update", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/building/building-stage-3-insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/building/building-stage-4-cross-insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Build_Feed);
        scriptExecutor.executeInsUpd("domclick/main/building/building-stage-5-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("domclick/main/building/building-photo-stage-1-tmp-create", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Prep_Building_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLDomclick.updateDocumentPhotoBuilding.getSQL()), feedLog, true, FeedEventTypes.Upd_Photo_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/building/building-photo-stage-2-document-photo-insert"), feedLog, true, FeedEventTypes.Add_Photo_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("domclick/main/complex/complex-infrastructure-stage-1-tmp-create", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/complex/complex-infrastructure-stage-2-update", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Cmpx_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/complex/complex-infrastructure-stage-3-insert", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Cmpx_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/complex/complex-infrastructure-stage-4-complex-update"), feedLog, true, FeedEventTypes.Asgn_Cmpx_Infstr);
        scriptExecutor.executeScript("domclick/main/complex/complex-infrastructure-stage-5-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("domclick/main/flat/flat-stage-1-tmp-create", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/flat/flat-stage-2-update", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/flat/flat-stage-3-insert", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/flat/flat-stage-4-cross-insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Flat_Feed);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("domclick/main/flat/flats-photo-stage-1-tmp-create", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/flat/flats-photo-stage-2-update"), feedLog, true, FeedEventTypes.Upd_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/flat/flats-photo-stage-3-insert"), feedLog, true, FeedEventTypes.Add_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/flat/flats-photo-stage-4-flats-update"), feedLog, true, FeedEventTypes.Asgn_Flats_photo);
        scriptExecutor.executeInsUpd("domclick/main/flat/flats-photo-stage-5-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/flat/prices-insert"), feedLog, true, FeedEventTypes.Add_Prices);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/flat/flat-prices-update", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Upd_Prices);
        scriptExecutor.executeInsUpd("domclick/main/flat/flat-stage-5-tmp-drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/address-sale-office-update"), feedLog, true, FeedEventTypes.Upd_Sales_Office_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/address-sale-office-insert"), feedLog, true, FeedEventTypes.Add_Sales_Office_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/contact-sales-office-update"), feedLog, true, FeedEventTypes.Upd_Sales_Office_Contact);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/contact-sales-office-insert"), feedLog, true, FeedEventTypes.Add_Sales_Office_Contact);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/seller-update"), feedLog, true, FeedEventTypes.Upd_Seller);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/seller-insert"), feedLog, true, FeedEventTypes.Add_Seller);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/sale-office-update"), feedLog, true, FeedEventTypes.Upd_Sales_Office);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/sale-office-insert"), feedLog, true, FeedEventTypes.Add_Sales_Office);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("domclick/main/salesoffice/seller-office-building-bind", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Asgn_Sales_Office_Building);
    }

    public void flatsCheckNonUniqueId(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        scriptExecutor.executeScript("domclick/validation/flats/insert-unique-flat-fields-check",
                new Object[]{ValidationEvents.notUniqueFlatId.getMessage(), feedLog.getId().toString()});
        LoadLogger.writeValidationLog(scriptExecutor.executeScript("domclick/validation/flats/flats-check-non-unique-flat-id",
                new Object[]{}), feedLog, FeedEventTypes.Flats_Check_Non_Unique_Internal_Id);
    }

    public void flatsCheckMandatoryFieldsValidation(FeedLog feedLog) throws Exception {
        StringBuilder fullPredicate = new StringBuilder();
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        String field = "flat_id";
        String predicate = " " + field + " IS NULL ";
        fullPredicate.append(predicate);
        scriptExecutor.executeScript("domclick/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldID.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "room";
        predicate = " " + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldRooms.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "price";
        predicate = " " + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldPrice.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "area";
        predicate = " " + field + " IS NULL OR " + field + " = 0 ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldSquare.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "floor";
        predicate = " " + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldFloor.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
//        field = "renovation";
//        predicate = field + " IS NULL ";
//        fullPredicate.append(" OR ").append(predicate);
//        scriptExecutor.executeScript("domclick/validation/flats/insert-mandatory-flat-fields-check",
//                new Object[]{predicate, ValidationEvents.fieldRenovation.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "plan";
        predicate = " " + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldPlan.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "price";
        predicate = " price < 300000 ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldLowPrice.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        LoadLogger.writeValidationLog(scriptExecutor.executeScript("domclick/validation/flats/flats-check-mandatory-fields",
                new Object[]{fullPredicate.toString()}), feedLog, FeedEventTypes.Flats_Check_Mandatory_Fields);
    }

    public void buildingsRemoveRelatedData(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());

        LoadLogger.writeValidationLog(scriptExecutor.executeScript("domclick/validation/buildings/buildings-remove-related-data",
                new Object[]{}), feedLog, FeedEventTypes.Buildings_Remove_Related_Data);

        complexesRemoveRelatedData(feedLog);
    }

    public void buildingsCheckNonUniqueId(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        scriptExecutor.executeScript("domclick/validation/buildings/insert-unique-building-fields-check",
                new Object[]{ValidationEvents.notUniqueBuildingId.getMessage(), feedLog.getId().toString(), feedLog.getId()});
        LoadLogger.writeValidationLog(scriptExecutor.executeScript("domclick/validation/buildings/buildings-check-non-unique-id",
                new Object[]{}), feedLog, FeedEventTypes.Buildings_Check_Non_Unique_Building_Custom_Id);
    }

    public void buildingsCheckMandatoryFieldsValidation(FeedLog feedLog) throws Exception {
        StringBuilder fullPredicate = new StringBuilder();
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        String field = "id";
        String predicate = " " + field + " IS NULL ";
        fullPredicate.append(predicate);
        scriptExecutor.executeScript("domclick/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldID.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "ready_quarter";
        predicate = " " + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldReadyQuarter.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "built_year";
        predicate = " " + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldReadyYear.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
//        field = "building_state";
//        predicate = field + " IS NULL ";
//        fullPredicate.append(" OR ").append(predicate);
//        scriptExecutor.executeScript("domclick/validation/buildings/insert-mandatory-building-fields-check",
//                new Object[]{predicate, ValidationEvents.fieldBuildingState.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
//        field = "floors";
//        predicate = field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
//        scriptExecutor.executeScript("domclick/validation/buildings/insert-mandatory-building-fields-check",
//                new Object[]{predicate, ValidationEvents.fieldBuildingFloors.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "address";
        predicate = " " + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldAddress.getMessage(), field, predicate, feedLog.getId().toString(), predicate});

        LoadLogger.writeValidationLog(scriptExecutor.executeScript("domclick/validation/buildings/buildings-check-mandatory-fields",
                new Object[]{fullPredicate.toString()}), feedLog, FeedEventTypes.Buildings_Check_Mandatory_Fields);
    }

    public void complexesRemoveRelatedData(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());

        LoadLogger.writeValidationLog(scriptExecutor.executeScript("domclick/validation/complexes/complexes-remove-related-data",
                new Object[]{}), feedLog, FeedEventTypes.Buildings_Remove_Related_Data);
    }

    public void complexesCheckNonUniqueId(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        scriptExecutor.executeScript("domclick/validation/complexes/insert-unique-complex-fields-check",
                new Object[]{ValidationEvents.notUniqueComplexId.getMessage(), feedLog.getId().toString()});
        LoadLogger.writeValidationLog(scriptExecutor.executeScript("domclick/validation/complexes/complexes-check-non-unique-id",
                new Object[]{}), feedLog, FeedEventTypes.Complexes_Check_Non_Unique_Complex_Custom_Id);
    }

    public void complexesCheckMandatoryFieldsValidation(FeedLog feedLog) throws Exception {
        StringBuilder fullPredicate = new StringBuilder();
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        String field = "id";
        String predicate = " dc." + field + " IS NULL ";
        fullPredicate.append(predicate);
        scriptExecutor.executeScript("domclick/validation/complexes/insert-mandatory-complex-fields-check",
                new Object[]{predicate, ValidationEvents.fieldID.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "namen";
        predicate = " dc." + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/complexes/insert-mandatory-complex-fields-check",
                new Object[]{predicate, ValidationEvents.fieldComplexName.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "developer_name";
        predicate = " dc." + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/complexes/insert-mandatory-complex-fields-check",
                new Object[]{predicate, ValidationEvents.fieldDeveloperName.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "developer_phone,sales_phone";
        predicate = " (dc.developer_phone IS NULL AND so.sales_phone IS NULL) ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/complexes/insert-mandatory-complex-fields-check",
                new Object[]{predicate, ValidationEvents.fieldDeveloperPhone.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        predicate = " (dc.developer_phone IS NOT NULL AND char_length(dc.developer_phone)<10) OR (so.sales_phone IS NOT NULL AND char_length(so.sales_phone)<10)";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/complexes/insert-mandatory-complex-fields-check",
                new Object[]{predicate, ValidationEvents.fieldWrongDeveloperPhone.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "address";
        predicate = " dc." + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/complexes/insert-mandatory-complex-fields-check",
                new Object[]{predicate, ValidationEvents.fieldAddress.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "latitude,longitude";
        predicate = " dc.latitude IS NULL OR dc.longitude IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/complexes/insert-mandatory-complex-fields-check",
                new Object[]{predicate, ValidationEvents.fieldCoordinates.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "latitude,longitude";
        predicate = " (dc.longitude IS NOT NULL AND dc.latitude IS NOT NULL AND\n" +
                "            ((dc.longitude NOT BETWEEN 20 AND 180 OR dc.latitude NOT BETWEEN 41.186158 AND 74)\n" +
                "            AND (dc.latitude NOT BETWEEN 20 AND 180 OR dc.longitude NOT BETWEEN 41.186158 AND 74))) ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("domclick/validation/complexes/insert-mandatory-complex-fields-check",
                new Object[]{predicate, ValidationEvents.fieldWrongCoordinates.getMessage(), field, predicate, feedLog.getId().toString(), predicate});

        LoadLogger.writeValidationLog(scriptExecutor.executeScript("domclick/validation/complexes/complexes-check-mandatory-fields",
                new Object[]{fullPredicate.toString()}), feedLog, FeedEventTypes.Complexes_Check_Mandatory_Fields);

        scriptExecutor.executeScript("domclick/validation/complexes/complex-reverse-coordinates",
                new Object[]{feedLog.getId()});
    }

    public int getCount(String sql) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        return scriptExecutor.executeQuery(sql).getRows();
    }

    public void addComplexes(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/complex/" + operation + "-complexes",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Cmpx);

    }

    public void addBuildings(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/building/" + operation + "-buildings",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Building);

    }

    public void addFlats(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/flat/" + operation + "-flats",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Flat);

    }

    public void addFlatRooms(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/flat/" + operation + "-flats-rooms",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Flats_rooms);
    }

    public void addComplexesPhoto(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/complex/" + operation + "-complexes-photos",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Photo_Cmpx);
    }

    public void addBuildingsPhoto(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER);
        ScriptResult result = scriptExecutor.executeScript("domclick/main/building/" + operation + "-buildings-photos",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Photo_Building);
    }

    public void addFlatsPhoto(FeedLog feedLog, String operation) throws SQLException, IOException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/flat/" + operation + "-flats-photo-plan",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Flats_photo);
    }

    public void addSalesOffice(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/salesoffice/" + operation + "-sales-office",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Sales_Office);
    }

    public void addSalesOfficeComplex(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/salesoffice/" + operation + "-sales-office-complex",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Sales_Office_Address);
    }

    public void updateBuildungReference(FeedLog feedLog) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/building/load-buildings-update-reference",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Building);

    }

    public void updateFlatReference(FeedLog feedLog) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("domclick/main/flat/load-flats-update-reference",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Building);

    }

    @Override
    public void addFlatMetro(FeedLog feedLog, String operation) throws Exception {

    }

    public void createTempSchema(String schemaName, FeedLog feedLog) throws SQLException {
        ScriptRunner scriptRunner = new ScriptRunner(connection, getSchemaName(), 10000);
        scriptRunner.runScript(SQL.createSchema.getSQL(), new Object[]{getSchemaName()});
        LoadLogger.writeScriptLog(new ScriptResult(scriptRunner.getErrorLogWriter(), scriptRunner.getUpdatedCount(), scriptRunner.getLogWriter(), scriptRunner.getJobTime()), feedLog, true, FeedEventTypes.Prep_Temp_schema);
    }

    public void removeTempSchema(String schemaName, FeedLog feedLog) throws SQLException {
        ScriptRunner scriptRunner = new ScriptRunner(connection, getSchemaName(), 10000);
        scriptRunner.runScript(SQL.dropSchema.getSQL(), new Object[]{getSchemaName()});
        LoadLogger.writeScriptLog(new ScriptResult(scriptRunner.getErrorLogWriter(), scriptRunner.getUpdatedCount(), scriptRunner.getLogWriter(), scriptRunner.getJobTime()), feedLog, true, FeedEventTypes.Remove_Temp_schema);
    }
}
