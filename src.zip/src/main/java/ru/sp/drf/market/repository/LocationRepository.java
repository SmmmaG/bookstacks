package ru.sp.drf.market.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import ru.domrf.rem.domain.address.Address;
import ru.domrf.rem.domain.address.BaseLocation;
import ru.domrf.rem.domain.address.Location;

import java.util.List;
import java.util.UUID;

@Repository
public interface LocationRepository extends JpaRepository<Location, UUID>{


    @Query("SELECT a FROM Location a WHERE a.actual = true AND a.point.latitude IS NOT NULL AND a.point.longitude IS NOT NULL AND (a.region IS NULL OR a.district IS NULL OR a.city IS NULL OR a.country IS NULL)")
    List<Location> findAllCrushedLocations();

    @Query("SELECT a FROM Location a WHERE a.actual = true AND a.point.latitude IS NOT NULL AND a.point.longitude IS NOT NULL ")
    List<Location> findAllLocations();

}