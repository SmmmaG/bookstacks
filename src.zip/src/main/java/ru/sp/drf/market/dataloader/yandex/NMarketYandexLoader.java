package ru.sp.drf.market.dataloader.yandex;

public class NMarketYandexLoader extends YandexLoader<NMarketYandexDataSource> {

    @Override
    protected void executeDisableTasks() throws Exception {
        operation.setAutoCommit(false);
        operation.setSchemaName("nmarket");
        onDisable();
        operation.commit();
    }

    @Override
    protected boolean executeTasks() throws Exception {
        operation.setAutoCommit(false);
        operation.setSchemaName("nmarket");
        onPrepare();
        onDownload();
        operation.commit();
        onParse();
        operation.commit();
        onLoad();
        operation.commit();
        return false;
    }

    @Override
    public void initConnection() throws Exception {
        operation = createContents(NMarketYandexDataSource.class);
    }

    @Override
    protected void storeDataFlat(String loadOperation) throws Exception {
        operation.addFlats(feedLog, loadOperation);
        operation.addBuildings(feedLog, loadOperation);
    }

}
