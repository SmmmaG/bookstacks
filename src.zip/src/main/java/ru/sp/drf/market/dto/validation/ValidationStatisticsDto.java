package ru.sp.drf.market.dto.validation;

import java.util.Objects;

public class ValidationStatisticsDto {
    private int complexesCount;
    private int buildingsCount;
    private int flatsCount;

    public ValidationStatisticsDto() {
        this.complexesCount = -1;
        this.buildingsCount = -1;
        this.flatsCount = -1;
    }

    public void setComplexesCount(int complexesCount) {
        this.complexesCount = complexesCount;
    }

    public void setBuildingsCount(int buildingsCount) {
        this.buildingsCount = buildingsCount;
    }

    public void setFlatsCount(int flatsCount) {
        this.flatsCount = flatsCount;
    }

    public int getComplexesCount() {
        return complexesCount;
    }

    public int getBuildingsCount() {
        return buildingsCount;
    }

    public int getFlatsCount() {
        return flatsCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ValidationStatisticsDto that = (ValidationStatisticsDto) o;
        return complexesCount == that.complexesCount &&
                buildingsCount == that.buildingsCount &&
                flatsCount == that.flatsCount;
    }

    @Override
    public int hashCode() {
        return Objects.hash(complexesCount, buildingsCount, flatsCount);
    }

    @Override
    public String toString() {
        return "ValidationStatisticsDto{" +
                "complexesCount=" + complexesCount +
                ", buildingsCount=" + buildingsCount +
                ", flatsCount=" + flatsCount +
                '}';
    }
}
