package ru.sp.drf.market.utilities;

import javassist.NotFoundException;
import org.springframework.stereotype.Service;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.repository.dictionaries.CityRepository;
import ru.sp.drf.market.repository.dictionaries.CountryRepository;
import ru.sp.drf.market.repository.dictionaries.DistrictReposotory;
import ru.sp.drf.market.repository.dictionaries.RegionRepository;
import ru.sp.drf.market.service.AddressService;
import ru.sp.drf.market.service.ComplexService;
import ru.sp.drf.market.task.FillComplexLocationTask;
import ru.sp.drf.market.task.FillLocationsTask;
import ru.sp.drf.market.task.RegionCityGeocodeTask;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


@Service
public class Geocoder extends LoadLogger {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private final ComplexService complexService;
    private final AddressService addressService;

    private final CountryRepository countryRepository;
    private final RegionRepository regionRepository;
    private final DistrictReposotory districtReposotory;
    private final CityRepository cityReposotory;

    public Geocoder(ComplexService complexService, AddressService addressService, CountryRepository countryRepository, RegionRepository regionRepository, DistrictReposotory districtReposotory, CityRepository cityReposotory) {
        this.complexService = complexService;
        this.addressService = addressService;
        this.countryRepository = countryRepository;
        this.regionRepository = regionRepository;
        this.districtReposotory = districtReposotory;
        this.cityReposotory = cityReposotory;
    }

    /**
     * Filling Region's and Cities' center points and ZOOM
     */
    public static void executeRegionCityGeocode() {
        //TODO необходимо поясение. Зачем в бине такой метод?
        new Thread(new RegionCityGeocodeTask()).start();
    }

    /**
     * Filling addresses components if address nis incomplete
     *
     * @param geocodeAllAddresses
     */
    public void fillAddresses(boolean geocodeAllAddresses) {
        new Thread(getFillLocationsTask(geocodeAllAddresses)).start();
    }

    public FillLocationsTask getFillLocationsTask(boolean geocodeAllAddresses) {
        return new FillLocationsTask(geocodeAllAddresses, addressService, countryRepository, regionRepository, districtReposotory, cityReposotory);
    }

    /**
     * Filling complexes coordinates by region, city and complex name
     */
    public void fillComplexCoordinate() {
        new Thread(getFillComplexLocationTask()).start();
    }

    public FillComplexLocationTask getFillComplexLocationTask() {
        return new FillComplexLocationTask(complexService, addressService);
    }

    /**
     * Return Yandex geocoding by URL request
     *
     * @param url
     * @return
     * @throws IOException
     * @throws NotFoundException
     */
    public static String getGeocode(String url) throws IOException, NotFoundException {

        StringBuilder result = new StringBuilder();
        HttpURLConnection conns = (HttpURLConnection) new URL(url).openConnection();
        conns.setRequestMethod("GET");
        BufferedReader rd = new BufferedReader(new InputStreamReader(conns.getInputStream(), "UTF-8"));
        String line;
        while ((line = rd.readLine()) != null) {
            result.append(line);
        }
        rd.close();

        if (result.length() == 0) {
            LOG.error("GEOCODE NOT FOUND");
            throw new NotFoundException("GEOCODE NOT FOUND");
        }

        return result.toString();
    }

}
