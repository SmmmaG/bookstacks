package ru.sp.drf.market.task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.domrf.rem.dto.bus.processes.PostProcessAction;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.dataloader.FeedBroker;
import ru.sp.drf.market.dataloader.FeedLoader;
import ru.sp.drf.market.dataloader.elastic.ComplexLoader;
import ru.sp.drf.market.dataloader.elastic.MetroLoader;
import ru.sp.drf.market.queue.FeedEventBus;
import ru.sp.drf.market.queue.FeedRedisProvider;
import ru.sp.drf.market.repository.FeedLogRepository;
import ru.sp.drf.market.service.FeedService;
import ru.sp.drf.market.utilities.Geocoder;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

@Component
public class FeedTaskManager {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private static Geocoder geocoder;

    private FeedService feedService;

    private FeedLogRepository feedLogRepository;

    private static FeedBroker feedBroker;

    private static ComplexLoader complexLoader;

    private static MetroLoader metroLoader;

    private static FeedRedisProvider redisProvider;

    public FeedTaskManager(FeedService feedService, FeedLogRepository feedLogRepository) {
        this.feedService = feedService;
        this.feedLogRepository = feedLogRepository;
    }

    @Autowired
    public void setGeocoder(Geocoder geocoder) {
        FeedTaskManager.geocoder = geocoder;
    }

    @Autowired
    public void setFeedBroker(FeedBroker feedBroker) {
        FeedTaskManager.feedBroker = feedBroker;
    }

    @Autowired
    public void setComplexLoader(ComplexLoader complexLoader) {
        FeedTaskManager.complexLoader = complexLoader;
    }

    @Autowired
    public void setMetroLoader(MetroLoader metroLoader) {
        FeedTaskManager.metroLoader = metroLoader;
    }

    @Autowired
    public void setRedisProvider(FeedRedisProvider redisProvider) {
        FeedTaskManager.redisProvider = redisProvider;
    }

    @Scheduled(cron = "${app.feed-loading.cron}")
    public void scheduleFeedLoading() {
        if (FeedServiceConfig.ENABLE_FEED_LOADING) {
            executeActiveFeedsLoading();
        } else {
            LOG.info("Scheduler switch off from  parameter spring.scheduled.feed-loading.enable={}", FeedServiceConfig.ENABLE_FEED_LOADING);
        }

    }


    public synchronized static void executeActiveFeedsLoading() {
        boolean success = false;
        for (FeedLoader loader : feedBroker.getLoaders()) {
            boolean curentFeedSuccess = loader.execute();
            success = success || curentFeedSuccess;
        }
        LOG.info("end loaders");

        if (success) {
            executeAfterLoading();
        }
    }

    public synchronized static void executeSingleFeed(UUID feedId) {
        boolean success;
        FeedLoader loader = feedBroker.getLoaderById(feedId);
        if (isValid(loader)) {
            success = loader.execute();
            if (success) {
                executeAfterLoading();
            }
        }
    }

    public void disableSingleFeed(UUID feedId) {
        FeedLoader loader = feedBroker.getLoaderById(feedId);
        loader.executeDisable();
        startElasticLoader();

        notifyPostProcessing();
    }

    private static void startPhotoRetriever() {
        new Thread(new RetrieverTask()).start();
    }


    private static void executeAfterLoading() {
        try {
            //  EXEC PHOTO LOADING
            startPhotoRetriever();

            Executor executor = Executors.newFixedThreadPool(10);
            CompletableFuture<Void> fillComplexCoordinateFuture = CompletableFuture.runAsync(geocoder.getFillComplexLocationTask(), executor);
            //  FILL COMPLEX COORDINATES
            //  FILL CRUSHED ADDRESSES BY COORDINATES
            CompletableFuture<Void> fillAddressesFuture = CompletableFuture.runAsync(geocoder.getFillLocationsTask(false), executor);
            CompletableFuture<Void> combined = CompletableFuture.allOf(fillComplexCoordinateFuture, fillAddressesFuture);

            // wait while task fillComplexCoordinateFuture and fillAddressesFuture finished
            combined.get();

            startElasticLoader();

        } catch (Exception e) {
            LOG.error("Unexpected exception", e);
        }
        notifyPostProcessing();

    }

    private static void startElasticLoader() {
        new Thread(new LoadElasticTask(complexLoader, metroLoader)).start();
    }

    private static void notifyPostProcessing() {
        if (redisProvider != null) {
            redisProvider.firePostProcessingEvent(new PostProcessAction(FeedEventBus.postLoadFeedEvent.getCode()));
        }
    }

    public static void loadElastic() {
        new Thread(new LoadElasticTask(complexLoader, metroLoader)).start();
    }

    public static void clearMetroSchema() {
        new LoadElasticTask(complexLoader, metroLoader).clearMetroSchema();

    }


    public void clearAddressSchema() {
        new LoadElasticTask(complexLoader, metroLoader).clearAddressSchema();
    }

    public static void clearComplexSchema() {
        new LoadElasticTask(complexLoader, metroLoader).clearComplexSchema();

    }

    public void clearSchema() {
        new LoadElasticTask(complexLoader, metroLoader).clearSchema();
    }
}
