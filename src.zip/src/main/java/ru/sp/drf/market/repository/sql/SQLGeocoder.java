package ru.sp.drf.market.repository.sql;

public enum SQLGeocoder {
    addAddressGeocode("INSERT INTO address_geocode (address_id, json) VALUES (?,?);"),
    updAddressGeocode("UPDATE address_geocode SET json=? WHERE address_id=?"),
    updAddress("UPDATE address SET latitude=?, longitude=? WHERE id=?"),
    addComplexGeocode("INSERT INTO complex_geocode (complex_id, json) VALUES (?,?);"),
    getAddressGeocode("SELECT json FROM address_geocode WHERE address_id=?;"),
    getComplexGeocode("SELECT json FROM complex_geocode WHERE complex_id=?;"),
    findCountry("SELECT id FROM country WHERE LOWER(name) like '%'||?||'%'"),
    findRegion("SELECT id FROM region WHERE LOWER(name) like '%'||?||'%'"),
    findDistrict("SELECT id FROM district WHERE LOWER(name) like '%'||?||'%' AND region_id=?"),
    addDistrict("INSERT INTO district (id, actual, create_date, version, name, code, statistic, city_id, region_id) VALUES (uuid_generate_v4(),true,now(),0,?,?,0,?,?) RETURNING id"),
    addCity("INSERT INTO city (id, actual, create_date, version, name, name_prepositional, code, prefix_type, statistic, region_id, is_millionaire) VALUES (uuid_generate_v4(),true,now(),0,?,?,rem_translit(?),?,0,?,false) RETURNING id"),
    findCity("SELECT id FROM city WHERE LOWER(name) like ?||'%' AND region_id=? AND prefix_type=?"),
    updateLocation("UPDATE address SET country_id=?, region_id=?, city_id=?, district_id=? WHERE id=?"),
    updateCoords("UPDATE address SET latitude=?, longitude=? WHERE id=?"),
    checkIsRegionCity("SELECT true FROM public.region_city WHERE LOWER(city) like LOWER(?)")
    ;

    SQLGeocoder(String sql) {
        this.sql = sql;
    }

    private String sql;

    public String getSQL() {
        return sql;
    }
}
