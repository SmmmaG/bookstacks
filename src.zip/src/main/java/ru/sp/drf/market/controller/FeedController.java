package ru.sp.drf.market.controller;

import io.swagger.annotations.ApiOperation;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.FeedBroker;
import ru.sp.drf.market.dataloader.TempFeedLoader;
import ru.sp.drf.market.dto.validation.ValidationResultDto;
import ru.sp.drf.market.exception.DownloadFeedException;
import ru.sp.drf.market.exception.UndefinedFeedHandlerException;
import ru.sp.drf.market.task.FeedTaskManager;
import ru.sp.drf.market.utilities.Geocoder;

import java.util.UUID;

@RestController
@RequestMapping("/api")
public class FeedController {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private FeedTaskManager feedTaskManager;

    private Geocoder geocoder;

    public FeedController(FeedTaskManager feedTaskManager, Geocoder geocoder) {
        this.feedTaskManager = feedTaskManager;
        this.geocoder = geocoder;
    }

    @ApiOperation(value = "Удаление контента конкретного фида", response = String.class)
    @PostMapping(path = "/feeds/{id}/disableData", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity disableFeedData(@PathVariable(name = "id") String id) {
        LOG.info("The host has got POST request /feeds/{id}/disableData with id {}", id);
        feedTaskManager.disableSingleFeed(UUID.fromString(id));
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Запуск конкретного фида", response = String.class)
    @PostMapping(path = "/feeds/{id}/execute", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity execFeed(@PathVariable(name = "id") String id) {
        LOG.info("The host has got POST request /feeds/{id}/execute with id {}", id);
        feedTaskManager.executeSingleFeed(UUID.fromString(id));
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Запуск загрузки активных фидов", response = String.class)
    @PostMapping(path = "/feeds/execute", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity execActiveFeeds() {
        feedTaskManager.executeActiveFeedsLoading();
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Запуск геокодера регионов и городов", response = String.class)
    @GetMapping(path = "/geocoder/execute", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity executeRegionCityGeocode() {
        LOG.info("The host has got GET request /geocoder/execute");
        geocoder.executeRegionCityGeocode();
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Запуск геокодера битых адресов", response = String.class)
    @GetMapping(path = "/geocoder/executeCrushedGeocode", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity executeCrushedGeocode() {
        LOG.info("The host has got GET request /geocoder/executeCrushedGeocode");
        geocoder.fillAddresses(false);
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Запуск геокодера всех адресов", response = String.class)
    @GetMapping(path = "/geocoder/executeAllAddressesGeocode", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity executeAllAddressesGeocode() {
        LOG.info("The host has got GET request /geocoder/executeAllAddressesGeocode");
        geocoder.fillAddresses(true);
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Запуск геокодера комплексов без координат", response = String.class)
    @GetMapping(path = "/geocoder/executeComplexCoordinateGeocode", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity executeComplexCoordinateGeocode() {
        LOG.info("The host has got POST request /geocoder/executeComplexCoordinateGeocode");
        geocoder.fillComplexCoordinate();
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Чистка схемы Elastic", response = String.class)
    @PostMapping(path = "/elastic/schema/metro/clear", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity clearElasticMetroSchema() {
        LOG.info("The host has got POST request /elastic/schema/metro/clear");
        feedTaskManager.clearMetroSchema();
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Чистка схемы Elastic", response = String.class)
    @PostMapping(path = "/elastic/schema/complex/clear", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity clearComplexElasticSchema() {
        LOG.info("The host has got POST request /elastic/schema/complex/clear");
        feedTaskManager.clearComplexSchema();
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Чистка схемы Elastic Address", response = String.class)
    @PostMapping(path = "/elastic/schema/address/clear", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity clearElasticAddressSchema() {
        LOG.info("The host has got POST request /elastic/schema/address/clear");
        feedTaskManager.clearAddressSchema();
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Чистка схемы Elastic ", response = String.class)
    @PostMapping(path = "/elastic/schema/clear", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity clearElasticSchema() {
        LOG.info("The host has got POST request /elastic/schema/clear");
        feedTaskManager.clearSchema();
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Загрузка данных Elastic", response = String.class)
    @PostMapping(path = "/elastic/schema/load", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity loadElastic() {
        LOG.info("The host has got POST request /elastic/schema/load");
        feedTaskManager.loadElastic();
        return new ResponseEntity("", HttpStatus.OK);
    }

    @ApiOperation(value = "Валидация внешнего фида", response = String.class)
    @GetMapping(path = "/feeds/validation", produces = MediaTypes.HAL_JSON_UTF8_VALUE)
    public ResponseEntity externalValidation(@RequestParam(name = "url") String url) {
        LOG.info("The host has got GET request /feeds/validation with url: {}", url);
        if (url.length() > 500) {
            ValidationResultDto result = new ValidationResultDto(3);
            result.addError("Слишком длинная ссылка");
            return new ResponseEntity(result, HttpStatus.OK);
        }
        try {
            TempFeedLoader loader = FeedBroker.getTempLoader(url);
            loader.onDownload();
            ValidationResultDto result = loader.executeValidateTask();
            return new ResponseEntity(result, HttpStatus.OK);
        } catch (DownloadFeedException e) {
            LOG.error("Cannot validate feeds url:{}", url, e);
            ValidationResultDto result = new ValidationResultDto(3);
            result.addError("Фид недоступен, проверьте URL");
            return new ResponseEntity(result, HttpStatus.OK);
        } catch (UndefinedFeedHandlerException e) {
            LOG.error("Cannot validate feeds url:{}", url, e);
            ValidationResultDto result = new ValidationResultDto(3);
            result.addError("Не удалось распознать фид");
            return new ResponseEntity(result, HttpStatus.OK);
        } catch (Exception e) {
            LOG.error("Cannot validate feeds url:{}", url, e);
            ValidationResultDto result = new ValidationResultDto(3);
            result.addError("Непредвиденная ошибка сервера");
            return new ResponseEntity(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
