package ru.sp.drf.market.task;

import com.fasterxml.jackson.databind.ObjectMapper;
import ru.domrf.rem.domain.address.Address;
import ru.domrf.rem.domain.address.BaseLocation;
import ru.domrf.rem.domain.address.City;
import ru.domrf.rem.domain.address.Country;
import ru.domrf.rem.domain.address.District;
import ru.domrf.rem.domain.address.Location;
import ru.domrf.rem.domain.address.Region;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.dataloader.MarketDataSource;
import ru.sp.drf.market.exception.geocode.CityNotFoundException;
import ru.sp.drf.market.exception.geocode.CountryNotFoundException;
import ru.sp.drf.market.exception.geocode.DistrictNotFoundException;
import ru.sp.drf.market.exception.geocode.RegionNotFoundException;
import ru.sp.drf.market.exchange.geocode.GeocodeOrganisation;
import ru.sp.drf.market.repository.dictionaries.CityRepository;
import ru.sp.drf.market.repository.dictionaries.CountryRepository;
import ru.sp.drf.market.repository.dictionaries.DistrictReposotory;
import ru.sp.drf.market.repository.dictionaries.RegionRepository;
import ru.sp.drf.market.repository.sql.SQLGeocoder;
import ru.sp.drf.market.service.AddressService;
import ru.sp.drf.market.utilities.Geocoder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Filling addresses components if address nis incomplete
 */
public class FillLocationsTask implements Runnable {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private final AddressService addressService;

    private final CountryRepository countryRepository;
    private final RegionRepository regionRepository;
    private final DistrictReposotory districtReposotory;
    private final CityRepository cityReposotory;

    private List<UUID> notFoundCityLocations = new ArrayList();
    private List<UUID> notFoundDistrictLocations = new ArrayList();
    private List<UUID> notFoundRegionLocations = new ArrayList();
    private List<UUID> notFoundCountryLocations = new ArrayList();
    private static Set<String> areaCityPrefixes;

    private final boolean geocodeAllAddresses;

    static {
        areaCityPrefixes = new HashSet();
        areaCityPrefixes.add("городской округ город");
        areaCityPrefixes.add("сельское поселение");
        areaCityPrefixes.add("поселение");
    }

    public FillLocationsTask(boolean geocodeAllAddresses, AddressService addressService, CountryRepository countryRepository, RegionRepository regionRepository, DistrictReposotory districtReposotory, CityRepository cityReposotory) {
        this.geocodeAllAddresses = geocodeAllAddresses;
        this.addressService = addressService;
        this.countryRepository = countryRepository;
        this.regionRepository = regionRepository;
        this.districtReposotory = districtReposotory;
        this.cityReposotory = cityReposotory;
    }

    @Override
    public void run() {
        List<Address> addresses;
        if (geocodeAllAddresses)
            addresses = addressService.findAllAddresses();
        else
            addresses = addressService.findAllCrushedAddresses();

        for (BaseLocation address : addresses)
            geocodeLocation(address, false);


        List<Location> locations;
        if (geocodeAllAddresses)
            locations = addressService.findAllLocations();
        else
            locations = addressService.findAllCrushedLocations();

        for (BaseLocation location : locations)
            geocodeLocation(location, false);


        if (notFoundCountryLocations.size() > 0)
            System.out.println("notFoundCountryLocations = " + notFoundCountryLocations);
        if (notFoundRegionLocations.size() > 0)
            System.out.println("notFoundRegionLocations = " + notFoundRegionLocations);
        if (notFoundDistrictLocations.size() > 0)
            System.out.println("notFoundDistrictLocations = " + notFoundDistrictLocations);
        if (notFoundCityLocations.size() > 0)
            System.out.println("notFoundCityLocations = " + notFoundCityLocations);

        new Thread(new RegionCityGeocodeTask()).start();
    }

    private void geocodeLocation(BaseLocation locationParam, boolean reverseCoords) {
        BaseLocation location = locationParam;
        UUID locationId = location.getId();
        try (Connection conn = MarketDataSource.getConnection();
             PreparedStatement psAdd = conn.prepareStatement(SQLGeocoder.addAddressGeocode.getSQL());
//             PreparedStatement psUpd = conn.prepareStatement(SQLGeocoder.updAddressGeocode.getSQL());
             PreparedStatement psGet = conn.prepareStatement(SQLGeocoder.getAddressGeocode.getSQL());
             PreparedStatement psFindCountry = conn.prepareStatement(SQLGeocoder.findCountry.getSQL());
             PreparedStatement psFindRegion = conn.prepareStatement(SQLGeocoder.findRegion.getSQL());
             PreparedStatement psFindDistrict = conn.prepareStatement(SQLGeocoder.findDistrict.getSQL());
             PreparedStatement psAddDistrict = conn.prepareStatement(SQLGeocoder.addDistrict.getSQL());
             PreparedStatement psAddCity = conn.prepareStatement(SQLGeocoder.addCity.getSQL());
             PreparedStatement psUpdateLocation = conn.prepareStatement(SQLGeocoder.updateLocation.getSQL());
//             PreparedStatement psUpdateCoords = conn.prepareStatement(SQLGeocoder.updateCoords.getSQL());
             PreparedStatement psCheckIsRegionCity = conn.prepareStatement(SQLGeocoder.checkIsRegionCity.getSQL());
             PreparedStatement psFindCity = conn.prepareStatement(SQLGeocoder.findCity.getSQL())) {
            psGet.setObject(1, location.getId());
            try (ResultSet rsGet = psGet.executeQuery()) {
                String geocodeStr = null;
                while (rsGet.next()) {
                    geocodeStr = rsGet.getString("json");
                }
                if (Objects.isNull(geocodeStr) || reverseCoords) {

                    StringBuffer result = new StringBuffer();
                    String coordinates;
                    //                    if (reverseCoords) {
//                        coordinates = location.getPoint().getLatitude() + "," + location.getPoint().getLongitude();
//                    } else {
                    coordinates = location.getPoint().getLongitude() + "," + location.getPoint().getLatitude();
//                    }
                    String urlStr = "https://geocode-maps.yandex.ru/1.x/?apikey=" + FeedServiceConfig.YANDEX_APIKEY + "&format=json&geocode=" + coordinates + "&kind=district";
                    geocodeStr = Geocoder.getGeocode(urlStr);

//                    if (reverseCoords){
//                        psUpd.setObject(2, location.getId());
//                        psUpd.setString(1, geocodeStr);
//                        psUpd.executeUpdate();
//                    } else {
                    psAdd.setObject(1, location.getId());
                    psAdd.setString(2, geocodeStr);
                    psAdd.executeUpdate();
//                    }
                }

                geocodeStr = geocodeStr.replace("Ё", "Е").replace("ё", "е");
                ObjectMapper mapper = new ObjectMapper();
                GeocodeOrganisation geocode = mapper.readValue(geocodeStr, GeocodeOrganisation.class);

                Set<GeocodeOrganisation.Component> componentSet = geocode.getComponents();

                UUID countryId = null;
                UUID regionId = null;
                UUID cityId = null;
                UUID districtId = null;

                countryId = getCountryId(location, componentSet, psFindCountry);
                regionId = getRegionId(location, componentSet, psFindRegion);
                cityId = getCityId(location, componentSet, psFindCity, psAddCity);
                districtId = getDistrictId(location, componentSet, psFindDistrict, psAddDistrict, psCheckIsRegionCity);

                psUpdateLocation.setObject(1, countryId);
                psUpdateLocation.setObject(2, regionId);
                psUpdateLocation.setObject(3, cityId);
                psUpdateLocation.setObject(4, districtId);
                psUpdateLocation.setObject(5, locationId);
                psUpdateLocation.execute();

//                if (reverseCoords){
//                    psUpdateCoords.setDouble(1,location.getPoint().getLongitude());
//                    psUpdateCoords.setDouble(2,location.getPoint().getLatitude());
//                    psUpdateCoords.setObject(5, locationId);
//                }
            }
        } catch (CountryNotFoundException e) {
//            if (!reverseCoords) {
//                geocodeLocation(locationParam, true);
//            } else {
            notFoundCountryLocations.add(locationId);
//            }
        } catch (RegionNotFoundException e) {
            notFoundRegionLocations.add(locationId);
        } catch (DistrictNotFoundException e) {
            notFoundDistrictLocations.add(locationId);
        } catch (CityNotFoundException e) {
            notFoundCityLocations.add(locationId);
        } catch (Exception e) {
            LOG.error("Unexpected exception",e);
        }
    }


    private UUID getCountryId(BaseLocation location, Set<GeocodeOrganisation.Component> componentSet,
                              PreparedStatement psFindCountry) throws SQLException, CountryNotFoundException {
        GeocodeOrganisation.Component countryGeocoded = componentSet.stream().
                filter(component -> "country".equals(component.kind)).
                findFirst().orElseThrow(() -> new CountryNotFoundException("Not fount country in geocode for location " + location.getId()));
        psFindCountry.setString(1, countryGeocoded.name.toLowerCase());
        try (ResultSet rs = psFindCountry.executeQuery()) {
            while (rs.next()) {
                Country country1 = countryRepository.findById((UUID) rs.getObject("id")).orElseThrow(() -> new SQLException("NOT_FOUND_COUNTRY"));
                location.setCountry(country1);
                return country1.getId();
            }
        }
        throw new CountryNotFoundException("NOT FOUND COUNTRY  locationId=" + location.getId());
    }

    private UUID getRegionId(BaseLocation location, Set<GeocodeOrganisation.Component> componentSet,
                             PreparedStatement psFindRegion) throws SQLException, RegionNotFoundException {
        List<GeocodeOrganisation.Component> regionsFiltered = componentSet.stream().
                filter(component -> "province".equals(component.kind)).
                collect(Collectors.toCollection(ArrayList::new));
        for (GeocodeOrganisation.Component curRegion : regionsFiltered) {
            psFindRegion.setString(1, curRegion.name.toLowerCase());
            try (ResultSet rs = psFindRegion.executeQuery()) {
                while (rs.next()) {
                    Region region = regionRepository.findById((UUID) rs.getObject("id")).orElseThrow(() -> new SQLException("NOT_FOUND_REGION"));
                    location.setRegion(region);
                    return region.getId();
                }
            }
        }
        throw new RegionNotFoundException("NOT FOUND REGION  locationId=" + location.getId());
    }

    private UUID getCityId(BaseLocation location, Set<GeocodeOrganisation.Component> componentSet,
                           PreparedStatement psFindCity, PreparedStatement psAddCity) throws SQLException, CityNotFoundException {

        City city = null;
        List<GeocodeOrganisation.Component> cityesFiltered = componentSet.stream().
                filter(component -> "locality".equals(component.kind)).
                collect(Collectors.toCollection(ArrayList::new));
        if (cityesFiltered.size() == 0) {
            cityesFiltered = findCityInAreas(componentSet);
        }

        for (GeocodeOrganisation.Component curCity : cityesFiltered) {
            CityGeocoded cityGeocoded = getCityPrefixAndFixCityName(curCity.name.toLowerCase());

            psFindCity.setString(1, cityGeocoded.name);
            psFindCity.setObject(2, location.getRegion().getId());
            psFindCity.setString(3, cityGeocoded.prefix);
            try (ResultSet rs = psFindCity.executeQuery()) {
                while (rs.next()) {
                    city = cityReposotory.findById((UUID) rs.getObject("id")).orElseThrow(() -> new SQLException("NOT_FOUND_DISTRICT"));
                    break;
                }
            }
            if (Objects.isNull(city)) {
                cityGeocoded.name = Character.toUpperCase(cityGeocoded.name.charAt(0)) + cityGeocoded.name.substring(1);
                psAddCity.setString(1, cityGeocoded.name);
                psAddCity.setString(2, cityGeocoded.name);
                psAddCity.setString(3, cityGeocoded.name);
                psAddCity.setObject(4, cityGeocoded.prefix);
                psAddCity.setObject(5, location.getRegion().getId());
                try (ResultSet rs = psAddCity.executeQuery()) {
                    while (rs.next()) {
                        UUID newCityId = (UUID) rs.getObject("id");
                        city = cityReposotory.findById(newCityId).orElseThrow(() -> new SQLException("UNEXPECTED EXCEPTION"));
                    }
                }
            }
        }
        if (Objects.nonNull(city)) {
            location.setCity(city);
            return city.getId();
        } else {
            throw new CityNotFoundException("NOT FOUND CITY  locationId=" + location.getId());
        }
    }

    private UUID getDistrictId(BaseLocation location, Set<GeocodeOrganisation.Component> componentSet, PreparedStatement psFindDistrict, PreparedStatement psAddDistrict, PreparedStatement psCheckIsRegionCity)
            throws SQLException, DistrictNotFoundException {
        List<GeocodeOrganisation.Component> districtsAreasFiltered = componentSet.stream().
                filter(component -> ("area".equals(component.kind) && !areaIsCity(component)) || "district".equals(component.kind)).
                collect(Collectors.toCollection(ArrayList::new));
        District district = null;
        for (GeocodeOrganisation.Component curDistrict : districtsAreasFiltered) {
            String curDistrictStr = getLowerDistrictName(curDistrict.name);

            psFindDistrict.setString(1, curDistrictStr);
            psFindDistrict.setObject(2, location.getRegion().getId());
            try (ResultSet rs = psFindDistrict.executeQuery()) {
                while (rs.next()) {
                    district = districtReposotory.findById((UUID) rs.getObject("id")).orElseThrow(() -> new SQLException("NOT_FOUND_DISTRICT"));
                    break;
                }
            }
        }

        //Add new district
        if (Objects.isNull(district)) {
            boolean isRegionCity = false;

            List<GeocodeOrganisation.Component> districtsFiltered = componentSet.stream().
                    filter(component -> "district".equals(component.kind)).
                    collect(Collectors.toCollection(ArrayList::new));
            String districtStr = null;
            for (GeocodeOrganisation.Component curDistrict : districtsFiltered) {
                if (curDistrict.name.toLowerCase().startsWith("жилой комплекс ") || curDistrict.name.toLowerCase().startsWith("жк "))
                    continue;
                districtStr = curDistrict.name;
                psCheckIsRegionCity.setString(1, location.getCity().getNameWithoutPrefix());
                try (ResultSet rs = psCheckIsRegionCity.executeQuery()) {
                    isRegionCity = rs.next();
                }
                break;
            }
            if (Objects.isNull(districtStr)) {
                List<GeocodeOrganisation.Component> areasFiltered = componentSet.stream().
                        filter(component -> "area".equals(component.kind)).
                        collect(Collectors.toCollection(ArrayList::new));
                for (GeocodeOrganisation.Component curArea : areasFiltered) {
                    districtStr = curArea.name;
                    break; //first is bigger
                }
            }
            if (Objects.nonNull(districtStr)) {
                districtStr = getLowerDistrictName(districtStr);
                districtStr = Character.toUpperCase(districtStr.charAt(0)) + districtStr.substring(1);
                psAddDistrict.setString(1, districtStr);
                psAddDistrict.setString(2, districtStr);
                psAddDistrict.setObject(3, isRegionCity ? null : location.getCity().getId());
                psAddDistrict.setObject(4, location.getRegion().getId());
                try (ResultSet rs = psAddDistrict.executeQuery()) {
                    while (rs.next()) {
                        UUID newDistrictId = (UUID) rs.getObject("id");
                        district = districtReposotory.findById(newDistrictId).orElseThrow(() -> new SQLException("UNEXPECTED EXCEPTION"));
                    }
                }
            } else {
                throw new DistrictNotFoundException("CANT FIND DISTRICT INFO IN GEOCODE FOR LOCATION=" + location.getId());
            }

        }
        location.setDistrict(district);
        return district.getId();
    }


    private String getLowerDistrictName(String districtStr) {
        districtStr = districtStr.toLowerCase();
        if (districtStr.startsWith("микрорайон")) districtStr = districtStr.replace("микрорайон", "").trim() + " мкр.";
        return districtStr.replace("микрорайон", "мкр")
                .replace("административный", "адм.")
                .replace("городской округ", "г.о.")
                .replace("город ", "г. ");
    }

    private CityGeocoded getCityPrefixAndFixCityName(String cityStr) {
        String cityPrefixStr = "г.";
        CityGeocoded city = new CityGeocoded(cityStr, cityPrefixStr);

        if (cityStr.contains("городской округ город")) {
            city.name = cityStr.replaceFirst("городской округ город", "").trim();
        } else if (cityStr.contains("деревня")) {
            city.name = cityStr.replaceFirst("деревня", "").trim();
            city.prefix = "дер.";
        } else if (cityStr.startsWith("аул")) {
            city.name = cityStr.replaceFirst("аул", "").trim();
            city.prefix = "аул";
        } else if (cityStr.contains("поселок городского типа")) {
            city.name = cityStr.replaceFirst("поселок городского типа", "").trim();
            city.prefix = "пгт.";
        } else if (cityStr.contains("рабочий посёлок")) {
            city.name = cityStr.replaceFirst("рабочий посёлок", "").trim();
            city.prefix = "рп";
        } else if (cityStr.contains("городской поселок")) {
            city.name = cityStr.replaceFirst("городской поселок", "").trim();
            city.prefix = "гп.";
        } else if (cityStr.contains("сельское поселение")) {
            city.name = cityStr.replaceFirst("сельское поселение", "").trim();
            city.prefix = "п.";
        } else if (cityStr.startsWith("поселение")) {
            city.name = cityStr.replaceFirst("поселение", "").trim();
            city.prefix = "п.";
        } else if (cityStr.startsWith("поселок")) {
            city.name = cityStr.replaceFirst("поселок", "").trim();
            city.prefix = "пос.";
        } else if (cityStr.startsWith("село")) {
            city.name = cityStr.replaceFirst("село", "").trim();
            city.prefix = "село";
        }


        return city;
    }

    private List<GeocodeOrganisation.Component> findCityInAreas(Set<GeocodeOrganisation.Component> components) {
        return components.stream().filter(component -> areaIsCity(component)).collect(Collectors.toCollection(ArrayList::new));
    }

    private boolean areaIsCity(GeocodeOrganisation.Component area) {
        for (String prefix : areaCityPrefixes) {
            if (area.name.toLowerCase().contains(prefix))
                return true;
        }
        return false;
    }

    private class CityGeocoded {
        public String name;
        public String prefix;

        public CityGeocoded(String name, String prefix) {
            this.name = name;
            this.prefix = prefix;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setPrefix(String prefix) {
            this.prefix = prefix;
        }
    }

}
