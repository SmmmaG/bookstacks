package ru.sp.drf.market.repository.dictionaries;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import ru.domrf.rem.domain.admin.FeedHandler;

import java.util.UUID;

@Repository
public interface FeedHandlerRepository extends JpaRepository<FeedHandler, UUID> {

    @Query("SELECT o FROM FeedHandler o WHERE o.code='validation'")
    FeedHandler getValidationHandler();
}
