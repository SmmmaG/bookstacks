package ru.sp.drf.market.repository;

import org.springframework.data.repository.CrudRepository;
import ru.domrf.rem.domain.admin.FeedLog;

import java.util.UUID;

public interface FeedLogRepository extends CrudRepository <FeedLog, UUID> {
}
