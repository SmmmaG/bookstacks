package ru.sp.drf.market.dataloader.yandex;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptRunner;
import ru.sp.drf.market.repository.sql.SQL;
import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptExecutor;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.dataloader.validation.ValidationEvents;
import ru.sp.drf.market.repository.BatchOperation;
import ru.sp.drf.market.repository.FeedLogRepository;
import ru.sp.drf.market.repository.sql.SQLDataSource;
import ru.sp.drf.market.repository.sql.SQLYandex;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.IOException;
import java.sql.SQLException;
import java.util.UUID;

import static ru.sp.drf.market.dataloader.MarketDataSource.getConnection;

@Component
public class YandexDataSource extends SQLDataSource implements BatchOperation {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    @Autowired
    private FeedLogRepository feedLogRepository;


    public YandexDataSource() throws Exception {
        super(getConnection());
    }

    public void prepareTables(FeedLog feedLog) throws Exception {
        LOG.info("Create temporary tables");
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript(
                "yandex/main/truncate-tables");

        LoadLogger.writeScriptLog(result, feedLog, false, FeedEventTypes.Prep_Temp_tbls);
    }

    public void storeData(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName(), 1800);
        UUID feedUuid = feedLog.getFeed().getId();

        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLYandex.getTempComplexCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLYandex.getTempBuildCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Build);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLYandex.getTempFlatCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/city/City Insert"), feedLog, true, FeedEventTypes.Add_City);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/district/District Insert"), feedLog, true, FeedEventTypes.Add_District);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/decoration/Decoration_type Update"), feedLog, true, FeedEventTypes.Upd_Decoration_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/decoration/Decoration_type Insert"), feedLog, true, FeedEventTypes.Add_Decoration_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/parking_type/Parking_type Update"), feedLog, true, FeedEventTypes.Upd_Parking_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/parking_type/Parking_type Insert"), feedLog, true, FeedEventTypes.Add_Parking_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/currency/Currency_type Update"), feedLog, true, FeedEventTypes.Upd_Curency_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/currency/Currency_type Insert"), feedLog, true, FeedEventTypes.Add_Curency_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/developer/Developer Update"), feedLog, true, FeedEventTypes.Upd_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/developer/Developer Insert"), feedLog, true, FeedEventTypes.Add_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/balcony/Balcony_type Insert"), feedLog, true, FeedEventTypes.Add_Balcony_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/material_wall_type/Material_wall_type Insert"), feedLog, true, FeedEventTypes.Add_Mtrl_wall_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/address/Address_building Update"), feedLog, true, FeedEventTypes.Upd_Build_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/address/Address_building Insert"), feedLog, true, FeedEventTypes.Add_Build_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/metro/Metro_location Update"), feedLog, true, FeedEventTypes.Upd_Metro_location);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/metro/Metro_location Insert"), feedLog, true, FeedEventTypes.Add_Metro_location);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("yandex/main/complex/Complex stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/complex/Complex stage 2 Update", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/complex/Complex stage 3 Insert", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/complex/Complex stage 4 cross Insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Cmpx_Feed);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("yandex/main/complex/complex-photo-stage-1-tmp-create", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLYandex.updateDocumentPhotoComplex.getSQL()), feedLog, true, FeedEventTypes.Upd_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/complex/complex-photo-stage-2-document-photo-insert"), feedLog, true, FeedEventTypes.Add_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/complex/complex-photo-stage-3-complex-document-photo-insert"), feedLog, true, FeedEventTypes.Asgn_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("yandex/main/building/Building stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/building/Building stage 2 Update", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/building/Building stage 3 Insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/building/Building stage 4 cross Insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Build_Feed);
        scriptExecutor.executeInsUpd("yandex/main/building/Building stage 5 tmp drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/address/Address_complex Insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Cmpx_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/complex/Complex-address-update", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Cmpx_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("yandex/main/flat/public/Flat stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/flat/public/Flat stage 2 Update", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/flat/public/Flat stage 3 Insert", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/flat/public/Flat stage 4 cross Insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Flat_Feed);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("yandex/main/flat/public_flat_photo_plan/Flats_photo_plan stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/flat/public_flat_photo_plan/Flats_photo_plan stage 2 Update"), feedLog, true, FeedEventTypes.Upd_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/flat/public_flat_photo_plan/Flats_photo_plan stage 3 Insert"), feedLog, true, FeedEventTypes.Add_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/flat/public_flat_photo_plan/Flats_photo_plan stage 4 Flats Update"), feedLog, true, FeedEventTypes.Asgn_Flats_photo);
        scriptExecutor.executeInsUpd("yandex/main/flat/public_flat_photo_plan/Flats_photo_plan stage 5 tmp drop");
        //disable adding photos to flats
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("yandex/main/flat/public_flat_photo/Flat_photo stage 1 tmp prepare", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Prep_Flat_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLYandex.updateDocumentPhotoFlat.getSQL()), feedLog, true, FeedEventTypes.Upd_Photo_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/flat/public_flat_photo/Flat_photo stage 2 document_photo Insert"), feedLog, true, FeedEventTypes.Add_Photo_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/flat/public_flat_photo/Flat_photo stage 3 flat_document_photo Insert"), feedLog, true, FeedEventTypes.Asgn_Photo_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/prices/Prices Insert"), feedLog, true, FeedEventTypes.Add_Prices);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/prices/Flat Prices Update", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Upd_Prices);
        scriptExecutor.executeInsUpd("yandex/main/flat/public/Flat stage 5 tmp drop");
        addSalesOfficeComplex(feedLog, null);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/salesoffice/contact-sales-office-update"), feedLog, true, FeedEventTypes.Upd_Sales_Office_Contact);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/salesoffice/contact-sales-office-insert"), feedLog, true, FeedEventTypes.Add_Sales_Office_Contact);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/salesoffice/seller-update"), feedLog, true, FeedEventTypes.Upd_Seller);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/salesoffice/seller-insert"), feedLog, true, FeedEventTypes.Add_Seller);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/salesoffice/sale-office-update"), feedLog, true, FeedEventTypes.Upd_Sales_Office);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/salesoffice/sale-office-insert"), feedLog, true, FeedEventTypes.Add_Sales_Office);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("yandex/main/salesoffice/seller-office-building-bind", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Asgn_Sales_Office_Building);
    }

    public void buildingsRemoveRelatedData(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());

        LoadLogger.writeValidationLog(scriptExecutor.executeScript("yandex/validation/buildings/buildings-remove-related-data",
                new Object[]{}), feedLog, FeedEventTypes.Buildings_Remove_Related_Data);
    }

    public void flatsCheckNonUniqueId(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        scriptExecutor.executeScript("yandex/validation/flats/insert-unique-flat-fields-check",
                new Object[]{ValidationEvents.notUniqueFlatId.getMessage(), feedLog.getId().toString()});
        LoadLogger.writeValidationLog(scriptExecutor.executeScript("yandex/validation/flats/flats-check-non-unique-internal-id",
                new Object[]{}), feedLog, FeedEventTypes.Flats_Check_Non_Unique_Internal_Id);
    }

    public void flatsCheckMandatoryFieldsValidation(FeedLog feedLog) throws Exception {
        StringBuilder fullPredicate = new StringBuilder();
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        String field = "rooms";
        String predicate = field + " IS NULL ";
        fullPredicate.append(predicate);
        scriptExecutor.executeScript("yandex/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldRooms.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "price_value";
        predicate = field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldPrice.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "area_value";
        predicate = field + " IS NULL OR " + field + " = 0 ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldSquare.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "floorr";
        predicate = field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldFloor.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "price_value";
        predicate = "(price_value < 300000 AND price_unit IS NULL) OR (price_value < 10000 AND price_unit IS NOT NULL)";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/flats/insert-mandatory-flat-fields-check",
                new Object[]{predicate, ValidationEvents.fieldLowPrice.getMessage(), field, predicate, feedLog.getId().toString(), predicate});

        LoadLogger.writeValidationLog(scriptExecutor.executeScript("yandex/validation/flats/flats-check-mandatory-fields",
                new Object[]{fullPredicate.toString()}), feedLog, FeedEventTypes.Flats_Check_Mandatory_Fields);
    }

    public void buildingsCheckNonUniqueId(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        scriptExecutor.executeScript("yandex/validation/buildings/insert-unique-building-fields-check",
                new Object[]{ValidationEvents.notUniqueBuildingId.getMessage(), feedLog.getId().toString(), feedLog.getId()});
        LoadLogger.writeValidationLog(scriptExecutor.executeScript("yandex/validation/buildings/buildings-check-non-unique-building-custom-id",
                new Object[]{}), feedLog, FeedEventTypes.Buildings_Check_Non_Unique_Building_Custom_Id);
    }

    public void buildingsCheckMandatoryFieldsValidation(FeedLog feedLog) throws Exception {
        StringBuilder fullPredicate = new StringBuilder();
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        String field = "building_name + (location_latitude,location_longitude OR location_address)";
        String predicate = "(building_name IS NULL AND ((location_latitude IS NULL AND location_longitude IS NULL) OR location_address IS NULL))";
        fullPredicate.append(predicate);
        scriptExecutor.executeScript("yandex/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldComplexNameAddress.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "location_latitude,location_longitude";
        predicate = "(location_latitude IS NOT NULL AND location_longitude IS NOT NULL AND\n" +
                "            ((location_longitude NOT BETWEEN 20 AND 180 OR location_latitude NOT BETWEEN 41.186158 AND 74)\n" +
                "            AND (location_latitude NOT BETWEEN 20 AND 180 OR location_longitude NOT BETWEEN 41.186158 AND 74)))";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldWrongCoordinates.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "sales_agent_organization";
        predicate = field + " IS NULL";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldDeveloperName.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "building_name";
        predicate = field + " IS NULL";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldComplexName.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        field = "sales_phone";
        predicate = "so." + field + " IS NULL ";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldDeveloperPhone.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        predicate = " char_length(so." + field + ")<10";
        fullPredicate.append(" OR ").append(predicate);
        scriptExecutor.executeScript("yandex/validation/buildings/insert-mandatory-building-fields-check",
                new Object[]{predicate, ValidationEvents.fieldWrongDeveloperPhone.getMessage(), field, predicate, feedLog.getId().toString(), predicate});
        LoadLogger.writeValidationLog(scriptExecutor.executeScript("yandex/validation/buildings/buildings-check-mandatory-fields",
                new Object[]{fullPredicate.toString()}), feedLog, FeedEventTypes.Buildings_Check_Mandatory_Fields);

        scriptExecutor.executeScript("yandex/validation/buildings/building-reverse-coordinates",
                new Object[]{feedLog.getId()});
    }

    public int getCount(String sql) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        return scriptExecutor.executeQuery(sql).getRows();
    }

    public void addFlats(FeedLog feedLog, String operation) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("yandex/load/" + operation + "-flats",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Flat);
    }

    public void addBuildings(FeedLog feedLog, String operation) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("yandex/load/" + operation + "-buildings",
                new Object[]{feedLog.getFeed().getId(), feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Building);
    }

    public void addFlatsPhoto(FeedLog feedLog, String operation) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("yandex/load/" + operation + "-flat-images",
                new Object[]{feedLog.getId(), feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Flats_photo);
    }

    public void addFlatRooms(FeedLog feedLog, String operation) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("yandex/load/" + operation + "-flat-rooms",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Flats_rooms);
    }

    public void addFlatMetro(FeedLog feedLog, String operation) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("yandex/load/" + operation + "-flat-metro",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Metro_location);
    }

    public void addSalesOffice(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("yandex/load/" + operation + "-sales-office",
                new Object[]{feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Sales_Office);
    }

    public void addComplexesPhoto(FeedLog feedLog, String operation) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("yandex/load/" + operation + "-complex-images",
                new Object[]{feedLog.getFeed().getId(), feedLog.getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Photo_Cmpx);
    }

    public void addSalesOfficeComplex(FeedLog feedLog, String operation) throws IOException, SQLException {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER, getSchemaName());
        ScriptResult result = scriptExecutor.executeScript("yandex/main/salesoffice/load-sales-office-complex",
                new Object[]{feedLog.getFeed().getId()});
        LoadLogger.writeScriptLog(result, feedLog, true, FeedEventTypes.Add_Sales_Office_Address);
    }

    @Override
    public void addBuildingsPhoto(FeedLog feedLog, String operation) throws Exception {

    }

    @Override
    public void addComplexes(FeedLog feedLog, String operation) throws Exception {

    }

    public void createTempSchema(String schemaName, FeedLog feedLog) throws SQLException {
        ScriptRunner scriptRunner = new ScriptRunner(connection, getSchemaName(), 10000);
        scriptRunner.runScript(SQL.createSchema.getSQL(), new Object[]{getSchemaName()});
        LoadLogger.writeScriptLog(new ScriptResult(scriptRunner.getErrorLogWriter(), scriptRunner.getUpdatedCount(), scriptRunner.getLogWriter(), scriptRunner.getJobTime()), feedLog, true, FeedEventTypes.Prep_Temp_schema);
    }

    public void removeTempSchema(String schemaName, FeedLog feedLog) throws SQLException {
        ScriptRunner scriptRunner = new ScriptRunner(connection, getSchemaName(), 10000);
        scriptRunner.runScript(SQL.dropSchema.getSQL(), new Object[]{getSchemaName()});
        LoadLogger.writeScriptLog(new ScriptResult(scriptRunner.getErrorLogWriter(), scriptRunner.getUpdatedCount(), scriptRunner.getLogWriter(), scriptRunner.getJobTime()), feedLog, true, FeedEventTypes.Remove_Temp_schema);
    }
}
