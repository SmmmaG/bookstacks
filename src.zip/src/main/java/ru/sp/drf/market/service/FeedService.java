package ru.sp.drf.market.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.domrf.rem.domain.admin.Feed;
import ru.sp.drf.market.dataloader.MarketDataSource;
import ru.sp.drf.market.repository.FeedRepository;
import ru.sp.drf.market.repository.sql.SQL;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class FeedService extends AbstractService  {

    private final FeedRepository repository;

    public FeedService(FeedRepository repository) {
        this.repository = repository;
    }

    public Optional<Feed> findById(UUID id){
        return repository.findById(id);
    }

    public Feed save(Feed feed){
        return repository.save(feed);
    }

    public void delete (Feed feed){
        repository.delete(feed);
    }

    @Transactional
    public List<Feed> findAllActive() {
        return repository.findAllActive();
    }

    @Transactional
    public Feed findByID(UUID uuid) {
        Optional<Feed> f = repository.findById(uuid);
        return (f.isPresent())?f.get():null;
    }

    public void setExpiredFeedsAsError() throws SQLException{
        try (Connection conn =MarketDataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL.setExpiredFeedsAsError.getSQL())){
            ps.executeUpdate();
        }
    }
}
