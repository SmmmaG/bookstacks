package ru.sp.drf.market.task;

public  interface PostProcessingListener {
    void onAfterLoad();
}
