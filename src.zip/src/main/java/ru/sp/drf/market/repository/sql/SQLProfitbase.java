package ru.sp.drf.market.repository.sql;

public enum SQLProfitbase {

    addComplex("INSERT INTO profitbase.profitbase_complex (uuid,complex_id, " +
    "complex_name," +
    "type,"+
    "region,"+
    "district,"+
    "locality,"+
    "developer,"+
    "developer_brand,"+
    "banks,"+
    "currency) VALUES (?,?,rem_clean_complex_name(?),?,?,?,?,?,?,?,?);"),


    addHouse("INSERT INTO profitbase.profitbase_house (uuid, house_id, complex_id," +
            "name, " +
            "year_end," +
            "quarter_end," +
            "min_floors," +
            "max_floors," +
            "building_number," +
            "address_full," +
            "address_locality," +
            "address_district," +
            "address_region," +
            "address_street," +
            "address_number," +
            "house_type," +
            "facing," +
            "material," +
            "building_state," +
            "min_price," +
            "min_price_area," +
            "image_url," +
            "currency_code," +
            "currency_symbol," +
            "currency_title," +
            "currency_short_name," +
            "currency_unicode_symbol," +
            "sales_start," +
            "sales_end," +
            "house_badge_label," +
            "house_badge_color," +
            "house_badge_icon," +
            "complex_uuid," +
            "flats_count) VALUES (?,?,?,rem_clean_building_name(?),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"),
    addAppartment("INSERT INTO profitbase.profitbase_appartments (uuid,flat_id,house_id," +
            "complex_name," +
            "flat_number," +
            "rooms_amount," +
            "floor," +
            "section_name," +
            "is_studio," +
            "is_free_layout," +
            "type," +
            "area_total," +
            "area_estimated," +
            "area_living," +
            "area_kitchen," +
            "area_balcony," +
            "area_without_balcony," +
            "status," +
            "special_offers_ids," +
            "house_uuid," +
            "price) VALUES (?,?,?,rem_clean_complex_name(?),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"),
    addComplexPhoto("INSERT INTO profitbase.profitbase_complex_photos (id,url,complex_id,complex_uuid) VALUES (?,?,?,?);"),
    addHousePhoto("INSERT INTO profitbase.profitbase_house_photos (id,url,house_id,house_uuid) VALUES (?,?,?,?);"),
    addPhotoTag("INSERT INTO profitbase.profitbase_phototags (id, title, photoid) VALUES (?,?,?);"),
    addStatictic("INSERT INTO profitbase.profitbase_statistic (id,sAllMin,sAllMax,totalPriceMin,totalPriceMax,countActive,housesId,complexId,flatCode) VALUES (?,?,?,?,?,?,?,?,?);"),
    addApprovedCreditProduct("INSERT INTO profitbase.profitbase_house_bank_products(id,title,house_id,house_uuid) VALUES (?,?,?,?);"),
    addDiscounts("INSERT INTO profitbase.profitbase_discounts(id,name,description,dateBegin,dateEnd,houseid,houseuuid) VALUES (?,?,?,?,?,?,?);"),
    updateDocumentPhotoComplex("SELECT rem_update_document_photo_complex_profitbase() updated;"),
    updateDocumentPhotoBuilding("SELECT rem_update_document_photo_building_profitbase() updated;"),
    getTempComplexCount("SELECT count(uuid) FROM profitbase.profitbase_complex;"),
    getTempBuildCount("SELECT count(uuid) FROM profitbase.profitbase_house;"),
    getTempFlatCount("SELECT count(uuid) FROM profitbase.profitbase_appartments;"),
    ;

    SQLProfitbase(String sql) {
        this.sql = sql;
    }
    private String sql;

    public String getSQL() {return sql;}
}
