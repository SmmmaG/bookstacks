package ru.sp.drf.market.model.elastic;

import ru.sp.drf.market.model.BasicItem;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static ru.sp.drf.market.model.elastic.Attributes.*;
import static ru.sp.drf.market.utilities.HelperUtils.*;

public class ComplexData implements BasicItem<String> {

    private final String id;
    private final String name;
    private final String address;
    private final String cityId;
    private final String cityName;
    private final String cityFias;
    private final String regionId;
    private final String regionName;
    private final String regionFias;
    private String[] location;

    public ComplexData(String id, String name, String address, String cityId, String cityName, String cityFias, String regionId, String regionName, String regionFias, Double lat, Double lon) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.cityId = cityId;
        this.cityName = cityName;
        this.cityFias = cityFias;
        this.regionId = regionId;
        this.regionName = regionName;
        this.regionFias = regionFias;
        if (lat != null && lon != null)
            this.location = new String[]{String.valueOf(lon), String.valueOf(lat)};

    }

    public ComplexData(UUID _id, String name, String addressFull, UUID cityId, String cityName, UUID cityFias, UUID regionId, String regionName, UUID regionFias, Double lat, Double lon) {

        this.id = _id != null ? _id.toString() : null;
        this.name = name;
        this.address = addressFull;

        this.cityId = cityId != null ? cityId.toString() : null;
        this.cityName = cityName;
        this.cityFias = cityFias != null ? cityFias.toString() : null;

        this.regionId = regionId != null ? regionId.toString() : null;
        this.regionName = regionName;
        this.regionFias = regionFias != null ? regionFias.toString() : null;
        if (lat != null && lon != null)
            this.location = new String[]{String.valueOf(lon), String.valueOf(lat)};

    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getCityId() {
        return cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public String getCityFias() {
        return cityFias;
    }

    public String getRegionId() {
        return regionId;
    }

    public String getRegionName() {
        return regionName;
    }

    public String getRegionFias() {
        return regionFias;
    }

    public String[] getLocation() {
        return location;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> result = new HashMap<>();
        result.put(ACTUAL_ON, new Date());
        result.put(NAME, formatName(getValue(this.name)));
        result.put(Attributes.UUID, this.id);
        result.put(CITY_UUID, getValue(this.cityId));
        result.put(CITY_NAME, formatName(getValue(this.cityName)));
        result.put(CITY_CODE, formatName(getValue(this.cityFias)));
        result.put(REGION_UUID, getValue(this.regionId));
        result.put(REGION_NAME, formatName(getValue(this.regionName)));
        result.put(REGION_CODE, formatName(getValue(this.regionFias)));
        result.put(ADDRESS, formatName(getValue(this.address)));
        SuggestRequest request = new SuggestRequest(getValue(this.name), SplitBuilder.split(getValue(this.name), " ").split("-").toArray());
        request.getContext().add(CONTEXTS_AREA_CODE, result.get(REGION_CODE), result.get(CITY_CODE));
        result.put(SUGGEST_NAME, request);

/*
        if (isValid(this.location))
            result.put("location", new LocationPoint(this.location).getCoordinates());

*/
        return result;
    }

    @Override
    public Map<String, Object> toMap(String... attributes) {
        return toMap();
    }
}
