package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Statistics{

	@JsonProperty("recognizedConditions")
	private List<String> recognizedConditions;

	@JsonProperty("duration")
	private String duration;

	@JsonProperty("resultObjectsCount")
	private Object resultObjectsCount;

	@JsonProperty("currentPageObjectsCount")
	private int currentPageObjectsCount;

	@JsonProperty("searchString")
	private String searchString;

	@JsonProperty("houseId")
	private int houseId;

	@JsonProperty("pageNumber")
	private int pageNumber;

	@JsonProperty("regionGroupId")
	private int regionGroupId;

	@JsonProperty("totalPages")
	private int totalPages;

	@JsonProperty("pageSize")
	private int pageSize;

	@JsonProperty("lastDateUpdate")
	private Object lastDateUpdate;

	@JsonProperty("totalObjectsCount")
	private int totalObjectsCount;

	public void setRecognizedConditions(List<String> recognizedConditions){
		this.recognizedConditions = recognizedConditions;
	}

	public List<String> getRecognizedConditions(){
		return recognizedConditions;
	}

	public void setDuration(String duration){
		this.duration = duration;
	}

	public String getDuration(){
		return duration;
	}

	public void setResultObjectsCount(Object resultObjectsCount){
		this.resultObjectsCount = resultObjectsCount;
	}

	public Object getResultObjectsCount(){
		return resultObjectsCount;
	}

	public void setCurrentPageObjectsCount(int currentPageObjectsCount){
		this.currentPageObjectsCount = currentPageObjectsCount;
	}

	public int getCurrentPageObjectsCount(){
		return currentPageObjectsCount;
	}

	public void setSearchString(String searchString){
		this.searchString = searchString;
	}

	public String getSearchString(){
		return searchString;
	}

	public void setHouseId(int houseId){
		this.houseId = houseId;
	}

	public int getHouseId(){
		return houseId;
	}

	public void setPageNumber(int pageNumber){
		this.pageNumber = pageNumber;
	}

	public int getPageNumber(){
		return pageNumber;
	}

	public void setRegionGroupId(int regionGroupId){
		this.regionGroupId = regionGroupId;
	}

	public int getRegionGroupId(){
		return regionGroupId;
	}

	public void setTotalPages(int totalPages){
		this.totalPages = totalPages;
	}

	public int getTotalPages(){
		return totalPages;
	}

	public void setPageSize(int pageSize){
		this.pageSize = pageSize;
	}

	public int getPageSize(){
		return pageSize;
	}

	public void setLastDateUpdate(Object lastDateUpdate){
		this.lastDateUpdate = lastDateUpdate;
	}

	public Object getLastDateUpdate(){
		return lastDateUpdate;
	}

	public void setTotalObjectsCount(int totalObjectsCount){
		this.totalObjectsCount = totalObjectsCount;
	}

	public int getTotalObjectsCount(){
		return totalObjectsCount;
	}

	@Override
 	public String toString(){
		return 
			"Statistics{" + 
			"recognizedConditions = '" + recognizedConditions + '\'' + 
			",duration = '" + duration + '\'' + 
			",resultObjectsCount = '" + resultObjectsCount + '\'' + 
			",currentPageObjectsCount = '" + currentPageObjectsCount + '\'' + 
			",searchString = '" + searchString + '\'' + 
			",houseId = '" + houseId + '\'' + 
			",pageNumber = '" + pageNumber + '\'' + 
			",regionGroupId = '" + regionGroupId + '\'' + 
			",totalPages = '" + totalPages + '\'' + 
			",pageSize = '" + pageSize + '\'' + 
			",lastDateUpdate = '" + lastDateUpdate + '\'' + 
			",totalObjectsCount = '" + totalObjectsCount + '\'' + 
			"}";
		}
}