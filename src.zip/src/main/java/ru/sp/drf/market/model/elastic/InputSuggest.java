package ru.sp.drf.market.model.elastic;

public class InputSuggest {
    private String[] input;
    private int weight = 1;

    public InputSuggest() {
    }

    public InputSuggest(int weight, String... input) {
        this.input = input;
        this.weight = weight;
    }

    public InputSuggest(String... input) {
        this.input = input;
    }

    public String[] getInput() {
        return input;
    }

    public void setInput(String[] input) {
        this.input = input;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
