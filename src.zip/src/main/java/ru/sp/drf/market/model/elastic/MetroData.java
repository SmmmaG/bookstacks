package ru.sp.drf.market.model.elastic;

import ru.sp.drf.market.model.BasicItem;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static ru.sp.drf.market.model.elastic.Attributes.*;
import static ru.sp.drf.market.utilities.HelperUtils.formatName;
import static ru.sp.drf.market.utilities.HelperUtils.getValue;

public class MetroData implements BasicItem<String> {

    private final String id;
    private final String name;
    private final String line_color;
    private final String code;
    private final String cityId;
    private final String regionId;
    private final String regionFias;
    private final String cityFias;

    public MetroData(String _id, String name, String line_color, String code, String cityId, String cityFias, String regionId, String regionFias) {
        this.id = _id;
        this.name = name;
        this.line_color = line_color;
        this.code = code;
        this.cityId = cityId;
        this.cityFias = cityFias;
        this.regionId = regionId;
        this.regionFias = regionFias;
    }

    public MetroData(UUID _id, String name, String line_color, String code, UUID cityId, UUID cityFias, UUID regionId, UUID regionFias) {
        this.id = _id != null ? _id.toString() : null;
        this.name = name;
        this.line_color = line_color;
        this.code = code;
        this.cityId = cityId != null ? cityId.toString() : null;
        this.cityFias = cityFias != null ? cityFias.toString() : null;
        this.regionId = regionId != null ? regionId.toString() : null;
        this.regionFias = regionFias != null ? regionFias.toString() : null;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLine_color() {
        return line_color;
    }

    public String getCode() {
        return code;
    }

    public String getCityId() {
        return cityId;
    }

    public String getRegionId() {
        return regionId;
    }

    public String getRegionFias() {
        return regionFias;
    }

    public String getCityFias() {
        return cityFias;
    }

    @Override
    public Map<String, Object> toMap() {
        Map<String, Object> result = new HashMap<>();
        result.put(ACTUAL_ON, new Date());
        result.put(NAME, formatName(getValue(this.name)));
        result.put(UUID, this.getId());
        result.put(CITY_UUID, getValue(this.cityId));
        result.put(CITY_CODE, formatName(getValue(this.cityFias)));
        result.put(REGION_UUID, getValue(this.regionId));
        result.put(REGION_CODE, getValue(formatName(this.regionFias)));
        result.put(LINE_COLOR, getValue(this.line_color));
        result.put(ICON_CODE, getValue(this.code));
        SuggestRequest request =  new SuggestRequest(getValue(this.name), SplitBuilder.split(getValue(this.name), " ").split("-").toArray());
        request.getContext().add(CONTEXTS_AREA_CODE, result.get(REGION_CODE), result.get(CITY_CODE));
        result.put(SUGGEST_NAME, request);
        //todo make location
//        result.put("contexts.location-geo", new GeoPoint[]{lat, long});
        return result;
    }

    @Override
    public Map<String, Object> toMap(String... attributes) {
        return toMap();
    }
}
