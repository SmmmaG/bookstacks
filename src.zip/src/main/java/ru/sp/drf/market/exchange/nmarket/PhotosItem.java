package ru.sp.drf.market.exchange.nmarket;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
public class PhotosItem extends Storable<ComplexesItem, UUID> {

    @JsonProperty("objectTypeId")
    private int objectTypeId;

    @JsonProperty("description")
    private String description;

    @JsonProperty("url")
    private String url;

    @JsonProperty("tags")
    private List<String> tags;

    public void setObjectTypeId(int objectTypeId) {
        this.objectTypeId = objectTypeId;
    }

    public int getObjectTypeId() {
        return objectTypeId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public List<String> getTags() {
        return tags;
    }

    @Override
    public UUID save(ComplexesItem complexesItem, AtomicOperation dataSourse) throws Exception {
        UUID photoUUId = dataSourse.addComplexPhoto(this, complexesItem.getComplexUUId(), complexesItem.getComplexId());
        dataSourse.addPhotoTags(tags, photoUUId);
        return photoUUId;
    }

    @Override
    public String toString() {
        return
                "PhotosItem{" +
                        "objectTypeId = '" + objectTypeId + '\'' +
                        ",description = '" + description + '\'' +
                        ",url = '" + url + '\'' +
                        ",tags = '" + tags + '\'' +
                        "}";
    }
}