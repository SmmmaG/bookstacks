package ru.sp.drf.market.exchange.nmarket;


public abstract class Storable<PARENT, ENTITY> {
    abstract ENTITY save(PARENT parent, AtomicOperation dataSourse) throws Exception;
}
