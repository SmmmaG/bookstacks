package ru.sp.drf.market.dataloader.elastic;

import org.elasticsearch.action.index.IndexRequest;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.loaders.FiasConfig;
import ru.sp.drf.market.model.fias.AOLevel;
import ru.sp.drf.market.model.fias.DataRow;

import java.io.IOException;
import java.util.Map;

public class AddressSliceLoader extends BasicSlicer<DataRow> {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    public AddressSliceLoader() {
        super("address");
    }

    public void addItemForCreate(DataRow item) {
        try {
            request.add(new IndexRequest(FiasConfig.getElasticDbPrefix() + indexName).id(item.getId().toString()).source(buildIndexBody(item.toMap())));

            if (AOLevel.findByCode(item.getLevel()) == AOLevel.regionLevel) {
                if (item.getPrefix().equalsIgnoreCase("г")) {
                    Map<String, Object> values = item.toMap();
                    values.put("level", AOLevel.city1Level.getType());
                    request.add(new IndexRequest(FiasConfig.getElasticDbPrefix() + indexName).id(item.getId().toString()).source(buildIndexBody(values)));
                }
            }
        } catch (IOException e) {
           LOG.error("Unexpected exception", e);
        }

    }


}
