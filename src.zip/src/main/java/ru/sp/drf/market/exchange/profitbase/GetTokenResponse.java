package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class GetTokenResponse {
    @JsonProperty("access_token")
    private String accessToken;
    @JsonProperty("lang")
    private String lang;
    @JsonProperty("remaining_time")
    private double remainingTime;


    public String getAccessToken() {
        return accessToken;
    }

    public String getLang() {
        return lang;
    }

    public double getRemainingTime() {
        return remainingTime;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public void setRemainingTime(double remainingTime) {
        this.remainingTime = remainingTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof GetTokenResponse)) return false;
        GetTokenResponse that = (GetTokenResponse) o;
        return Double.compare(that.remainingTime, remainingTime) == 0 &&
                Objects.equals(accessToken, that.accessToken) &&
                Objects.equals(lang, that.lang);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accessToken, lang, remainingTime);
    }


}