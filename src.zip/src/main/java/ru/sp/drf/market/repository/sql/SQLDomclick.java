package ru.sp.drf.market.repository.sql;

public enum SQLDomclick {

    updateDocumentPhotoComplex("SELECT rem_update_document_photo_complex_domclick() updated;"),
    updateDocumentPhotoBuilding("SELECT rem_update_document_photo_building_domclick() updated;"),

    getTempComplexCount("SELECT count(UUID) FROM $schema$.complexes;"),
    getTempBuildCount("SELECT count(UUID) FROM $schema$.buildings;"),
    getTempFlatCount("SELECT count(UUID) FROM $schema$.flats;"),
    ;

    SQLDomclick(String sql) {
        this.sql = sql;
    }
    private String sql;

    public String getSQL() {return sql;}
}
