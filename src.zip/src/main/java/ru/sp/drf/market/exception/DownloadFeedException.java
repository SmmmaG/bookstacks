package ru.sp.drf.market.exception;

public class DownloadFeedException extends FeedException {
    public DownloadFeedException() {
    }

    public DownloadFeedException(String message) {
        super(message);
    }

    public DownloadFeedException(String message, Throwable cause) {
        super(message, cause);
    }

    public DownloadFeedException(Throwable cause) {
        super(cause);
    }

    public DownloadFeedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
