package ru.sp.drf.market.utilities;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.domrf.rem.domain.admin.*;
import ru.domrf.rem.utilities.ScriptExecutor.EventResult;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.MarketDataSource;
import ru.sp.drf.market.repository.*;
import ru.sp.drf.market.repository.sql.SQL;

import javax.annotation.PostConstruct;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

@Component
public class LoadLogger {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    static EventLogsRepository eventLogsRepository;
    static FeedLogRepository feedLogRepository;
    static FeedLogFileRepository feedLogFileRepository;

    static FeedEventTypeRepository feedEventTypeRepository;
    static Map<FeedEventTypes, FeedEventType> feedEvents = new HashMap();
    static FeedLogStatusRepository feedLogStatusRepository;
    static Map<FeedLogStatuses, FeedLogStatus> feedStatuses = new HashMap();

    @PostConstruct
    private void postConstruct() {
        //add new events
        Arrays.asList(FeedEventTypes.values()).forEach(event -> {
            FeedEventType feedEventType = feedEventTypeRepository.findByCode(event.getEvent());
            if (Objects.isNull(feedEventType)) {
                feedEventType = new FeedEventType(event.getEvent(), event.getName());
                feedEventTypeRepository.save(feedEventType);
            }
            feedEvents.put(FeedEventTypes.valueOf(event.getEvent()), feedEventType);
        });
        //update names and descriptions
        feedEventTypeRepository.findAll().forEach(event -> {
            event.setName(FeedEventTypes.valueOf(event.getCode()).getName());
            feedEventTypeRepository.save(event);
        });

        //add new statuses
        Arrays.asList(FeedLogStatuses.values()).forEach(status -> {
            FeedLogStatus newStatus = feedLogStatusRepository.findByCode(status.getStatus());
            if (Objects.isNull(newStatus)) {
                newStatus = new FeedLogStatus(status.getStatus(), status.getDescript(), status.getName());
                feedLogStatusRepository.save(newStatus);
            }
            feedStatuses.put(FeedLogStatuses.valueOf(status.getStatus()), newStatus);
        });
        //update names and descriptions
        feedLogStatusRepository.findAll().forEach(status -> {
            status.setName(FeedLogStatuses.valueOf(status.getCode()).getName());
            status.setDescription(FeedLogStatuses.valueOf(status.getCode()).getDescript());
            feedLogStatusRepository.save(status);
        });
        LOG.info("feedStatuses=" + feedStatuses);
    }

    public static Map<FeedLogStatuses, FeedLogStatus> getFeedStatuses() {
        return feedStatuses;
    }

    @Autowired
    public void setFeedLogRepository(EventLogsRepository feedLogRepository) {
        this.eventLogsRepository = feedLogRepository;
    }

    @Autowired
    public void setFeedEventTypeRepository(FeedEventTypeRepository feedEventTypeRepository) {
        this.feedEventTypeRepository = feedEventTypeRepository;
    }

    @Autowired
    public void setFeedLogStatusRepository(FeedLogStatusRepository feedLogStatusRepository) {
        LoadLogger.feedLogStatusRepository = feedLogStatusRepository;
    }

    @Autowired
    public void setFeedLogRepository(FeedLogRepository feedLogRepository) {
        LoadLogger.feedLogRepository = feedLogRepository;
    }

    @Autowired
    public void setFeedLogFileRepository(FeedLogFileRepository feedLogFileRepository) {
        LoadLogger.feedLogFileRepository = feedLogFileRepository;
    }

    public static void writeFeedFile(FeedLog feedLog, char[] file) {
        FeedLogFile logFile = new FeedLogFile();
        logFile.setFile(file);
        logFile = feedLogFileRepository.save(logFile);
        feedLog.setFile(logFile);
        feedLog.setUpdateDate(new Date());
        FeedLog latest = feedLogRepository.findById(feedLog.getId()).get();
        feedLog.setVersion(latest.getVersion());
        feedLogRepository.save(feedLog);
    }

    public static void setLoadStatus(FeedLog feedLog, FeedLogStatuses status, boolean updateFeedStatus) throws SQLException {
        try (Connection conn = MarketDataSource.getConnection();
             PreparedStatement psFeed = conn.prepareStatement(SQL.setFeedStatus.getSQL());
             PreparedStatement psFeedLog = conn.prepareStatement(SQL.setFeedLogStatus.getSQL())) {
            if (updateFeedStatus) {
                psFeed.setObject(1, feedStatuses.get(status).getId());
                psFeed.setObject(2, feedLog.getFeed().getId());
                psFeed.executeUpdate();
            }
            psFeedLog.setObject(1, feedStatuses.get(status).getId());
            psFeedLog.setObject(2, feedLog.getId());
            psFeedLog.executeUpdate();
        }
    }

    public static void setLastFeedEvent(DevelopEventLog event, Feed feed) throws SQLException{
        try (Connection conn = MarketDataSource.getConnection();
             PreparedStatement psFeedEvent = conn.prepareStatement(SQL.setFeedLastEvent.getSQL())) {
            psFeedEvent.setObject(1, event.getId());
            psFeedEvent.setObject(2, feed.getId());
            psFeedEvent.executeUpdate();
        }
    }

    public static DevelopEventLog writeScriptLog(ScriptResult result, FeedLog feedLog, boolean throwTheException, FeedEventTypes eventType) throws SQLException {
        boolean hasError = !Objects.isNull(result.getError());
        DevelopEventLog log = new DevelopEventLog(
                feedLog,
                result.getLog(),
                result.getError(),
                result.getRows(),
                feedEvents.get(eventType),
                (hasError ? 0 : result.getScriptTime()),
                (!Objects.isNull(result.getError())));

        if (Objects.nonNull(result.getError())) {
            LOG.info("errors: " + result.getError() + " script:" + result.getLog());
            if (throwTheException)
                throw new SQLException(result.getError());
        }
        return eventLogsRepository.save(log);
    }

    public static void writeValidationLog(EventResult result, FeedLog feedLog, FeedEventTypes eventType) throws SQLException {
        ValidationEventLog log = new ValidationEventLog(
                feedLog,
                result.getLog(),
                result.getError(),
                result.getRows(),
                feedEvents.get(eventType),
                (!Objects.isNull(result.getError())));

        eventLogsRepository.save(log);
        if (Objects.nonNull(result.getError())) {
            LOG.info("errors: " + result.getError() + " action:" + result.getLog());
        }
    }
}
