package ru.sp.drf.market.dataloader.validation;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.ScriptExecutor.ValidationResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dto.validation.ValidationStatisticsDto;
import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

abstract public class ErrorHandler extends DefaultHandler {

    private static final CustomLogger LOG = CustomLogger.getLogger();

    private FeedLog feedLog;
    private Map<ValidationMapKey, Set<String>> validationMap;
    private int validationStatus = 0;
    protected File file;


    ErrorHandler() {
        this.validationMap = new HashMap();
    }

    ErrorHandler(FeedLog feedLog, File file) {
        this.validationMap = new HashMap();
        this.feedLog = feedLog;
        this.file = file;
    }

    public void setFeedLog(FeedLog feedLog) {
        this.feedLog = feedLog;
    }

    public Map<ValidationMapKey, Set<String>> getValidationMap() {
        return validationMap;
    }

    public int getValidationStatus() {
        return validationStatus;
    }

    public void setValidationStatus(int validationStatus) {
        this.validationStatus = validationStatus;
    }

    @Override
    public void warning(SAXParseException e) throws SAXException {
        printInfo(e);
    }

    @Override
    public void error(SAXParseException e) throws SAXException {
        printInfo(e);
    }

    @Override
    public void fatalError(SAXParseException e) throws SAXException {
        LOG.error("Fattal error: ",e);
        printInfo(e);
    }

    private void printInfo(SAXParseException e) {
        String error = e.getMessage();
        String message = "Неверно заполнено поле";
        String field = null;
        if (error.startsWith("cvc-type.3.1.3: The value ''") || error.startsWith("cvc-minLength-valid: Value '' with length = '0'"))
            message = "Не задано значение";
        if (error.startsWith("cvc-type.3.1.3:")) {
            field = error.substring(error.indexOf("of element '") + 12, error.length() - 15);
        } else if (error.startsWith("cvc-enumeration-valid")) {
            String value = error.substring(30, error.indexOf("' is not facet-valid"));
            message = "".equals(value) ? "Не задано значение" :
                    "Значение \"" + value + "\" не соответствует возможным значениям: " + error.substring(error.indexOf("[") + 1, error.indexOf("]"));
        } else if (error.startsWith("cvc-datatype-valid.1.2.")) {
            int valueEndIdx = error.indexOf("' is not a valid value");
            String substr = error.substring(valueEndIdx + 2);
            String value = error.substring(27, valueEndIdx);
            message = "".equals(value) ? message = "Не задано значение" :
                    "Недопустимое значение \"" + value + "\" ожидается значение типа \"" + substr.substring(substr.indexOf("'") + 1, substr.length() - 2) + "\"";
        } else if (error.startsWith("cvc-pattern-valid")) {
            String value = error.substring(26, error.indexOf("' is not facet-valid"));
            message = "".equals(value) ? "Не задано значение" :
                    "Значение \"" + value + "\" не соответствует формату: " + error.substring(error.indexOf("pattern ") + 9, error.indexOf("' for type"));
        } else if (error.startsWith("cvc-minInclusive") || error.startsWith("cvc-minExclusive") || error.startsWith("cvc-maxInclusive") || error.startsWith("cvc-maxExclusive")) {
            String value = error.substring(31, error.indexOf("' is not facet-valid"));
            message = "Не верное значение: " + value;
        } else if (error.startsWith("cvc-complex-type.2.4.b")) {
            String value = error.substring(48, error.indexOf("' is not complete. "));
            message = "Заполнены не все обязательные поля в блоке: " + value;
        } else if (error.startsWith("cvc-complex-type.2.4.") || error.startsWith("cvc-type.3.1.1:")) {
            return;
        }
        if (message.equals("Неверно заполнено поле") && field == null) {
            LOG.info("Line number: {}  Message: {}",e.getLineNumber(),e.getMessage().replace("\"http://webmaster.yandex.ru/schemas/feed/realty/2010-06\":", ""));
        }
        ValidationMapKey key = new ValidationMapKey(field, message);

        if (validationMap.containsKey(key)) {
            validationMap.get(key).add(Integer.toString(e.getLineNumber()));
        } else {
            TreeSet lines = new TreeSet();
            lines.add(Integer.toString(e.getLineNumber()));
            validationMap.put(key, lines);
        }
        validationStatus = 1;
    }

    public abstract ValidationStatisticsDto countStatistics() throws IOException;

    public void writeValidationLog() throws SQLException {
        for (ValidationMapKey validationMapKey : validationMap.keySet()) {
            LoadLogger.writeValidationLog(
                    new ValidationResult(
                            validationMapKey.getMessage(),
                            validationMap.get(validationMapKey).size(),
                            validationMap.get(validationMapKey).stream().collect(Collectors.joining(","))
                    ),
                    feedLog,
                    FeedEventTypes.Is_XML_Validation);
        }
    }

}
