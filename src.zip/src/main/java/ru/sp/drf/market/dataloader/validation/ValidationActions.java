package ru.sp.drf.market.dataloader.validation;

public enum ValidationActions {
    IsXMLValidationAction("Проверка файла фида на корректность формата XML"),
    SSLValidationAction("Проверка протокола рукопожатия SSL"),
    SchemeValidationAction("Проверка фида на XSD-схему"),
    ;

    ValidationActions(String validation_action) {
        this.validation_action = validation_action;
    }

    private String validation_action;

    public String getAction() {
        return validation_action;
    }
}
