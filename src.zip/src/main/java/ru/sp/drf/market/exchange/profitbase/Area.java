package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.Objects;

@Generated("com.robohorse.robopojogenerator")
public class Area {
    @JsonProperty("area_total")
    private Double areaTotal;
    @JsonProperty("area_estimated")
    private Double areaEstimated;
    @JsonProperty("area_living")
    private Double areaLiving;
    @JsonProperty("area_kitchen")
    private Double areaKitchen;
    @JsonProperty("area_balcony")
    private Double areaBalcony;
    @JsonProperty("area_without_balcony")
    private Double areaWithoutBalcony;

    public Double getAreaTotal() {
        return areaTotal;
    }

    public void setAreaTotal(Double areaTotal) {
        this.areaTotal = areaTotal;
    }

    public Double getAreaEstimated() {
        return areaEstimated;
    }

    public void setAreaEstimated(Double areaEstimated) {
        this.areaEstimated = areaEstimated;
    }

    public Double getAreaLiving() {
        return areaLiving;
    }

    public void setAreaLiving(Double areaLiving) {
        this.areaLiving = areaLiving;
    }

    public Double getAreaKitchen() {
        return areaKitchen;
    }

    public void setAreaKitchen(Double areaKitchen) {
        this.areaKitchen = areaKitchen;
    }

    public Double getAreaBalcony() {
        return areaBalcony;
    }

    public void setAreaBalcony(Double areaBalcony) {
        this.areaBalcony = areaBalcony;
    }

    public Double getAreaWithoutBalcony() {
        return areaWithoutBalcony;
    }

    public void setAreaWithoutBalcony(Double areaWithoutBalcony) {
        this.areaWithoutBalcony = areaWithoutBalcony;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Area)) return false;
        Area area = (Area) o;
        return Objects.equals(areaTotal, area.areaTotal) &&
                Objects.equals(areaEstimated, area.areaEstimated) &&
                Objects.equals(areaLiving, area.areaLiving) &&
                Objects.equals(areaKitchen, area.areaKitchen) &&
                Objects.equals(areaBalcony, area.areaBalcony) &&
                Objects.equals(areaWithoutBalcony, area.areaWithoutBalcony);
    }

    @Override
    public int hashCode() {
        return Objects.hash(areaTotal, areaEstimated, areaLiving, areaKitchen, areaBalcony, areaWithoutBalcony);
    }

    @Override
    public String toString() {
        return "Area{" +
                "areaTotal=" + areaTotal +
                ", areaEstimated=" + areaEstimated +
                ", areaLiving=" + areaLiving +
                ", areaKitchen=" + areaKitchen +
                ", areaBalcony=" + areaBalcony +
                ", areaWithoutBalcony=" + areaWithoutBalcony +
                '}';
    }
}
