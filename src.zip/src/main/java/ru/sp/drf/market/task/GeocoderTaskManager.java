package ru.sp.drf.market.task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;
import ru.domrf.rem.utilities.LoggedClass;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.utilities.Geocoder;

@Configuration
public class GeocoderTaskManager {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    @Autowired
    private Geocoder geocoder;

    @Scheduled(cron = "${app.geocoder.cron}")
    public void scheduleGeocoding() {
        if (FeedServiceConfig.ENABLE_GEOCODER_CITY_REGIONS) {
            geocoder.executeRegionCityGeocode();
            LOG.info("end geocoding");
        } else {
            LOG.info("Scheduler switch off from  parameter spring.scheduled.geocoder.enable={}", FeedServiceConfig.ENABLE_GEOCODER_CITY_REGIONS);
        }

    }
}
