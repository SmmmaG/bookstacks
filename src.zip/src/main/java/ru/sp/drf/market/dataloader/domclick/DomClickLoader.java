package ru.sp.drf.market.dataloader.domclick;

import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.XmlFeedLoader;
import ru.sp.drf.market.dataloader.validation.DomclickErrorHandler;
import ru.sp.drf.market.dataloader.validation.ValidationEvents;
import ru.sp.drf.market.dataloader.validation.XmlValidator;
import ru.sp.drf.market.dto.validation.ValidationResultDto;
import ru.sp.drf.market.exception.NoObjectsAfterValidationException;
import ru.sp.drf.market.repository.sql.SQLDomclick;
import ru.sp.drf.market.utilities.FeedEventTypes;

import java.io.IOException;
import java.sql.SQLException;

@Component
public class DomClickLoader extends XmlFeedLoader<DomclickDataSource> {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    private static final String DOMCLICK = "domclick";
    @Override
    public String getSchemaNamePrefix(){
        return DOMCLICK;
    }

    @Override
    public ValidationResultDto onSchemeValidation() throws SQLException {
        try {
            DomclickErrorHandler errorHandler = new DomclickErrorHandler(feedLog, xmlFile);
            XmlValidator.validate(xmlFile, errorHandler, "feeds/xsd/domclick/domclick.xsd");
            errorHandler.writeValidationLog();
            return new ValidationResultDto(errorHandler);
        } catch (IOException e) {
            LOG.error("Unexpected exception", e);
        } catch (SAXException e) {
            LOG.info(feedLog.getFeed().getUrl() + " is not valid because ");
            LOG.info("SAXException: " + e.getMessage());
            ValidationResultDto result = new ValidationResultDto(3);
            result.addError("Не удалось распознать фид");
            return result;
        }
        return null;
    }

    @Override
    public ValidationResultDto executeValidateTask() throws Exception {
        operation.setAutoCommit(false);
        String tempSchemaName = DOMCLICK + "_" + feedLog.getId();
        operation.setSchemaName(tempSchemaName);
        ValidationResultDto result = onSchemeValidation();
        onCreateTempSchema(tempSchemaName);
        operation.commit();
        onParse();
        onValidate();
        operation.commit();
        onRemoveTempSchema(tempSchemaName);
        operation.commit();
        return result;
    }

    @Override
    protected void onCreateTempSchema(final String schemaName) throws IOException, SQLException {
        operation.createTempSchema(schemaName, feedLog);
    }

    @Override
    protected void onRemoveTempSchema(final String schemaName) throws IOException, SQLException {
        operation.removeTempSchema(schemaName, feedLog);
    }

    @Override
    public void onValidate() throws Exception {
        int complexesCount = operation.getCount(SQLDomclick.getTempComplexCount.getSQL());
        int buildingsCount = operation.getCount(SQLDomclick.getTempBuildCount.getSQL());
        int flatsCount = operation.getCount(SQLDomclick.getTempFlatCount.getSQL());
        writeValidationLog(ValidationEvents.checkComplexCountBeforeValidation, FeedEventTypes.Complexes_Validation, complexesCount, false);
        writeValidationLog(ValidationEvents.checkBuildCountBeforeValidation, FeedEventTypes.Buildings_Validation, buildingsCount, false);
        writeValidationLog(ValidationEvents.checkFlatCountBeforeValidation, FeedEventTypes.Flats_Validation, flatsCount, false);

        this.onComplexesValidation(complexesCount);
        this.onBuildingsValidation(buildingsCount);
        this.onFlatsValidation(flatsCount);

        int afterComplexesCount = operation.getCount(SQLDomclick.getTempComplexCount.getSQL());
        int afterBuildingsCount = operation.getCount(SQLDomclick.getTempBuildCount.getSQL());
        int afterFlatsCount = operation.getCount(SQLDomclick.getTempFlatCount.getSQL());
        writeValidationLog(ValidationEvents.checkComplexCountAfterValidation, FeedEventTypes.Count_Complexes_Validation, afterComplexesCount, true);
        writeValidationLog(ValidationEvents.checkBuildCountAfterValidation, FeedEventTypes.Count_Buildings_Validation, afterBuildingsCount, true);
        writeValidationLog(ValidationEvents.checkFlatCountAfterValidation, FeedEventTypes.Count_Flats_Validation, afterFlatsCount, true);
        feedIsFullyLoaded = (flatsCount == afterFlatsCount) && (buildingsCount == afterBuildingsCount) && (complexesCount == afterComplexesCount);
        feedIsEmpty = flatsCount == 0 && buildingsCount == 0 && complexesCount == 0;
    }

    public void onComplexesValidation(int complexesCountBefore) throws Exception {
        operation.complexesCheckMandatoryFieldsValidation(feedLog);
        operation.complexesCheckNonUniqueId(feedLog);
        operation.complexesRemoveRelatedData(feedLog);
        int complexesCountAfter = operation.getCount(SQLDomclick.getTempComplexCount.getSQL());
        operation.commit();

        if (complexesCountAfter == 0 && complexesCountBefore != complexesCountAfter) {
            throw new NoObjectsAfterValidationException("Complexes " + ValidationEvents.noDataAfterValidation.getMessage());
        }
    }

    public void onBuildingsValidation(int buildingsCountBefore) throws Exception {
        operation.buildingsCheckMandatoryFieldsValidation(feedLog);
        operation.buildingsCheckNonUniqueId(feedLog);
        operation.buildingsRemoveRelatedData(feedLog);
        int buildingsCountAfter = operation.getCount(SQLDomclick.getTempBuildCount.getSQL());
        operation.commit();

        if (buildingsCountAfter == 0 && buildingsCountBefore != buildingsCountAfter) {
            throw new NoObjectsAfterValidationException("Buildings " + ValidationEvents.noDataAfterValidation.getMessage());
        }
    }

    public void onFlatsValidation(int flatsCountBefore) throws Exception {
        operation.flatsCheckMandatoryFieldsValidation(feedLog);
        operation.flatsCheckNonUniqueId(feedLog);
        operation.buildingsRemoveRelatedData(feedLog);
        int flatsCountAfter = operation.getCount(SQLDomclick.getTempFlatCount.getSQL());
        operation.commit();

        if (flatsCountAfter == 0 && flatsCountBefore != flatsCountAfter) {
            throw new NoObjectsAfterValidationException("Flats " + ValidationEvents.noDataAfterValidation.getMessage());
        }
    }

    @Override
    public void onParse() throws Exception {
//        this.onSchemeValidation();
        String loadOperation = "load";
        LOG.info("Load Complexes");
        storeDataComplexes(loadOperation);
        LOG.info("Load Building");
        storeDataBuilding(loadOperation);
        LOG.info("Load Flat");
        storeDataFlat(loadOperation);
        LOG.info("Load SalesOffice");
        storeDataSalesOffice(loadOperation);
    }

    private void storeDataFlat(String loadOperation) throws IOException, SQLException {
        operation.addFlats(feedLog, loadOperation);
        operation.addFlatRooms(feedLog, loadOperation);
        operation.commit();
        operation.updateFlatReference(feedLog);
        //todo this will need later
        //operation.addFlatsPhoto(feedLog);

    }

    private void storeDataBuilding(String loadOperation) throws IOException, SQLException {
        operation.addBuildings(feedLog, loadOperation);
        operation.commit();
        operation.updateBuildungReference(feedLog);
        operation.addBuildingsPhoto(feedLog, loadOperation);
    }

    private void storeDataSalesOffice(String loadOperation) throws IOException, SQLException {
        operation.addSalesOffice(feedLog, loadOperation);
        operation.addSalesOfficeComplex(feedLog, loadOperation);
    }

    private void storeDataComplexes(String loadOperation) throws IOException, SQLException {
        operation.addComplexes(feedLog, loadOperation);
        operation.addComplexesPhoto(feedLog, loadOperation);
    }

    @Override
    protected boolean executeTasks() throws Exception {
        operation.setAutoCommit(false);
        operation.setSchemaName(DOMCLICK);
        onPrepare();
        onDownload();
        onParse();
        operation.commit();
        onValidate();
        onDisable();
        onLoad();
        onAfter();
        operation.commit();
        return true;
    }

    @Override
    protected void executeDisableTasks() throws Exception {
        operation.setAutoCommit(false);
        operation.setSchemaName(DOMCLICK);
        onDisable();
        onAfter();
        operation.commit();
    }

    @Override
    public void onAfter() throws Exception {
        LOG.info("on post processing phase");
        operation.recalculation(feedLog);
    }

    @Override
    public void onLoad() throws Exception {
        LOG.info("onLoad feedLog = " + feedLog);
        operation.storeData(feedLog);

    }

    public void onPrepare() throws Exception {
        LOG.info("on clear old Tables");
        operation.prepareTables(feedLog);
    }

    @Override
    public void onDisable() throws IOException, SQLException {
        LOG.info("on Disable old data");
        operation.disableData(feedLog);
    }

    @Override
    public void initConnection() throws Exception {
        operation = new DomclickDataSource();
    }

}