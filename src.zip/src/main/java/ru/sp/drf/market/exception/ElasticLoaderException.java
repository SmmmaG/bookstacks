package ru.sp.drf.market.exception;

public class ElasticLoaderException extends RuntimeException {
    public ElasticLoaderException() {
    }

    public ElasticLoaderException(String message) {
        super(message);
    }

    public ElasticLoaderException(String message, Throwable cause) {
        super(message, cause);
    }

    public ElasticLoaderException(Throwable cause) {
        super(cause);
    }

    public ElasticLoaderException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
