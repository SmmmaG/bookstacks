package ru.sp.drf.market.model;

import java.beans.Transient;
import java.util.Map;

public interface BasicItem<T> {
    T getId();
    @Transient
    Map<String,Object> toMap();
    @Transient
    Map<String,Object> toMap(String... attributes);
}
