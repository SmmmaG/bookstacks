package ru.sp.drf.market.dataloader.fias;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import ru.sp.drf.market.model.fias.AddressObject;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static ru.sp.drf.market.utilities.HelperUtils.isValid;

public class FiasXmlParserHandler extends DefaultHandler {

    private AddressObject addressObject = null;
    private StringBuffer insertScriptAddresses = null;
    private Set<Integer> objectLevels = null;

    @Override
    public void startElement(String uri, String localName, String qName,
                             Attributes attributes) throws SAXException {

        if ("Object".equalsIgnoreCase(qName)) {
            addressObject = new AddressObject();
            init();
            int length = attributes.getLength();
            // process each attribute
            for (int i = 0; i < length; i++) {
                switch (attributes.getQName(i).toUpperCase()) {
                    case "AOGUID":
                        addressObject.setId(attributes.getValue(i));
                        break;
                    case "PARENTGUID":
                        addressObject.setParentId(attributes.getValue(i));
                        break;
                    case "REGIONCODE":
                        addressObject.setRegionCode(attributes.getValue(i));
                        break;
                    case "AREACODE":
                        addressObject.setAreaCode(attributes.getValue(i));
                        break;
                    case "CITYCODE":
                        addressObject.setCityCode(attributes.getValue(i));
                        break;
                    case "CTARCODE":
                        addressObject.setCityAreaCode(attributes.getValue(i));
                        break;
                    case "PLACECODE":
                        addressObject.setPlaceCode(attributes.getValue(i));
                        break;
                    case "STREETCODE":
                        addressObject.setStreetCode(attributes.getValue(i));
                        break;
                    case "FORMALNAME":
                        addressObject.setFormalName(attributes.getValue(i));
                        break;
                    case "OFFNAME":
                        addressObject.setOfficialName(attributes.getValue(i));
                        break;
                    case "SHORTNAME":
                        addressObject.setObjTypeName(attributes.getValue(i));
                        break;
                    case "AOLEVEL":
                        addressObject.setObjLevel(Integer.parseInt(attributes.getValue(i)));
                        break;
                    case "OPERSTATUS":
                        addressObject.setRecordStatus(Integer.parseInt(attributes.getValue(i)));
                        break;
                    case "LIVESTATUS":
                        addressObject.setAlive(attributes.getValue(i).equals("1"));
                        break;
                    case "DIVTYPE":
                        addressObject.setDivType(Integer.parseInt(attributes.getValue(i)));
                        break;
                    case "AOID":
                        addressObject.setAoId(attributes.getValue(i));
                        break;
                    case "PREVID":
                        addressObject.setPrevId(attributes.getValue(i));
                        break;
                    case "NEXTID":
                        addressObject.setNextId(attributes.getValue(i));
                        break;
                    case "POSTALCODE":
                        addressObject.setPostalCode(attributes.getValue(i));
                        break;
                    case "OKATO":
                        addressObject.setOkato(attributes.getValue(i));
                        break;
                    case "OKTMO":
                        addressObject.setOktmo(attributes.getValue(i));
                        break;
                    case "AUTOCODE":
                        addressObject.setAutoCode(attributes.getValue(i));
                        break;
                    case "EXTRCODE":
                        addressObject.setExtCodeAutoCode(attributes.getValue(i));
                        break;
                    case "SEXTCODE":
                        addressObject.setSextCode(attributes.getValue(i));
                        break;
                    case "CODE":
                        addressObject.setCode(attributes.getValue(i));
                        break;
                    case "PLAINCODE":
                        addressObject.setPlainCode(attributes.getValue(i));
                        break;
                    case "CURRSTATUS":
                        addressObject.setCurrStatus(Integer.parseInt(attributes.getValue(i)));
                        break;
                    case "IFNSFL":
                        addressObject.setIfnsfl(attributes.getValue(i));
                        break;
                    case "TERRIFNSFL":
                        addressObject.setTerrifnsfl(attributes.getValue(i));
                        break;
                    case "TERRIFNSUL":
                        addressObject.setTerrifnsul(attributes.getValue(i));
                        break;
                    case "ACTSTATUS":
                        addressObject.setActStatus(Integer.parseInt(attributes.getValue(i)));
                        break;
                    case "CENTSTATUS":
                        addressObject.setCentStatus(Integer.parseInt(attributes.getValue(i)));
                        break;
                    case "STARTDATE":
                        addressObject.setStartDate(attributes.getValue(i));
                        break;
                    case "ENDDATE":
                        addressObject.setEndDate(attributes.getValue(i));
                        break;
                    case "UPDATEDATE":
                        addressObject.setUpdateDate(attributes.getValue(i));
                        break;
                    case "NORMDOC":
                        addressObject.setNormDoc(attributes.getValue(i));
                        break;

                }
            }
        }
    }

    private void init() {
        if (insertScriptAddresses == null) {
            insertScriptAddresses = new StringBuffer();
        }
        if (objectLevels == null) {
            objectLevels = new HashSet<>(Arrays.asList(new Integer[]{1, 3, 4, 6, 7, 35}));
        }

    }


    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if ("Object".equalsIgnoreCase(qName)) {
            if (addressObject.isAlive() && objectLevels.contains(addressObject.getObjLevel())) {
                insertScriptAddresses.append(addressObject.toSqlInsert());
            }
        }
    }


    public String getInsertScriptAddresses() {
        return insertScriptAddresses.toString();
    }

    public void clear() {
        insertScriptAddresses.delete(0, insertScriptAddresses.length());
    }

}
