package ru.sp.drf.market.task;

import ru.sp.drf.market.dataloader.elastic.ComplexLoader;
import ru.sp.drf.market.dataloader.elastic.MetroLoader;

import static ru.sp.drf.market.utilities.ElasticBulkClient.createIndex;
import static ru.sp.drf.market.utilities.ElasticBulkClient.deleteIndex;

public class LoadElasticTask implements Runnable {

    private ComplexLoader complexLoader;

    private MetroLoader metroLoader;


    public LoadElasticTask(ComplexLoader complexLoader, MetroLoader metroLoader) {
        this.complexLoader = complexLoader;
        this.metroLoader = metroLoader;
    }

    @Override
    public void run() {

        //sync elastic
        clearMetroSchema();
        clearComplexSchema();

        loadElastic();
    }

    private void loadElastic() {
        metroLoader.loadMetro();
        complexLoader.loadComplexes();
    }

    public void clearMetroSchema() {
        deleteIndex("metro");
        createIndex("metro.json", "metro");

    }


    public void clearAddressSchema() {
        deleteIndex("address");
        createIndex("address.json", "address");

    }

    public void clearComplexSchema() {
        deleteIndex("complex");
        createIndex("complex.json", "complex");

    }

    public void clearSchema() {
        clearMetroSchema();
        clearComplexSchema();
    }

}
