package ru.sp.drf.market.dataloader.fias;

public class StoreEvent {
    private String script;

    public StoreEvent(String script) {
        this.script = script;
    }

    public String getScript() {
        return script;
    }
}
