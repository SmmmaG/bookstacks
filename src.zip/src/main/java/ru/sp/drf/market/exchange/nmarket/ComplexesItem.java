package ru.sp.drf.market.exchange.nmarket;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
public class ComplexesItem extends Storable<Object, UUID> implements HasStatistic {

    @JsonProperty("complexName")
    private String complexName;

    @JsonProperty("apartmentsTotalCount")
    private int apartmentsTotalCount;

    @JsonProperty("minPrice")
    private int minPrice;

    @JsonProperty("activeFlatsCount")
    private int activeFlatsCount;

    @JsonProperty("houses")
    private List<HousesItem> houses;

    @JsonProperty("yearEnd")
    private int yearEnd;

    @JsonProperty("complexId")
    private int complexId;

    @JsonProperty("isDone")
    private boolean isDone;

    @JsonProperty("photos")
    private List<PhotosItem> photos;

    @JsonProperty("quarterEnd")
    private int quarterEnd;

    @JsonProperty("statisticByRooms")
    private StatisticByRooms statisticByRooms;

    private UUID complexUUId;

    public void setComplexUUId(UUID complexUUId) {
        this.complexUUId = complexUUId;
    }

    public UUID getComplexUUId() {
        return complexUUId;
    }

    public void setComplexName(String complexName) {
        this.complexName = complexName;
    }

    public String getComplexName() {
        return complexName;
    }

    public void setApartmentsTotalCount(int apartmentsTotalCount) {
        this.apartmentsTotalCount = apartmentsTotalCount;
    }

    public int getApartmentsTotalCount() {
        return apartmentsTotalCount;
    }

    public void setMinPrice(int minPrice) {
        this.minPrice = minPrice;
    }

    public int getMinPrice() {
        return minPrice;
    }

    public void setActiveFlatsCount(int activeFlatsCount) {
        this.activeFlatsCount = activeFlatsCount;
    }

    public int getActiveFlatsCount() {
        return activeFlatsCount;
    }

    public void setHouses(List<HousesItem> houses) {
        this.houses = houses;
    }

    public List<HousesItem> getHouses() {
        return houses;
    }

    public void setYearEnd(int yearEnd) {
        this.yearEnd = yearEnd;
    }

    public int getYearEnd() {
        return yearEnd;
    }

    public void setComplexId(int complexId) {
        this.complexId = complexId;
    }

    public int getComplexId() {
        return complexId;
    }

    public void setIsDone(boolean isDone) {
        this.isDone = isDone;
    }

    public boolean isIsDone() {
        return isDone;
    }

    public void setPhotos(List<PhotosItem> photos) {
        this.photos = photos;
    }

    public List<PhotosItem> getPhotos() {
        return photos;
    }

    public void setQuarterEnd(int quarterEnd) {
        this.quarterEnd = quarterEnd;
    }

    public int getQuarterEnd() {
        return quarterEnd;
    }

    public void setStatisticByRooms(StatisticByRooms statisticByRooms) {
        this.statisticByRooms = statisticByRooms;
    }

    @Override
    public StatisticByRooms getStatisticByRooms() {
        return statisticByRooms;
    }

    @Override
    public UUID save(Object parent, AtomicOperation dataSourse) throws Exception {

        UUID complexUUId = dataSourse.addComplex(this);
        this.setComplexUUId(complexUUId);
        for (PhotosItem photo : photos) {
            photo.save(this, dataSourse);
        }
        for (HousesItem house : houses) {
            house.save(this, dataSourse);
        }
        statisticByRooms.save(this, dataSourse);
        return complexUUId;
    }

    @Override
    public String toString() {
        return
                "ComplexesItem{" +
                        "complexName = '" + complexName + '\'' +
                        ",apartmentsTotalCount = '" + apartmentsTotalCount + '\'' +
                        ",minPrice = '" + minPrice + '\'' +
                        ",activeFlatsCount = '" + activeFlatsCount + '\'' +
                        ",houses = '" + houses + '\'' +
                        ",yearEnd = '" + yearEnd + '\'' +
                        ",complexId = '" + complexId + '\'' +
                        ",isDone = '" + isDone + '\'' +
                        ",photos = '" + photos + '\'' +
                        ",quarterEnd = '" + quarterEnd + '\'' +
                        ",statisticByRooms = '" + statisticByRooms + '\'' +
                        "}";
    }
}