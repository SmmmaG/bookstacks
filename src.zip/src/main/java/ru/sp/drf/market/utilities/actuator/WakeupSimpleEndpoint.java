package ru.sp.drf.market.utilities.actuator;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.domrf.rem.utilities.logs.CustomLogger;

@Component
@Endpoint(id = "wakeup-endpoint-simple")
public class WakeupSimpleEndpoint {
    CustomLogger LOG = CustomLogger.getLogger();

    @ReadOperation
    public HttpStatus check() {
        LOG.info("Try to check WakeupSimple");
        return HttpStatus.OK;
    }
}
