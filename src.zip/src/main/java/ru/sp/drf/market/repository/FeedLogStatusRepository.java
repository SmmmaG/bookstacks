package ru.sp.drf.market.repository;

import org.springframework.data.repository.CrudRepository;
import ru.domrf.rem.domain.admin.FeedLogStatus;

import java.util.UUID;

public interface FeedLogStatusRepository extends CrudRepository<FeedLogStatus, UUID>{

    FeedLogStatus findByCode(String code);
}
