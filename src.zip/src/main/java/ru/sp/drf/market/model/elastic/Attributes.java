package ru.sp.drf.market.model.elastic;

public class Attributes {
    public static final String NAME = "name";
    public static final String ACTUAL_ON = "actual_on";
    public static final String UUID = "uuid";
    public static final String CITY_UUID = "city_uuid";
    public static final String CITY_NAME = "city_name";
    public static final String CITY_CODE = "city_code";
    public static final String REGION_UUID = "region_uuid";
    public static final String REGION_NAME = "region_name";
    public static final String REGION_CODE = "region_code";
    public static final String ADDRESS = "address";
    public static final String SUGGEST_NAME = "suggest_name";
    public static final String CONTEXTS = "contexts";
    public static final String CONTEXTS_AREA_CODE = "area-code";
    public static final String CONTEXTS_LOCATION_GEO = "location-geo";
    public static final String LINE_COLOR = "line_color";
    public static final String ICON_CODE= "icon_code";
    public static final String POINT_TYPE= "point";


    public static final String LEVEL_OAS= "level";
    public static final String PREFIX_OAS= "prefix";
    public static final String NAME_OAS= "name";
    public static final String COUNTRY_OAS= "country";
    public static final String PARENT_ID_OAS= "parent_id";

}
