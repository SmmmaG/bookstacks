package ru.sp.drf.market.dataloader.elastic;

import ru.sp.drf.market.model.elastic.ComplexData;

public class ComplexSliceLoader extends BasicSlicer<ComplexData> {

    public ComplexSliceLoader() {
        super("complex");
    }

}
