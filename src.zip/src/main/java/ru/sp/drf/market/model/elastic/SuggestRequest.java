package ru.sp.drf.market.model.elastic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SuggestRequest {
    private String[] names;
    private SuggestContext context = new SuggestContext();

    public SuggestRequest(String original, String[] names) {
        List<String> tmpNames = new ArrayList<>(Arrays.asList(names));
        if (!tmpNames.contains(original))
            tmpNames.add(original);
        this.names = tmpNames.toArray(new String[tmpNames.size()]);
    }

    public String[] getNames() {
        return names;
    }

    public SuggestContext getContext() {
        return context;
    }

}
