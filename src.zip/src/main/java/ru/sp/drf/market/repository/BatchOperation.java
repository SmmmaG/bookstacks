package ru.sp.drf.market.repository;

import ru.domrf.rem.domain.admin.FeedLog;

import java.sql.SQLException;

public interface BatchOperation {

    void addComplexes(FeedLog feedLog, String operation) throws Exception;

    void addBuildings(FeedLog feedLog, String operation) throws Exception;

    void addFlats(FeedLog feedLog, String operation) throws Exception;

    void addComplexesPhoto(FeedLog feedLog, String operation) throws Exception;

    void addBuildingsPhoto(FeedLog feedLog, String operation) throws Exception;

    void addFlatsPhoto(FeedLog feedLog, String operation) throws Exception;

    void addSalesOffice(FeedLog feedLog, String operation) throws Exception;

    void addSalesOfficeComplex(FeedLog feedLog, String operation) throws Exception;

    void addFlatRooms(FeedLog feedLog, String operation) throws Exception;

    void addFlatMetro(FeedLog feedLog, String operation) throws Exception;

    void createTempSchema(String schemaName, FeedLog feedLog) throws SQLException ;

    void removeTempSchema(String schemaName, FeedLog feedLog) throws SQLException;

}
