package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.*;
import ru.domrf.rem.utilities.logs.CustomLogger;

import javax.annotation.Generated;
import java.util.List;
import java.util.Objects;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchComplexesResponse implements Response {

    private static final CustomLogger LOG = CustomLogger.getLogger();


    private List<ComplexesItem> complexes;

    @JsonCreator
    public SearchComplexesResponse(List<ComplexesItem> complexes) {
        this.complexes = complexes;
    }

    public void setComplexes(List<ComplexesItem> complexes) {
        this.complexes = complexes;
    }

    public List<ComplexesItem> getComplexes() {
        return complexes;
    }

    @Override
    @JsonIgnore
    public void save(AtomicOperation operation) throws Exception {
        for (ComplexesItem item : complexes) {
            if (item.getComplexId() == 0) {
                LOG.info("Complexid=" + item);
            }
            item.setComplexUUId(item.save(null, operation));
            operation.getContextLoader().putComplex(item.getComplexId(), item);
        }

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SearchComplexesResponse)) return false;
        SearchComplexesResponse that = (SearchComplexesResponse) o;
        return Objects.equals(complexes, that.complexes);
    }

    @Override
    public int hashCode() {
        return Objects.hash(complexes);
    }

    @Override
    public String toString() {
        return "SearchComplexesResponse{" +
                complexes +
                '}';
    }
}