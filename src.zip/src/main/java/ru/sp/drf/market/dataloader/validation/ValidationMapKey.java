package ru.sp.drf.market.dataloader.validation;

import java.util.Objects;

public class ValidationMapKey {
    private final String field;
    private final String error;

    public ValidationMapKey(String field, String error) {
        if (Objects.isNull(field)){
            this.field=null;
        } else {
            this.field = field;
        }
        this.error = error;
    }

    public ValidationMapKey(String error) {
        this.error = error;
        this.field=null;
    }

    public String getField() {
        if (Objects.isNull(field))
            return "";
        return field;
    }

    public String getError() {
        return error;
    }

    public String getMessage(){
        if (Objects.isNull(field))
            return error;
        return "В " + field + " " +error.toLowerCase();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ValidationMapKey that = (ValidationMapKey) o;
        return Objects.equals(field, that.field) &&
                Objects.equals(error, that.error);
    }

    @Override
    public int hashCode() {
        return Objects.hash(field, error);
    }

    @Override
    public String toString() {
        return "ValidationMapKey{" +
                "field='" + field + '\'' +
                ", error='" + error + '\'' +
                '}';
    }
}
