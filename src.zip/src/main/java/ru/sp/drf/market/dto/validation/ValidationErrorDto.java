package ru.sp.drf.market.dto.validation;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class ValidationErrorDto {
    private final int code;
    private final String message;
    private final Set<String> lines;
    private final Set<String> ids;

    public ValidationErrorDto(int code, String message, Set<String> lines, Set<String> ids) {
        this.code = code;
        this.message = message;
        this.lines = lines;
        this.ids = ids;
    }

    public ValidationErrorDto(int code, String message) {
        this.code = code;
        this.message = message;
        this.lines = new HashSet();
        this.ids = new HashSet();
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public Set<String> getLines() {
        return lines;
    }

    public Set<String> getIds() {
        return ids;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ValidationErrorDto that = (ValidationErrorDto) o;
        return code == that.code &&
                Objects.equals(message, that.message) &&
                Objects.equals(lines, that.lines) &&
                Objects.equals(ids, that.ids);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, message, lines, ids);
    }

    @Override
    public String toString() {
        return "ValidationErrorDto{" +
                "code=" + code +
                ", message='" + message + '\'' +
                ", lines=" + lines +
                ", ids=" + ids +
                '}';
    }
}
