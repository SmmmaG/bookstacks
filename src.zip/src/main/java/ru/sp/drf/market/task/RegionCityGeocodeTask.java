package ru.sp.drf.market.task;

import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.dataloader.MarketDataSource;
import ru.sp.drf.market.utilities.Geocoder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Objects;
import java.util.UUID;

/**
 * Filling Region's and Cities' center points and ZOOM
 */
public class RegionCityGeocodeTask implements Runnable {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    @Override
    public void run() {
        fillTableCoordinates("city");
        fillTableCoordinates("region");
    }

    private static void fillTableCoordinates(String entity) {

        try (Connection conn = MarketDataSource.getConnection();
             PreparedStatement psGetCities = conn.prepareStatement("SELECT * from " + entity + " WHERE zoom is null");
             PreparedStatement psUpd = conn.prepareStatement("UPDATE " + entity + " SET latitude=?, longitude=?, zoom=? WHERE id=?");
             ResultSet rs = psGetCities.executeQuery()) {
            while (rs.next()) {
                UUID uuid = (UUID) rs.getObject("id");
                String name = rs.getString("name");
                if (Objects.nonNull(name)) {
                    String prefix = "";
                    if ("city".equals(entity))
                        prefix = rs.getString("prefix_type") + " ";
                    LOG.error("launch " + name);
                    if (prefix == null || name == null)
                        continue;
                    String url = "https://geocode-maps.yandex.ru/1.x/?apikey=" + FeedServiceConfig.YANDEX_APIKEY + "&geocode=" + prefix + name;
                    String file = Geocoder.getGeocode(url);
                    LOG.error("file = " + file);
                    if (!file.contains("<pos>") || !file.contains("<lowerCorner>") || !file.contains("<upperCorner>"))
                        continue;
                    PointCoord cityCenter = new PointCoord(file, "pos");
                    PointCoord leftDown = new PointCoord(file, "lowerCorner");
                    PointCoord rightUp = new PointCoord(file, "upperCorner");
                    Double maxDiff = Math.max(rightUp.longitude - leftDown.longitude, rightUp.latitude - leftDown.latitude) + FeedServiceConfig.GEOCODER_DIF_INCR;
                    long zoom = Math.round(1 / maxDiff * FeedServiceConfig.GEOCODER_K) - 1;
                    psUpd.setDouble(1, cityCenter.latitude);
                    psUpd.setDouble(2, cityCenter.longitude);
                    psUpd.setInt(3, (int) zoom);
                    psUpd.setObject(4, uuid);
                    psUpd.executeUpdate();
                }
            }
        } catch (Exception e) {
            LOG.error(e);
           LOG.error("Unexpected exception", e);
        }
    }

    private static class PointCoord {
        private Double longitude;
        private Double latitude;

        public PointCoord(String file, String element) {
            String coord = file.substring(file.indexOf("<" + element + ">") + element.length() + 2, file.indexOf("</" + element + ">"));
            this.longitude = Double.parseDouble(coord.split(" ")[0]);
            this.latitude = Double.parseDouble(coord.split(" ")[1]);
        }

    }
}
