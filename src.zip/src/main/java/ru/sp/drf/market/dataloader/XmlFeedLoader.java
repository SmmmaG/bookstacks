package ru.sp.drf.market.dataloader;

import ru.domrf.rem.domain.admin.FeedLogStatuses;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.domrf.rem.utilities.FileLoader;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.validation.ValidationEvents;
import ru.sp.drf.market.dataloader.yandex.YandexLoader;
import ru.sp.drf.market.dto.validation.ValidationResultDto;
import ru.sp.drf.market.exception.DownloadFeedException;
import ru.sp.drf.market.exception.FeedException;
import ru.sp.drf.market.repository.sql.SQLDataSource;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.*;
import java.sql.SQLException;
import java.util.Date;

public abstract class XmlFeedLoader<T extends SQLDataSource> extends FeedLoader<T> {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    public static final long MAX_FILE_SIZE = 1024 * 1024 * 40;

    public void onDownload() throws FeedException {
        LOG.info("Load " + handler_name + " feed by url: " + feedLog.getFeed().getUrl().trim());
        save(handler_name);
        if (xmlFileSize < 1) {
            throw new DownloadFeedException(feedLog.getFeed().getUrl().trim());
        }
    }

    public long save(String handler_name) throws DownloadFeedException {
        boolean tryOneMoreTime = true;
        int attemptsCount = 0;
        String feedURL = feedLog.getFeed().getUrl()
                .trim()
                .replace(TempFeedLoader.TEMP_LOADER_URL_PREFIX, "")
                .replace(" ", "%20")
                .replace(" ", "");
        try {
            File tmpFile = File.createTempFile(handler_name + "-feed", ".xml");
            while (tryOneMoreTime && attemptsCount <= 2) {
                attemptsCount++;
                String returnCode = FileLoader.saveUrl(tmpFile.toPath(), feedURL, 60000, 60000);
                tryOneMoreTime = false;
                LOG.info("Loaded " + handler_name + " feed size: " + tmpFile.length());
                switch (returnCode) {
                    case "0":
                        if (tmpFile.length() == 0) {
                            throw new DownloadFeedException(ValidationEvents.FileIsEmptyError.getMessage() + " " + feedURL);
                        }
                        String fullFeedStr = FileLoader.getFullFeed(tmpFile).replace(' ', ' ');
                        if (this instanceof YandexLoader || this instanceof TempFeedLoader) {
                            fullFeedStr = fullFeedStr.replace("<realty-feed>", "<realty-feed xmlns=\"http://webmaster.yandex.ru/schemas/feed/realty/2010-06\">");
                            FileLoader.reSaveFile(tmpFile, fullFeedStr);
                        }
                        xmlFileSize = tmpFile.length();
//                      Save file only if its not temp and not too BIG
                        if (!(this instanceof TempFeedLoader) && xmlFileSize <= MAX_FILE_SIZE)
                            LoadLogger.writeFeedFile(feedLog, fullFeedStr.toCharArray());
                        break;
                    case "8":
                        throw new DownloadFeedException(ValidationEvents.FileNotFoundError.getMessage() + " " + feedURL);
                    case "9":
                        throw new DownloadFeedException(ValidationEvents.FeedServerError.getMessage() + " " + feedURL);
                    case "10":
                        throw new DownloadFeedException(ValidationEvents.FeedServerSSLError.getMessage() + " " + feedURL);
                    case "1":
                    case "4":
                        if (attemptsCount == 2)
                            throw new DownloadFeedException(ValidationEvents.DownloadTimeout.getMessage() + " " + feedURL);
                        tryOneMoreTime = true;
                        break;
                    case "2":
                    case "3":
                    case "5":
                    case "6":
                        throw new DownloadFeedException(ValidationEvents.DownloadFileException.getMessage() + " " + feedURL);
                    default:
                        feedURL = returnCode;
                        tryOneMoreTime = true;
                }
            }

            this.xmlFile = tmpFile;
        } catch (UncheckedIOException e) {
            LOG.error("Error load " + handler_name + " by url: " + feedLog.getFeed().getUrl(), e);
            throw new DownloadFeedException(ValidationEvents.DownloadFileEncodingException.getMessage() + " " + feedURL);
        } catch (DownloadFeedException e) {
            LOG.error("Error load " + handler_name + " by url: " + feedLog.getFeed().getUrl(), e);
            throw e;
        } catch (Exception e) {
            LOG.error("Error load " + handler_name + " by url: " + feedLog.getFeed().getUrl(), e);
        }
        return xmlFileSize;
    }

    public final ValidationResultDto executeValidate() throws Exception {

        try {
            initConnection();
            LOG.info(this.getClass().getSimpleName() + " task execute validate");
            LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.PROGRESS, false);

            ValidationResultDto result = executeValidateTask();

            LOG.info(this.getClass().getSimpleName() + " task finish");
            LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.OK, false);
            return result;
        } catch (Exception e) {
            try {
                LOG.error(e);
                operation.rollback();
                LoadLogger.setLoadStatus(feedLog, FeedLogStatuses.ERROR, true);
                LoadLogger.writeScriptLog(new ScriptResult(e.getLocalizedMessage(), -1, e.getLocalizedMessage(), new Date().getTime()),
                        feedLog, false, FeedEventTypes.Executing);
            } catch (Exception e1) {
                LOG.error(e1);
            }
            throw e;
        } finally {
            try {
                operation.close();
            } catch (SQLException ex) {
                LOG.error(ex);
            }
        }
    }

    protected abstract ValidationResultDto onSchemeValidation() throws Exception;

    public ValidationResultDto executeValidateTask() throws Exception {
        operation.setAutoCommit(false);
        String tempSchemaName = getSchemaNamePrefix() + "_" + feedLog.getId().toString().replaceAll("-","_");
        operation.setSchemaName(tempSchemaName);
        ValidationResultDto result = onSchemeValidation();
        onCreateTempSchema(tempSchemaName);
        operation.commit();
        onParse();
        onValidate();
        operation.commit();
        onRemoveTempSchema(tempSchemaName);
        operation.commit();
        return result;
    }

    public abstract String getSchemaNamePrefix();

    /**
     * There are extended logic like create temp schema for separate validation from other tasks
     */
    protected abstract void onCreateTempSchema(final String schemaName) throws IOException, SQLException;

    /**
     * There is some logic to undo or clear temp data created in {@link ru.sp.drf.market.dataloader.XmlFeedLoader#onCreateTempSchema(String)}
     */
    protected abstract void onRemoveTempSchema(final String schemaName) throws IOException, SQLException;
}
