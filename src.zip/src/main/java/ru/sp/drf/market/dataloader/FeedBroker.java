package ru.sp.drf.market.dataloader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.domrf.rem.domain.admin.Feed;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.domain.admin.FeedLogStatuses;
import ru.domrf.rem.utilities.FileLoader;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.exception.UndefinedFeedHandlerException;
import ru.sp.drf.market.repository.dictionaries.FeedHandlerRepository;
import ru.sp.drf.market.repository.sql.SQLDataSource;
import ru.sp.drf.market.service.FeedEventLogService;
import ru.sp.drf.market.service.FeedLogService;
import ru.sp.drf.market.service.FeedService;
import ru.sp.drf.market.utilities.LoadLogger;
import ru.sp.drf.market.utilities.LoaderFactory;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import static ru.sp.drf.market.utilities.HelperUtils.canRunFeed;

@Component
public class FeedBroker {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private LoaderFactory factory;

    private static FeedService feedService;
    private static FeedLogService feedLogService;
    private static FeedEventLogService feedEventLogService;
    private static FeedHandlerRepository feedHandlerRepository;

    private Map<UUID, FeedLoader> loaders;


    public FeedBroker(LoaderFactory factory) {
        this.factory = factory;
    }

    public static void deleteFeedLog(FeedLog feedLog) {
        feedEventLogService.delete(feedLog);
        feedLogService.delete(feedLog);
        feedService.delete(feedLog.getFeed());
    }

    @Autowired
    public void setFeedHandlerRepository(FeedHandlerRepository feedHandlerRepository) {
        FeedBroker.feedHandlerRepository = feedHandlerRepository;
    }

    @Autowired
    public void setFeedService(FeedService feedService) {
        FeedBroker.feedService = feedService;
    }

    @Autowired
    public void setFeedLogService(FeedLogService feedLogService) {
        FeedBroker.feedLogService = feedLogService;
    }

    @Autowired
    public void setFeedEventLogService(FeedEventLogService feedEventLogService) {
        FeedBroker.feedEventLogService = feedEventLogService;
    }

    public static TempFeedLoader getTempLoader(String url) {
        Feed tempFeed = new Feed();
        tempFeed.setUrl(TempFeedLoader.TEMP_LOADER_URL_PREFIX + url);
        tempFeed.setActual(false);
        tempFeed.setHandler(feedHandlerRepository.getValidationHandler());
        tempFeed = feedService.save(tempFeed);
        FeedLog tempFeedLog = new FeedLog(tempFeed);
        tempFeedLog = feedLogService.save(tempFeedLog);
        TempFeedLoader<SQLDataSource> loader = new TempFeedLoader();
        loader.setFeedLog(tempFeedLog);
        return loader;
    }

    public static FeedLoader getXmlLoader(File tempFile) throws IOException, UndefinedFeedHandlerException {
        String fullFeed = FileLoader.getFullFeed(tempFile);
        fullFeed = fullFeed.substring(fullFeed.indexOf(">") + 1).trim(); //trimXmlTag
        int spacePos = fullFeed.indexOf(" ");
        int bracePos = fullFeed.indexOf(">");
        String firstTag = fullFeed.substring(1, Math.min(spacePos, bracePos));
        FeedHandlers feedHandler = null;
        for (LoaderTags tag : LoaderTags.values()) {
            if (tag.getFirstTag().equalsIgnoreCase(firstTag)) {
                feedHandler = tag.getHandler();
            }
        }
        if (Objects.isNull(feedHandler) || (feedHandler != FeedHandlers.Domclick && feedHandler != FeedHandlers.Yandex))
            throw new UndefinedFeedHandlerException("Undefined handler");

        FeedLoader newLoader = LoaderFactory.getFeedLoader(feedHandler.getHandlerName());
        return newLoader;
    }

    private void init(UUID feedId) {
        loaders = new HashMap<>();
        try {
            if (Objects.nonNull(feedId)) {
                Feed feed = feedService.findById(feedId).orElse(null);
                if (Objects.nonNull(feed)) {
                    if (feed.getActual()) {
                        try {
                            FeedLoader feedLoader = factory.getLoader(feed.getHandler().getCode());
                            if (feedLoader != null) {
                                FeedLog feedLog = new FeedLog(feed);
                                feedLog.setStatus(LoadLogger.getFeedStatuses().get(FeedLogStatuses.PROGRESS));
                                feedLog = feedLogService.save(feedLog);
                                feedLoader.setFeedLog(feedLog);
                                loaders.put(feed.getId(), feedLoader);
                            } else {
                                LOG.info("Class Handler doesn't exists");
                            }
                        } catch (Exception e) {
                            LOG.error("Error init loader", e);
                        }
                    }
                }
            } else {
                List<Feed> feedList = feedService.findAllActive();
                feedService.setExpiredFeedsAsError();
                feedLogService.setExpiredFeedLogsAsError();
                feedList.forEach(feed -> {
                    if (!canRunFeed(feed)) {
                        LOG.info("Feed name:" + feed.getName() + ", id: " + feed.getId() + " skip execute by Frequency. It's start next time.");
                    } else {
                        try {
                            FeedLoader feedLoader = factory.getLoader(feed.getHandler().getCode());
                            if (feedLoader != null) {
                                FeedLog feedLog = new FeedLog(feed);
                                feedLog.setStatus(LoadLogger.getFeedStatuses().get(FeedLogStatuses.PROGRESS));
                                feedLog = feedLogService.save(feedLog);
                                feedLoader.setFeedLog(feedLog);
                                loaders.put(feed.getId(), feedLoader);
                            } else {
                                LOG.error("Class Handler doesn't exists");
                            }
                        } catch (Exception e) {
                            LOG.error("Error init loader", e);
                        }
                    }
                });
            }
        } catch (SQLException e) {
            LOG.error("Unexpected exception",e);
        }
    }

    public Collection<FeedLoader> getLoaders() {
        init(null);
        return loaders.values();
    }

    public FeedLoader getLoaderById(UUID feedId) {
        init(feedId);
        return this.loaders.get(feedId);
    }
}
