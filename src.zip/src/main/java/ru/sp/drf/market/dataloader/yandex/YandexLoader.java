package ru.sp.drf.market.dataloader.yandex;

import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;
import ru.domrf.rem.utilities.FileLoader;
import ru.sp.drf.market.dataloader.XmlFeedLoader;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.validation.XmlValidator;
import ru.sp.drf.market.dataloader.validation.ValidationEvents;
import ru.sp.drf.market.dataloader.validation.YandexErrorHandler;
import ru.sp.drf.market.dto.validation.ValidationResultDto;
import ru.sp.drf.market.exception.NoObjectsAfterValidationException;
import ru.sp.drf.market.repository.sql.SQLYandex;
import ru.sp.drf.market.utilities.BigFileChunkReader;
import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static ru.sp.drf.market.config.loaders.YandexConfig.*;

@Component
public class YandexLoader<D extends YandexDataSource> extends XmlFeedLoader<D> {

    private static final CustomLogger LOG = CustomLogger.getLogger();
    private static final String YANDEX = "yandex";

    public String getSchemaNamePrefix() {
        return YANDEX;
    }

    @Override
    protected void onCreateTempSchema(final String schemaName) throws IOException, SQLException {
        operation.createTempSchema(schemaName, feedLog);
    }

    @Override
    protected void onRemoveTempSchema(final String schemaName) throws IOException, SQLException {
        operation.removeTempSchema(schemaName, feedLog);
    }

    @Override
    protected void executeDisableTasks() throws Exception {
        operation.setAutoCommit(false);
        operation.setSchemaName(YANDEX);
        onDisable();
        onAfter();
        operation.commit();
    }

    @Override
    protected boolean executeTasks() throws Exception {
        operation.setAutoCommit(false);
        operation.setSchemaName(YANDEX);
        onPrepare();
        onDownload();
        onParse();
        operation.commit();
        onValidate();
        operation.commit();
        onDisable();
        onLoad();
        onAfter();
        operation.commit();
        return true;
    }

    @Override
    public void onPrepare() throws Exception {
        LOG.info("on clear old Tables");
        operation.prepareTables(feedLog);
    }

    @Override
    public ValidationResultDto onSchemeValidation() throws SQLException {
        try {
            YandexErrorHandler errorHandler = new YandexErrorHandler(feedLog, xmlFile);
            XmlValidator.validate(xmlFile, errorHandler, "feeds/xsd/domclick/yandex_basic_xml.xsd");
            errorHandler.writeValidationLog();
            return new ValidationResultDto(errorHandler);
        } catch (IOException e) {
            LOG.error("Unexpected exception", e);
        } catch (SAXException e) {
            LOG.info(feedLog.getFeed().getUrl() + " is not valid because ");
            LOG.info("SAXException: " + e.getMessage());
            ValidationResultDto result = new ValidationResultDto(3);
            result.addError("Не удалось распознать фид");
            return result;
        }
        return null;
    }

    @Override
    public void onValidate() throws Exception {
        int flatsCount = operation.getCount(SQLYandex.getFlatsCount.getSQL());
        int buildingsCount = operation.getCount(SQLYandex.getBuildingsCount.getSQL());
        int complexCount = operation.getCount(SQLYandex.getTempComplexCount.getSQL());
        writeValidationLog(ValidationEvents.checkFlatCountBeforeValidation, FeedEventTypes.Flats_Validation, flatsCount, false);
        writeValidationLog(ValidationEvents.checkBuildCountBeforeValidation, FeedEventTypes.Buildings_Validation, buildingsCount, false);
        writeValidationLog(ValidationEvents.checkComplexCountBeforeValidation, FeedEventTypes.Complexes_Validation, complexCount, false);

        this.onBuildingsValidation(buildingsCount);
        this.onFlatsValidation(flatsCount);

        int afterFlatsCount = operation.getCount(SQLYandex.getFlatsCount.getSQL());
        int afterBuildingsCount = operation.getCount(SQLYandex.getBuildingsCount.getSQL());
        int afterComplexCount = operation.getCount(SQLYandex.getTempComplexCount.getSQL());
        writeValidationLog(ValidationEvents.checkFlatCountAfterValidation, FeedEventTypes.Count_Flats_Validation, afterFlatsCount, true);
        writeValidationLog(ValidationEvents.checkBuildCountAfterValidation, FeedEventTypes.Count_Buildings_Validation, afterBuildingsCount, true);
        writeValidationLog(ValidationEvents.checkComplexCountAfterValidation, FeedEventTypes.Count_Complexes_Validation, afterComplexCount, true);
        feedIsFullyLoaded = (flatsCount == afterFlatsCount) && (buildingsCount == afterBuildingsCount) && (complexCount == afterComplexCount);
        feedIsEmpty = flatsCount == 0 && buildingsCount == 0 && complexCount == 0;
    }

    public void onFlatsValidation(int flatsCountBefore) throws Exception {
        operation.flatsCheckMandatoryFieldsValidation(feedLog);
        operation.flatsCheckNonUniqueId(feedLog);
        operation.buildingsRemoveRelatedData(feedLog);
        int flatsCountAfter = operation.getCount(SQLYandex.getFlatsCount.getSQL());
        operation.commit();

        if (flatsCountAfter == 0 && flatsCountBefore != flatsCountAfter) {
            throw new NoObjectsAfterValidationException("Flats " + ValidationEvents.noDataAfterValidation.getMessage());
        }
    }

    public void onBuildingsValidation(int buildingsCountBefore) throws Exception {
        operation.buildingsCheckMandatoryFieldsValidation(feedLog);
        operation.buildingsCheckNonUniqueId(feedLog);
        int buildingsCountAfter = operation.getCount(SQLYandex.getBuildingsCount.getSQL());
        operation.commit();

        if (buildingsCountBefore == 0 && buildingsCountBefore != buildingsCountAfter) {
            throw new NoObjectsAfterValidationException("Buildings " + ValidationEvents.noDataAfterValidation.getMessage());
        }
    }

    @Override
    public void onParse() throws Exception {
        LOG.info("Load Flat");
        List<File> fileList;
        if (xmlFileSize > MAX_FILE_SIZE) {

            LOG.info("File too big to process - need to split it.");
            final long partSize = MAX_FILE_SIZE;
            fileList = splitFile(xmlFile, partSize);
            LOG.info("Split process completed.");
        } else {
            fileList = new ArrayList(Arrays.asList(xmlFile));
        }
        for (int idx = 0; idx < fileList.size(); idx++) {
            File file = fileList.get(idx);
            LoadLogger.writeFeedFile(feedLog, FileLoader.getFullFeed(file).toCharArray());
            String loadOperation = idx == 0 ? "load" : "add";
            storeDataFlat(loadOperation);
            file.delete();
        }

    }

    protected void storeDataFlat(String loadOperation) throws Exception {
        operation.addFlats(feedLog, loadOperation);
        operation.addBuildings(feedLog, loadOperation);
        operation.addComplexesPhoto(feedLog, loadOperation);
        operation.addFlatsPhoto(feedLog, loadOperation);
        operation.addFlatRooms(feedLog, loadOperation);
        operation.addFlatMetro(feedLog, loadOperation);
        operation.addSalesOffice(feedLog, loadOperation);
    }

    private List<File> splitFile(File file, final long partSize) throws IOException {
        List<File> result = new ArrayList<>();
        BigFileChunkReader reader = new BigFileChunkReader(file, 1024 * 1024);
        int count = 1;
        long size = 0;
        String chunk = "";
        String fileName = file.getAbsolutePath();
        File f = new File(fileName + "." + count);
        result.add(f);
        int parseableChunkStart;
        int parseableChunkStop;

        BufferedWriter writer = new BufferedWriter(new FileWriter(f));
        while (reader.hasNextChunk()) {

            chunk = chunk.concat(reader.getNextChunk());
            parseableChunkStart = chunk.indexOf(OBJECT_TAG_START);
            parseableChunkStop = chunk.lastIndexOf(TAG_STOP) + 8;
            String parseableChunk = chunk.substring(parseableChunkStart, parseableChunkStop);
            chunk = chunk.substring(parseableChunkStop);
            if (size == 0)
                writer.write(XML_START_TAG);
            size += parseableChunk.length();
            writer.write(parseableChunk);
            if (size >= partSize) {
                writer.write(XML_STOP_TAG);
                writer.close();
                size = 0;
                count++;
                f = new File(fileName + "." + count);
                result.add(f);
                writer = new BufferedWriter(new FileWriter(f));
            }
        }
        writer.write(XML_STOP_TAG);
        writer.close();
        return result;
    }


    @Override
    public void onLoad() throws Exception {
        LOG.info("onLoad feedLog = " + feedLog);
        operation.storeData(feedLog);

    }

    @Override
    public void onAfter() throws Exception {
        LOG.info("on post processing phase");
        operation.recalculation(feedLog);
    }

    @Override
    public void onDisable() throws IOException, SQLException {
        LOG.info("on Disable old data");
        operation.disableData(feedLog);
    }

    @Override
    public void initConnection() throws Exception {
        operation = createContents((Class<D>) YandexDataSource.class);
    }

    protected D createContents(Class<D> dClass) throws IllegalAccessException, InstantiationException {
        return dClass.newInstance();
    }
}
