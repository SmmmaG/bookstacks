package ru.sp.drf.market.exchange.nmarket;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class HouseInfo{

	@JsonProperty("houseId")
	private int houseId;

	@JsonProperty("description")
	private String description;

	@JsonProperty("complexId")
	private int complexId;

	@JsonProperty("parkingName")
	private String parkingName;

	@JsonProperty("quarterEnd")
	private int quarterEnd;

	@JsonProperty("floors")
	private String floors;

	@JsonProperty("discounts")
	private List<DiscountsItem> discounts;

	@JsonProperty("ceilingHeight")
	private double ceilingHeight;

	@JsonProperty("approvedCreditProducts")
	private List<String> approvedCreditProducts;

	@JsonProperty("buildingNumber")
	private String buildingNumber;

	@JsonProperty("isProperty")
	private boolean isProperty;

	@JsonProperty("developerName")
	private String developerName;

	@JsonProperty("transportNode")
	private String transportNode;

	@JsonProperty("coords")
	private Coords coords;

	@JsonProperty("address")
	private String address;

	@JsonProperty("contract")
	private String contract;

	@JsonProperty("houseType")
	private String houseType;

	@JsonProperty("lastChangeDate")
	private String lastChangeDate;

	@JsonProperty("yearEnd")
	private int yearEnd;

	@JsonProperty("fromTransportNode")
	private String fromTransportNode;

	@JsonProperty("houseClass")
	private String houseClass;

	@JsonProperty("isDone")
	private boolean isDone;

	@JsonProperty("advantages")
	private String advantages;

	@JsonProperty("appartmentsCount")
	private Object appartmentsCount;

	@JsonProperty("district")
	private String district;

	@JsonProperty("name")
	private String name;

	@JsonProperty("lift")
	private String lift;

	@JsonProperty("stageNumber")
	private int stageNumber;

	@JsonProperty("region")
	private String region;

	public void setHouseId(int houseId){
		this.houseId = houseId;
	}

	public int getHouseId(){
		return houseId;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return description;
	}

	public void setComplexId(int complexId){
		this.complexId = complexId;
	}

	public int getComplexId(){
		return complexId;
	}

	public void setParkingName(String parkingName){
		this.parkingName = parkingName;
	}

	public String getParkingName(){
		return parkingName;
	}

	public void setQuarterEnd(int quarterEnd){
		this.quarterEnd = quarterEnd;
	}

	public int getQuarterEnd(){
		return quarterEnd;
	}

	public void setFloors(String floors){
		this.floors = floors;
	}

	public String getFloors(){
		return floors;
	}

	public void setDiscounts(List<DiscountsItem> discounts){
		this.discounts = discounts;
	}

	public List<DiscountsItem> getDiscounts(){
		return discounts;
	}

	public void setCeilingHeight(double ceilingHeight){
		this.ceilingHeight = ceilingHeight;
	}

	public double getCeilingHeight(){
		return ceilingHeight;
	}

	public void setApprovedCreditProducts(List<String> approvedCreditProducts){
		this.approvedCreditProducts = approvedCreditProducts;
	}

	public List<String> getApprovedCreditProducts(){
		return approvedCreditProducts;
	}

	public void setBuildingNumber(String buildingNumber){
		this.buildingNumber = buildingNumber;
	}

	public String getBuildingNumber(){
		return buildingNumber;
	}

	public void setIsProperty(boolean isProperty){
		this.isProperty = isProperty;
	}

	public boolean isIsProperty(){
		return isProperty;
	}

	public void setDeveloperName(String developerName){
		this.developerName = developerName;
	}

	public String getDeveloperName(){
		return developerName;
	}

	public void setTransportNode(String transportNode){
		this.transportNode = transportNode;
	}

	public String getTransportNode(){
		return transportNode;
	}

	public void setCoords(Coords coords){
		this.coords = coords;
	}

	public Coords getCoords(){
		return coords;
	}

	public void setAddress(String address){
		this.address = address;
	}

	public String getAddress(){
		return address;
	}

	public void setContract(String contract){
		this.contract = contract;
	}

	public String getContract(){
		return contract;
	}

	public void setHouseType(String houseType){
		this.houseType = houseType;
	}

	public String getHouseType(){
		return houseType;
	}

	public void setLastChangeDate(String lastChangeDate){
		this.lastChangeDate = lastChangeDate;
	}

	public String getLastChangeDate(){
		return lastChangeDate;
	}

	public void setYearEnd(int yearEnd){
		this.yearEnd = yearEnd;
	}

	public int getYearEnd(){
		return yearEnd;
	}

	public void setFromTransportNode(String fromTransportNode){
		this.fromTransportNode = fromTransportNode;
	}

	public String getFromTransportNode(){
		return fromTransportNode;
	}

	public void setHouseClass(String houseClass){
		this.houseClass = houseClass;
	}

	public String getHouseClass(){
		return houseClass;
	}

	public void setIsDone(boolean isDone){
		this.isDone = isDone;
	}

	public boolean isIsDone(){
		return isDone;
	}

	public void setAdvantages(String advantages){
		this.advantages = advantages;
	}

	public String getAdvantages(){
		return advantages;
	}

	public void setAppartmentsCount(Object appartmentsCount){
		this.appartmentsCount = appartmentsCount;
	}

	public Object getAppartmentsCount(){
		return appartmentsCount;
	}

	public void setDistrict(String district){
		this.district = district;
	}

	public String getDistrict(){
		return district;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setLift(String lift){
		this.lift = lift;
	}

	public String getLift(){
		return lift;
	}

	public void setStageNumber(int stageNumber){
		this.stageNumber = stageNumber;
	}

	public int getStageNumber(){
		return stageNumber;
	}

	public void setRegion(String region){
		this.region = region;
	}

	public String getRegion(){
		return region;
	}

	@Override
 	public String toString(){
		return 
			"HouseInfo{" + 
			"houseId = '" + houseId + '\'' + 
			",description = '" + description + '\'' + 
			",complexId = '" + complexId + '\'' + 
			",parkingName = '" + parkingName + '\'' + 
			",quarterEnd = '" + quarterEnd + '\'' + 
			",floors = '" + floors + '\'' + 
			",discounts = '" + discounts + '\'' + 
			",ceilingHeight = '" + ceilingHeight + '\'' + 
			",approvedCreditProducts = '" + approvedCreditProducts + '\'' + 
			",buildingNumber = '" + buildingNumber + '\'' + 
			",isProperty = '" + isProperty + '\'' + 
			",developerName = '" + developerName + '\'' + 
			",transportNode = '" + transportNode + '\'' + 
			",coords = '" + coords + '\'' + 
			",address = '" + address + '\'' + 
			",contract = '" + contract + '\'' + 
			",houseType = '" + houseType + '\'' + 
			",lastChangeDate = '" + lastChangeDate + '\'' + 
			",yearEnd = '" + yearEnd + '\'' + 
			",fromTransportNode = '" + fromTransportNode + '\'' + 
			",houseClass = '" + houseClass + '\'' + 
			",isDone = '" + isDone + '\'' + 
			",advantages = '" + advantages + '\'' + 
			",appartmentsCount = '" + appartmentsCount + '\'' + 
			",district = '" + district + '\'' + 
			",name = '" + name + '\'' + 
			",lift = '" + lift + '\'' + 
			",stageNumber = '" + stageNumber + '\'' + 
			",region = '" + region + '\'' + 
			"}";
		}
}