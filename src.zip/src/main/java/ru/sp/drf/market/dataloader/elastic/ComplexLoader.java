package ru.sp.drf.market.dataloader.elastic;


import org.springframework.stereotype.Service;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.repository.ComplexRepository;
import ru.sp.drf.market.utilities.ElasticBulkClient;

@Service
public class ComplexLoader {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private ComplexRepository complexRepository;

    public ComplexLoader(ComplexRepository complexRepository) {
        this.complexRepository = complexRepository;
    }

    public void loadComplexes() {
        LOG.info("Load Complexes");
        ElasticBulkClient.loadToElastic(new ComplexSliceLoader(), complexRepository.findAllActive(),null);
    }
}
