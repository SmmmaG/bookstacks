package ru.sp.drf.market.dataloader.nmarket;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.domain.admin.FeedLogStatuses;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.dataloader.FeedLoader;
import ru.sp.drf.market.exchange.nmarket.*;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.rmi.activation.UnknownObjectException;
import java.sql.SQLException;

public class NMarketLoader extends FeedLoader<NMarketDataSource> {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private static String NMARKET_USER;
    private static String NMARKET_PASSWORD;
    private static String NMARKET_URL;
    private static String NMARKET_APPS_URL;
    private static String NMARKET_COMPLEX_URL;
    private static String NMARKET_TOKET_URL;
    private static String NMARKET_PAGE_SIZE;

    private static GetTokenResponse TOKEN;

    @Override
    protected boolean executeTasks() throws Exception {
        operation.setAutoCommit(false);
        onPrepare();
        onDisable();
        onParse();
        onLoad();
        onAfter();
        operation.commit();
        return true;
    }

    @Override
    protected void executeDisableTasks() throws Exception {
        operation.setAutoCommit(false);
        onDisable();
        onAfter();
        operation.commit();
    }

    @Override
    public void onPrepare() throws Exception {
        LOG.info("on clear old nmarket Tables");
        operation.prepareTables(feedLog);
    }

    @Override
    public void onValidate() {
        //NO NEED FOR NMARKET
    }


    @Override
    public void onAfter() throws Exception {
        LOG.info("on post processing phase");
        operation.recalculation(feedLog);
    }


    @Override
    public void onParse() throws Exception {
        StringBuffer fullFeed = new StringBuffer();
        LOG.info("Find Complexes");
        String infoBlock = storeNMarketData(NMARKET_COMPLEX_URL, SearchComplexesResponse.class);
        fullFeed.append(infoBlock);
        LOG.info("Find Appartments");
        infoBlock = storeNMarketData(NMARKET_APPS_URL, SearchApprtmentsResponse.class);
        fullFeed.append(infoBlock);
        LoadLogger.writeFeedFile(feedLog, fullFeed.toString().toCharArray());
    }

    private <P extends Response> String storeNMarketData(String urlPrefix, Class<P> clazz) throws Exception {
        int total = 1;
        StringBuffer pages = new StringBuffer();
        String[] regions = feedLog.getFeed().getUrl().split(",");
        for (String region : regions) {
            LOG.info("Start downloading region:" + region);
            for (int i = 1; i <= total; i++) {
//                if (Objects.isNull(TOKEN) || TOKEN.isOld())
                TOKEN = getToken();
                SinglePage page = getSinglePage(i, region, urlPrefix, clazz);
                pages.append(page.getPageContent());
                if (page.getResponseEntity().getStatusCodeValue() == 200) {
                    P response = (P) page.getResponseEntity().getBody();
                    total = response.getStatistics().getTotalPages();
                    storeData(response, feedLog);
                } else {
                    throw new Exception("Unexpected error on read request");
                }
            }
        }
        return pages.toString();
    }

    private void storeData(Response page, FeedLog feedLog) throws Exception {


        if (page instanceof SearchApprtmentsResponse) {
            // store appartments
            SearchApprtmentsResponse appartments = (SearchApprtmentsResponse) page;
            for (AppartmentsItem appartment : appartments.getAppartments()) {
                appartment.save(null, operation);
            }
        } else if (page instanceof SearchComplexesResponse) {
            // store houses and complexes
            SearchComplexesResponse complexes = (SearchComplexesResponse) page;
            for (ComplexesItem complex : complexes.getComplexes()) {
                if (complex.getComplexId() == 0) {
                    LOG.info("Complexid=" + complex);
//                    continue;
                }
                complex.save(null, operation);
            }
        } else {
            throw new UnknownObjectException("Unexpected Response Entity");
        }

    }

    public GetTokenResponse getToken() throws IOException {
        HttpURLConnection connection = null;
        int responseCode = 0;
        try {
            //Create connection
            URL url = new URL(NMARKET_URL.concat(NMARKET_TOKET_URL));
            String urlParameters = new StringBuffer()
                    .append("grant_type=password&userName=").append(NMARKET_USER)
                    .append("&password=").append(NMARKET_PASSWORD)
                    .append("&response_type=token").toString();
            byte[] postData = urlParameters.getBytes(StandardCharsets.UTF_8);
            int postDataLength = postData.length;
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            connection.setRequestProperty("response_type", "token");
            connection.setRequestProperty("Content-Length", Integer.toString(postDataLength));
            connection.setDoOutput(true);
            //Send request
            DataOutputStream wr = new DataOutputStream(
                    connection.getOutputStream());
            wr.writeBytes(urlParameters);
            //Get Response
            responseCode = connection.getResponseCode();
            InputStream is = connection.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            StringBuffer response = new StringBuffer();
            String line;
            while ((line = rd.readLine()) != null) {
                response.append(line);
                response.append('\r');
            }
            rd.close();

            ObjectMapper mapper = new ObjectMapper();
            GetTokenResponse tokenResponse = mapper.readValue(response.toString(), GetTokenResponse.class);
            return tokenResponse;
        } catch (IOException io) {
            io.printStackTrace();
            throw new IOException("Token exception " + new StringBuffer().append(io.getMessage()).append(" with code ").append(responseCode).toString());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }


    public <P> SinglePage getSinglePage(int pageNumber, String region, String searchPrefix, Class<P> clazz) {
        HttpURLConnection connection = null;
        int responseCode = 0;
        String pageContent = null;
        try {
            //Create connection
            String urlParameters = new StringBuffer()
                    .append("?PageNumber=").append(pageNumber)
                    .append("&PageSize=").append(NMARKET_PAGE_SIZE)
                    .append("&RegionGroupId=").append(region)
                    .append("&SortBy=Rank&SortOrder=Descending").toString();
            URL url = new URL(NMARKET_URL.concat(searchPrefix.concat(urlParameters)));
            LOG.info("Send ".concat(NMARKET_URL.concat(searchPrefix.concat(urlParameters))));
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", TOKEN.getAuthorization());
            connection.connect();
            //Get Response
            responseCode = connection.getResponseCode();
            InputStream is = connection.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuffer response = new StringBuffer();
            String line;
            while ((line = rd.readLine()) != null) {
                response.append(line);
                response.append('\r');
            }
            rd.close();
            ObjectMapper mapper = new ObjectMapper();
            pageContent = response.toString();
            pageContent = pageContent.replace("ё", "е").replace("Ё", "Е");
            P searchComplexesResponse = mapper.readValue(pageContent, clazz);

            return new SinglePage(pageContent, new ResponseEntity(searchComplexesResponse, HttpStatus.OK));
        } catch (IOException io) {
            io.printStackTrace();
            responseCode = responseCode == 200 ? 500 : responseCode;
            return new SinglePage(pageContent, new ResponseEntity(io.getMessage(), HttpStatus.valueOf(responseCode)));
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }

    }


    @Override
    public void onLoad() throws Exception {
        LOG.info("onLoad feedLog = " + feedLog);
        operation.storeData(feedLog);

    }

    @Override
    public void onDisable() throws IOException, SQLException {
        LOG.info("on Disable old data");
        operation.disableData(feedLog);
    }

    private class SinglePage {
        private final String pageContent;
        private final ResponseEntity responseEntity;

        public SinglePage(String pageContent, ResponseEntity responseEntity) {
            this.pageContent = pageContent;
            this.responseEntity = responseEntity;
        }

        public String getPageContent() {
            return pageContent;
        }

        public ResponseEntity getResponseEntity() {
            return responseEntity;
        }
    }

    @Value("${spring.feedloader.nmarket.user}")
    public void setNmarketUser(String nmarketUser) {
        NMARKET_USER = nmarketUser;
    }

    @Value("${spring.feedloader.nmarket.password}")
    public void setNmarketPassword(String nmarketPassword) {
        NMARKET_PASSWORD = nmarketPassword;
    }

    @Value("${spring.feedloader.nmarket.url.basic}")
    public void setNmarketUrl(String nmarketUrl) {
        NMARKET_URL = nmarketUrl;
    }

    @Value("${spring.feedloader.nmarket.url.app-prefix}")
    public void setNmarketAppsUrl(String nmarketAppsUrl) {
        NMARKET_APPS_URL = nmarketAppsUrl;
    }

    @Value("${spring.feedloader.nmarket.url.complex-prefix}")
    public void setNmarketComplexUrl(String nmarketComplexUrl) {
        NMARKET_COMPLEX_URL = nmarketComplexUrl;
    }

    @Value("${spring.feedloader.nmarket.url.token-prefix}")
    public void setNmarketToketUrl(String nmarketToketUrl) {
        NMARKET_TOKET_URL = nmarketToketUrl;
    }

    @Value("${spring.feedloader.nmarket.pagesize}")
    public void setNmarketPageSize(String nmarketPageSize) {
        NMARKET_PAGE_SIZE = nmarketPageSize;
    }

//    @Value("${spring.feedloader.nmarket.regions}")
//    public void setNmarketRegions(String[] nmarketRegions) {
//        NMARKET_REGIONS = nmarketRegions;
//    }


    @Override
    public void initConnection() throws Exception {
        operation = new NMarketDataSource();
    }
}
