package ru.sp.drf.market.task.validation.rule;

import com.querydsl.core.types.Predicate;

public interface RuleValidation {
    Predicate toPredicate();
}