package ru.sp.drf.market.dataloader.fias;

public  interface BulkStoreListener  {
    void onStore(StoreEvent event );
}
