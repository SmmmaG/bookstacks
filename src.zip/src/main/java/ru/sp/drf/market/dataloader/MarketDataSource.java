package ru.sp.drf.market.dataloader;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@Component
public class MarketDataSource {

    private static String DB_URL;
    private static String DB_USER;
    private static String DB_PASS;

    @Value("${spring.datasource.url}")
    public void setDbUrl(String dbUrl) {
        DB_URL = dbUrl;
    }

    @Value("${spring.datasource.username}")
    public void setUSER(String user) {
        DB_USER = user;
    }

    @Value("${spring.datasource.password}")
    public void setPASS(String pass) {
        DB_PASS = pass;
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

}
