package ru.sp.drf.market.dataloader.elastic;

import org.springframework.stereotype.Service;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.repository.MetroRepository;
import ru.sp.drf.market.utilities.ElasticBulkClient;
import ru.domrf.rem.utilities.LoggedClass;

@Service
public class MetroLoader {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    MetroRepository metroRepository;

    public MetroLoader(MetroRepository metroRepository) {
        this.metroRepository = metroRepository;
    }


    public void loadMetro() {
        LOG.info("Load Metros");
        ElasticBulkClient.loadToElastic( new MetroSliceLoader(), metroRepository.findAllActive(), null);
    }


}