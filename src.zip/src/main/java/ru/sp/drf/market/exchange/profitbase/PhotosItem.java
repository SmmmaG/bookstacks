package ru.sp.drf.market.exchange.profitbase;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.Objects;
import java.util.UUID;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PhotosItem extends Storable<ComplexesItem, UUID> {

    @JsonProperty("url")
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public UUID save(ComplexesItem complexesItem, AtomicOperation dataSourse) throws Exception {
        UUID photoUUId = dataSourse.addComplexPhoto(this, complexesItem.getComplexUUId(), complexesItem.getComplexId());
        return photoUUId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PhotosItem)) return false;
        PhotosItem that = (PhotosItem) o;
        return Objects.equals(url, that.url);
    }

    @Override
    public int hashCode() {
        return Objects.hash(url);
    }

    @Override
    public String toString() {
        return "PhotosItem{" +
                "url='" + url + '\'' +
                '}';
    }
}