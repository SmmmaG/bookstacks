package ru.sp.drf.market.utilities;


import ru.sp.drf.market.exchange.QuarterDeadline;

import java.util.Calendar;
import java.util.Date;

public class DateUtils {


    public static Date convertQuarterToDate(QuarterDeadline deadline, boolean isFirstDay) {
        if (deadline != null && deadline.getYear() != null) {
            Calendar cl = Calendar.getInstance();
            cl.set(Calendar.YEAR, deadline.getYear());
            if (isFirstDay) {
                if (deadline.getQuarter() != null) {
                    switch (deadline.getQuarter()) {
                        case 1:
                            cl.set(Calendar.MONTH, Calendar.JANUARY);
                            break;
                        case 2:
                            cl.set(Calendar.MONTH, Calendar.APRIL);
                            break;
                        case 3:
                            cl.set(Calendar.MONTH, Calendar.JULY);
                            break;
                        case 4:
                            cl.set(Calendar.MONTH, Calendar.OCTOBER);
                            break;
                        default:
                            cl.set(Calendar.MONTH, Calendar.JANUARY);

                    }
                } else {
                    cl.set(Calendar.MONTH, Calendar.JANUARY);
                }
            } else {
                if (deadline.getQuarter() != null) {
                    switch (deadline.getQuarter()) {
                        case 1:
                            cl.set(Calendar.MONTH, Calendar.MARCH);
                            break;
                        case 2:
                            cl.set(Calendar.MONTH, Calendar.JUNE);
                            break;
                        case 3:
                            cl.set(Calendar.MONTH, Calendar.SEPTEMBER);
                            break;
                        case 4:
                            cl.set(Calendar.MONTH, Calendar.DECEMBER);
                            break;
                        default:
                            cl.set(Calendar.MONTH, Calendar.MARCH);

                    }
                } else {
                    cl.set(Calendar.MONTH, Calendar.MARCH);
                }

            }
            if (isFirstDay) {
                cl.set(Calendar.DAY_OF_MONTH, 1);
                cl.set(Calendar.HOUR, 0);
                cl.set(Calendar.MINUTE, 0);
                cl.set(Calendar.SECOND, 0);
                cl.set(Calendar.MILLISECOND, 1);
            } else {
                cl.set(Calendar.HOUR, 23);
                cl.set(Calendar.MINUTE, 59);
                cl.set(Calendar.SECOND, 59);
                cl.set(Calendar.MILLISECOND, 999);
                cl.set(Calendar.DAY_OF_MONTH, cl.getActualMaximum(Calendar.DAY_OF_MONTH));
            }

            return cl.getTime();
        }
        return null;
    }
}
