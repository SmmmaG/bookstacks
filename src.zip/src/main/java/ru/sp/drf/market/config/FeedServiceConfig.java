package ru.sp.drf.market.config;

import brave.context.log4j2.ThreadContextScopeDecorator;
import brave.propagation.CurrentTraceContext;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import ru.domrf.rem.actuator.checks.PostgresQueriesHealthChecker;
import ru.domrf.rem.actuator.checks.PostgresSimpleHealthChecker;

@Configuration
public class FeedServiceConfig {

    public static boolean ENABLE_FEED_LOADING;
    public static boolean ENABLE_GEOCODER_CITY_REGIONS;
    public static String YANDEX_APIKEY;
    public static String YANDEX_ORGANIZATION_APIKEY;
    public static Double GEOCODER_DIF_INCR;
    public static Double GEOCODER_K;
    public static String PHOTO_RETRIEVER_SERVICE_URL;
    public static ResourceLoader RESOURCE_LOADER;


    @Value("${app.geocoder.dif-incr}")
    public void setGeocoderDifIncr(Double geocoderDifIncr) {
        GEOCODER_DIF_INCR = geocoderDifIncr;
    }

    @Value("${app.geocoder.k}")
    public void setGeocoderK(Double geocoderK) {
        GEOCODER_K = geocoderK;
    }

    @Value("${app.geocoder.yandex.apikey}")
    public void setYandexApikey(String apiKey) {
        YANDEX_APIKEY = apiKey;
    }

    @Value("${app.geocoder.yandex.organization-apikey}")
    public void setYandexOrganizationApikey(String apiKey) {
        YANDEX_ORGANIZATION_APIKEY = apiKey;
    }

    @Value("${app.feed-loading.enable}")
    public void setEnableFeedLoading(boolean enableFeedLoading) {
        ENABLE_FEED_LOADING = enableFeedLoading;
    }

    @Value("${app.geocoder.enable}")
    public void setEnableGeocoderCityRegions(boolean enableGeocoderCityRegions) {
        ENABLE_GEOCODER_CITY_REGIONS = enableGeocoderCityRegions;
    }

    @Value("${app.photo-retriever-service-url}")
    public void setPhotoRetrieverServiceUrl(String photoRetrieverServiceUrl) {
        PHOTO_RETRIEVER_SERVICE_URL = photoRetrieverServiceUrl;
    }

    @Bean
    public CurrentTraceContext.ScopeDecorator scopeDecorator() {
        return ThreadContextScopeDecorator.create();
    }

    @Bean
    public ObjectMapper actuatorMapper() {
        return new ObjectMapper().setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
    }

    @Bean
    public PostgresSimpleHealthChecker postgresSimpleHealthChecker() {
        return new PostgresSimpleHealthChecker();
    }

    @Bean
    public PostgresQueriesHealthChecker postgresQueriesHealthChecker() {
        return new PostgresQueriesHealthChecker();
    }

    @Autowired
    public void setResourceLoader(ResourceLoader resourceLoader) {
        FeedServiceConfig.RESOURCE_LOADER = resourceLoader;
    }
}
