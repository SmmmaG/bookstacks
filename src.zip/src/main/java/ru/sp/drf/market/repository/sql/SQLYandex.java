package ru.sp.drf.market.repository.sql;

public enum SQLYandex {

    updateDocumentPhotoComplex("SELECT rem_update_document_photo_complex_yandex() updated;"),
    getTempComplexCount("SELECT count(DISTINCT(yb.building_name)) FROM $schema$.buildings yb;"),
    getTempBuildCount("SELECT COUNT(DISTINCT(building_custom_id)) FROM $schema$.buildings;"),
    getTempFlatCount("SELECT COUNT(uuid) FROM $schema$.flats;"),
    getBuildingsCount("SELECT COUNT(*) FROM $schema$.buildings;"),
    getFlatsCount("SELECT COUNT(*) FROM $schema$.flats;"),
    updateDocumentPhotoFlat("SELECT rem_update_document_photo_flat_yandex() updated;");
    ;


    SQLYandex(String sql) {
        this.sql = sql;
    }

    private String sql;

    public String getSQL() {
        return sql;
    }

}