package ru.sp.drf.market.repository.sql;

public enum SQLNMarket {

    addComplex("INSERT INTO $schema$.nmarket_complex (uuid,id, complexName, isDone, yearEnd, quarterEnd, minPrice, activeFlatsCount, apartmentsTotalCount) VALUES (?,?,?,?,?,?,?,?,?);"),
    addHouse("INSERT INTO $schema$.nmarket_house (id, houseId, complexId,lastChangeDate,name,developerName,district,transportNode,fromTransportNode,address,floors,yearEnd,quarterEnd,stageNumber,buildingNumber,isDone,isProperty,contract,houseType,houseClass,ceilingHeight,parkingName,region,longitude,latitude,lift,appartmentsCount,description,advantages,complexuuid) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"),
    addAppartment("INSERT INTO $schema$.nmarket_appartments (uuid,id,houseId,section,floor,type,appNumber,rooms,sAll,sLiving,sKitchen,sRooms,status,minimalAmount,baseAmount,amountUnit,ceilingHeight,sellerType,datePriceUpdate,planUrl,wc,balcony,objectType,widgetId,decoration) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);"),
    addPhoto("INSERT INTO $schema$.nmarket_photos (id,description,url,complex_id,complex_uuid,objectTypeId) VALUES (?,?,?,?,?,?);"),
    addPhotoTag("INSERT INTO $schema$.nmarket_phototags (id, title, photoid) VALUES (?,?,?);"),
    addStatictic("INSERT INTO $schema$.nmarket_statistic (id,sAllMin,sAllMax,totalPriceMin,totalPriceMax,countActive,housesId,complexId,flatCode) VALUES (?,?,?,?,?,?,?,?,?);"),
    addApprovedCreditProduct("INSERT INTO $schema$.nmarket_approvedCreditProducts(id,title,houseid,houseuuid) VALUES (?,?,?,?);"),
    addDiscounts("INSERT INTO $schema$.nmarket_discounts(id,name,description,dateBegin,dateEnd,houseid,houseuuid) VALUES (?,?,?,?,?,?,?);"),
    updateDocumentPhotoComplex("SELECT rem_update_document_photo_complex_nmarket() updated;"),
    getTempComplexCount("SELECT count(id) FROM nmarket.nmarket_complex;"),
    getTempBuildCount("SELECT count(id) FROM nmarket.nmarket_house;"),
    getTempFlatCount("SELECT count(id) FROM nmarket.nmarket_appartments;"),
    ;

    SQLNMarket(String sql) {
        this.sql = sql;
    }
    private String sql;

    public String getSQL() {return sql;}
}
