package ru.sp.drf.market.dataloader.nmarket;

import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptExecutor;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.exchange.nmarket.*;
import ru.sp.drf.market.repository.sql.SQLDataSource;
import ru.sp.drf.market.repository.sql.SQLNMarket;
import ru.sp.drf.market.utilities.LoadLogger;

import java.rmi.activation.UnknownObjectException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import static ru.sp.drf.market.dataloader.MarketDataSource.getConnection;

public class NMarketDataSource extends SQLDataSource implements AtomicOperation {
    private static final CustomLogger LOG = CustomLogger.getLogger();


    public NMarketDataSource() throws Exception {
        super(getConnection());
    }

    public void prepareTables(FeedLog feedLog) throws Exception {
        LOG.info("Create temporary tables");
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER);
        ScriptResult result = scriptExecutor.executeScript(
                "nmarket/Truncate_NMarket_tables");
        LoadLogger.writeScriptLog(
                result,
                feedLog,
                false,
                FeedEventTypes.Prep_Temp_tbls);
    }

    public UUID addComplex(ComplexesItem complex) throws Exception {
        LOG.info("Inserting complex id=" + complex.getComplexId());
        UUID uuid = UUID.randomUUID();
        try (PreparedStatement ps = connection.prepareStatement(SQLNMarket.addComplex.getSQL())) {
            ps.setObject(1, uuid);
            ps.setString(2, String.valueOf(complex.getComplexId()));
            ps.setString(3, complex.getComplexName());
            ps.setBoolean(4, complex.isIsDone());
            ps.setInt(5, complex.getYearEnd());
            ps.setInt(6, complex.getQuarterEnd());
            ps.setDouble(7, complex.getMinPrice());
            ps.setInt(8, complex.getActiveFlatsCount());
            ps.setInt(9, complex.getApartmentsTotalCount());
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted complex id=" + complex.getComplexId() + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT conplex " + complex.getComplexId());
            }
        }
    }

    public UUID addHouse(HousesItem house, UUID complexUUId) throws Exception {
        UUID uuid = UUID.randomUUID();
        try (PreparedStatement ps = connection.prepareStatement(SQLNMarket.addHouse.getSQL())) {
            ps.setObject(1, uuid);
            ps.setString(2, String.valueOf(house.getHouseInfo().getHouseId()));
            ps.setString(3, String.valueOf(house.getHouseInfo().getComplexId()));
            ps.setString(4, house.getHouseInfo().getLastChangeDate());
            ps.setString(5, house.getHouseInfo().getName());
            ps.setString(6, house.getHouseInfo().getDeveloperName());
            ps.setString(7, house.getHouseInfo().getDistrict());
            ps.setString(8, house.getHouseInfo().getTransportNode());
            ps.setString(9, house.getHouseInfo().getFromTransportNode());
            ps.setString(10, house.getHouseInfo().getAddress());
            ps.setString(11, house.getHouseInfo().getFloors());
            ps.setInt(12, house.getHouseInfo().getYearEnd());
            ps.setInt(13, house.getHouseInfo().getQuarterEnd());
            ps.setInt(14, house.getHouseInfo().getStageNumber());
            ps.setString(15, house.getHouseInfo().getBuildingNumber());
            ps.setBoolean(16, house.getHouseInfo().isIsDone());
            ps.setBoolean(17, house.getHouseInfo().isIsProperty());
            ps.setString(18, house.getHouseInfo().getContract());
            ps.setString(19, house.getHouseInfo().getHouseType());
            ps.setString(20, house.getHouseInfo().getHouseClass());
            ps.setDouble(21, house.getHouseInfo().getCeilingHeight());
            ps.setString(22, house.getHouseInfo().getParkingName());
            ps.setString(23, house.getHouseInfo().getRegion());
            ps.setDouble(24, house.getHouseInfo().getCoords().getLongitude());
            ps.setDouble(25, house.getHouseInfo().getCoords().getLatitude());
            ps.setString(26, house.getHouseInfo().getLift());
            ps.setString(27, (String) house.getHouseInfo().getAppartmentsCount());
            ps.setString(28, house.getHouseInfo().getDescription());
            ps.setString(29, house.getHouseInfo().getAdvantages());
            ps.setObject(30, complexUUId);
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted house id=" + house.getHouseInfo().getHouseId() + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT house " + house.getHouseInfo().getHouseId());
            }

        }
    }

    public UUID addAppartment(AppartmentsItem appartment) throws Exception {
        LOG.info("appartments = " + appartment);
        UUID uuid = UUID.randomUUID();
        try (PreparedStatement ps = connection.prepareStatement(SQLNMarket.addAppartment.getSQL())) {
            ps.setObject(1, uuid);
            ps.setString(2, String.valueOf(appartment.getId()));
            ps.setString(3, String.valueOf(appartment.getHouseId()));
            ps.setString(4, appartment.getSection());
            ps.setString(5, appartment.getFloor());
            ps.setString(6, appartment.getType());
            ps.setString(7, appartment.getAppNumber());
            ps.setString(8, appartment.getRooms());
            ps.setDouble(9, appartment.getSAll());
            ps.setDouble(10, appartment.getSLiving());
            ps.setDouble(11, appartment.getSKitchen());
            ps.setString(12, appartment.getSRooms());
            ps.setString(13, appartment.getStatus());
            ps.setInt(14, appartment.getMinimalAmount());
            ps.setInt(15, appartment.getBaseAmount());
            ps.setString(16, appartment.getAmountUnit());
            ps.setDouble(17, appartment.getCeilingHeight());
            ps.setString(18, appartment.getSellerType());
            ps.setTimestamp(19, appartment.getDatePriceUpdateStamp());
            ps.setString(20, appartment.getPlanUrl());
            ps.setString(21, appartment.getWc());
            ps.setString(22, appartment.getBalcony());
            ps.setInt(23, appartment.getObjectType());
            ps.setString(24, appartment.getWidgetId());
            ps.setString(25, appartment.getDecoration());
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted apartment id=" + appartment.getId() + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT apartment " + appartment.getId());
            }
        }
    }

    public UUID addComplexPhoto(PhotosItem photo, UUID complexId, int complexIntId) throws Exception {
        try (PreparedStatement ps = connection.prepareStatement(SQLNMarket.addPhoto.getSQL())) {
            UUID uuid = UUID.randomUUID();
            ps.setObject(1, uuid);
            ps.setString(2, photo.getDescription());
            ps.setString(3, photo.getUrl());
            ps.setString(4, String.valueOf(complexIntId));
            ps.setObject(5, complexId);
            ps.setInt(6, photo.getObjectTypeId());
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted photo id=" + uuid + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT photo " + uuid);
            }
        }
    }

    public List<UUID> addPhotoTags(List<String> tags, UUID photoId) throws Exception {
        try (PreparedStatement ps = connection.prepareStatement(SQLNMarket.addPhotoTag.getSQL())) {
            UUID uuid;
            int tagCount = 0;
            List<UUID> tagIds = new ArrayList();
            ps.setObject(3, photoId);
            for (String tag : tags) {
                uuid = UUID.randomUUID();
                tagIds.add(uuid);
                ps.setObject(1, UUID.randomUUID());
                ps.setString(2, tag);
                tagCount += ps.executeUpdate();
            }
            if (tagCount == tags.size()) {
                LOG.info("Inserted photo tags " + tagIds + " result=" + tagCount);
                return tagIds;
            } else {
                throw new SQLException("Cant INSERT photoTags " + tags);
            }
        }
    }

    public List<UUID> addStatistic(HasStatistic itemWithStatistic) throws Exception {
        try (PreparedStatement ps = connection.prepareStatement(SQLNMarket.addStatictic.getSQL())) {
            if (itemWithStatistic instanceof ComplexesItem) {
                ps.setObject(7, null);
                ps.setString(8, String.valueOf(((ComplexesItem) itemWithStatistic).getComplexId()));
            } else if (itemWithStatistic instanceof HousesItem) {
                ps.setString(7, String.valueOf(((HousesItem) itemWithStatistic).getHouseInfo().getHouseId()));
                ps.setObject(8, null);
            } else {
                throw new UnknownObjectException("Unknown Object with statistic");
            }
            List<UUID> statisticItems = new ArrayList();
            statisticItems.add(addStatisticItem(ps, itemWithStatistic.getStatisticByRooms().getRoomCharacteristicStudia(), "studia"));
            statisticItems.add(addStatisticItem(ps, itemWithStatistic.getStatisticByRooms().getRoomCharacteristicOne(), "oneroom"));
            statisticItems.add(addStatisticItem(ps, itemWithStatistic.getStatisticByRooms().getRoomCharacteristicTwo(), "two"));
            statisticItems.add(addStatisticItem(ps, itemWithStatistic.getStatisticByRooms().getRoomCharacteristicThird(), "three"));
            statisticItems.add(addStatisticItem(ps, itemWithStatistic.getStatisticByRooms().getRoomCharacteristicForth(), "four"));
            statisticItems.add(addStatisticItem(ps, itemWithStatistic.getStatisticByRooms().getRoomCharacteristicForthMore(), "fourmore"));
            LOG.info("added statisticItems:" + statisticItems);
            return statisticItems;
        }
    }

    private static UUID addStatisticItem(PreparedStatement ps, RoomCharacteristic roomCharacteristic, String flatCode) throws Exception {
        if (Objects.nonNull(roomCharacteristic)) {
            UUID uuid = UUID.randomUUID();
            ps.setObject(1, uuid);
            ps.setDouble(2, roomCharacteristic.getSAllMin());
            ps.setDouble(3, roomCharacteristic.getSAllMax());
            ps.setDouble(4, roomCharacteristic.getTotalPriceMin());
            ps.setDouble(5, roomCharacteristic.getTotalPriceMax());
            ps.setDouble(6, roomCharacteristic.getCountActive());
            ps.setString(9, flatCode);
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted roomCharacteristic =" + roomCharacteristic + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT roomCharacteristic " + roomCharacteristic);
            }
        }
        return null;
    }

    public UUID addDiscount(DiscountsItem discountsItem, UUID houseUUID, int houseId) throws Exception {
        try (PreparedStatement ps = connection.prepareStatement(SQLNMarket.addDiscounts.getSQL())) {
            UUID uuid = UUID.randomUUID();
            ps.setObject(1, uuid);
            ps.setString(2, discountsItem.getName());
            ps.setString(3, discountsItem.getDescription());
            ps.setTimestamp(4, discountsItem.getDateBeginStamp());
            ps.setTimestamp(5, discountsItem.getDateEndStamp());
            ps.setString(6, String.valueOf(houseId));
            ps.setObject(7, houseUUID);
            int res = ps.executeUpdate();
            if (res == 1) {
                LOG.info("Inserted Discount id" + uuid + " result=" + res);
                return uuid;
            } else {
                throw new SQLException("Cant INSERT Discount " + discountsItem);
            }
        }
    }

    public List<UUID> addApprovedCreditProducts(List<String> approvedCreditProducts, UUID houseUUID, int houseId) throws Exception {
        try (PreparedStatement ps = connection.prepareStatement(SQLNMarket.addApprovedCreditProduct.getSQL())) {
            ps.setString(3, String.valueOf(houseId));
            ps.setObject(4, houseUUID);
            int productCount = 0;
            List<UUID> productsIds = new ArrayList();
            for (String creditProduct : approvedCreditProducts) {
                UUID uuid = UUID.randomUUID();
                productsIds.add(uuid);
                ps.setObject(1, uuid);
                ps.setString(2, creditProduct);
                productCount += ps.executeUpdate();
            }
            if (productCount == approvedCreditProducts.size()) {
                LOG.info("Inserted approvedCreditProducts " + productsIds + " result=" + productCount);
                return productsIds;
            } else {
                throw new SQLException("Cant INSERT approvedCreditProducts " + approvedCreditProducts);
            }
        }
    }

    public void storeData(FeedLog feedLog) throws Exception {
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER);
        UUID feedUuid = feedLog.getFeed().getId();
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLNMarket.getTempComplexCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLNMarket.getTempBuildCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Build);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLNMarket.getTempFlatCount.getSQL()), feedLog, true, FeedEventTypes.Get_Feed_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Region Insert"), feedLog, true, FeedEventTypes.Add_Regoin);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/City Insert"), feedLog, true, FeedEventTypes.Add_City);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/CityBig Insert"), feedLog, true, FeedEventTypes.Add_City);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/District Update"), feedLog, true, FeedEventTypes.Upd_District);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/District Insert"), feedLog, true, FeedEventTypes.Add_District);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Bank Update"), feedLog, true, FeedEventTypes.Upd_Bank);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Bank Insert"), feedLog, true, FeedEventTypes.Add_Bank);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Decoration_type Update"), feedLog, true, FeedEventTypes.Upd_Decoration_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Decoration_type Insert"), feedLog, true, FeedEventTypes.Add_Decoration_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Parking_type Update"), feedLog, true, FeedEventTypes.Upd_Parking_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Parking_type Insert"), feedLog, true, FeedEventTypes.Add_Parking_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Currency_type Update"), feedLog, true, FeedEventTypes.Upd_Curency_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Currency_type Insert"), feedLog, true, FeedEventTypes.Add_Curency_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Developer Update"), feedLog, true, FeedEventTypes.Upd_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Developer Insert"), feedLog, true, FeedEventTypes.Add_Developer);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Building_type Update"), feedLog, true, FeedEventTypes.Upd_Build_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Building_type Insert"), feedLog, true, FeedEventTypes.Add_Build_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Balcony_type Update"), feedLog, true, FeedEventTypes.Upd_Balcony_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Balcony_type Insert"), feedLog, true, FeedEventTypes.Add_Balcony_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flat status_type Update"), feedLog, true, FeedEventTypes.Upd_Flat_status_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flat status_type Insert"), feedLog, true, FeedEventTypes.Add_Flat_status_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Material_wall_type Update"), feedLog, true, FeedEventTypes.Upd_Mtrl_wall_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Material_wall_type Insert"), feedLog, true, FeedEventTypes.Add_Mtrl_wall_type);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Discount_building Update"), feedLog, true, FeedEventTypes.Upd_Disc_build);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Discount_building Insert"), feedLog, true, FeedEventTypes.Add_Disc_build);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Address_complex Update"), feedLog, true, FeedEventTypes.Upd_Cmpx_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Address_complex Insert"), feedLog, true, FeedEventTypes.Add_Cmpx_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Address_building Update"), feedLog, true, FeedEventTypes.Upd_Build_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Address_building Insert"), feedLog, true, FeedEventTypes.Add_Build_Address);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Metro_location Update"), feedLog, true, FeedEventTypes.Upd_Metro_location);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Metro_location Insert"), feedLog, true, FeedEventTypes.Add_Metro_location);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Advantage Insert"), feedLog, true, FeedEventTypes.Add_Advantage);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("nmarket/Complex stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Complex stage 2 Update", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Upd_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Complex stage 3 Insert", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Add_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Complex stage 4 cross Insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Cmpx_Feed);
        scriptExecutor.executeInsUpd("nmarket/Complex stage 5 tmp drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("nmarket/Complex_photo stage 1 tmp prepare", new Object[]{feedUuid,feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeQuery(SQLNMarket.updateDocumentPhotoComplex.getSQL()), feedLog, true, FeedEventTypes.Upd_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Complex_photo stage 2 document_photo Insert"), feedLog, true, FeedEventTypes.Add_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Complex_photo stage 3 complex_document_photo Insert"), feedLog, true, FeedEventTypes.Asgn_Photo_Cmpx);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("nmarket/Building stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Building stage 2 Update", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Building stage 3 Insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Building stage 4 cross Insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Build_Feed);
        scriptExecutor.executeInsUpd("nmarket/Building stage 5 tmp drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Discount_buildings Delete", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Del_Build_stats);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Discounts_building Insert", new Object[]{feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Build_stats);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Bank_building Update", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Upd_Bank_building);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Bank_building Insert", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Add_Bank_building);
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("nmarket/BuildingInfrastrucure stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Build_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/BuildingInfrastrucure stage 2 Update"), feedLog, true, FeedEventTypes.Upd_Build_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/BuildingInfrastrucure stage 3 Insert"), feedLog, true, FeedEventTypes.Add_Build_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/BuildingInfrastrucure stage 4 Build Update"), feedLog, true, FeedEventTypes.Asgn_Build_Infstr);
        scriptExecutor.executeScript("nmarket/BuildingInfrastrucure stage 5 tmp drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("nmarket/ComplexInfrastrucure stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Cmpx_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/ComplexInfrastrucure stage 2 Update"), feedLog, true, FeedEventTypes.Upd_Cmpx_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/ComplexInfrastrucure stage 3 Insert"), feedLog, true, FeedEventTypes.Add_Cmpx_Infstr);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/ComplexInfrastrucure stage 4 Complex Update"), feedLog, true, FeedEventTypes.Asgn_Cmpx_Infstr);
        scriptExecutor.executeScript("nmarket/ComplexInfrastrucure stage 5 tmp drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("nmarket/Flat stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flat stage 2 Update", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Upd_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flat stage 3 Insert", new Object[]{feedUuid, feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Add_Flat);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flat stage 4 cross Insert", new Object[]{feedUuid, feedUuid, feedUuid}), feedLog, true, FeedEventTypes.Asgn_Flat_Feed);
        scriptExecutor.executeInsUpd("nmarket/Flat stage 5 tmp drop");
        LoadLogger.writeScriptLog(scriptExecutor.executeScript("nmarket/Flats_photo stage 1 tmp prepare", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Prep_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flats_photo stage 2 Update"), feedLog, true, FeedEventTypes.Upd_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flats_photo stage 3 Insert"), feedLog, true, FeedEventTypes.Add_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flats_photo stage 4 Flats Update"), feedLog, true, FeedEventTypes.Asgn_Flats_photo);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Prices Insert"), feedLog, true, FeedEventTypes.Add_Prices);
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("nmarket/Flat Prices Update", new Object[]{feedUuid}), feedLog, true, FeedEventTypes.Upd_Prices);
        scriptExecutor.executeInsUpd("nmarket/Flats_photo stage 5 tmp drop");
    }

}
