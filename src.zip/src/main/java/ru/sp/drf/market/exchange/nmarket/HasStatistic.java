package ru.sp.drf.market.exchange.nmarket;

public interface HasStatistic {
    StatisticByRooms getStatisticByRooms();
}
