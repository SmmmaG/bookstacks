package ru.sp.drf.market.exchange.nmarket;

import java.util.List;
import java.util.UUID;

public interface AtomicOperation {

    UUID addComplex(ComplexesItem complex) throws Exception;
    UUID addHouse(HousesItem house, UUID complexUUId) throws Exception;
    UUID addAppartment(AppartmentsItem appartment) throws Exception;
    UUID addComplexPhoto(PhotosItem photo, UUID complexId, int complexIntId) throws Exception;
    List<UUID> addStatistic(HasStatistic itemWithStatistic) throws Exception;
    UUID addDiscount(DiscountsItem discountsItem, UUID houseUUID, int houseId) throws Exception;
    List<UUID> addPhotoTags(List<String> tags, UUID photoId) throws Exception;
    List<UUID> addApprovedCreditProducts(List<String> approvedCreditProducts, UUID houseUUID, int houseId) throws Exception;

}
