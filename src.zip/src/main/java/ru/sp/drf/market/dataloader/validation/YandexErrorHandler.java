package ru.sp.drf.market.dataloader.validation;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.FileLoader;
import ru.sp.drf.market.dto.validation.ValidationStatisticsDto;

import java.io.File;
import java.io.IOException;

@Component
public class YandexErrorHandler extends ErrorHandler {

    public YandexErrorHandler() {
    }

    public YandexErrorHandler(FeedLog feedlog, File file) {
        super(feedlog,file);
    }

    @Override

    public ValidationStatisticsDto countStatistics () throws IOException {
        ValidationStatisticsDto statistics  = new ValidationStatisticsDto();
        String fullFeed = FileLoader.getFullFeed(file);
        statistics.setFlatsCount(StringUtils.countMatches(fullFeed, "<offer"));
        return statistics;
    }

}
