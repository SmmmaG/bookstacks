package ru.sp.drf.market.repository.sql;

public enum SQL {
    setFeedStatus("UPDATE feed SET status_id=?, upload_date=now() WHERE id=?"),
    setFeedLogStatus("UPDATE feed_log SET status_id=?, update_date=now() WHERE id=?"),
    setFeedLastEvent("UPDATE feed SET event_log_id=? WHERE id=?"),
    setExpiredFeedsAsError("UPDATE feed set status_id=(SELECT id FROM feed_log_status WHERE code='ERROR') WHERE status_id = (SELECT id FROM feed_log_status WHERE code='PROGRESS')"),
    setExpiredFeedLogsAsError("UPDATE feed_log set status_id=(SELECT id FROM feed_log_status WHERE code='ERROR') WHERE status_id = (SELECT id FROM feed_log_status WHERE code='PROGRESS')"),
    setDisableInactivePhotos("UPDATE document_photo SET key=null, hash_code=null WHERE actual=false AND key is not null;"),
    createSchema("CREATE SCHEMA ?"),
    dropSchema("DROP SCHEMA ? CASCADE"),
    ;

    SQL(String sql) {
        this.sql = sql;
    }

    private String sql;

    public String getSQL() {
        return sql;
    }

}
