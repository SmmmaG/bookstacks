package ru.sp.drf.market.exception;

public class UndefinedFeedHandlerException extends FeedException {
    public UndefinedFeedHandlerException() {
    }

    public UndefinedFeedHandlerException(String message) {
        super(message);
    }

    public UndefinedFeedHandlerException(String message, Throwable cause) {
        super(message, cause);
    }

    public UndefinedFeedHandlerException(Throwable cause) {
        super(cause);
    }

    public UndefinedFeedHandlerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
