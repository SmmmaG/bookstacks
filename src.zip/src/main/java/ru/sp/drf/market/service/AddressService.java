package ru.sp.drf.market.service;

import org.springframework.stereotype.Service;
import ru.domrf.rem.domain.address.Address;
import ru.domrf.rem.domain.address.Location;
import ru.sp.drf.market.repository.AddressRepository;
import ru.sp.drf.market.repository.LocationRepository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class AddressService extends AbstractService {

    private final AddressRepository addressRepository;
    private final LocationRepository locationRepository;

    public AddressService(AddressRepository addressRepository, LocationRepository locationRepository) {
        this.addressRepository = addressRepository;
        this.locationRepository = locationRepository;
    }

    public Address saveAddress(Address address) {
        return this.addressRepository.save((Address) address);
    }

    public Location saveLocation(Location location) {
        return this.locationRepository.save(location);
    }

    public Optional<Address> findAddressById(UUID uuid) {
        return addressRepository.findById(uuid);
    }

    public Optional<Location> findLocationById(UUID uuid) {
        return locationRepository.findById(uuid);
    }

    public List<Address> findAllCrushedAddresses() {
        return addressRepository.findAllCrushedAddresses();
    }

    public List<Location> findAllCrushedLocations() {
        return locationRepository.findAllCrushedLocations();
    }

    public List<Address> findAllAddresses() {
        return addressRepository.findAllAddresses();
    }

    public List<Location> findAllLocations() {
        return locationRepository.findAllLocations();
    }
}
