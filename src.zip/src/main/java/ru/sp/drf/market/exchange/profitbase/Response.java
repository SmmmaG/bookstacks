package ru.sp.drf.market.exchange.profitbase;

public interface Response {

    void save(AtomicOperation operation) throws Exception;

}
