package ru.sp.drf.market.exchange.nmarket;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;

@Generated("com.robohorse.robopojogenerator")
public class RoomCharacteristic {

	@JsonProperty("totalPriceMin")
	private double totalPriceMin;

	@JsonProperty("totalPriceMax")
	private double totalPriceMax;

	@JsonProperty("sAllMax")
	private double sAllMax;

	@JsonProperty("countActive")
	private double countActive;

	@JsonProperty("sAllMin")
	private double sAllMin;

	public void setTotalPriceMin(int totalPriceMin){
		this.totalPriceMin = totalPriceMin;
	}

	public double getTotalPriceMin(){
		return totalPriceMin;
	}

	public void setTotalPriceMax(int totalPriceMax){
		this.totalPriceMax = totalPriceMax;
	}

	public double getTotalPriceMax(){
		return totalPriceMax;
	}

	public void setSAllMax(double sAllMax){
		this.sAllMax = sAllMax;
	}

	public double getSAllMax(){
		return sAllMax;
	}

	public void setCountActive(int countActive){
		this.countActive = countActive;
	}

	public double getCountActive(){
		return countActive;
	}

	public void setSAllMin(double sAllMin){
		this.sAllMin = sAllMin;
	}

	public double getSAllMin(){
		return sAllMin;
	}

	@Override
 	public String toString(){
		return 
			"RoomCharacteristic{" +
			"totalPriceMin = '" + totalPriceMin + '\'' + 
			",totalPriceMax = '" + totalPriceMax + '\'' + 
			",sAllMax = '" + sAllMax + '\'' + 
			",countActive = '" + countActive + '\'' + 
			",sAllMin = '" + sAllMin + '\'' + 
			"}";
		}
}