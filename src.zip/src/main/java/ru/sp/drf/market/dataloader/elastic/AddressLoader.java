package ru.sp.drf.market.dataloader.elastic;


import org.springframework.stereotype.Service;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.repository.ComplexRepository;
import ru.sp.drf.market.utilities.ElasticBulkClient;

@Service
public class AddressLoader {
    private static final CustomLogger LOG = CustomLogger.getLogger();


    private ComplexRepository complexRepository;


    public AddressLoader(ComplexRepository complexRepository) {
        this.complexRepository = complexRepository;
    }


    public void load() {
        LOG.info("Load Addresses");
        ElasticBulkClient.loadToElastic(new AddressSliceLoader(), complexRepository.findAllActive(),null);

    }


}
