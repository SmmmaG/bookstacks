package ru.sp.drf.market.dataloader.fias.strategy;

import ru.domrf.rem.domain.admin.FeedLog;
import ru.sp.drf.market.model.fias.DataRow;
import ru.sp.drf.market.utilities.ElasticBulkClient;

import java.util.List;

public class CreateAddressElasticCommand extends OperationCommand {


    @Override
    public void execute(List<DataRow> datas, FeedLog feedLog) {
        insertIndex(datas, feedLog);
    }

    protected void insertIndex(List<DataRow> datas, FeedLog feedLog) {
        ElasticBulkClient.loadToElastic(sliceLoader, datas, feedLog);
    }


}
