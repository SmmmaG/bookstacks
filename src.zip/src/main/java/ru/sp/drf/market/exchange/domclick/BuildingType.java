
package ru.sp.drf.market.exchange.domclick;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for buildingType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="buildingType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="id">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="141398"/>
 *               &lt;enumeration value="141396"/>
 *               &lt;enumeration value="145924"/>
 *               &lt;enumeration value="146476"/>
 *               &lt;enumeration value="146477"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="fz_214" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="name">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="г. Москва, ЮЗАО, ул. Вавилова, вл. 27-31"/>
 *               &lt;enumeration value="Левобережный р-н, мкр.2Г, корп. 19"/>
 *               &lt;enumeration value="г. Москва, ул. Никулинская, мкр. 2А, корп. 3"/>
 *               &lt;enumeration value="г. Москва, ул. Чоботовская, корп. 1"/>
 *               &lt;enumeration value="г. Москва, ул. Чоботовская, корп. 2"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="floors">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="19"/>
 *               &lt;enumeration value="35"/>
 *               &lt;enumeration value="24"/>
 *               &lt;enumeration value="23"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="building_state" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="built_year">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="2019"/>
 *               &lt;enumeration value="2020"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ready_quarter">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;enumeration value="2"/>
 *               &lt;enumeration value="3"/>
 *               &lt;enumeration value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="building_type" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="flats" type="{}flatsType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "buildingType", propOrder = {
    "id",
    "fz214",
    "name",
    "floors",
    "buildingState",
    "builtYear",
    "readyQuarter",
    "buildingType",
    "flats"
})
public class BuildingType {

    @XmlElement(required = true)
    protected String id;
    @XmlElement(name = "fz_214", required = true)
    protected String fz214;
    @XmlElement(required = true)
    protected String name;
    @XmlElement(required = true)
    protected String floors;
    @XmlElement(name = "building_state", required = true)
    protected String buildingState;
    @XmlElement(name = "built_year", required = true)
    protected String builtYear;
    @XmlElement(name = "ready_quarter", required = true)
    protected String readyQuarter;
    @XmlElement(name = "building_type", required = true)
    protected String buildingType;
    @XmlElement(required = true)
    protected FlatsType flats;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the fz214 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFz214() {
        return fz214;
    }

    /**
     * Sets the value of the fz214 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFz214(String value) {
        this.fz214 = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the floors property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFloors() {
        return floors;
    }

    /**
     * Sets the value of the floors property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFloors(String value) {
        this.floors = value;
    }

    /**
     * Gets the value of the buildingState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuildingState() {
        return buildingState;
    }

    /**
     * Sets the value of the buildingState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuildingState(String value) {
        this.buildingState = value;
    }

    /**
     * Gets the value of the builtYear property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuiltYear() {
        return builtYear;
    }

    /**
     * Sets the value of the builtYear property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuiltYear(String value) {
        this.builtYear = value;
    }

    /**
     * Gets the value of the readyQuarter property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReadyQuarter() {
        return readyQuarter;
    }

    /**
     * Sets the value of the readyQuarter property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReadyQuarter(String value) {
        this.readyQuarter = value;
    }

    /**
     * Gets the value of the buildingType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBuildingType() {
        return buildingType;
    }

    /**
     * Sets the value of the buildingType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBuildingType(String value) {
        this.buildingType = value;
    }

    /**
     * Gets the value of the flats property.
     * 
     * @return
     *     possible object is
     *     {@link FlatsType }
     *     
     */
    public FlatsType getFlats() {
        return flats;
    }

    /**
     * Sets the value of the flats property.
     * 
     * @param value
     *     allowed object is
     *     {@link FlatsType }
     *     
     */
    public void setFlats(FlatsType value) {
        this.flats = value;
    }

}
