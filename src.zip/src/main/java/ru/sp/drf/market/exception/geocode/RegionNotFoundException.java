package ru.sp.drf.market.exception.geocode;

public class RegionNotFoundException extends Exception {

    public RegionNotFoundException() {
    }

    public RegionNotFoundException(String message) {
        super(message);
    }

    public RegionNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public RegionNotFoundException(Throwable cause) {
        super(cause);
    }

    public RegionNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
