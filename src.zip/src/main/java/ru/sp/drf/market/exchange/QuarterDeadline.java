package ru.sp.drf.market.exchange;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import ru.sp.drf.market.utilities.DateUtils;

import javax.annotation.Generated;
import java.util.Date;

@Generated("com.robohorse.robopojogenerator")
@JsonIgnoreProperties(ignoreUnknown = true)
public class QuarterDeadline {
    @JsonProperty("year")
    private Integer year ;
    @JsonProperty("quarter")
    private Integer quarter;

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Integer getQuarter() {
        return quarter;
    }

    public void setQuarter(Integer quarter) {
        this.quarter = quarter;
    }


    @JsonIgnore
    public Date toBeginDate() {
        return DateUtils.convertQuarterToDate(this,true);
    }
    @JsonIgnore
    public Date toEndDate() {
        return DateUtils.convertQuarterToDate(this,false);
    }
}
