package ru.sp.drf.market.dataloader;

public enum LoaderTags {
    Yandex(FeedHandlers.Yandex, "realty-feed"),
    Domclick(FeedHandlers.Domclick, "complexes"),
    Cian(FeedHandlers.Cian, "feed");

    LoaderTags(FeedHandlers handler, String firstTag) {
        this.handler = handler;
        this.firstTag = firstTag;
    }

    private FeedHandlers handler;
    private String firstTag;

    public String getFirstTag() {
        return firstTag;
    }

    public FeedHandlers getHandler() {
        return handler;
    }
}
