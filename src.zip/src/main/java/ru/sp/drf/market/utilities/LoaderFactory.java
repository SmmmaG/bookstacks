package ru.sp.drf.market.utilities;

import ru.sp.drf.market.dataloader.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ru.sp.drf.market.dataloader.domclick.DomClickLoader;
import ru.sp.drf.market.dataloader.FeedLoader;
import ru.sp.drf.market.dataloader.nmarket.NMarketLoader;
import ru.sp.drf.market.dataloader.profitbase.ProfitbaseLoader;
import ru.sp.drf.market.dataloader.fias.FiasLoader;
import ru.sp.drf.market.dataloader.yandex.NMarketYandexLoader;
import ru.sp.drf.market.dataloader.yandex.YandexLoader;
import ru.sp.drf.market.exception.UndefinedFeedHandlerException;
import ru.sp.drf.market.repository.FiasAddressObjectRepository;

import java.util.Objects;

@Component
public class LoaderFactory {

    @Autowired
    private FiasAddressObjectRepository fiasRepository;

    public FeedLoader getLoader(String code) throws UndefinedFeedHandlerException {
        FeedLoader loader = getFeedLoader(code);
        if (code.equals(FeedHandlers.FIAS.getHandlerName()))
            loader = new FiasLoader(fiasRepository);
        if (Objects.isNull(loader))
            throw new UndefinedFeedHandlerException("Undefined feed handler");
        return loader;
    }

    public static FeedLoader getFeedLoader(String code) {
        if (code.equals(FeedHandlers.NMarket.getHandlerName()))
            return new NMarketLoader();
        if (code.equals(FeedHandlers.Domclick.getHandlerName()))
            return new DomClickLoader();
        if (code.equals(FeedHandlers.Profitbase.getHandlerName()))
            return new ProfitbaseLoader();
        if (code.equals(FeedHandlers.Yandex.getHandlerName()))
            return new YandexLoader();
        if (code.equals(FeedHandlers.NMarketYandex.getHandlerName()))
            return new NMarketYandexLoader();
        return null;
    }
}
