package ru.sp.drf.market.dataloader.elastic;

import ru.sp.drf.market.model.elastic.MetroData;

public class MetroSliceLoader extends BasicSlicer<MetroData> {

    public MetroSliceLoader() {
        super("metro");
    }

}
