package ru.sp.drf.market.model.fias;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public enum AOLevel {
    regionLevel(1, "region"),
    districtLevel(3, "district"),
    city1Level(4, "city"),
    city2Level(6, "city"),
    city3Level(35, "city"),
    streetLevel(7, "street"),
    unknown(-1, "no_level");

    private int code;
    private String type;

    AOLevel(int code, String type) {
        this.code = code;
        this.type = type;
    }

    public int getCode() {
        return code;
    }

    public String getType() {
        return type;
    }

    public static AOLevel findByCode(int code) {
        Optional<AOLevel> param = Arrays.stream(values()).filter(item -> item.code == code).findFirst();
        return param.isPresent() ? param.get() : unknown;
    }

    public static Integer[] findByType(String type) {
        List<Integer> result = new ArrayList<>();
        Arrays.stream(values()).filter(item -> item.type == type).forEach(item -> result.add(item.code));
        return result.toArray(new Integer[result.size()]);
    }
}
