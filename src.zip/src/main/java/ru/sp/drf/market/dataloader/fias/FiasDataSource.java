package ru.sp.drf.market.dataloader.fias;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import ru.sp.drf.market.utilities.FeedEventTypes;
import ru.domrf.rem.domain.admin.FeedLog;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptExecutor;
import ru.domrf.rem.utilities.ScriptExecutor.ScriptResult;
import ru.domrf.rem.utilities.logs.CustomLogger;
import ru.sp.drf.market.config.FeedServiceConfig;
import ru.sp.drf.market.config.loaders.FiasConfig;
import ru.sp.drf.market.dataloader.fias.strategy.CreateAddressElasticCommand;
import ru.sp.drf.market.dataloader.fias.strategy.OperationCommand;
import ru.sp.drf.market.dataloader.fias.strategy.UpdateAddressElasticCommand;
import ru.sp.drf.market.model.fias.AOLevel;
import ru.sp.drf.market.model.fias.DataRow;
import ru.sp.drf.market.repository.FiasAddressObjectRepository;
import ru.sp.drf.market.repository.sql.SQLDataSource;
import ru.sp.drf.market.utilities.LoadLogger;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import static ru.sp.drf.market.config.loaders.FiasConfig.*;
import static ru.sp.drf.market.utilities.ElasticBulkClient.*;
import static ru.sp.drf.market.utilities.HelperUtils.*;

public class FiasDataSource extends SQLDataSource {
    private static final CustomLogger LOG = CustomLogger.getLogger();
    private FiasAddressObjectRepository repository;


    public FiasDataSource(Connection connection, FiasAddressObjectRepository repository) {
        super(connection);
        this.repository = repository;
    }

    @Override
    public void prepareTables(FeedLog feedLog) throws Exception {
        LOG.info("Create temporary tables");
        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER);
        ScriptResult result = scriptExecutor.executeScript(
                "fias/main/create-address-object",
                null);
        init(feedLog);
        LoadLogger.writeScriptLog(result, feedLog, false, FeedEventTypes.Prep_Temp_tbls);
    }

    @Override
    public void storeData(FeedLog feedLog) throws Exception {

        connection.setAutoCommit(true);

        ScriptExecutor scriptExecutor = new ScriptExecutor(connection, FeedServiceConfig.RESOURCE_LOADER);

        //update address_object fill code region, city, address full
        //todo explain needed
        Integer[] levels = new Integer[]{1, 4, 6, 35, 3};
        for (Integer level : levels)
            LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("fias/main/update-address-object", new Object[]{level}), feedLog, true, FeedEventTypes.Upd_District);
        List<String> regionCodes = repository.getRegionCodes();

        for (String regionCode : regionCodes) {
            LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("fias/main/update-address-object-street", new Object[]{7, "'" + regionCode + "'"}), feedLog, true, FeedEventTypes.Upd_District);
        }

        //update fias code on region
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("fias/main/update-fias-code-region", null), feedLog, true, FeedEventTypes.Upd_District);

        //update fias code on city
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("fias/main/update-fias-code-city", null), feedLog, true, FeedEventTypes.Upd_District);

        //update fias code on district
        LoadLogger.writeScriptLog(scriptExecutor.executeInsUpd("fias/main/update-fias-code-district", null), feedLog, true, FeedEventTypes.Upd_District);


        // update ElasticSearch store district
        insertStore(feedLog, AOLevel.findByType(AOLevel.districtLevel.getType()));
        // update ElasticSearch store  city
        insertStore(feedLog, AOLevel.findByType(AOLevel.city1Level.getType()));
        // update ElasticSearch store street
        insertStore(feedLog, AOLevel.findByType(AOLevel.streetLevel.getType()));
    }

    private void updateStore(FeedLog feedLog, Integer... levels) {
        saveStore(new UpdateAddressElasticCommand(), feedLog, levels);
    }

    private void insertStore(FeedLog feedLog, Integer... levels) {
        saveStore(new CreateAddressElasticCommand(), feedLog, levels);
    }


    private void saveStore(OperationCommand command, FeedLog feedLog, Integer... levels) {
        int pageNumber;
        Page<DataRow> addresses = null;

        List<String> regionCodes = repository.getRegionCodes();
        if (isValid(levels)) {
            for (String regionCode : regionCodes) {
                pageNumber = 0;
                Pageable pageable = PageRequest.of(pageNumber, FETCH_SIZE);
                while (true) {
                    try {
                        addresses = repository.findAddressObjectByLevel(levels, regionCode, pageable);
                    } catch (Exception e) {
                        LOG.error("Unexpected exception", e);
                        break;
                    }
                    if (isValid(addresses) && isValid(addresses.getContent())) {
                        command.execute(addresses.getContent(), feedLog);
                        if (!addresses.hasNext())
                            break;
                        pageable = addresses.nextPageable();
                        LOG.info(String.join(", ",
                                "Processing AO level: " + String.join(",",
                                        Arrays.stream(levels).map(String::valueOf).toArray(String[]::new)),
                                "Region: " + regionCode,
                                "Page: " + pageable.getPageNumber(),
                                "Fetch size: " + pageable.getPageSize()));
                    } else
                        break;
                }
            }
        }
    }


    private void init(FeedLog feedLog) {
        if (!existsIndex("address")) {
            createIndex("address.json", "address");
        } else {
            boolean isMainFeed = feedLog.getFeed().getCode().equalsIgnoreCase(FEED_FIAS_MAIN);
            if (isMainFeed || FiasConfig.isClearElasticStore()) {
                clearSchema();
            }
        }
    }

    private void clearSchema() {
        deleteIndex("address");
        createIndex("address.json", "address");
    }

    @Override
    public void disableData(FeedLog feedLog) throws IOException, SQLException {
    }

    @Override
    public void recalculation(FeedLog feedLog) throws Exception {
    }
}
