package ru.sp.drf.market.exception;

import javax.xml.bind.ValidationException;

public class NoObjectsAfterValidationException extends ValidationException {
    public NoObjectsAfterValidationException(String message) {
        super(message);
    }

    public NoObjectsAfterValidationException(String message, String errorCode) {
        super(message, errorCode);
    }

    public NoObjectsAfterValidationException(Throwable exception) {
        super(exception);
    }

    public NoObjectsAfterValidationException(String message, Throwable exception) {
        super(message, exception);
    }

    public NoObjectsAfterValidationException(String message, String errorCode, Throwable exception) {
        super(message, errorCode, exception);
    }
}
