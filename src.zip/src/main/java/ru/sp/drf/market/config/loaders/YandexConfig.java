package ru.sp.drf.market.config.loaders;


import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
public class YandexConfig {


    public static final String XML_START_TAG = "<?xml version=\"1.0\" encoding=\"utf-8\"?><realty-feed xmlns=\"http://webmaster.yandex.ru/schemas/feed/realty/2010-06\">";
    public static final String XML_STOP_TAG = "</realty-feed>";
    public static final String OBJECT_TAG_START = "<offer ";
    public static final String TAG_STOP = "</offer>";
}
