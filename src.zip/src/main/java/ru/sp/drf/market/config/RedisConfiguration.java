package ru.sp.drf.market.config;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.domrf.rem.utilities.logs.CustomLogger;

import java.io.IOException;

@Configuration
public class RedisConfiguration {
    private static final CustomLogger LOG = CustomLogger.getLogger();

    private static String hostName;


    private static String port;


    private static String keyPrefix;

    private static String configFileName;

    public static String getKeyPrefix() {
        return keyPrefix;
    }

    public static String getHostName() {
        return hostName;
    }

    public static String getPort() {
        return port;
    }

    public static String getConfigFileName() { return configFileName; }

    @Value(value = "${spring.redis.host}")
    public void setHostName(String hostName) {
        RedisConfiguration.hostName = hostName;
    }

    @Value(value = "${spring.redis.port}")
    public  void setPort(String port) {
        RedisConfiguration.port = port;
    }

    @Value(value = "${spring.redis.key-env-prefix}")
    public void setKeyPrefix(String keyPrefix) {
        RedisConfiguration.keyPrefix = keyPrefix;
    }

    @Value(value = "${appsettings.redisson.config}")
    public void setConfigFileName(String configFileName) { RedisConfiguration.configFileName = configFileName; }

    @Bean
    public RedissonClient redisson() {
        Config config = null;
        try {
            config = Config.fromYAML(this.getClass().getClassLoader().getResourceAsStream("redisson/"+ getConfigFileName()));
            RedissonClient client = Redisson.create(config);
            return client;
        } catch (IOException e) {
            LOG.error("Unexpected exception", e);
            return Redisson.create();
        }
    }
}

