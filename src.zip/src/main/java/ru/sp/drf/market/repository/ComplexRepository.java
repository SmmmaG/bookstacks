package ru.sp.drf.market.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.domrf.rem.domain.Complex;
import ru.sp.drf.market.model.elastic.ComplexData;

import javax.persistence.Tuple;
import java.util.List;
import java.util.UUID;

@Repository
public interface ComplexRepository extends JpaRepository<Complex, UUID>{

    @Query("SELECT c FROM Complex c WHERE c.actual = true AND c.id in " +
            "(SELECT cr.complex.id FROM CrossIdentityComplex cr WHERE cr.feed.id=:feedId )")
    List<Complex> findAllByFeedId(@Param("feedId") UUID id);

    @Query("select new ru.sp.drf.market.model.elastic.ComplexData " +
            "(c.id , c.name , location.addressFull , city.id, city.name , city.fiasCode , region.id, region.name, region.fiasCode, c.location.point.latitude, c.location.point.longitude) " +
            "from Complex c JOIN c.location location JOIN location.city city JOIN location.region region where c.actual=true AND c.location IS NOT NULL")
    List<ComplexData> findAllActive();

    @Query("SELECT c.id, c.name, location.id, city.name, city.prefixType, region.name FROM Complex c JOIN c.location location JOIN location.city city JOIN location.region region " +
            "WHERE c.actual = true AND ( location.point.latitude IS NULL OR location.point.longitude IS NULL)")
    List<Tuple> findAllWithoutCoordinates();

}