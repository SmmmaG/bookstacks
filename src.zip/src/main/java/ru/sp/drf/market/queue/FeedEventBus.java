package ru.sp.drf.market.queue;

public enum FeedEventBus {
    postLoadFeedEvent("rem-feed-service:post-load-feed:process-event:topic");

    private String code;

    FeedEventBus(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
