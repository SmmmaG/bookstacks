package ru.sp.drf.market.exchange.nmarket;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.Generated;
import java.util.List;

@Generated("com.robohorse.robopojogenerator")
public class SearchComplexesResponse implements Response {

    @JsonProperty("statistics")
    private ru.sp.drf.market.exchange.nmarket.Statistics statistics;

    @JsonProperty("complexes")
    private List<ComplexesItem> complexes;

    public void setStatistics(ru.sp.drf.market.exchange.nmarket.Statistics statistics) {
        this.statistics = statistics;
    }

    @Override
    public Statistics getStatistics() {
        return statistics;
    }

    public void setComplexes(List<ComplexesItem> complexes) {
        this.complexes = complexes;
    }

    public List<ComplexesItem> getComplexes() {
        return complexes;
    }

    @Override
    public String toString() {
        return
                "SearchComplexesResponse{" +
                        "statistics = '" + statistics + '\'' +
                        ",complexes = '" + complexes + '\'' +
                        "}";
    }

    public void storeComplexe(){

    }
}