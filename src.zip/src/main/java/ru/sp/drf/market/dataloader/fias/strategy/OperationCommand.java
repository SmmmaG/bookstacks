package ru.sp.drf.market.dataloader.fias.strategy;

import ru.domrf.rem.domain.admin.FeedLog;
import ru.sp.drf.market.dataloader.elastic.AddressSliceLoader;
import ru.sp.drf.market.dataloader.elastic.BasicSlicer;
import ru.sp.drf.market.model.fias.DataRow;

import java.util.List;

public abstract class OperationCommand {

    protected BasicSlicer sliceLoader = new AddressSliceLoader();

    public abstract void execute(List<DataRow> datas, FeedLog feedLog);

}
