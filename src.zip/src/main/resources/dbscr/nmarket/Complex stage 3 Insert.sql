INSERT INTO complex
(id,name,is_done,end_year,end_quarter,actual,create_date,version,developer_id,address_id)
SELECT
(SELECT complex_id FROM tmp_complex_cross WHERE nmarket_complex=nmc.id) as id,
--nmc.uuid as id,
nmc.complexname as name,
nmc.isdone is_done,
nmc.yearend end_year,
nmc.quarterend end_quarter,
true actual,
now() create_date,
0 as version,
(SELECT d.id FROM developer d WHERE lower(d.full_name)=(SELECT lower(h.developername) FROM nmarket.nmarket_house h WHERE h.complexid=nmc.id LIMIT 1) LIMIT 1) developer_id,
(SELECT a.id FROM address A INNER JOIN
        (SELECT nh.address as address_full,
                (SELECT hh1.latitude FROM (SELECT latitude,longitude FROM nmarket.nmarket_house hh WHERE hh.address=nh.address ORDER BY hh.latitude LIMIT 1)hh1) as latitude,
                (SELECT hh2.longitude FROM (SELECT  latitude,longitude FROM nmarket.nmarket_house hh WHERE hh.address=nh.address ORDER BY hh.latitude LIMIT 1)hh2) as longitude
                 FROM nmarket.nmarket_house nh WHERE nh.complexid = nmc.id LIMIT 1) fa
         ON fa.address_full=a.address_full AND fa.latitude = a.latitude AND fa.longitude = a.longitude
         WHERE a.type=1  LIMIT 1) address_id
FROM nmarket.nmarket_complex nmc
WHERE NOT EXISTS
        ( SELECT object_id FROM cross_identity_complex WHERE code=nmc.id AND feed_id='?');
