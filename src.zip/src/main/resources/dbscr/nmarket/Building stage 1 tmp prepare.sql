--DROP TABLE tmp_build_cross;

CREATE TEMP TABLE tmp_build_cross (
build_id uuid,
nmarket_build varchar(20));

INSERT
INTO
    tmp_build_cross
    (
        build_id,
        nmarket_build
    )
SELECT
    uuid_generate_v4() build_id,
    nmap.houseid nmarket_build
FROM  nmarket.nmarket_house nmap;
