UPDATE complex_statistic ns
SET 
    actual=true,
    update_date=now(),
    count_object=TT.apartmentstotalcount,
    count_active_object=TT.apartmentstotalcount,
    min_price=TT.minprice,    
    version=TT.version+1
FROM (
        SELECT
            nmc.apartmentstotalcount,
            nmc.activeflatscount,
            nmc.minprice,
            cic.object_id,
            os.version
        FROM cross_identity_complex cic
            INNER JOIN nmarket.nmarket_complex nmc on nmc.id = cic.code
            INNER JOIN complex_statistic os ON os.complex_id = cic.object_id
        WHERE feed_id='?') TT
WHERE
    TT.object_id=ns.complex_id;
