UPDATE material_wall_type nwt
SET
        actual=true,
        update_date=now(),
        version=TT.version+1
FROM
(
SELECT
       wm.name,
       mwt.version
FROM
(SELECT DISTINCT housetype as name FROM nmarket.nmarket_house ) wm
INNER JOIN material_wall_type mwt ON mwt.name = wm.name)TT
WHERE TT.name=nwt.name;
