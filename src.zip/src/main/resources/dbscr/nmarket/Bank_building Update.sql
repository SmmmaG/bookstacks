UPDATE
    bank_building nb
SET
    actual=true,
    update_date=now(),
    version=TT.version+1
FROM
    (
        SELECT
            b.id bankid,
            cib.object_id,
            ob.version
        FROM
            nmarket.nmarket_approvedcreditproducts apc
        INNER JOIN bank b ON b.short_name = apc.title
        INNER JOIN cross_identity_building cib ON cib.code=apc.houseid
        INNER JOIN bank_building ob ON ob.building_id=cib.object_id AND ob.bank_id=b.id
        WHERE
            cib.feed_id='?') TT
WHERE
    TT.bankid=nb.bank_id
AND TT.object_id = nb.building_id;
