INSERT INTO bank
    (
        short_name,
        id,
        actual,
        create_date,
        version
    )

SELECT
        b.title,
        uuid_generate_v4(),
        true,
        now() create_date,
        0
FROM
    (SELECT DISTINCT title
    FROM nmarket.nmarket_approvedcreditproducts) b

WHERE
    NOT EXISTS
    ( SELECT * FROM bank WHERE short_name = b.title )