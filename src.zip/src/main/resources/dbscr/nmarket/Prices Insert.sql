INSERT INTO price
    (
        id,
        actual,
        create_date,
        version,
        amount,
        base_amount,
        min_amount,
--        flat_id,
        amount_update_date,
        currency_type_id
    )
SELECT
    (SELECT price_id FROM tmp_flat_cross WHERE nmarket_flat=nmap.id ) id,
    true,
    now() create_date,
    0,
    CASE WHEN nmap.amountunit LIKE '%м.кв%'  THEN (SELECT CAST(nmap.minimalAmount*nmap.sall AS DECIMAL(10,0))) ELSE nmap.minimalAmount END minamount,
    CASE WHEN nmap.amountunit  LIKE '%м.кв%' THEN (SELECT CAST(nmap.baseAmount*nmap.sall    AS DECIMAL(10,0))) ELSE nmap.baseAmount  END baseAmount,
    CASE WHEN nmap.amountunit LIKE '%м.кв%'  THEN (SELECT CAST(nmap.minimalAmount*nmap.sall AS DECIMAL(10,0))) ELSE nmap.minimalAmount END amount,
--    (SELECT object_id FROM cross_identity_flat cif WHERE code=nmap.id AND feed_id='?') flatid,
    nmap.datepriceupdate amount_update_date,
    (SELECT id FROM currency_type WHERE name=LOWER (split_part(nmap.amountunit,'.',1)))currency_type_id

FROM
    nmarket.nmarket_appartments nmap