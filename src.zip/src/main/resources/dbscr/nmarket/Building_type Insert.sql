INSERT INTO building_type (id,name,actual,version,create_date)
SELECT
        uuid_generate_v4(),
        T.houseclass,
        true,
        0,
        now()
FROM
        (SELECT DISTINCT
        (SELECT CASE WHEN nmarket.nmarket_house.houseclass IS NULL THEN 'Нет данных' ELSE nmarket.nmarket_house.houseclass END) houseclass
        FROM nmarket.nmarket_house) T
WHERE NOT EXISTS (
        SELECT * FROM building_type WHERE name = T.houseclass
);