UPDATE flat f SET
        price_id = TT.price_id
FROM(
  SELECT
    cif.object_id flat_id,
    tmp.price_id price_id
FROM
    nmarket.nmarket_appartments nmap
    INNER JOIN tmp_flat_cross tmp ON tmp.nmarket_flat=nmap.id
    INNER JOIN cross_identity_flat cif ON cif.code=nmap.id
    WHERE cif.feed_id='?') TT
WHERE TT.flat_id=f.id;