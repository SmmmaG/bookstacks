UPDATE flat of
SET nmarket_code=(SELECT internal_id
                  FROM yandex.flats f
                           JOIN yandex.buildings b ON b.building_custom_id = f.building_custom_id
                  WHERE --main match rules
                      f.floorr = of.floor
                    AND f.rooms = of.room_count
                    AND f.area_value = of.total_area
                  LIMIT 1)
WHERE id IN (SELECT f.id
             FROM flat f
                      JOIN complex c ON c.id = f.complex_id
                      JOIN address a on c.address_id = a.id
                      JOIN region r on a.region_id = r.id
             WHERE f.actual = true
               AND lower(c.name) IN (SELECT DISTINCT lower(building_name) FROM yandex.buildings)
               AND lower(r.name) IN (SELECT DISTINCT lower(location_region) FROM yandex.buildings));
