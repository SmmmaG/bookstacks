UPDATE currency_type nc
SET actual=true,
    update_date=now(),
    version=TT.ver+1
FROM
(SELECT
    uuid_generate_v4() id,
    T.amountunit as name,
    now() create_date,
    0 as version,
    'code' code,
    0 statistic,
    oct.id,
    oct.version as ver
FROM
    (
        SELECT DISTINCT
            LOWER (split_part(amountunit,'.',1)) amountunit
         FROM
            nmarket.nmarket_appartments
         WHERE
            amountunit NOT LIKE '%м.кв%') T
INNER JOIN currency_type oct ON oct.name=T.amountunit) TT
WHERE TT.name=nc.name;