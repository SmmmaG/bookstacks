INSERT INTO material_wall_type (
        id,
        name,
        actual,
        create_date,
        version
)
SELECT uuid_generate_v4(),
       name,
       true,
       now(),
       0
FROM
(SELECT DISTINCT housetype as name FROM nmarket.nmarket_house ) wm
 WHERE NOT EXISTS
        (SELECT id FROM material_wall_type mwt WHERE mwt.name = wm.name);