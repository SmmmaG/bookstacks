INSERT INTO bank_building
    (
        bank_id,
        building_id,
        create_date,
        version,
        actual
    )
SELECT
    b.id          bankid,
    cib.object_id buildingid,
    now()         create_date,
    0,
    true
FROM
    nmarket.nmarket_approvedcreditproducts apc
INNER JOIN bank b ON b.short_name = apc.title
INNER JOIN cross_identity_building cib ON cib.code=apc.houseid
WHERE
    cib.feed_id='?'
AND NOT EXISTS
    (
        SELECT * FROM bank_building bb
        WHERE bb.building_id = cib.object_id
        AND bb.bank_id = b.id);