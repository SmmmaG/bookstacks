UPDATE parking_type
SET
    actual=true,
    update_date=now(),
    version=TT.version+1
FROM 
(
        SELECT DISTINCT
            nmarket.nmarket_house.parkingname,
            bt.version "version"
         FROM
            nmarket.nmarket_house 
         INNER JOIN parking_type bt ON bt.name=nmarket.nmarket_house.parkingname ) TT
WHERE TT.parkingname=name;
