
UPDATE infrastructure ni SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        has_parking=TT.has_parking
FROM
        (
        SELECT
            oi.id,
            oi.version,
            tnmp.has_parking has_parking
        FROM
            (SELECT
                tmp.infrastructure_id id,
                tmp.complex_uuid tmpComplexId,
                (SELECT DISTINCT has_parking FROM infrastructure i JOIN building b ON b.infrastructure_id = i.id AND b.complex_id=c.id AND has_parking IS NOT NULL ORDER BY has_parking desc LIMIT 1) has_parking
            FROM tmp_complex_infrastructure tmp
            INNER JOIN complex c ON c.id=tmp.complex_uuid) tnmp
        INNER JOIN infrastructure oi ON oi.id=(SELECT c.infrastructure_id FROM complex c WHERE c.id=tnmp.tmpComplexId)
        ) TT
WHERE ni.id=TT.id;