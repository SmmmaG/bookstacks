INSERT INTO city (id, name,name_prepositional,prefix_type,region_id,actual,version,create_date)
SELECT
        uuid_generate_v4() id,
        t.city as name,
        t.city as name_prepositional,
        t.prefix_type as prefix_type,
        t.region_id region_id,
        true actual,
        0 as version,
        now() create_date
FROM
        (SELECT
                nmarket_house.city city,
                nmarket_house.prefix_type prefix_type, 
                (SELECT r.id FROM region r WHERE LOWER(r.name) like LOWER(nmarket_house.region)||'%') region_id
        FROM
                (SELECT DISTINCT
                rem_split_city_name_nmarket(address) city,
                rem_split_city_prefix_nmarket(address) prefix_type,
                region
                FROM nmarket.nmarket_house
                WHERE rem_split_has_city_nmarket(address) = true)  nmarket_house) t
WHERE NOT EXISTS
(SELECT 1 FROM city WHERE LOWER(name) like LOWER(t.city) AND prefix_type=t.prefix_type AND region_id=t.region_id );