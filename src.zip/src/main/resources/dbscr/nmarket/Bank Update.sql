
UPDATE bank
SET
    actual=true,
    update_date=now(),
    version=TT.version+1
FROM
    (
        SELECT DISTINCT
            nmarket.nmarket_approvedcreditproducts.title,
            bt.version "version"
        FROM
            nmarket.nmarket_approvedcreditproducts
        INNER JOIN
            bank bt
        ON
            bt.short_name=nmarket.nmarket_approvedcreditproducts.title ) TT
WHERE
    TT.title=short_name;