INSERT INTO complex_document_photo(
        complex_id,
        document_photo_id
)
SELECT
    complex_id,
    document_photo_id
FROM
 tmp_complex_document_photo tmp
WHERE complex_id is not null;
