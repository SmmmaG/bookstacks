
UPDATE complex c SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        name=TT.name,
        is_done=TT.is_done,
        end_year=TT.end_year,
        end_quarter=TT.end_quarter,
        developer_id=TT.developer_id,
        address_id=TT.address_id
FROM (
SELECT
        oc.id,
        oc.version,
        nmc.complexname as name,
        nmc.isdone is_done,
        nmc.yearend end_year,
        nmc.quarterend end_quarter,
--        nmc.id,
        (SELECT d.id FROM developer d WHERE lower(d.full_name)=(SELECT lower(h.developername) FROM nmarket.nmarket_house h WHERE h.complexid=nmc.id LIMIT 1)LIMIT 1) developer_id,
        (SELECT a.id FROM address A INNER JOIN
                (SELECT nh.address as address_full,
                        (SELECT hh1.latitude FROM (SELECT latitude,longitude FROM nmarket.nmarket_house hh WHERE hh.address=nh.address ORDER BY hh.latitude LIMIT 1)hh1) as latitude,
                        (SELECT hh2.longitude FROM (SELECT  latitude,longitude FROM nmarket.nmarket_house hh WHERE hh.address=nh.address ORDER BY hh.latitude LIMIT 1)hh2) as longitude
                         FROM nmarket.nmarket_house nh WHERE nh.complexid = nmc.id LIMIT 1) fa
                 ON fa.address_full=a.address_full AND fa.latitude = a.latitude AND fa.longitude = a.longitude
                 WHERE a.type=1  LIMIT 1) address_id
        FROM nmarket.nmarket_complex nmc
        INNER JOIN complex oc ON oc.id = ( SELECT object_id FROM cross_identity_complex WHERE code=nmc.id AND feed_id='?') )TT
WHERE TT.id=c.id;