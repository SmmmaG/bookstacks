INSERT INTO infrastructure(
        id,
        actual,
        create_date,
        version,
        has_parking
)
SELECT
    tnmp.infrastructure_id id,
    true actual,
    now() create_date,
    0 as version,
    (CASE WHEN tnmp.has_parking IS NULL THEN NULL WHEN LOWER(tnmp.has_parking) LIKE '%отсутству%' OR LOWER(tnmp.has_parking) LIKE '%нет%' THEN false ELSE true END) has_parking
FROM
 (SELECT
        npb.parkingname has_parking,
        tmp.infrastructure_id,
        tmp.building_uuid
  FROM tmp_building_infrastructure tmp
  INNER JOIN nmarket.nmarket_house npb
        ON npb.houseid=tmp.nmarket_house) tnmp
WHERE NOT EXISTS
        (SELECT 1 FROM tmp_building_infrastructure tmp INNER JOIN building b ON b.id = tmp.building_uuid INNER JOIN infrastructure inf ON b.infrastructure_id = inf.id WHERE b.id =tnmp.building_uuid ) ;