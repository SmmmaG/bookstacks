--DROP TABLE tmp_flat_cross;

CREATE TEMP TABLE tmp_flat_cross (
flat_id uuid,
nmarket_flat varchar(20),
price_id uuid);

INSERT
INTO
    tmp_flat_cross
    (
        flat_id,
        nmarket_flat,
        price_id
    )
SELECT
    uuid_generate_v4() flat_id,
    nmap.id nmarket_flat,
    uuid_generate_v4() price_id
FROM  nmarket.nmarket_appartments nmap;
