UPDATE discount d SET
actual=true,
update_date=now(),
version=TT.version+1
FROM (
  SELECT
  t.id,
  t.version
  FROM (
    SELECT DISTINCT
    od.id,
    od.version,
    nd.name,
    nd.description,
    nd.datebegin,
    nd.dateend
    FROM
    nmarket.nmarket_discounts nd
      INNER JOIN discount od ON od.end_date=nd.dateend
      AND od.start_date=nd.datebegin
      AND od.descript=nd.description
      AND od.name=nd.name) t)TT
WHERE TT.id=d.id