INSERT INTO document_advantage as olda (
        id,
        actual,
        create_date,
        version,
        content,
        hash_code)
(SELECT
        uuid_generate_v4() as id,
        true actual,
        now() create_date,
        0 as version,
        a.advantages as content,
        md5(a.advantages) hash_code
FROM
    (SELECT DISTINCT advantages FROM nmarket.nmarket_house WHERE advantages IS NOT NULL OR length(advantages)>0 ) a)
ON CONFLICT (hash_code) DO UPDATE SET
        actual=true,
        update_date=now(),
        version=olda.version+1;