INSERT into discount (type,id,name,descript,start_date,end_date,create_date,version,actual)
  SELECT
  1,
  uuid_generate_v4() id,
  TT.name as name,
  TT.description descript,
  TT.datebegin start_date,
  TT.dateend end_date,
  now() create_date,
  0 as version,
  true
  FROM
  (
    SELECT DISTINCT
    name,description,datebegin,dateend
    FROM
    nmarket.nmarket_discounts) TT
  WHERE NOT EXISTS (
    SELECT * FROM discount od WHERE od.name = TT.name AND od.descript = TT.description AND od.start_date = TT.datebegin AND od.end_date = TT.dateend
  );