UPDATE complex c SET infrastructure_id=i.infrastructure_id
FROM (SELECT tmp.infrastructure_id, tmp.complex_uuid FROM tmp_complex_infrastructure tmp) i
WHERE i.complex_uuid=c.id AND c.infrastructure_id IS NULL;