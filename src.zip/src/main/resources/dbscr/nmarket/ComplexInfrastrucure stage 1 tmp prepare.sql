CREATE TEMP TABLE tmp_complex_infrastructure (
infrastructure_id uuid,
complex_uuid uuid );

INSERT
INTO
    tmp_complex_infrastructure
    (
        infrastructure_id,
        complex_uuid
    )
SELECT
    uuid_generate_v4() infrastructure_id,
    (SELECT object_id complex_uuid FROM cross_identity_complex cib WHERE code=nmc.id
            AND feed_id='?')
FROM  nmarket.nmarket_complex nmc;

--Дизактуализация старых инфраструктур комплексов
UPDATE  infrastructure SET actual=false WHERE id IN (SELECT infrastructure_id FROM complex c WHERE c.id IN (SELECT complex_uuid FROM tmp_complex_infrastructure) ) AND actual=true;