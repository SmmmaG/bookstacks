INSERT INTO infrastructure(
        id,
        actual,
        create_date,
        version,
        has_parking
)
SELECT
    tnmp.id id,
    true actual,
    now() create_date,
    0 as version,
    tnmp.has_parking has_parking
FROM
    (SELECT
         tmp.infrastructure_id id,
         (SELECT DISTINCT has_parking FROM infrastructure i INNER JOIN building b ON b.infrastructure_id = i.id AND b.complex_id=c.id AND has_parking IS NOT NULL ORDER BY has_parking desc LIMIT 1) has_parking
    FROM tmp_complex_infrastructure tmp
    INNER JOIN complex c ON c.id=tmp.complex_uuid
    WHERE c.infrastructure_id IS NULL) tnmp;