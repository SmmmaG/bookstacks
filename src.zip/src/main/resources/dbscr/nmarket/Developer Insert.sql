  INSERT INTO developer (id,actual,create_date,full_name)
  SELECT
        uuid_generate_v4(),
        true,
        now(),
        developername
  FROM (SELECT DISTINCT developername FROM nmarket.nmarket_house) tt
  WHERE NOT EXISTS
        (SELECT id FROM developer WHERE lower(full_name) = lower(tt.developername));