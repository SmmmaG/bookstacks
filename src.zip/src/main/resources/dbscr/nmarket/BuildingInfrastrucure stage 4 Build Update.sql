UPDATE
    building b
SET
    infrastructure_id=
    (
        SELECT
            infrastructure_id
        FROM
            tmp_building_infrastructure pfdp
        WHERE
            pfdp.building_uuid = b.id
        AND EXISTS
            (
                SELECT
                    1
                FROM
                    infrastructure
                WHERE
                    id=pfdp.infrastructure_id))
WHERE
    b.infrastructure_id IS NULL
AND b.id IN
    (
        SELECT
            building_uuid
        FROM
            tmp_building_infrastructure);