CREATE TEMP TABLE tmp_building_infrastructure (
infrastructure_id uuid,
nmarket_house varchar(20),
building_uuid uuid );

INSERT
INTO
    tmp_building_infrastructure
    (
        infrastructure_id,
        nmarket_house,
        building_uuid
    )
SELECT
    uuid_generate_v4() infrastructure_id,
    nmh.houseid nmarket_house,
    (SELECT object_id building_uuid FROM cross_identity_building cib WHERE code=nmh.houseid
            AND feed_id='?')
FROM  nmarket.nmarket_house nmh;

--Дизактуализация старых инфраструктур зданий
UPDATE  infrastructure SET actual=false WHERE id IN (SELECT infrastructure_id FROM building b WHERE b.id IN (SELECT building_uuid FROM tmp_building_infrastructure) ) AND actual=true;