DELETE FROM discount_building WHERE discount_building.building_id in
(SELECT (SELECT object_id FROM cross_identity_building cib WHERE cib.code = h.houseid AND cib.feed_id='?') as building_id
 FROM nmarket.nmarket_house h);