CREATE TEMP TABLE plan_flat_document_photo (
document_photo_id uuid,
nmarket_flat varchar(20),
flatuuid uuid );

INSERT
INTO
    plan_flat_document_photo
    (
        document_photo_id,
        nmarket_flat,
        flatuuid
    )
SELECT
    uuid_generate_v4() document_photo_id,
    nmap.id nmarket_flat,
    (SELECT object_id flatuuid FROM cross_identity_flat cif WHERE code=nmap.id
            AND feed_id='?')
FROM  nmarket.nmarket_appartments nmap;

--Дизактуализация старых фото квартир по текущей выборке квартир
UPDATE  document_photo SET actual=false WHERE id IN (SELECT plan_document_photo_id FROM flat f WHERE f.id IN (SELECT flatuuid FROM plan_flat_document_photo) ) AND actual=true;