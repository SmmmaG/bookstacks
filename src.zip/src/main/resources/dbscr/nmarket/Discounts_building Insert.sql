INSERT INTO discount_building (building_id, discount_id)
  SELECT   (SELECT object_id FROM cross_identity_building cib WHERE cib.code = nd.houseid AND cib.feed_id='?') as building_id,
           (SELECT id FROM discount d WHERE d.name = nd.name AND d.descript = nd.description AND d.start_date = nd.datebegin AND d.end_date = nd.dateend)
  FROM nmarket.nmarket_discounts nd