UPDATE balcony_type
SET
    actual=true,
    update_date=now(),
    version=TT.version+1
FROM 
(
        SELECT DISTINCT
            nmarket.nmarket_appartments.balcony,
            bt.version "version"
         FROM
            nmarket.nmarket_appartments 
         INNER JOIN balcony_type bt ON bt.name=nmarket.nmarket_appartments.balcony ) TT
WHERE TT.balcony=name;
