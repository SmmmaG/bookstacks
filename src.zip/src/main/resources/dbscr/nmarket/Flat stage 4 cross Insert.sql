INSERT INTO cross_identity_flat(id,actual,create_date,version,code,object_id,feed_id)
  SELECT
      uuid_generate_v4(),
      true,
      now() create_date,
      0,
      nf.id,
      f.id,
      '?' sourceid
   FROM nmarket.nmarket_appartments nf
   INNER JOIN flat f ON f.id=(SELECT flat_id FROM tmp_flat_cross WHERE nmarket_flat=nf.id )
   WHERE NOT EXISTS
          ( SELECT * FROM cross_identity_flat WHERE code=nf.id AND feed_id='?');