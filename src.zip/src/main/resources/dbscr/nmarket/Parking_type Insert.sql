INSERT into parking_type (id,name,create_date,version)
SELECT 
    uuid_generate_v4(),
    TT.parkingname,
    now() create_date,
    0
FROM
    (
        SELECT DISTINCT
            parkingname
         FROM
            nmarket.nmarket_house) TT
WHERE NOT EXISTS (
        SELECT * FROM parking_type WHERE name = parkingname
);