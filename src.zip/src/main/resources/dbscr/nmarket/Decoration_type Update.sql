UPDATE decoration_type 
SET actual=true, 
    update_date=now(),
    version=TT.version+1
FROM 
(
        SELECT DISTINCT
            (SELECT CASE WHEN nmarket.nmarket_appartments.decoration IS NULL THEN 'Нет данных' ELSE nmarket.nmarket_appartments.decoration END) decoration,
            dt.version "version"
         FROM
            nmarket.nmarket_appartments 
         INNER JOIN decoration_type dt ON dt.name=(SELECT CASE WHEN nmarket.nmarket_appartments.decoration IS NULL THEN 'Нет данных' ELSE nmarket.nmarket_appartments.decoration END)  ) TT
WHERE TT.decoration=name;