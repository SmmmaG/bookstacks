INSERT INTO complex_statistic
    (
        id,
        actual,
        create_date,
        version,
        count_object,
        count_active_object,
        min_price,
        complex_id
    )
SELECT
    uuid_generate_v4(),
    true,
    now() create_date,
    0,
    nmc.apartmentstotalcount,
    nmc.activeflatscount,
    nmc.minprice,
    cic.object_id
FROM cross_identity_complex cic
    INNER JOIN nmarket.nmarket_complex nmc on nmc.id = cic.code
WHERE feed_id='?'
AND NOT EXISTS
    (
        SELECT * FROM complex_statistic bb
        WHERE bb.complex_id = cic.object_id);