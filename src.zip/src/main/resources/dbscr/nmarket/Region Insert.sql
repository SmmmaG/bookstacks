INSERT INTO region (id, name, name_prepositional, country_id,create_date,actual,version)
SELECT
        uuid_generate_v4(),
        t.region,
        t.region,
        (SELECT r.id FROM country r WHERE r.code='ru'),
        now(),
        true,
        0
FROM (SELECT DISTINCT nh.region FROM nmarket.nmarket_house nh) t
WHERE NOT EXISTS
        (SELECT 1 FROM region WHERE name LIKE t.region);