UPDATE building_statistic ns
SET
    actual=true,
    update_date=now(),
    area_max_amount=TT.sallmax,
    area_min_amount=TT.sallmin,
    count_active_object=TT.countactive,
    price_max_amount=TT.totalpricemax,
    price_min_amount=TT.totalpricemin,
    building_id=TT.buildid,
    count_room_type=TT.count_room_type,
    version=TT.version+1
FROM (
          SELECT
                stat.sallmax,
                stat.sallmin,
                stat.countactive,
                stat.totalpricemax,
                stat.totalpricemin,
                (SELECT object_id FROM cross_identity_building WHERE code=stat.housesid AND feed_id='?') buildid,
                (SELECT CASE WHEN stat.flatcode LIKE 'studia' THEN 0
                             WHEN stat.flatcode LIKE 'oneroom' THEN 1
                             WHEN stat.flatcode LIKE 'two' THEN 2
                             WHEN stat.flatcode LIKE 'three' THEN 3
                             WHEN stat.flatcode LIKE 'four' THEN 4
                             WHEN stat.flatcode LIKE 'fourmore' THEN 4 END) count_room_type,
                os.version

        FROM
                nmarket.nmarket_statistic stat
                INNER JOIN building_statistic os ON os.building_id =
                (SELECT object_id FROM cross_identity_building WHERE code=stat.housesid AND feed_id='?')
                AND os.count_room_type=(SELECT CASE WHEN stat.flatcode LIKE 'studia' THEN 0
                                                 WHEN stat.flatcode LIKE 'oneroom' THEN 1
                                                 WHEN stat.flatcode LIKE 'two' THEN 2
                                                 WHEN stat.flatcode LIKE 'three' THEN 3
                                                 WHEN stat.flatcode LIKE 'four' THEN 4
                                                 WHEN stat.flatcode LIKE 'fourmore' THEN 4 END)
        WHERE stat.housesid IS NOT NULL) TT
WHERE
    TT.count_room_type=ns.count_room_type
AND TT.buildid = ns.building_id;