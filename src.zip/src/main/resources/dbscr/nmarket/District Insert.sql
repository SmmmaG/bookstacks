INSERT INTO district (id, name,city_id,region_id,actual,version,create_date)
SELECT
        uuid_generate_v4() id,
        t.district as name,
        t.city_id city_id,
        t.region_id region_id,
        true actual,
        0 as version,
        now() create_date
FROM
        (SELECT DISTINCT
                REPLACE (nmarket_house.district, 'р-н', 'район') district,
                nmarket_house.city_id city_id,
                nmarket_house.region_id region_id
        FROM
                (
                SELECT
                district,
                region_id,
                (CASE WHEN rem_split_has_city_nmarket(h1.address)
                      THEN (
                        (SELECT id FROM city WHERE region_id=h1.region_id AND name=rem_split_city_name_nmarket(h1.address) AND prefix_type=rem_split_city_prefix_nmarket(h1.address))
                      )
                      ELSE (
                        SELECT id FROM city WHERE name = (SELECT city FROM region_city WHERE region=h1.region) AND prefix_type like 'г.') END
                        ) city_id
                FROM (
                        SELECT DISTINCT
                        (SELECT r.id FROM region r WHERE LOWER(r.name) like LOWER(ho.region)||'%') region_id,
                         ho.region region,
                         ho.district,
                         ho.address FROM nmarket.nmarket_house ho
                ) h1
                )  nmarket_house
        ) t
WHERE NOT EXISTS
(SELECT 1 FROM district WHERE LOWER(name) like  split_part(LOWER(t.district),' р-н',1)||'%'
AND city_id=t.city_id
AND region_id=t.region_id );
