INSERT into decoration_type (id,name,create_date,version,has_decoration)
SELECT
    uuid_generate_v4() id,
    TT.decoration as name,
    now() create_date,
    0 as version,
    (CASE WHEN TT.decoration LIKE 'Нет данных' THEN null WHEN (LOWER(TT.decoration) LIKE '%истовая%') OR (LOWER(TT.decoration) LIKE '%ключ%') THEN true ELSE false END ) has_decoration
FROM
    (
        SELECT DISTINCT
            (SELECT CASE WHEN nmarket.nmarket_appartments.decoration IS NULL THEN 'Нет данных' ELSE nmarket.nmarket_appartments.decoration END) decoration
         FROM
            nmarket.nmarket_appartments) TT
WHERE NOT EXISTS (
        SELECT * FROM decoration_type WHERE name = decoration
);