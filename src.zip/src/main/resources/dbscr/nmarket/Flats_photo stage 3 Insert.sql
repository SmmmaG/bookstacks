INSERT INTO document_photo(
        id,
        actual,
        create_date,
        descript,
        name,
        version,
        state,
        url
)
SELECT
    tnmp.document_photo_id id,
    true actual,
    now() create_date,
    'flat plan' descript,
    'flat plan' as name,
    0 as version,
    'NEW' state,
    tnmp.planurl url
FROM
 (SELECT
        npa.planurl,
        tmp.document_photo_id,
        tmp.flatuuid
  FROM plan_flat_document_photo tmp
  INNER JOIN nmarket.nmarket_appartments npa
        ON npa.id=tmp.nmarket_flat
  WHERE npa.planurl IS NOT NULL) tnmp
WHERE NOT EXISTS
        (SELECT 1 FROM plan_flat_document_photo tmp INNER JOIN flat f ON f.id = tmp.flatuuid INNER JOIN document_photo dp ON f.plan_document_photo_id = dp.id WHERE f.id =tnmp.flatuuid ) ;
