INSERT INTO document_photo(
        id,
        actual,
        create_date,
        descript,
        name,
        version,
        KEY,
        state,
        url,
        is_default
)
SELECT
    tnmp.document_photo_id id,
    true actual,
    now() create_date,
    tnmp.description descript,
    'photoname' as name,
    0 as version,
    '' as KEY,
    'NEW' state,
    tnmp.url url,
    ( SELECT CASE WHEN (SELECT COUNT(id) FROM nmarket.nmarket_phototags pt WHERE pt.photoid=tnmp.nmarket_photo_id AND LOWER(pt.title) LIKE 'main%' )>0 THEN true ELSE false END ) is_default
FROM
 (SELECT
        nmarket_photo_id,
        document_photo_id,
        np.description,
        np.url
  FROM tmp_complex_document_photo tmp
  INNER JOIN nmarket.nmarket_photos np
        ON np.id=tmp.nmarket_photo_id) tnmp;
