
CREATE TABLE ?schema?.nmarket_complex (
  uuid uuid NOT NULL,
  id varchar(50) NOT NULL,
  complexName varchar(300),
  isDone boolean,
  yearEnd numeric,
  quarterEnd numeric,
  minPrice numeric,
  activeFlatsCount numeric,
  apartmentsTotalCount numeric
--    CONSTRAINT temp_nmarket_complex_id_pk PRIMARY KEY (uuid)
);

CREATE TABLE ?schema?.nmarket_house (
    id uuid NOT NULL,
    houseId varchar(50) NOT NULL,
    complexuuid uuid,
    complexId varchar(50),
    lastChangeDate varchar(100),
    name varchar(300),
    developerName varchar(300),
    district varchar(300),
    transportNode varchar(100),
    fromTransportNode varchar(100),
    address varchar(300),
    floors varchar(100),
    yearEnd numeric,
    quarterEnd numeric(1),
stageNumber numeric(2),
buildingNumber varchar(300),
isDone boolean,
isProperty boolean,
contract varchar(300),
houseType varchar(300),
houseClass varchar(100),
ceilingHeight numeric,
parkingName varchar(100),
region varchar(300),
longitude double precision,
latitude double precision,
lift varchar(300),
appartmentsCount varchar(10),
description varchar(10485760),
advantages varchar(10485760)
--    CONSTRAINT temp_nmarket_houses_id_pk PRIMARY KEY (id),
--    CONSTRAINT temp_nmarket_house_fk1 FOREIGN KEY (complexuuid) REFERENCES ?schema?.nmarket_complex (uuid)
);

CREATE TABLE ?schema?.nmarket_appartments (
  uuid uuid NOT NULL,
  id varchar(50) NOT NULL,
  houseId varchar(50) NOT NULL,
  section varchar(10),
  floor varchar(3),
  type varchar(100),
  appNumber varchar(10),
  rooms varchar(5),
  sAll float,
  sLiving float,
  sKitchen float,
  sRooms varchar(50),
  status varchar(50),
  minimalAmount numeric,
  baseAmount numeric,
  amountUnit varchar(20),
  ceilingHeight float,
  sellerType varchar(20),
  datePriceUpdate TIMESTAMP(6) WITHOUT TIME ZONE,
  planUrl varchar(1000),
  wc varchar(200),
  balcony varchar(100),
  objectType numeric,
  widgetId varchar(100),
  decoration varchar(10485760)
--    CONSTRAINT temp_nmarket_appartments_id_pk PRIMARY KEY (uuid)
--    CONSTRAINT temp_nmarket_apps_fk1 FOREIGN KEY (houseId) REFERENCES ?schema?.nmarket_house (id)
);
CREATE TABLE ?schema?.nmarket_photos (
  id uuid NOT NULL,
  description varchar(100),
  url varchar(1000),
  complex_uuid uuid,
  complex_id varchar(50),
  objectTypeId numeric
--    CONSTRAINT temp_nmarket_photos_id_pk PRIMARY KEY (id),
--    CONSTRAINT temp_nmarket_photos_fk1 FOREIGN KEY (complex_uuid) REFERENCES ?schema?.nmarket_complex (uuid)
);
CREATE TABLE ?schema?.nmarket_discounts (
  id uuid NOT NULL,
  name varchar,
  description varchar(2000),
  dateBegin TIMESTAMP(6) WITHOUT TIME ZONE,
  dateEnd TIMESTAMP(6) WITHOUT TIME ZONE,
  houseuuid uuid,
  houseid varchar(50)
--    CONSTRAINT temp_nmarket_discounts_id_pk PRIMARY KEY (id),
--    CONSTRAINT temp_nmarket_discounts_fk1 FOREIGN KEY (houseuuid) REFERENCES ?schema?.nmarket_house (id)
);
CREATE TABLE ?schema?.nmarket_approvedCreditProducts (
  id uuid NOT NULL,
  title varchar(100),
  houseuuid uuid,
  houseid varchar(50)
--    CONSTRAINT temp_nmarket_approvedCreditProducts_id_pk PRIMARY KEY (id),
--    CONSTRAINT temp_nmarket_approvedCreditProducts_fk1 FOREIGN KEY (houseuuid) REFERENCES ?schema?.nmarket_house (id)
);
CREATE TABLE ?schema?.nmarket_statistic (
  id uuid NOT NULL,
  flatCode varchar(10),
  sAllMin float,
  sAllMax float,
  totalPriceMin numeric,
  totalPriceMax numeric,
  countActive numeric,
  housesId varchar(50),
  complexId varchar(50)
--    CONSTRAINT temp_nmarket_statistic_id_pk PRIMARY KEY (id)
);
CREATE TABLE ?schema?.nmarket_phototags (
  id uuid NOT NULL,
  title varchar(100),
  photoid uuid NOT NULL
--    CONSTRAINT temp_nmarket_phototags_id_pk PRIMARY KEY (id),
--    CONSTRAINT temp_nmarket_phototags_fk1 FOREIGN KEY (photoid) REFERENCES ?schema?.nmarket_photos (id)
);
