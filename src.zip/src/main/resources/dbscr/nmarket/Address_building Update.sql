UPDATE address a SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        city_id=TT.city_id,
        country_id=TT.country_id,
        district_id=TT.district_id,
        region_id=TT.region_id
FROM  (
SELECT
        t.id,
        t.version,
        city_id,
        country_id ,
        district_id ,
        region_id
 FROM (
        select DISTINCT
         nh.address as address_full ,
         nh.latitude,
         nh.longitude ,
         oa.version,
         oa.id,
        nh.city_id as city_id,
        nh.region_id region_id,
        (SELECT r.id FROM country r WHERE r.code='ru') as country_id,
        (SELECT r.id FROM district r WHERE (r.name=REPLACE (nh.district, 'р-н', 'район') OR r.name=nh.district||' район') AND r.region_id=nh.region_id AND r.city_id=nh.city_id) as district_id
        FROM (SELECT *,(CASE WHEN rem_split_has_city_nmarket(h1.address)
                              THEN (
                                (SELECT id FROM city WHERE region_id=h1.region_id AND name=rem_split_city_name_nmarket(h1.address) AND prefix_type=rem_split_city_prefix_nmarket(h1.address))
                              )
                              ELSE (
                                SELECT id FROM city WHERE name = (SELECT city FROM region_city WHERE region=h1.region)) END
                                ) city_id
                        FROM (SELECT *,(SELECT r.id FROM region r WHERE r.name=region) as region_id FROM nmarket.nmarket_house) h1 ) nh
        INNER JOIN address oa ON oa.address_full=nh.address AND oa.latitude=nh.latitude AND oa.longitude=nh.longitude AND oa.type=2
        )t
    )TT
WHERE TT.id=a.id;