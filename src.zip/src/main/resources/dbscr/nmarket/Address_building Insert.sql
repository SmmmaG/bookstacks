INSERT INTO address(
        id,
        type,
        actual,
        create_date ,
        version,
        address_full ,
        latitude,
        longitude,
        city_id,
        country_id ,
        district_id ,
        region_id
        )
SELECT
        uuid_generate_v4() as id,
        type,
        actual,
        create_date ,
        version,
        address_full ,
        latitude,
        longitude,
        city_id,
        country_id ,
        district_id ,
        region_id
 FROM (
        select DISTINCT 2 as type,
         true as actual ,
         now() create_date,
         0 as version,
         nh.address as address_full ,
         latitude,
         longitude ,
         nh.city_id as city_id,
         nh.region_id region_id,
        (SELECT r.id FROM country r WHERE r.code='ru') as country_id,
        (SELECT r.id FROM district r WHERE (r.name=REPLACE (nh.district, 'р-н', 'район') OR r.name=nh.district||' район') AND r.region_id=nh.region_id AND r.city_id=nh.city_id) as district_id
        FROM (SELECT *,(CASE WHEN rem_split_has_city_nmarket(h1.address)
                              THEN (
                                (SELECT id FROM city WHERE region_id=h1.region_id AND name=rem_split_city_name_nmarket(h1.address) AND prefix_type=rem_split_city_prefix_nmarket(h1.address))
                              )
                              ELSE (
                                SELECT id FROM city WHERE name = (SELECT city FROM region_city WHERE region=h1.region)) END
                                ) city_id
                        FROM (SELECT *,(SELECT r.id FROM region r WHERE r.name=region) as region_id FROM nmarket.nmarket_house) h1 ) nh )TT
        WHERE NOT EXISTS
        (SELECT id FROM address WHERE address_full = TT.address_full AND latitude=TT.latitude AND longitude=TT.longitude AND type=2);