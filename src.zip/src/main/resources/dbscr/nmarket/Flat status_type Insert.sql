INSERT INTO status
    (
        name,
        code,
        type,
        id,
        actual,
        create_date,
        version
    )
SELECT 
        nas.status,
        LOWER(nas.status),
        2,
        uuid_generate_v4(),
        true,
        now() create_date,
        0
FROM  ( SELECT DISTINCT status FROM nmarket.nmarket_appartments) nas
WHERE NOT EXISTS 
        (SELECT * FROM status WHERE code = LOWER(nas.status) AND type LIKE '2')
