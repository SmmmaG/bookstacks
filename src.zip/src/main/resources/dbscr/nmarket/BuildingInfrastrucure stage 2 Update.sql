UPDATE infrastructure ni SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        has_parking=TT.has_parking
FROM
        (
        SELECT
            oi.id,
            oi.version,
            (CASE WHEN tnmp.has_parking IS NULL THEN NULL WHEN LOWER(tnmp.has_parking) LIKE '%отсутству%' OR LOWER(tnmp.has_parking) LIKE '%нет%' THEN false ELSE true END) has_parking
        FROM
               (SELECT
                      npb.parkingname has_parking,
                      npb.advantages advantages,
                      tmp.infrastructure_id,
                      tmp.building_uuid tmpBuildId
                FROM tmp_building_infrastructure tmp
                INNER JOIN nmarket.nmarket_house npb
                      ON npb.houseid=tmp.nmarket_house) tnmp
        INNER JOIN infrastructure oi ON oi.id=(SELECT b.infrastructure_id FROM building b WHERE b.id=tnmp.tmpBuildId)
        )TT
WHERE TT.id=ni.id;