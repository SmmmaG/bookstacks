UPDATE
    flat fl
SET
    plan_document_photo_id=
    (
        SELECT
            document_photo_id
        FROM
            plan_flat_document_photo pfdp
        WHERE
            pfdp.flatuuid = fl.id
        AND EXISTS
            (
                SELECT
                    1
                FROM
                    document_photo
                WHERE
                    id=pfdp.document_photo_id))
WHERE
    plan_document_photo_id IS NULL
AND fl.id IN
    (
        SELECT
            flatuuid
        FROM
            plan_flat_document_photo);