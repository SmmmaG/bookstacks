--DROP TABLE tmp_complex_document_photo ;
CREATE TEMP TABLE tmp_complex_document_photo (
complex_id uuid,
document_photo_id uuid,
nmarket_photo_id uuid );

INSERT
INTO
    tmp_complex_document_photo
    (
        complex_id,
        document_photo_id,
        nmarket_photo_id
    )
SELECT
    ( SELECT IC.object_id FROM cross_identity_complex IC WHERE IC.code=nmp.complex_id AND IC.feed_id='?') complex_id,
    uuid_generate_v4() document_photo_id,
    nmp.id nmarket_photo_id
FROM
    (SELECT nmarket_photos.id, nmarket_photos.complex_id FROM nmarket.nmarket_photos) nmp;

UPDATE document_photo SET actual=false WHERE id in
(SELECT document_photo_id FROM complex_document_photo WHERE complex_id in (SELECT object_id FROM cross_identity_complex WHERE feed_id='?') )
AND actual=true;