INSERT into currency_type (id,name,create_date,version,code,statistic)
SELECT
    uuid_generate_v4() id,
    T.amountunit as name,
    now() create_date,
    0 as version,
    'code' code,
    0 statistic
FROM
    (
        SELECT DISTINCT
            LOWER (split_part(amountunit,'.',1)) amountunit
         FROM
            nmarket.nmarket_appartments) T
WHERE
 amountunit NOT LIKE '%м.кв%' AND
 NOT EXISTS (
        SELECT * FROM currency_type WHERE LOWER (name) = T.amountunit
);