--DROP TABLE tmp_complex_cross;

CREATE TEMP TABLE tmp_complex_cross (
complex_id uuid,
nmarket_complex varchar(20));

INSERT
INTO
    tmp_complex_cross
    (
        complex_id,
        nmarket_complex
    )
SELECT
    uuid_generate_v4() complex_id,
    nmap.id nmarket_complex
FROM  nmarket.nmarket_complex nmap;
