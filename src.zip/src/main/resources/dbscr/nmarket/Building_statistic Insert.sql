INSERT INTO building_statistic
    (
        id,
        actual,
        create_date,
        version,
        area_max_amount,
        area_min_amount,
        count_active_object,
        price_max_amount,
        price_min_amount,
        building_id,
        count_room_type
    )
SELECT
        uuid_generate_v4(),
        true,
        now() create_date,
        0,
        stat.sallmax,
        stat.sallmin,
        stat.countactive,
        stat.totalpricemax,
        stat.totalpricemin,
        (SELECT object_id FROM cross_identity_building WHERE code=stat.housesid AND feed_id='?') buildid,
        (SELECT CASE WHEN stat.flatcode LIKE 'studia' THEN 0
                             WHEN stat.flatcode LIKE 'oneroom' THEN 1
                             WHEN stat.flatcode LIKE 'two' THEN 2
                             WHEN stat.flatcode LIKE 'three' THEN 3
                             WHEN stat.flatcode LIKE 'four' THEN 4
                             WHEN stat.flatcode LIKE 'fourmore' THEN 4 END) count_room_type

FROM
        nmarket.nmarket_statistic stat
WHERE stat.housesid IS NOT NULL
AND NOT EXISTS
    (
        SELECT * FROM building_statistic bb
        WHERE bb.building_id = (SELECT object_id FROM cross_identity_building WHERE code=stat.housesid AND feed_id='?')
        AND bb.count_room_type = (SELECT CASE WHEN stat.flatcode LIKE 'studia' THEN 0
                             WHEN stat.flatcode LIKE 'oneroom' THEN 1
                             WHEN stat.flatcode LIKE 'two' THEN 2
                             WHEN stat.flatcode LIKE 'three' THEN 3
                             WHEN stat.flatcode LIKE 'four' THEN 4
                             WHEN stat.flatcode LIKE 'fourmore' THEN 4 END));