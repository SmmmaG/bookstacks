UPDATE developer d SET
        actual=true,
        update_date=now(),
        version=TT.version+1
FROM  (
SELECT
        t.id,
        t.version
 FROM (
        SELECT
        od.version,
        od.id
        FROM (SELECT DISTINCT developername FROM nmarket.nmarket_house) tt
        INNER JOIN developer od ON lower(od.full_name)=lower(tt.developername)
        )t)TT
WHERE TT.id=d.id;
