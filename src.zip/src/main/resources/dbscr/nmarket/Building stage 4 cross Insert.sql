INSERT INTO cross_identity_building (id,object_id, code, actual,create_date, feed_id,version)
  SELECT
    uuid_generate_v4(),
    b.id,
    nh.houseid,
    true,
    now(),
    '?',
    0
  FROM nmarket.nmarket_house nh
  INNER JOIN building b ON b.id=(SELECT build_id FROM tmp_build_cross WHERE nmarket_build=nh.houseid )
  WHERE NOT EXISTS
        ( SELECT * FROM cross_identity_building WHERE code=nh.houseid AND feed_id='?');