INSERT INTO metro_location (address_id,metro_id ,time_on_foot,time_on_transport)
SELECT
    DISTINCT
    a.id address_id,
    m.id metro_id,
    CASE
        WHEN nh.fromtransportnode like '%пешко%'
        THEN CAST(split_part(fromtransportnode,' ',1) as integer)
        ELSE null
    END time_on_foot,
    CASE
        WHEN nh.fromtransportnode like '%ранспор%'
        THEN CAST(split_part(fromtransportnode,' ',1) as integer)
        ELSE null
    END time_on_transport
FROM
    address a
INNER JOIN
    nmarket.nmarket_house nh
        ON nh.address = a.address_full
        AND nh.latitude=a.latitude
        AND nh.longitude = a.longitude

INNER JOIN metro m ON LOWER(nh.transportnode) LIKE LOWER (m.name||'%')
INNER JOIN address ma ON ma.id=m.address_id
    AND ma.region_id IN (
         CASE WHEN (SELECT COUNT(id) FROM region_association WHERE region_with_metro_id=a.region_id OR  region_association_id=a.region_id )>0
         THEN (SELECT DISTINCT region_with_metro_id FROM region_association WHERE region_with_metro_id=a.region_id OR  region_association_id=a.region_id)
         ELSE a.region_id END)
WHERE nh.transportnode IS NOT NULL
AND NOT EXISTS
        (SELECT 1 FROM metro_location WHERE address_id=a.id AND metro_id=m.id);