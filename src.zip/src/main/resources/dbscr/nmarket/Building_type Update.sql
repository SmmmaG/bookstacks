UPDATE building_type nbt
SET actual=true,
    update_date=now(),
    version=TT.version+1
FROM
(
        (SELECT
                T.houseclass,
                obt.version "version"
        FROM
                (SELECT DISTINCT
                (SELECT CASE WHEN nmarket.nmarket_house.houseclass IS NULL THEN 'Нет данных' ELSE nmarket.nmarket_house.houseclass END) houseclass
                FROM nmarket.nmarket_house) T
        INNER JOIN building_type obt ON obt.name=(SELECT CASE WHEN T.houseclass IS NULL THEN 'Нет данных' ELSE T.houseclass END)
          )) TT
WHERE TT.houseclass=name;
