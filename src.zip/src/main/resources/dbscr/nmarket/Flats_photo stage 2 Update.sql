UPDATE document_photo ndp SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        url=TT.url,
        state='NEW'
FROM
        (
        SELECT
            odp.id,
            odp.version,
            tnmp.planurl url
        FROM
               (SELECT
                      npa.planurl,
                      tmp.document_photo_id,
                      tmp.flatuuid tmpFlatId
                FROM plan_flat_document_photo tmp
                INNER JOIN nmarket.nmarket_appartments npa
                      ON npa.id=tmp.nmarket_flat
                WHERE npa.planurl IS NOT NULL) tnmp
        INNER JOIN document_photo odp ON odp.id=(SELECT f.plan_document_photo_id FROM flat f WHERE f.id=tnmp.tmpFlatId)
        )TT
WHERE TT.id=ndp.id;