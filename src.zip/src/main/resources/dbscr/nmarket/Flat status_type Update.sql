UPDATE  status s
SET actual=true,
    update_date=now(),
    version=TT.version+1
FROM
(
SELECT
        os.id,
        os.version
FROM  ( SELECT DISTINCT status FROM nmarket.nmarket_appartments) nas
INNER JOIN status os ON os.code=LOWER(nas.status)
WHERE os.type LIKE '2'
) TT
WHERE TT.id=s.id;