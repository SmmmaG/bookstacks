--Обновление адресов дистриктов больших городов
update address a set district_id=(
        SELECT id FROM district WHERE id in (
                SELECT d1.id 
                FROM district d1
                INNER JOIN district d2 ON lower(d2.name)=lower(d1.name)
                WHERE d2.id = a.district_id 
                        AND d1.region_id=a.region_id
                        AND d2.id=a.district_id
                        AND d1.city_id not in (
                                SELECT c1.id FROM city c1 INNER JOIN region_city rc ON lower(c1.name)=lower(rc.city) WHERE c1.id=d1.city_id
                                )
        ) ORDER BY id LIMIT 1
)
where a.id in (SELECT a1.id from address a1 
        INNER JOIN district dd ON dd.id=a1.district_id 
        INNER JOIN city c ON c.id=dd.city_id         
        where NOT EXISTS (SELECT 1 FROM region_city WHERE lower(city)=lower(c.name)) );
        
--Обнуление городов у региональных дистриктов
UPDATE district d SET city_id= null WHERE exists (SELECT ra.id from region_association ra WHERE ra.region_With_Metro_id=d.region_id OR ra.region_Association_id=d.region_id);

--Обработка частных случаев
UPDATE district SET name='Выборгский район' WHERE lower(name)=lower('Выборгский') AND region_id='e9fdeaaa-57ed-81f0-44bf-9c71d14e3e66';

--Обновление адресов региональных дистриктов
update address a set district_id=(
        SELECT id FROM district WHERE id in (
                SELECT d1.id 
                FROM district d1
                INNER JOIN district d2 ON lower(d2.name)=lower(d1.name)
                WHERE d2.id = a.district_id 
                        AND d1.region_id=a.region_id
                        AND d2.id=a.district_id
                        AND d1.city_id is null
        ) ORDER BY id LIMIT 1
)
where a.id in (SELECT a1.id from address a1 
        INNER JOIN district dd ON dd.id=a1.district_id       
        where dd.city_id is null);
    
--Удаление лишних дистриктов
DELETE FROM district d WHERE d.id not in (select distinct d1.id from district d1 INNER JOIN address a ON a.district_id = d1.id)
        


