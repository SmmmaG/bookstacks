INSERT INTO gis.complex (id,gid, geom, name, address)  
SELECT  
        uuid_generate_v4() 
        ,c.id 
        , ST_SetSRID(ST_Point(a.longitude, a.latitude),4326) 
        , c.name 
        , a.address_full 
FROM complex c
INNER JOIN address a
        ON a.id=c.address_id 
WHERE c.actual=true AND a.longitude IS NOT NULL AND a.latitude IS NOT NULL
ON CONFLICT (gid) do NOTHING;