INSERT INTO building_document_photo(
        building_id,
        document_photo_id
)
SELECT
    building_id,
    document_photo_id
FROM
 tmp_profitbase_building_document_photo tmp
WHERE building_id is not null;