INSERT INTO building
    (
        id,
        actual,
        create_date,
        version,
        building_char,
        building_number,
        end_year,
        end_quarter,
        descript,
        is_done,
        max_floors,
        min_floors,
        name,
        complex_id,
        developer_id,
        address_id,
        building_type_id
    )
SELECT
                (SELECT build_id FROM tmp_profitbase_build_cross WHERE profitbase_build=nh.house_id) id,
                true actual,
                now() create_date,
                0 as version,
                 nh.building_number building_num,
                 rem_get_building_number(nh.building_number) building_number,
                 nh.year_end end_year,
                 nh.quarter_end end_quarter,
                 null descript,
                 (CASE WHEN nh.building_state ='HAND_OVER' THEN true ELSE null END) is_done,
                 nh.max_floors,
                 nh.min_floors,
                 nh.name as name,
                 (select ci.object_id from cross_identity_complex ci WHERE ci.code IN (SELECT yy.complex_id  FROM profitbase.profitbase_complex yy WHERE yy.uuid=nh.complex_uuid) AND ci.feed_id='?') as complex_id,
                 (SELECT r.id FROM developer r WHERE LOWER(r.full_name) IN (
                     SELECT LOWER((CASE WHEN cc.developer IS NULL THEN cc.developer_brand ELSE  cc.developer END)) FROM profitbase.profitbase_complex cc WHERE cc.uuid=nh.complex_uuid
                     ) LIMIT 1) developer_id,
                 (SELECT a.id FROM address a WHERE  LOWER(a.address_full)=LOWER(nh.address_full)
--                 coalesce(nh.address_region||', ','')||coalesce(nh.address_locality||', ','')||coalesce(nh.address_district||', ','')||coalesce(nh.address_street,'')||coalesce(nh.address_number,'')
                  AND a.type=2) address_id,
                 (SELECT t.id FROM building_type t WHERE LOWER(t.name) = LOWER(nh.house_type)) building_type_id
             FROM profitbase.profitbase_house nh
     WHERE NOT EXISTS
        ( SELECT object_id FROM cross_identity_building WHERE code=nh.house_id AND feed_id='?')