INSERT INTO document_photo(
        id,
        actual,
        create_date,
        descript,
        name,
        version,
        key,
        state,
        url,
        is_default
)
SELECT
    tnmp.document_photo_id id,
    true actual,
    now() create_date,
    'Building profitbase' descript,
    'photoname' as name,
    0 as version,
    null as key,
    'NEW' state,
    tnmp.url url,
    null is_default
FROM
 (SELECT
        profitbase_photo_id,
        document_photo_id,
        np.url
  FROM tmp_profitbase_building_document_photo tmp
  INNER JOIN profitbase.profitbase_house_photos np
        ON np.id=tmp.profitbase_photo_id) tnmp