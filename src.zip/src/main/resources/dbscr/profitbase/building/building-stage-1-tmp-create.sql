CREATE TEMP TABLE tmp_profitbase_build_cross (
build_id uuid,
build_name varchar(500),
profitbase_build varchar(20));

INSERT
INTO
    tmp_profitbase_build_cross
    (
        build_id,
        build_name,
        profitbase_build
    )
SELECT
    uuid_generate_v4() build_id,
    nmap.name,
    nmap.house_id profitbase_build
FROM  profitbase.profitbase_house nmap;