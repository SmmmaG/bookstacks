INSERT INTO address (
        id,
        type,
        actual,
        create_date ,
        version,
        address_full ,
        city_id,
        country_id ,
        district_id ,
        region_id
        )

SELECT  uuid_generate_v4() as id,
        type,
        actual,
        create_date ,
        version,
        address_full ,
        city_id,
        country_id ,
        district_id ,
        region_id
 FROM (
        select DISTINCT 1 as type,
         true as actual ,
         now() create_date,
         0 as version,
         (SELECT ph.address_full FROM profitbase.profitbase_house ph WHERE ph.complex_uuid=tt.complex_uuid ORDER BY ph.address_full LIMIT 1 ) address_full,
         null as latitude,
         null as longitude,
         (SELECT cc.id FROM (SELECT c.id, c.region_id, c.name, c.prefix_type FROM city c) cc
                            WHERE cc.name=rem_split_city_name_profitbase(tt.address_locality)
                            AND cc.prefix_type=rem_split_city_prefix_profitbase(tt.address_locality)
                            AND tt.region_id=cc.region_id LIMIT 1) as  city_id,
        (SELECT cnt.id FROM country cnt WHERE cnt.code='ru')  country_id,
        (SELECT d.id FROM district d WHERE lower(d.name) like split_part(LOWER(tt.address_district),' ',1)||'%'
        AND tt.region_id=d.region_id LIMIT 1) as  district_id,
        tt.region_id
         FROM (SELECT *,
         (SELECT r.id FROM region r WHERE lower(r.name) like split_part(LOWER(address_region),' ',1)||'%') as region_id
          FROM profitbase.profitbase_house WHERE address_full IS NOT NULL ) tt
        WHERE region_id IS NOT NULL AND NOT EXISTS
        (SELECT id FROM address WHERE address_full =
            (SELECT ph.address_full FROM profitbase.profitbase_house ph WHERE ph.complex_uuid=tt.complex_uuid ORDER BY ph.address_full LIMIT 1 )
        AND type=1)
        ) ttt;