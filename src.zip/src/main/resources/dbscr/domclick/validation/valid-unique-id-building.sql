SELECT fail=0 FROM (
SELECT COUNT(*) fail  FROM (   SELECT domclick_building, count (building_id ) FROM (
SELECT
    uuid_generate_v4() building_id,
    nmap.namen,
    nmap.id domclick_building
FROM  ?schema?.buildings nmap) tt
        GROUP BY domclick_building
        HAVING  count (building_id )>1) t) tt;
