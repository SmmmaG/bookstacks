DELETE FROM ?schema?.flats WHERE custom_id IN (
	SELECT
	    custom_id
	FROM
	    ?schema?.flats
	GROUP BY
	   custom_id
	HAVING
	    COUNT(*) > 1
);