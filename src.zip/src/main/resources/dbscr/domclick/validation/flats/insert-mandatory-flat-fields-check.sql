INSERT INTO event_log
        (id
        , actual
        , create_date
        , version
        , count
        , error
        , is_error
        , log
        , feed_event_id
        , feed_log_id
        , type)
SELECT
        uuid_generate_v4() id
        , true actual
        , now() create_date
        , 0 as version
        , (SELECT count(1) FROM ?schema?.flats WHERE ?) count
        , 'Не заполнено обязательное поле ? (?) в квартирах' error
        , true is_error
        , SUBSTRING(ARRAY_TO_STRING(ARRAY(SELECT DISTINCT flat_id FROM ?schema?.flats WHERE ?),',','*'),0,10000) log
        , (SELECT id FROM feed_event_type WHERE code='Flats_Detail_Mandatory_Fields') feed_event_id
        , '?' feed_log_id
        , 1 as type
WHERE
     EXISTS (SELECT DISTINCT flat_id FROM ?schema?.flats WHERE ?)