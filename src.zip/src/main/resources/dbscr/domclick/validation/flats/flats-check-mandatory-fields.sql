DELETE
FROM ?schema?.flats
WHERE ?