SELECT fail=0 FROM (
SELECT COUNT(*) fail  FROM (   SELECT domclick_flat, count (flat_id ) FROM (
SELECT
    uuid_generate_v4() flat_id,
    nmap.namen,
    nmap.id domclick_flat
FROM  ?schema?.flats nmap) tt
        GROUP BY domclick_flat
        HAVING  count (flat_id )>1) t) tt;
