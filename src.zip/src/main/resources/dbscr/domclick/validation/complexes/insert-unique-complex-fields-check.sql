INSERT INTO event_log
        (id
        , actual
        , create_date
        , version
        , count
        , error
        , is_error
        , log
        , feed_event_id
        , feed_log_id
        , type)
SELECT
        uuid_generate_v4() id
        , true actual
        , now() create_date
        , 0 as version
        , (SELECT count(1) FROM ?schema?.complexes WHERE id IN (SELECT id FROM  ?schema?.complexes GROUP BY id HAVING COUNT(*) > 1) ) count
        , '?' error
        , true is_error
        , SUBSTRING(ARRAY_TO_STRING(ARRAY(SELECT id FROM ?schema?.complexes GROUP BY id HAVING COUNT(*) > 1),',','*'),0,10000) log
        , (SELECT id FROM feed_event_type WHERE code='Complexes_Detail_Non_Unique_Complex_Custom_Id') feed_event_id
        , '?' feed_log_id
        , 1 as type
WHERE
     EXISTS (SELECT id FROM ?schema?.complexes GROUP BY id HAVING COUNT(*) > 1)