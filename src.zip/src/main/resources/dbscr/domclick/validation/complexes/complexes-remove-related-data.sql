DELETE FROM ?schema?.buildings
WHERE
complex_id IS NULL
OR complex_id::uuid
NOT IN (SELECT uuid FROM ?schema?.complexes);

DELETE FROM ?schema?.complexes_photos dcp
WHERE
dcp.parent_id IS NULL
OR dcp.parent_id
NOT IN (SELECT id FROM ?schema?.complexes);

DELETE FROM ?schema?.sale_office_complex soc
WHERE
soc.complex_id IS NULL
OR soc.complex_id
NOT IN (SELECT id FROM ?schema?.complexes);