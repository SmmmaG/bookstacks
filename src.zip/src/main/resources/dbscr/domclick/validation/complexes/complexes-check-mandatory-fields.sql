DELETE  FROM ?schema?.complexes
WHERE uuid in (
        SELECT dc.uuid FROM ?schema?.complexes dc
        LEFT JOIN ?schema?.sale_office_complex soc ON soc.complex_id=dc.id
        LEFT JOIN ?schema?.sale_office so ON so.developer_name=soc.developer_name AND COALESCE(soc.address,soc.address_alias) = COALESCE(so.address,so.address_alias)
        WHERE ? )