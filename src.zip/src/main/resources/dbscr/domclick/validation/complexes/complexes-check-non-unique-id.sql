DELETE FROM ?schema?.complexes WHERE id IN (
	SELECT
	    id
	FROM
	    ?schema?.complexes
	GROUP BY
	    id
	HAVING
	    COUNT(*) > 1
);