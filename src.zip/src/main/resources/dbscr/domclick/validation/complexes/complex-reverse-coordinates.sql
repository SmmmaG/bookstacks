INSERT INTO event_log
        (id
        , actual
        , create_date
        , version
        , count
        , error
        , is_error
        , log
        , feed_event_id
        , feed_log_id
        , type)
SELECT
        uuid_generate_v4() id
        , true actual
        , now() create_date
        , 0 as version
        , (SELECT count(1) FROM  ?schema?.complexes dc
                WHERE longitude IS NOT NULL AND latitude IS NOT NULL AND (longitude NOT BETWEEN 20 AND 180 OR latitude NOT BETWEEN 41.186158 AND 74)) count
        , 'Координаты препутаны местами в жилом комплексе' error
        , true is_error
        , SUBSTRING(ARRAY_TO_STRING(ARRAY(SELECT DISTINCT dc.id FROM  ?schema?.complexes dc
                WHERE longitude IS NOT NULL AND latitude IS NOT NULL AND (longitude NOT BETWEEN 20 AND 180 OR latitude NOT BETWEEN 41.186158 AND 74)),',','*'),0,10000) log
        , (SELECT id FROM feed_event_type WHERE code='Complexes_Detail_Mandatory_Fields') feed_event_id
        , '?' feed_log_id
        , 1 as type
WHERE
     EXISTS (SELECT DISTINCT dc.id FROM  ?schema?.complexes dc
                WHERE longitude IS NOT NULL AND latitude IS NOT NULL AND (longitude NOT BETWEEN 20 AND 180 OR latitude NOT BETWEEN 41.186158 AND 74));

UPDATE ?schema?.complexes SET latitude = longitude, longitude=latitude
WHERE longitude IS NOT NULL AND latitude IS NOT NULL AND (longitude NOT BETWEEN 20 AND 180 OR latitude NOT BETWEEN 41.186158 AND 74);