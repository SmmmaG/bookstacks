DELETE FROM ?schema?.buildings
WHERE ?