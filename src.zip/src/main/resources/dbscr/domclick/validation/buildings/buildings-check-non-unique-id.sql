DELETE FROM ?schema?.buildings WHERE custom_id IN (
	SELECT
	    custom_id
	FROM
	    ?schema?.buildings
	GROUP BY
	    custom_id
	HAVING
	    COUNT(*) > 1
);