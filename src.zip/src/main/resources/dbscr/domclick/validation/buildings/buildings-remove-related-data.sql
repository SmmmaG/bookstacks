DELETE FROM ?schema?.buildings b
WHERE
b.uuid NOT IN (SELECT DISTINCT building_id::uuid FROM ?schema?.flats);

DELETE FROM ?schema?.buildings_photos dbp
WHERE
dbp.parent_id IS NULL
OR dbp.parent_id
NOT IN (SELECT id FROM ?schema?.buildings);

DELETE FROM ?schema?.flats f
WHERE
f.building_id IS NULL
OR f.building_id::uuid
NOT IN (SELECT uuid FROM ?schema?.buildings);

DELETE FROM ?schema?.complexes
WHERE uuid
NOT IN (SELECT complex_id::uuid FROM ?schema?.buildings);