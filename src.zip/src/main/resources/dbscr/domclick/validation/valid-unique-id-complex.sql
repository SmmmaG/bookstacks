SELECT fail=0 FROM (
SELECT COUNT(*) fail  FROM (   SELECT domclick_complex, count (complex_id ) FROM (
SELECT
    uuid_generate_v4() complex_id,
    nmap.namen,
    nmap.id domclick_complex
FROM  ?schema?.complexes nmap) tt
        GROUP BY domclick_complex
        HAVING  count (complex_id )>1) t) tt;
