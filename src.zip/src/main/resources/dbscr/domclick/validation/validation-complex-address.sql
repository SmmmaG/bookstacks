SELECT fail=0 check_validation FROM (
     SELECT sum(fail) fail FROM
        (SELECT * FROM(SELECT count(uuid) fail FROM ?schema?.complexes c WHERE c.address IS NULL OR LENGTH(c.address)<3) fail_address
                UNION ALL
             SELECT * FROM (SELECT count(uuid) fail FROM ?schema?.complexes c WHERE c.latitude IS NULL) fail_latitude
                UNION ALL
             SELECT * FROM (SELECT count(uuid) fail FROM ?schema?.complexes c WHERE c.longitude IS NULL) fail_longitude
                UNION ALL
             SELECT * FROM (SELECT count(uuid) fail FROM ?schema?.complexes c WHERE c.developer_name IS NULL OR LENGTH(c.developer_name)<3) fail_developer_name
                UNION ALL
             SELECT * FROM (SELECT count(uuid)  fail FROM ?schema?.complexes c WHERE c.namen IS NULL OR LENGTH(c.namen)<3) fail_name) tt) ttt
