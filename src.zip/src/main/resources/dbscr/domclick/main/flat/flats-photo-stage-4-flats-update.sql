UPDATE
    flat fl
SET
    plan_document_photo_id=
    (
        SELECT
            document_photo_id
        FROM
            tmp_plan_flat_domclick_document_photo pfdp
        WHERE
            pfdp.parent_id = fl.id
        AND EXISTS
            (
                SELECT
                    1
                FROM
                    document_photo
                WHERE
                    id=pfdp.document_photo_id))
WHERE
    plan_document_photo_id IS NULL
AND fl.id IN
    (
        SELECT
            parent_id
        FROM
            tmp_plan_flat_domclick_document_photo);