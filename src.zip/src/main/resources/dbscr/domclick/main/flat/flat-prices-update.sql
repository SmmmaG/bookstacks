UPDATE flat f SET
        price_id = TT.price_id
FROM(
  SELECT
    cif.object_id flat_id,
    tmp.price_id price_id
FROM
    domclick.flats nmap
    INNER JOIN tmp_domclick_flat_cross tmp ON tmp.domclick_flat=nmap.custom_id
    INNER JOIN cross_identity_flat cif ON cif.code=nmap.custom_id
    WHERE cif.feed_id='?') TT
WHERE TT.flat_id=f.id;