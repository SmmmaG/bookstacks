INSERT INTO price
    (
        id,
        actual,
        create_date,
        version,
        amount,
        base_amount,
        min_amount,
--        flat_id,
        amount_update_date,
        currency_type_id
    )
SELECT
    (SELECT price_id FROM tmp_domclick_flat_cross WHERE domclick_flat=custom_id ) id,
    true,
    now() create_date,
    0,
    nmap.price minamount,
    nmap.price baseAmount,
    nmap.price amount,
--    (SELECT object_id FROM cross_identity_flat cif WHERE code=nmap.custom_id AND feed_id='?') flatid,
    now(),
    (SELECT id FROM currency_type WHERE code='rub' )currency_type_id
FROM
    domclick.flats nmap