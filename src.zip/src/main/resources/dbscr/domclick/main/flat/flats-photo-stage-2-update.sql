UPDATE document_photo ndp SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        url=TT.url,
        state='NEW'
FROM
        (
        SELECT
            odp.id,
            odp.version,
            tnmp.plan url
        FROM
               (SELECT
                      npa.plan,
                      tmp.document_photo_id,
                      tmp.parent_id tmpFlatId
                FROM tmp_plan_flat_domclick_document_photo tmp
                INNER JOIN domclick.flats npa
                      ON npa.custom_id=tmp.domclick_flat) tnmp
        INNER JOIN document_photo odp ON odp.id=(SELECT f.plan_document_photo_id FROM flat f WHERE f.id=tnmp.tmpFlatId)
        )TT
WHERE TT.id=ndp.id;