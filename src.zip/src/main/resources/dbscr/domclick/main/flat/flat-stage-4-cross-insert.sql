INSERT INTO cross_identity_flat(id,actual,create_date,version,code,object_id,feed_id)
  SELECT
      uuid_generate_v4(),
      true,
      now() create_date,
      0,
      nf.custom_id,
      f.id,
      '?' sourceid
   FROM domclick.flats nf
   INNER JOIN flat f ON f.id=(SELECT flat_id FROM tmp_domclick_flat_cross WHERE domclick_flat=nf.custom_id )
   WHERE NOT EXISTS
          ( SELECT * FROM cross_identity_flat WHERE code=nf.custom_id AND feed_id='?');