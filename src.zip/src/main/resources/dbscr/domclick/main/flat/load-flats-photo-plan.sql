CREATE TABLE ?schema?.flats_plan_photos AS (
SELECT
uuid_generate_v4() AS id,
rem_trim(complex_id)||':'||rem_trim(building_id) AS building_id,
rem_trim(complex_id)||':'||rem_trim(building_id)||':'||rem_trim(flat_id) parent_id,
rem_trim_url(url) url
  FROM (SELECT convert_from(lo_get(cast(ff.file as bigint)),'UTF-8') as file FROM feed_log f JOIN feed_log_file ff ON ff.id=f.file_id WHERE f.id='?') tt,
       XMLTABLE ('//flats/flat' PASSING CAST(file AS XML)
                 COLUMNS
                    complex_id varchar(255) PATH '../../../id',
                    building_id varchar(255) PATH '../../id',
                    flat_id varchar(255) PATH 'flat_id',
                    url varchar(1000) PATH 'plan' NOT NULL));