CREATE TEMP TABLE tmp_domclick_flat_cross (
flat_id uuid,
domclick_flat varchar(255),
domclick_flat_num varchar(50),
price_id uuid);

INSERT
INTO
    tmp_domclick_flat_cross
    (
        flat_id,
        domclick_flat,
        domclick_flat_num,
        price_id
    )
SELECT
    uuid_generate_v4() flat_id,
    nmap.custom_id domclick_flat,
    nmap.apartment  domclick_flat_num,
    uuid_generate_v4() price_id
FROM  domclick.flats nmap;
