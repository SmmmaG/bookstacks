CREATE TEMP TABLE tmp_plan_flat_domclick_document_photo (
document_photo_id uuid,
domclick_flat varchar(255),
parent_id uuid );

INSERT
INTO
    tmp_plan_flat_domclick_document_photo
    (
        document_photo_id,
        domclick_flat,
        parent_id
    )
SELECT
    uuid_generate_v4() document_photo_id,
    nmap.custom_id domclick_flat,
    (SELECT object_id parent_id FROM cross_identity_flat cif WHERE code=nmap.custom_id
            AND feed_id='?')
FROM  domclick.flats nmap WHERE nmap.plan IS NOT NULL;

--Дизактуализация старых фото квартир по текущей выборке квартир
UPDATE  document_photo SET actual=false WHERE id IN
  (SELECT plan_document_photo_id FROM flat f WHERE f.id IN
      (SELECT parent_id FROM tmp_plan_flat_domclick_document_photo) ) AND actual=true;