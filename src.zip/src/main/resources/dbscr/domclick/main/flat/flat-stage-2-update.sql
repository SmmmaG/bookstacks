UPDATE flat f
SET     actual=true,
        update_date=now(),
        version=TT.version+1,
        total_area=TT.total_area,
        kitchen_area=TT.kitchen_area,
        living_area=TT.living_area,
        total_rooms_area=TT.total_rooms_area,
        flat_char=TT.flat_char,
        flat_number=TT.flat_number,
        floor=TT.floor,
        room_count=TT.room_count,
        section=TT.section,
        address_id=TT.address_id,
        balcony_type_id=TT.balcony_type_id,
        building_id=TT.building_id,
        complex_id=TT.complex_id,
        decoration_type_id=TT.decoration_type_id,
        type_id=TT.type_id,
        deal_status_id=TT.deal_status_id,
        has_balcony=TT.has_balcony,
        has_loggia=TT.has_loggia,
        view_type=TT.view_type,
        wc_type=TT.wc_type
FROM
(
        SELECT
            olf.id,
            olf.version,
            nm.area total_area,
            nm.kitchen_area kitchen_area,
            nm.living_area living_area,
            (SELECT sum(area) FROM domclick.flat_rooms WHERE flat_id=nm.custom_id GROUP BY custom_id) total_rooms_area,
            nm.apartment flat_char,
            (SELECT (regexp_matches(nm.apartment,'\d+'))[1])::INTEGER flat_number,
            nm.floor::INTEGER floor,
            nm.room room_count,
            nm.sectionn section,
            (SELECT AB.address_id FROM building AB WHERE AB.id IN (SELECT DISTINCT IB.object_id building_id FROM cross_identity_building IB WHERE IB.code IN (SELECT bb.custom_id FROM domclick.buildings bb WHERE bb.uuid = (nm.building_id::uuid)) AND IB.feed_id='?') LIMIT 1) address_id,
            ( SELECT DISTINCT bt.id FROM balcony_type bt WHERE LOWER(bt.name) = LOWER(nm.balcony) LIMIT 1) balcony_type_id,
            ( SELECT IB.object_id building_id FROM cross_identity_building IB WHERE IB.code IN (SELECT bb.custom_id FROM domclick.buildings bb WHERE bb.uuid = (nm.building_id::uuid)) AND IB.feed_id='?' LIMIT 1) building_id,
            ( SELECT cb.complex_id FROM cross_identity_building IB JOIN building cb ON cb.id=IB.object_id WHERE IB.code IN (SELECT bb.custom_id FROM domclick.buildings bb WHERE bb.uuid = (nm.building_id::uuid)) AND IB.feed_id='?' LIMIT 1) complex_id,
            ( SELECT dt.id FROM decoration_type dt WHERE LOWER(dt.name)  = LOWER('Нет данных') LIMIT 1) decoration_type_id,
            ( SELECT ft.id FROM flat_type ft WHERE ft.code = '1') type_id,
            (SELECT s.id FROM status s WHERE LOWER(s.code) = 'available') deal_status_id,
            ( SELECT CASE WHEN LOWER(nm.balcony) LIKE '%балк%' THEN true ELSE false END) has_balcony,
            ( SELECT CASE WHEN LOWER(nm.balcony) LIKE '%лодж%' THEN true ELSE false END) has_loggia,
            ( SELECT CASE WHEN LOWER(nm.window_view) LIKE '%двор%улиц%' OR LOWER(nm.window_view) LIKE '%улиц%двор%' THEN 2
                    WHEN LOWER(nm.window_view) LIKE '%улиц%' THEN 0
                    WHEN LOWER(nm.window_view) LIKE '%двор%' THEN 1 ELSE null END) view_type,
            ( SELECT CASE WHEN (SPLIT_PART(nm.bathroom,' ' ,1) ~ '^[0-9]') THEN 1
                                WHEN (SPLIT_PART(nm.bathroom,' ' ,2) ~ '^[0-9]') THEN 1
                                WHEN nm.bathroom LIKE '%овмещен%' THEN 0
                                WHEN nm.bathroom LIKE '%аздельны%' THEN 0 ELSE null END ) wc_type
        FROM
            domclick.flats nm
            INNER JOIN flat olf ON olf.id = ( SELECT object_id FROM cross_identity_flat WHERE code=nm.custom_id AND feed_id='?'))TT
WHERE TT.id=f.id;