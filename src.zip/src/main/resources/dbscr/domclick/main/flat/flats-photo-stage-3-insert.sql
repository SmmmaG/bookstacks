INSERT INTO document_photo(
        id,
        actual,
        create_date,
        descript,
        name,
        version,
        state,
        url
)
SELECT
    tnmp.document_photo_id id,
    true actual,
    now() create_date,
    'flat plan' descript,
    'flat plan' as name,
    0 as version,
    'NEW' state,
    tnmp.plan url
FROM
 (SELECT
        npa.plan,
        tmp.document_photo_id,
        tmp.parent_id
  FROM tmp_plan_flat_domclick_document_photo tmp
  INNER JOIN domclick.flats npa
        ON npa.custom_id=tmp.domclick_flat) tnmp
WHERE NOT EXISTS
        (SELECT 1 FROM tmp_plan_flat_domclick_document_photo tmp INNER JOIN flat f ON f.id = tmp.parent_id INNER JOIN document_photo dp ON f.plan_document_photo_id = dp.id WHERE f.id =tnmp.parent_id );