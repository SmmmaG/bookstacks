DROP TABLE IF EXISTS
?schema?.complexes,
?schema?.buildings,
?schema?.flats,
?schema?.flat_rooms,
?schema?.complexes_photos,
?schema?.buildings_photos,
?schema?.flats_photos,
?schema?.sale_office,
?schema?.sale_office_complex;