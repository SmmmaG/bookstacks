UPDATE district nd
SET actual=true,
    update_date=now(),
    version=fff.version+1
FROM
(
 SELECT
                DISTINCT
                tt.district as name,
                tt.city_id city_id,
                tt.region_id region_id,
                tt.version,
                tt.id id
        FROM

                (SELECT DISTINCT od.id,
                        t.district,
                        t.region_id,
                        t.city_id,
                        od.version
                        FROM
                    (SELECT
                        REPLACE (rem_extract_district(address), 'р-н', 'район') district,
                        region_id,
                        (SELECT cc.id FROM (SELECT c.id, c.region_id, (SELECT DISTINCT part_content FROM rem_extract_city(c.name)) as name FROM city c) cc
                            WHERE cc.name IN (SELECT part_content FROM rem_extract_city(o.address)) AND o.region_id=cc.region_id LIMIT 1) as  city_id
                        FROM (
                                SELECT DISTINCT
                                (SELECT r.id FROM region r WHERE r.name = split_part(address,',',1)) as region_id,
                                 address
                                 FROM domclick.complexes) o
                                 ) t


        INNER JOIN district od ON LOWER(od.name) like  LOWER(t.district)||'%'
                                                AND od.city_id=t.city_id
                                                AND od.region_id=t.region_id
                ) tt) fff
WHERE fff.id=nd.id;