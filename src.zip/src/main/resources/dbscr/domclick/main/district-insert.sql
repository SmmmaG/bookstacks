INSERT INTO district (id, name,city_id,region_id,actual,version,create_date)
SELECT
        uuid_generate_v4() id,
        fff.district as name,
        fff.city_id city_id,
        fff.region_id region_id,
        true actual,
        0 as version,
        now() create_date
FROM
        (
 SELECT

                tt.district,
                tt.city_id city_id,
                tt.region_id region_id,
                tt.version,
                tt.id id
        FROM

                (SELECT DISTINCT od.id,
                        t.district,
                        t.region_id,
                        t.city_id,
                        od.version
                        FROM
                    (SELECT
                        REPLACE (rem_extract_district(address), 'р-н', 'район') district,
                        region_id,
                        (SELECT cc.id FROM (SELECT c.id, c.region_id, (SELECT part_content FROM rem_extract_city(c.name)) as name FROM city c) cc
                            WHERE cc.name IN (SELECT part_content FROM rem_extract_city(o.address)) AND o.region_id=cc.region_id LIMIT 1) as  city_id
                        FROM (
                                SELECT DISTINCT
                                (SELECT r.id FROM region r WHERE r.name = split_part(address,',',1)) as region_id,
                                 address
                                 FROM domclick.complexes) o
                                 ) t


        INNER JOIN district od ON LOWER(od.name) like  LOWER(t.district)||'%'
                                                AND od.city_id=t.city_id
                                                AND od.region_id=t.region_id
                ) TT) fff
WHERE NOT EXISTS
(SELECT 1 FROM district WHERE LOWER(name) like  split_part(LOWER(fff.district),' р-н',1)||'%'
AND city_id=fff.city_id
AND region_id=fff.region_id );