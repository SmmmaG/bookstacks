INSERT into parking_type (id,name,create_date,version)
            SELECT
    uuid_generate_v4(),
    TT.infrastructure_parking,
    now() create_date,
    0
FROM
    (
        SELECT DISTINCT
            trim(infrastructure_parking) infrastructure_parking
        FROM
            domclick.complexes
        WHERE TRIM(infrastructure_parking) IS NOT NULL) TT
WHERE NOT EXISTS (
        SELECT * FROM parking_type WHERE lower(trim(name)) = lower(trim(COALESCE(infrastructure_parking,infrastructure_parking,'Нет данных'))));