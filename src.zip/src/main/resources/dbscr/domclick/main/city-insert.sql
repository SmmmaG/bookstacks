INSERT INTO city (id, name, prefix_type, region_id,actual,version,create_date)
SELECT
        uuid_generate_v4() id,
        t.city as name,
        t.prefix_type,
        t.region_id region_id,
        true actual,
        0 as version,
        now() create_date
FROM
        (SELECT DISTINCT
                 (SELECT r.id FROM region r WHERE LOWER(r.name) like LOWER(split_part(address,',',1) )||'%') region_id,
                 (SELECT part_content as city FROM  rem_extract_city(address) LIMIT 1) ,
                 (SELECT prefix_type FROM rem_extract_city(address) LIMIT 1)

                FROM domclick.complexes) t
WHERE NOT EXISTS
(SELECT 1 FROM city WHERE LOWER(name) like LOWER(t.city) AND region_id=t.region_id );