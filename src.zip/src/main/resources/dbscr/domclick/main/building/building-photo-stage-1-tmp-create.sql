CREATE TEMP TABLE tmp_domclick_building_document_photo (
building_id uuid,
document_photo_id uuid,
domclick_photo_id uuid );

INSERT
INTO
    tmp_domclick_building_document_photo
    (
        building_id,
        document_photo_id,
        domclick_photo_id
    )
SELECT
    ( SELECT ic.object_id FROM cross_identity_building ic WHERE ic.code=nmp.parent_id AND ic.feed_id='?') building_id,
    uuid_generate_v4() document_photo_id,
    nmp.id domclick_photo_id
FROM
    (SELECT buildings_photos.id, buildings_photos.parent_id FROM domclick.buildings_photos WHERE buildings_photos.url IS NOT NULL) nmp;

UPDATE document_photo SET actual=false WHERE id in
(SELECT document_photo_id FROM building_document_photo WHERE building_id in (SELECT object_id FROM cross_identity_building WHERE feed_id='?') )
AND actual=true;