INSERT INTO cross_identity_building (id,object_id, code, actual,create_date, feed_id,version)
  SELECT
    uuid_generate_v4(),
    b.id,
    nh.custom_id,
    true,
    now(),
    '?',
    0
  FROM domclick.buildings nh
  INNER JOIN building b ON b.id=(SELECT build_id FROM tmp_domclick_build_cross WHERE domclick_build=nh.custom_id )
  WHERE NOT EXISTS
        ( SELECT * FROM cross_identity_building WHERE code=nh.custom_id AND feed_id='?');