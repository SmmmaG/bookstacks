INSERT INTO document_photo(
        id,
        actual,
        create_date,
        descript,
        name,
        version,
        key,
        state,
        url,
        is_default
)
SELECT
    tnmp.document_photo_id id,
    true actual,
    now() create_date,
    'Building Domclick' descript,
    'photoname' as name,
    0 as version,
    null as key,
    'NEW' state,
    tnmp.url url,
    null is_default
--    ( SELECT CASE WHEN (SELECT COUNT(id) FROM domclick.photos pt JOIN public  WHERE pt.complex_id=tnmp.complex_id AND LOWER(pt.title) LIKE 'main%' )>0 THEN true ELSE false END ) is_default
FROM
 (SELECT
        domclick_photo_id,
        document_photo_id,
        np.url
  FROM tmp_domclick_building_document_photo tmp
  INNER JOIN domclick.buildings_photos np
        ON np.id=tmp.domclick_photo_id) tnmp;