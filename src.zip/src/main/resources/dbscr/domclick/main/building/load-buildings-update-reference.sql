UPDATE   ?schema?.buildings
         SET complex_id = (SELECT c.uuid    FROM   ?schema?.complexes c WHERE   c.id = complex_id AND COALESCE(c.namen,'')=COALESCE(complex_name,''));


