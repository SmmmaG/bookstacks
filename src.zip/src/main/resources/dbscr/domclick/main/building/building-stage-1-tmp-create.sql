CREATE TEMP TABLE tmp_domclick_build_cross (
build_id uuid,
build_name varchar(500),
domclick_build varchar(255));

INSERT
INTO
    tmp_domclick_build_cross
    (
        build_id,
        build_name,
        domclick_build
    )
SELECT
    uuid_generate_v4() build_id,
    nmap.name,
    nmap.custom_id domclick_build
FROM  domclick.buildings nmap;