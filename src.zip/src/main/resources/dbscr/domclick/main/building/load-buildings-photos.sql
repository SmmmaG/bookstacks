CREATE TABLE ?schema?.buildings_photos AS (
SELECT
uuid_generate_v4() AS id,
rem_trim(complex_id)||':'||rem_trim(building_id) AS parent_id,
rem_trim_url(url) url
  FROM (SELECT convert_from(lo_get(cast(ff.file as bigint)),'UTF-8') as file FROM feed_log f JOIN feed_log_file ff ON ff.id=f.file_id WHERE f.id='?') tt,
       XMLTABLE ('//buildings/building' PASSING CAST(file AS XML)
                 COLUMNS
                    complex_id varchar(255) PATH '../id',
                    building_id varchar(255) PATH 'id',
                    url varchar(1000) PATH 'image'
                ) WHERE  xmltable.url IS NOT NULL);