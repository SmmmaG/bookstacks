update building nb SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        building_char=TT.building_char,
        building_number=TT.building_number,
        end_year=TT.end_year,
        end_quarter=TT.end_quarter,
        descript=TT.descript,
        max_floors=TT.max_floors,
        min_floors=TT.min_floors,
        name=TT.name,
        contract_type_id=TT.contract_type_id,
        complex_id=TT.complex_id,
        developer_id=TT.developer_id,
        address_id=TT.address_id,
        parking_type_id=TT.parking_type_id,
        document_advantage_id=TT.document_advantage_id,
        building_type_id=TT.building_type_id,
        material_wall_id=TT.material_wall_id
FROM
(
        SELECT
                 ob.id,
                 ob.version,
                 nh.name building_char,
                 rem_get_building_number(nh.name) building_number,
                 nh.built_year end_year,
                 nh.ready_quarter end_quarter,
                 nh.description_main descript,
                 (CASE WHEN nh.building_state ='hand_over' THEN true ELSE null END) is_done,
                 CASE WHEN position('-' in nh.floors)>0 THEN CAST(split_part(nh.floors,'-',2) AS integer)ELSE CAST(nh.floors AS integer) END max_floors,
                 CASE WHEN position('-' in nh.floors)>0 THEN CAST(split_part(nh.floors,'-',1) AS integer)ELSE CAST(nh.floors AS integer) END min_floors,
                 nh.name as name,
                 (SELECT r.id FROM contract_type r WHERE r.code = CASE WHEN nh.fz_214 THEN 'fz214' END) as contract_type_id,
                 (select ci.object_id from cross_identity_complex ci WHERE ci.code IN (SELECT id  FROM domclick.complexes WHERE uuid=nh.complex_id::uuid) AND ci.feed_id='?' ) as complex_id,
                 (SELECT r.id FROM developer r WHERE lower(r.full_name) IN (SELECT lower(cc.developer_name) FROM domclick.complexes cc WHERE uuid=nh.complex_id::uuid) LIMIT 1) developer_id,
                 (SELECT a.id FROM address a WHERE a.address_full=nh.address AND a.latitude=nh.latitude AND a.longitude=nh.longitude AND a.type=2) address_id,
                 (SELECT p.id FROM parking_type p WHERE lower(p.name)=lower(nh.infrastructure_parking)) parking_type_id,
                 (SELECT a.id FROM document_advantage a WHERE a.content=nh.description_main LIMIT 1)document_advantage_id,
                 (SELECT t.id FROM building_type t WHERE LOWER(t.name) = LOWER('Нет данных')) building_type_id,
                 (SELECT m.id FROM material_wall_type m WHERE LOWER(m.name) = LOWER(nh.building_type)) material_wall_id
             FROM domclick.buildings nh
             INNER JOIN building ob ON ob.id = ( SELECT object_id FROM cross_identity_building WHERE code=nh.custom_id AND feed_id='?'))TT
WHERE TT.id=nb.id;
