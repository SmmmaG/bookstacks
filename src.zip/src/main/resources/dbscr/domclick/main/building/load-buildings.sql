CREATE TABLE ?schema?.buildings AS (
SELECT
uuid_generate_v4() AS UUID,
T.*
FROM
(SELECT
                    DISTINCT
                    rem_trim(id) id,
                    rem_trim(complex_id)||':'||rem_trim(id) AS custom_id,
                    rem_trim(complex_id) complex_id,
                    rem_clean_complex_name(rem_trim(complex_name)) complex_name,
                    CASE WHEN REPLACE(rem_trim_numbers(latitude), ',', '.')::decimal != 0 THEN REPLACE(rem_trim_numbers(latitude), ',', '.')::decimal
                        ELSE NULL END                                                       latitude,
                    CASE WHEN  REPLACE(rem_trim_numbers(longitude), ',', '.')::decimal != 0 THEN  REPLACE(rem_trim_numbers(longitude), ',', '.')::decimal
                        ELSE NULL END                                                       longitude,
                    rem_trim(address) address,
                    rem_trim(infrastructure_parking) infrastructure_parking,
                    CASE WHEN fz_214  IS NOT NULL AND length(fz_214)=0 THEN null ELSE REPLACE(REPLACE(REPLACE(REPLACE(lower(fz_214),'да','true'),'нет','false'),'-','false'),'+','true')::boolean END fz_214,
                    rem_clean_building_name(CASE WHEN rem_trim(name) IS NULL THEN null ELSE name END) as name,
                    rem_trim(floors) floors,
                    CASE WHEN rem_trim(floors_ready) IS NULL THEN null ELSE rem_trim_numbers(floors_ready)::int END floors_ready,
                    rem_trim(building_state) building_state,
                    rem_trim(building_type) building_type ,
                    CASE WHEN rem_trim(built_year) IS NULL THEN null ELSE rem_trim_numbers(built_year)::int END built_year,
                    CASE WHEN rem_trim(ready_quarter) IS NULL THEN null ELSE
                        CASE WHEN rem_trim(ready_quarter)::int > 4 THEN NULL ELSE rem_trim_numbers(ready_quarter)::int END END ready_quarter ,
                    (CASE WHEN description_main like '' THEN null ELSE rem_remove_html(description_main) END) || (CASE WHEN description_secondary is null THEN '' ELSE chr(10)||rem_remove_html(description_secondary) END) description_main
  FROM (SELECT convert_from(lo_get(cast(ff.file as bigint)),'UTF-8') as file FROM feed_log f JOIN feed_log_file ff ON ff.id=f.file_id WHERE f.id='?') tt,
       XMLTABLE ('//buildings/building' PASSING CAST(file AS XML)
                 COLUMNS
                    id  varchar(255) PATH 'id',
                    complex_id varchar(255) PATH '../../id',
                    complex_name varchar(500) PATH '../../name',
                    latitude varchar(50) PATH '../../latitude',
                    longitude varchar(50) PATH '../../longitude',
                    address varchar(500) PATH '../../address',
                    infrastructure_parking varchar(20) PATH '../../infrastructure[1]/parking[1]' ,
                    fz_214 varchar(20) PATH 'fz_214',
                    name varchar(255) PATH 'name',
                    floors varchar(10) PATH 'floors[1]',
                    floors_ready varchar(10) PATH 'floors_ready',
                    building_state varchar(100) PATH 'building_state[1]',
                    building_type varchar(50) PATH 'building_type[1]',
                    built_year varchar(20) PATH 'built_year[1]',
                    ready_quarter varchar(20) PATH 'ready_quarter[1]',
                    description_main text PATH '../../description_main[1]/text',
                    description_secondary text PATH '../../description_secondary[1]/text'                )) T );