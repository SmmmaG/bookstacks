INSERT INTO document_advantage as olda (
        id,
        actual,
        create_date,
        version,
        content,
        hash_code)
(SELECT
        uuid_generate_v4() as id,
        true actual,
        now() create_date,
        0 as version,
        a.description_main as content,
        md5(a.description_main) hash_code
FROM
    (SELECT DISTINCT description_main FROM domclick.complexes WHERE description_main IS NOT NULL OR LENGTH (description_main)>0) a)
ON CONFLICT (hash_code) DO UPDATE SET
        actual=true,
        update_date=now(),
        version=olda.version+1;