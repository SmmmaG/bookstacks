INSERT into balcony_type (id,name,create_date,version,code,statistic)
SELECT 
    uuid_generate_v4(),
    TT.balcony,
    now() create_date,
    0,
    'code',
    0
FROM
    (
        SELECT DISTINCT
            balcony
         FROM
            domclick.flats
          WHERE TRIM(balcony) IS NOT NULL) TT
WHERE NOT EXISTS (
        SELECT * FROM balcony_type WHERE lower(name) = lower(balcony));