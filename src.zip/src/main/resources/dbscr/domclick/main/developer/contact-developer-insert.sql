INSERT INTO contact
    (
        id,
        actual,
        create_date,
        version,
        first_name,
        last_name,
        primary_phone,
        website

    )
 SELECT
            uuid_generate_v4() id,
                true actual,
                now() create_date,
                0 as version,
                first_name,
                last_name,
                primary_phone,
                website
                FROM (
                  SELECT DISTINCT
                  'Застройщик 'first_name ,
                  nh.developer_name last_name,
                  nh.developer_phone primary_phone,
                  nh.developer_site website
                  FROM domclick.complexes nh
                    WHERE nh.developer_phone IS NOT NULL AND NOT EXISTS
                      (SELECT id FROM contact WHERE first_name||last_name='Застройщик '||nh.developer_name AND primary_phone = nh.developer_phone))tt;