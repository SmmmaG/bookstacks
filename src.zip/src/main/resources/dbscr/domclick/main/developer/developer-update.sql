UPDATE developer d SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        contact_id=TT.contact_id,
        logo_document_photo_id=TT.logo_document_photo_id
FROM  (
SELECT
        t.id,
        t.version,
        t.contact_id,
        t.logo_document_photo_id
 FROM (
        SELECT
        od.version,
        od.id,
        (SELECT id FROM contact d WHERE d.primary_phone = tt.developer_phone LIMIT 1) contact_id,
        (SELECT id FROM document_photo d WHERE d.url = tt.developer_logo LIMIT 1) logo_document_photo_id
        FROM (SELECT DISTINCT developer_name, developer_logo, developer_phone FROM domclick.complexes) tt
        INNER JOIN developer od ON lower(od.full_name)=lower(tt.developer_name)
        )t)TT
WHERE TT.id=d.id;