UPDATE document_photo ndp SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        url=TT.url,
        state='NEW'
FROM
        (
        SELECT
            odp.id,
            odp.version,
            tnmp.developer_logo url
        FROM
               (SELECT
                      npa.developer_logo,
                      d.logo_document_photo_id
                FROM domclick.complexes npa INNER JOIN developer d ON d.full_name=npa.developer_name) tnmp
        INNER JOIN document_photo odp ON odp.id=tnmp.logo_document_photo_id
        )TT
WHERE TT.id=ndp.id;