  INSERT INTO developer (id,actual,create_date,full_name,contact_id,logo_document_photo_id)
  SELECT
        uuid_generate_v4(),
        true,
        now(),
        developer_name,
        (SELECT id FROM contact d WHERE d.primary_phone = tt.developer_phone LIMIT 1),
        (SELECT id FROM document_photo d WHERE d.url = tt.developer_logo LIMIT 1)
  FROM (SELECT DISTINCT developer_name, developer_logo, developer_phone FROM domclick.complexes) tt
  WHERE NOT EXISTS
        (SELECT id FROM developer WHERE lower(full_name) = lower(tt.developer_name));