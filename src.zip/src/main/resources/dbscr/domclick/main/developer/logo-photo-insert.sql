INSERT INTO document_photo(
        id,
        actual,
        create_date,
        descript,
        name,
        version,
        state,
        url
)
SELECT
    uuid_generate_v4(),
    true actual,
    now() create_date,
    developer_name||' Лого' descript,
    developer_name||' Лого' as name,
    0 as version,
    'NEW' state,
    tnmp.developer_logo url
FROM
 (SELECT
        npa.developer_logo,
        npa.developer_name
  FROM  domclick.complexes npa
       WHERE npa.developer_logo IS NOT NULL OR length(npa.developer_logo)>0) tnmp
WHERE NOT EXISTS
        (SELECT 1 FROM developer f INNER JOIN document_photo dp ON f.logo_document_photo_id = dp.id  WHERE f.full_name =tnmp.developer_name);