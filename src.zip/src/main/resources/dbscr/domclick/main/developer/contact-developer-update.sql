update  contact nb SET
        actual=true,
        update_date=now(),
        version=tt.version+1,
        primary_phone = tt.primary_phone,
        website=tt.website
    FROM (
SELECT DISTINCT
                  s.id,
                  'Застройщик' first_name,
                  nh.developer_name last_name,
                  s.version,
                  nh.developer_phone primary_phone,
                  nh.developer_site website
                  FROM domclick.complexes nh
                    INNER JOIN contact s ON s.first_name||s.last_name = 'Застройщик '||nh.developer_name AND primary_phone = nh.developer_phone
                    WHERE nh.developer_phone IS NOT NULL) tt
     WHERE tt.id=nb.id;