INSERT INTO material_wall_type (
        id,
        name,
        actual,
        create_date,
        version
)
SELECT uuid_generate_v4(),
       name,
       true,
       now(),
       0
FROM
(SELECT DISTINCT b.building_type as name FROM domclick.buildings b WHERE TRIM(b.building_type) IS NOT NULL ) wm
 WHERE NOT EXISTS
        (SELECT id FROM material_wall_type mwt WHERE LOWER(mwt.name) = LOWER(wm.name));