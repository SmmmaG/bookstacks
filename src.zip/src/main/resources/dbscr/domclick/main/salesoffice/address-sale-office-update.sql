UPDATE address a SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        city_id=TT.city_id,
        country_id=TT.country_id,
        district_id=TT.district_id,
        region_id=TT.region_id
FROM  (
SELECT
        t.id,
        t.version,
        city_id,
        country_id ,
        district_id ,
        region_id
 FROM (
        select DISTINCT
         true as actual ,
         tt.address as address_full ,
         oa.version,
         oa.id,
         tt.latitude,
         tt.longitude,
         (SELECT cc.id FROM (SELECT c.id, c.region_id, (SELECT part_content FROM rem_extract_city(c.name)) as name FROM city c) cc
                WHERE cc.name IN (SELECT part_content FROM rem_extract_city(tt.address)) AND tt.region_id=cc.region_id LIMIT 1) as  city_id,
         tt.region_id,
        (SELECT cnt.id FROM country cnt WHERE cnt.code='ru')  country_id,
        (SELECT d.id FROM district d WHERE REPLACE(lower(d.name),' район','')=lower(rem_extract_district(tt.address))
        AND tt.region_id=d.region_id LIMIT 1) as  district_id,
         rem_extract_district(tt.address)
         FROM (SELECT latitude,
                    longitude,
                    sales_phone,
                    responsible_officer_phone,
                    location_timezone,
                    developer_name,
                   COALESCE(address,address_alias) address,
         (SELECT r.id FROM region r WHERE r.name = split_part(COALESCE(address,address_alias),',',1)) as region_id
          FROM domclick.sale_office) tt
        INNER JOIN address oa ON oa.address_full=tt.address AND oa.latitude=tt.latitude AND oa.longitude=tt.longitude AND oa.type=2
        )t  )TT
WHERE TT.id=a.id;