update  contact nb SET
        actual=true,
        update_date=now(),
        version=tt.version+1,
        first_name=tt.first_name,
        last_name=tt.last_name,
        secondary_phone=tt.secondary_phone
    FROM (
            SELECT DISTINCT
                  s.id,
                  'Офис продаж '||rem_trim_empty_if_null(nh.address) first_name,
                  nh.developer_name last_name,
                  s.version,
                  nh.responsible_officer_phone secondary_phone
                  FROM domclick.sale_office nh
                    INNER JOIN contact s ON s.primary_phone = nh.sales_phone AND first_name= 'Офис продаж '||rem_trim_empty_if_null(nh.address)
                    WHERE nh.sales_phone IS NOT NULL) tt
     WHERE tt.id=nb.id;