INSERT INTO sales_office
    (
        id,
        actual,
        create_date,
        version,
        name,
        seller_id,
        address_id,
        contact_id

    )
    SELECT
                uuid_generate_v4() id,
                true actual,
                now() create_date,
                0 as version,
                tt.name,
                tt.seller_id,
                tt.address_id,
                tt.contact_id
                FROM (
                  SELECT DISTINCT
                  nh.developer_name as name,
                 (SELECT r.id FROM seller r WHERE r.name = nh.developer_name LIMIT 1) seller_id,
                 (SELECT r.id FROM address r WHERE r.address_full = COALESCE(nh.address,nh.address_alias) AND r.type=2 LIMIT 1) address_id,
                 (SELECT a.id FROM contact a WHERE a.primary_phone=nh.sales_phone LIMIT 1) contact_id
                    FROM domclick.sale_office nh
                    WHERE NOT EXISTS
                      (SELECT id FROM sales_office WHERE name = nh.developer_name AND address_id IN
                        (SELECT r.id FROM address r WHERE r.address_full = COALESCE(nh.address,nh.address_alias) AND r.type=2)))tt;