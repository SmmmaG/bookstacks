update  sales_office nb SET
        actual=true,
        update_date=now(),
        version=tt.version+1,
        address_id = tt.address_id,
        contact_id = tt.contact_id
    FROM (
            SELECT
                id,
                true actual,
                now() create_date,
                t.version,
                t.address_id,
                t.contact_id
                FROM (
                  SELECT DISTINCT
                  s.id,
                  s.version,
                  COALESCE(nh.address,nh.address_alias) ,
                 (SELECT r.id FROM address r WHERE r.address_full = COALESCE(nh.address,nh.address_alias) AND r.type=2 LIMIT 1) address_id,
                 (SELECT a.id FROM contact a WHERE a.primary_phone=nh.sales_phone LIMIT 1) contact_id
                    FROM domclick.sale_office nh
                    INNER JOIN sales_office s ON s.seller_id IN (SELECT r.id FROM seller r WHERE r.name = nh.developer_name)
                    AND address_id = (SELECT a.id FROM address a WHERE a.address_full=COALESCE(nh.address,nh.address_alias) AND a.type=2 LIMIT 1))t) tt
     WHERE tt.id=nb.id;