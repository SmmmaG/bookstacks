INSERT INTO seller_building
    (
        building_id,
        sales_office_id

    )
SELECT DISTINCT b.id building_id, so.id sales_office_id
                    FROM building b JOIN complex c ON b.complex_id = c.id
                    JOIN cross_identity_complex ci ON ci.object_id=c.id
                    JOIN domclick.sale_office_complex dc ON dc.complex_id=ci.code AND  ci.feed_id='?'
                    JOIN cross_identity_building cb ON cb.object_id=b.id
                    JOIN domclick.buildings db ON cb.code=db.custom_id
                    JOIN sales_office so ON  so.name=dc.developer_name AND so.address_id IN
                    (SELECT a.id FROM address a WHERE a.address_full=COALESCE(dc.address,dc.address_alias));