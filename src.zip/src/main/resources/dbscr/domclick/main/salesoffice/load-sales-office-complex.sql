CREATE TABLE ?schema?.sale_office_complex AS (
SELECT
uuid_generate_v4() AS UUID,
rem_trim(complex_id) complex_id,
rem_clean_complex_name(rem_trim(complex_name)) complex_name,
CASE WHEN address like '' THEN null ELSE rem_trim(address) END address,
CASE WHEN address_alias like '' THEN null ELSE rem_trim(address_alias) END address_alias,
CASE WHEN REPLACE(rem_trim_numbers(latitude), ',', '.')::decimal != 0 THEN REPLACE(rem_trim_numbers(latitude), ',', '.')::decimal
    ELSE NULL END                                                       latitude,
CASE WHEN  REPLACE(rem_trim_numbers(longitude), ',', '.')::decimal != 0 THEN  REPLACE(rem_trim_numbers(longitude), ',', '.')::decimal
    ELSE NULL END                                                       longitude,
CASE WHEN developer_name like '' THEN null ELSE developer_name END developer_name
FROM (
SELECT  DISTINCT
xmltable.*
  FROM (SELECT convert_from(lo_get(cast(ff.file as bigint)),'UTF-8') as file FROM feed_log f JOIN feed_log_file ff ON ff.id=f.file_id WHERE f.id='?') tt,
       XMLTABLE ('//sales_info[1]' PASSING CAST(file AS XML)
                 COLUMNS
                    complex_id varchar(20) PATH '../id',
                    complex_name varchar(500) PATH '../name',
                    address  varchar(150) PATH 'sales_address' ,
                    address_alias  varchar(150) PATH 'address' ,
                    latitude varchar(50) PATH 'sales_latitude',
                    longitude varchar(50) PATH 'sales_longitude',
                    developer_name varchar(100) PATH '../developer[1]/name')) ttt);