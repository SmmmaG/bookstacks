INSERT INTO seller
    (
        id,
        actual,
        create_date,
        version,
        name,
        developer_id,
        address_id,
        contact_id

    )
    SELECT
                uuid_generate_v4() id,
                true actual,
                now() create_date,
                0 as version,
                tt.seller_name,
                tt.developer_id,
                tt.address_id,
                tt.contact_id
                FROM (
                  SELECT DISTINCT
                  nh.developer_name seller_name,
                 (SELECT r.id FROM developer r WHERE lower(r.full_name) = lower(nh.developer_name) LIMIT 1) developer_id,
                 (SELECT r.legal_address_id FROM developer r WHERE r.full_name = nh.developer_name LIMIT 1) address_id,
                 (SELECT a.id FROM contact a WHERE a.primary_phone=nh.sales_phone LIMIT 1) contact_id
                    FROM domclick.sale_office nh
                    WHERE NOT EXISTS
                      (SELECT id FROM seller WHERE lower(name) = lower(nh.developer_name)))tt;