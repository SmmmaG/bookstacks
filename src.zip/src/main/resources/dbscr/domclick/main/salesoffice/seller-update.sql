update  seller nb SET
        actual=true,
        update_date=now(),
        version=tt.version+1,
        developer_id=tt.developer_id,
        address_id = tt.address_id,
        contact_id = tt.contact_id
    FROM (
            SELECT
                id,
                true actual,
                now() create_date,
                t.version,
                t.seller_name,
                t.developer_id,
                t.address_id,
                t.contact_id
                FROM (
                  SELECT DISTINCT
                  s.id,
                  s.version,
                  nh.developer_name seller_name,
                 (SELECT r.id FROM developer r WHERE lower(r.full_name) = lower(nh.developer_name) LIMIT 1) developer_id,
                 (SELECT r.legal_address_id FROM developer r WHERE r.full_name = nh.developer_name LIMIT 1) address_id,
                 (SELECT a.id FROM contact a WHERE a.primary_phone=nh.sales_phone LIMIT 1) contact_id
                    FROM domclick.sale_office nh
                    INNER JOIN seller s ON lower(s.name) = lower(nh.developer_name))t) tt
     WHERE tt.id=nb.id;