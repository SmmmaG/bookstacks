INSERT INTO contact
    (
        id,
        actual,
        create_date,
        version,
        first_name,
        last_name,
        primary_phone,
        secondary_phone

    )
    SELECT
                uuid_generate_v4() id,
                true actual,
                now() create_date,
                0 as version,
                first_name,
                last_name,
                primary_phone,
                secondary_phone
                FROM (
                  SELECT DISTINCT
                  'Офис продаж '||rem_trim_empty_if_null(nh.address) first_name,
                  nh.developer_name last_name,
                  nh.sales_phone primary_phone,
                  nh.responsible_officer_phone secondary_phone
                  FROM domclick.sale_office nh
                    WHERE nh.sales_phone IS NOT NULL AND NOT EXISTS
                      (SELECT id FROM contact WHERE primary_phone = nh.sales_phone AND
                        first_name='Офис продаж '||rem_trim_empty_if_null(nh.address)))tt;