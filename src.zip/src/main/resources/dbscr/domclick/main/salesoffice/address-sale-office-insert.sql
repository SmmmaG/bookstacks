INSERT INTO address (
        id,
        type,
        actual,
        create_date ,
        version,
        address_full ,
        latitude,
        longitude,
        city_id,
        country_id ,
        district_id ,
        region_id
        )

SELECT  uuid_generate_v4() as id,
        type,
        actual,
        create_date ,
        version,
        address_full ,
        latitude,
        longitude,
        city_id,
        country_id ,
        district_id ,
        region_id
 FROM (
        select DISTINCT 2 as type,
         true as actual ,
         now() create_date,
         0 as version,
         tt.address as address_full ,
         latitude,
         longitude,
         (SELECT cc.id FROM (SELECT c.id, c.region_id, (SELECT part_content FROM rem_extract_city(c.name)) as name FROM city c) cc
                WHERE cc.name IN (SELECT part_content FROM rem_extract_city(tt.address)) AND tt.region_id=cc.region_id LIMIT 1) as  city_id,
        (SELECT cnt.id FROM country cnt WHERE cnt.code='ru')  country_id,
        (SELECT d.id FROM district d WHERE REPLACE(lower(d.name),' район','')=lower(rem_extract_district(tt.address))
        AND tt.region_id=d.region_id LIMIT 1) as  district_id,
        region_id
         FROM (SELECT latitude,
                    longitude,
                    sales_phone,
                    responsible_officer_phone,
                    location_timezone,
                    developer_name,
                   COALESCE(address,address_alias) address,
         (SELECT r.id FROM region r WHERE r.name = split_part(COALESCE(address,address_alias),',',1)) as region_id
          FROM domclick.sale_office) tt
        WHERE NOT EXISTS
        (SELECT id FROM address WHERE address_full = tt.address AND latitude=tt.latitude AND longitude=tt.longitude AND type=2)
        ) ttt;