INSERT INTO infrastructure(
        id,
        actual,
        create_date,
        version,
        has_parking,
        has_security_service,
        has_fenced_area,
        has_sports_ground,
        has_play_ground,
        has_school,
        has_kindergarten

)
SELECT
    tnmp.id id,
    true actual,
    now() create_date,
    0 as version,
    tnmp.has_parking,
    tnmp.has_security_service,
    tnmp.has_fenced_area,
    tnmp.has_sports_ground,
    tnmp.has_play_ground,
    tnmp.has_school,
    tnmp.has_kindergarten

FROM
    (SELECT
         tmp.infrastructure_id id,
                (SELECT (CASE WHEN infrastructure_parking IS NOT NULL THEN true ELSE false END) has_parking FROM domclick.complexes dc JOIN cross_identity_complex cic ON dc.id =cic.code WHERE cic.object_id=c.id AND cic.feed_id='?'),
                (SELECT infrastructure_security has_security_service FROM domclick.complexes dc JOIN cross_identity_complex cic ON dc.id =cic.code WHERE cic.object_id=c.id AND cic.feed_id='?'),
                (SELECT infrastructure_fenced_area has_fenced_area FROM domclick.complexes dc JOIN cross_identity_complex cic ON dc.id =cic.code WHERE cic.object_id=c.id AND cic.feed_id='?'),
                (SELECT infrastructure_sports_ground has_sports_ground FROM domclick.complexes dc JOIN cross_identity_complex cic ON dc.id =cic.code WHERE cic.object_id=c.id AND cic.feed_id='?'),
                (SELECT infrastructure_playground has_play_ground FROM domclick.complexes dc JOIN cross_identity_complex cic ON dc.id =cic.code WHERE cic.object_id=c.id AND cic.feed_id='?'),
                (SELECT infrastructure_school has_school FROM domclick.complexes dc JOIN cross_identity_complex cic ON dc.id =cic.code WHERE cic.object_id=c.id AND cic.feed_id='?'),
                (SELECT infrastructure_kindergarten has_kindergarten FROM domclick.complexes dc JOIN cross_identity_complex cic ON dc.id =cic.code WHERE cic.object_id=c.id AND cic.feed_id='?')
    FROM tmp_domclick_complex_infrastructure tmp
    INNER JOIN complex c ON c.id=tmp.complex_id
    WHERE c.infrastructure_id IS NULL) tnmp;