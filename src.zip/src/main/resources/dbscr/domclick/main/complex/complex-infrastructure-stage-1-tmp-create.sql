CREATE TEMP TABLE tmp_domclick_complex_infrastructure (
infrastructure_id uuid,
complex_id uuid );

INSERT
INTO
  tmp_domclick_complex_infrastructure
    (
        infrastructure_id,
        complex_id
    )
SELECT
    uuid_generate_v4() infrastructure_id,
    (SELECT object_id complex_id FROM cross_identity_complex cib WHERE code=nmc.id
            AND feed_id='?')
FROM  domclick.complexes nmc;

--Дизактуализация старых инфраструктур комплексов
UPDATE  infrastructure SET actual=false WHERE id IN (SELECT infrastructure_id FROM complex c WHERE c.id IN (SELECT complex_id FROM tmp_domclick_complex_infrastructure) ) AND actual=true;
