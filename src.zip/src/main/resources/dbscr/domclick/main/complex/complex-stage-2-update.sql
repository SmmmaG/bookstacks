
UPDATE complex c SET
        actual=true,
        update_date=now(),
        version=TT.version+1,
        name=TT.name,
        code=TT.code,
        is_done=TT.is_done,
        end_year=TT.end_year,
        end_quarter=TT.end_quarter,
        developer_id=TT.developer_id,
        address_id=TT.address_id,
        document_advantage_id=TT.document_advantage_id
FROM (
SELECT
        oc.id,
        oc.version,
        nmc.namen as name,
        rem_translit(nmc.namen) code,
        (CASE WHEN (SELECT SUM(CASE WHEN building_state ='hand_over' THEN 1 ELSE 0 END) FROM domclick.buildings b WHERE b.complex_id::uuid=nmc.uuid GROUP BY b.complex_id) > 0 THEN true ELSE false END)::boolean is_done,
        (SELECT bb.built_year FROM domclick.buildings bb WHERE bb.complex_id::uuid=nmc.uuid ORDER BY bb.built_year, bb.ready_quarter  LIMIT 1) end_year,
        (SELECT bb.ready_quarter FROM domclick.buildings bb WHERE bb.complex_id::uuid=nmc.uuid ORDER BY bb.built_year, bb.ready_quarter LIMIT 1) end_quarter,
        (SELECT d.id FROM developer d WHERE lower(d.full_name)=lower(nmc.developer_name) LIMIT 1) developer_id,
        (SELECT a.id FROM address a WHERE  nmc.address=a.address_full AND nmc.latitude = a.latitude AND nmc.longitude = a.longitude AND a.type=1) address_id,
        (SELECT a.id FROM document_advantage a WHERE a.content=nmc.description_main LIMIT 1) document_advantage_id
        FROM domclick.complexes nmc

        INNER JOIN complex oc
        ON oc.id = ( SELECT object_id FROM cross_identity_complex WHERE code=nmc.id AND feed_id='?')
 ) TT
WHERE TT.id=c.id;