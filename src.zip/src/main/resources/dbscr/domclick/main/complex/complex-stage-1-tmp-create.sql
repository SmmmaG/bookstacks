--DROP TABLE tmp_complex_cross;

CREATE TEMP TABLE tmp_domclick_complex_cross (
complex_id uuid,
complex_name varchar(500),
domclick_complex varchar(255));

INSERT
INTO
    tmp_domclick_complex_cross
    (
        complex_id,
        complex_name,
        domclick_complex
    )
SELECT
    uuid_generate_v4() complex_id,
    c.namen complex_name,
    c.id domclick_complex
FROM  domclick.complexes c;
