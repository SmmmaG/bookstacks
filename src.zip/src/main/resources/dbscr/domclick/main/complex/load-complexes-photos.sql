CREATE TABLE ?schema?.complexes_photos AS (
SELECT
uuid_generate_v4() AS id,
rem_trim(parent_id) parent_id,
rem_trim_url(url) url
  FROM (SELECT convert_from(lo_get(cast(ff.file as bigint)),'UTF-8') as file FROM feed_log f JOIN feed_log_file ff ON ff.id=f.file_id WHERE f.id='?') tt,
       XMLTABLE ('//images/image' PASSING CAST(file AS XML)
                 COLUMNS
                    parent_id varchar(255) PATH '../../id',
                    url varchar(1000) PATH '.' NOT NULL));