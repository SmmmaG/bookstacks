INSERT INTO cross_identity_complex (id,actual,create_date,version,code,object_id,feed_id)
  SELECT
      uuid_generate_v4(),
      true,
      now() create_date,
      0,
      nc.id,
      c.id,
      '?' sourceid
   FROM domclick.complexes nc
   INNER JOIN complex c ON c.id=(SELECT complex_id FROM tmp_domclick_complex_cross WHERE domclick_complex=nc.id AND complex_name = nc.namen)
   WHERE NOT EXISTS
        ( SELECT * FROM cross_identity_complex WHERE code=nc.id AND feed_id='?');
