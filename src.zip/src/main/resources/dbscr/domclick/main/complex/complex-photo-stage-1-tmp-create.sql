CREATE TEMP TABLE tmp_domclick_complex_document_photo (
complex_id uuid,
document_photo_id uuid,
domclick_photo_id uuid );

INSERT
INTO
    tmp_domclick_complex_document_photo
    (
        complex_id,
        document_photo_id,
        domclick_photo_id
    )
SELECT
    ( SELECT ic.object_id FROM cross_identity_complex ic
                          WHERE ic.code=nmp.parent_id
                          AND ic.feed_id='?') complex_id,
    uuid_generate_v4() document_photo_id,
    nmp.id domclick_photo_id
FROM
    (SELECT complexes_photos.id, complexes_photos.parent_id FROM domclick.complexes_photos WHERE complexes_photos.url IS NOT NULL) nmp;

UPDATE document_photo SET actual=false WHERE id in
(SELECT document_photo_id FROM complex_document_photo WHERE complex_id in (SELECT object_id FROM cross_identity_complex WHERE feed_id='?') )
AND actual=true;