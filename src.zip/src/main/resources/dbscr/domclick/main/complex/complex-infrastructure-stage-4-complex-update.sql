UPDATE complex c SET infrastructure_id=i.infrastructure_id
FROM (SELECT tmp.infrastructure_id, tmp.complex_id FROM tmp_domclick_complex_infrastructure tmp) i
WHERE i.complex_id=c.id AND c.infrastructure_id IS NULL;