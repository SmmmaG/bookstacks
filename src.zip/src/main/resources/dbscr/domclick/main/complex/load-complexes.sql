CREATE TABLE ?schema?.complexes AS (
SELECT
uuid_generate_v4() AS UUID,
                    rem_trim(id) id,
                    rem_clean_complex_name(rem_trim(namen)) namen,
                    CASE WHEN REPLACE(rem_trim_numbers(latitude), ',', '.')::decimal != 0 THEN REPLACE(rem_trim_numbers(latitude), ',', '.')::decimal
                        ELSE NULL END                                                       latitude,
                    CASE WHEN  REPLACE(rem_trim_numbers(longitude), ',', '.')::decimal != 0 THEN  REPLACE(rem_trim_numbers(longitude), ',', '.')::decimal
                        ELSE NULL END                                                       longitude,
                    CASE WHEN rem_trim(address) IS NULL
                     THEN null
--                      CASE WHEN (building_address ~* 'г\.|ул\.|улиц|проспект|набережная|наб\.|пос\.|поселок|село|с\.|д\.|дом|корпус|к\.|корп\.') THEN building_address ELSE null END
                     ELSE rem_trim(address) END address,
                    (CASE WHEN description_main like '' THEN null ELSE rem_remove_html(description_main) END) || (CASE WHEN description_secondary is null THEN '' ELSE chr(10)||rem_remove_html(description_secondary) END) description_main,
                    CASE WHEN infrastructure_parking IS NOT NULL AND length(infrastructure_parking)=0 THEN null ELSE infrastructure_parking::varchar(20) END infrastructure_parking,
                    CASE WHEN infrastructure_security IS NOT NULL AND length(infrastructure_security)=0 THEN null ELSE           REPLACE(REPLACE(REPLACE(REPLACE(lower(infrastructure_security)         ,'да','true'),'нет','false'),'-','false'),'+','true')::boolean END infrastructure_security,
                    CASE WHEN infrastructure_fenced_area  IS NOT NULL AND length( infrastructure_fenced_area)=0 THEN null ELSE   REPLACE(REPLACE(REPLACE(REPLACE(lower( infrastructure_fenced_area )    ,'да','true'),'нет','false'),'-','false'),'+','true')::boolean END  infrastructure_fenced_area ,
                    CASE WHEN infrastructure_sports_ground IS NOT NULL AND length(infrastructure_sports_ground)=0 THEN null ELSE REPLACE(REPLACE(REPLACE(REPLACE(lower( infrastructure_sports_ground )  ,'да','true'),'нет','false'),'-','false'),'+','true') ::boolean END infrastructure_sports_ground,
                    CASE WHEN infrastructure_playground IS NOT NULL AND length(infrastructure_playground)=0 THEN null ELSE       REPLACE(REPLACE(REPLACE(REPLACE(lower( infrastructure_playground  )    ,'да','true'),'нет','false'),'-','false'),'+','true') ::boolean END infrastructure_playground,
                    CASE WHEN infrastructure_school  IS NOT NULL AND length(infrastructure_school )=0 THEN null ELSE             REPLACE(REPLACE(REPLACE(REPLACE(lower( infrastructure_school)          ,'да','true'),'нет','false'),'-','false'),'+','true')   ::boolean END infrastructure_school ,
                    CASE WHEN infrastructure_kindergarten IS NOT NULL AND length(infrastructure_kindergarten)=0 THEN null ELSE   REPLACE(REPLACE(REPLACE(REPLACE(lower( infrastructure_kindergarten )   ,'да','true'),'нет','false'),'-','false'),'+','true') ::boolean END infrastructure_kindergarten,
                    rem_trim(developer_id) developer_id ,
                    rem_trim(developer_name) developer_name ,
                    CASE WHEN rem_trim(developer_phone) IS NULL THEN null ELSE SPLIT_PART(SPLIT_PART(developer_phone,';',1),',',1) END developer_phone,
                    rem_trim(developer_site) developer_site ,
                    CASE WHEN rem_trim_url(developer_logo) like '' THEN null ELSE rem_trim_url(developer_logo) END developer_logo ,
                    rem_trim(project) project
  FROM (SELECT convert_from(lo_get(cast(ff.file as bigint)),'UTF-8') as file FROM feed_log f JOIN feed_log_file ff ON ff.id=f.file_id WHERE f.id='?') tt,
       XMLTABLE ('/complexes/complex' PASSING CAST(file AS XML)
                 COLUMNS

                    id varchar(255) PATH 'id',
                    namen  varchar(255) PATH 'name',
                    latitude varchar(50) PATH 'latitude',
                    longitude varchar(50) PATH 'longitude',
                    address varchar(500) PATH 'address',
--                    building_address varchar(500) PATH 'buildings/building[1]/name',
                    description_main text PATH 'description_main[1]/text' ,
                    description_secondary text PATH 'description_secondary[1]/text' ,
                    infrastructure_parking varchar(20) PATH 'infrastructure[1]/parking[1]' ,
                    infrastructure_security varchar(20) PATH 'infrastructure[1]/security' ,
                    infrastructure_fenced_area varchar(20) PATH 'infrastructure[1]/fenced_area' ,
                    infrastructure_sports_ground varchar(20) PATH 'infrastructure[1]/sports_ground' ,
                    infrastructure_playground varchar(20) PATH 'infrastructure[1]/playground' ,
                    infrastructure_school varchar(20) PATH 'infrastructure[1]/school' ,
                    infrastructure_kindergarten varchar(20) PATH 'infrastructure[1]/kindergarten' ,
                    developer_id varchar(20) PATH 'developer[1]/id',
                    developer_name varchar(255) PATH 'developer[1]/name',
                    developer_phone varchar(200) PATH 'developer[1]/phone',
                    developer_site varchar(1000) PATH 'developer[1]/site' ,
                    developer_logo varchar(1000) PATH 'developer[1]/logo' ,
                    project varchar(100) PATH 'project'));