INSERT INTO complex
(id, name, code, is_done,end_year,end_quarter,actual,create_date,version,developer_id,address_id,document_advantage_id)
SELECT
        (SELECT tm.complex_id FROM tmp_domclick_complex_cross tm WHERE tm.domclick_complex=nmc.id AND tm.complex_name=nmc.namen) as id,
         nmc.namen as name,
        rem_translit(nmc.namen) code,
        (CASE WHEN (SELECT SUM(CASE WHEN building_state ='hand_over' THEN 1 ELSE 0 END) FROM domclick.buildings b WHERE b.complex_id::uuid=nmc.uuid GROUP BY b.complex_id) > 0 THEN true ELSE false END) is_done,
        (SELECT bb.built_year FROM domclick.buildings bb WHERE bb.complex_id::uuid=nmc.uuid ORDER BY bb.built_year DESC, bb.ready_quarter  LIMIT 1) end_year,
        (SELECT bb.ready_quarter FROM domclick.buildings bb WHERE bb.complex_id::uuid=nmc.uuid ORDER BY bb.built_year DESC, bb.ready_quarter LIMIT 1) end_quarter,
        true ,
        now() ,
        0 as version,
        (SELECT d.id FROM developer d WHERE lower(d.full_name)=lower(nmc.developer_name) LIMIT 1) developer_id,
        (SELECT a.id FROM address a WHERE  nmc.address=a.address_full AND nmc.latitude = a.latitude AND nmc.longitude = a.longitude AND a.type=1) address_id,
        (SELECT a.id FROM document_advantage a WHERE a.content=nmc.description_main LIMIT 1) document_advantage_id
        FROM domclick.complexes nmc

WHERE NOT EXISTS
        ( SELECT object_id FROM cross_identity_complex WHERE code=nmc.id AND feed_id='?');


