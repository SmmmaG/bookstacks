UPDATE balcony_type
SET
    actual=true,
    update_date=now(),
    version=TT.version+1
FROM 
(
        SELECT DISTINCT
            domclick.flats.balcony,
            bt.version "version"
         FROM
            domclick.flats
         INNER JOIN balcony_type bt ON lower(bt.name)=lower(domclick.flats.balcony) ) TT
WHERE TT.balcony=name;