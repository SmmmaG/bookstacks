CREATE TABLE tmp_domclick_feed ( id uuid NOT NULL, url varchar(1000) NOT NULL, name varchar(100) NOT NULL, PRIMARY KEY (id) );
ALTER TABLE tmp_domclick_feed ADD COLUMN code varchar(50);
ALTER TABLE tmp_domclick_feed ADD COLUMN code_supplier varchar(50);
ALTER TABLE feed ALTER COLUMN code TYPE character varying(50);
ALTER TABLE tmp_domclick_feed ALTER COLUMN name DROP NOT NULL;


insert into supplier (id,actual, create_date, version, code, name, descript,supplier.supplier_type) values(uuid_generate_v4(), true, now(), 0, 'dmc_donstroy', 'ГК Донстрой' ,'ГК Донстрой',1);

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier, code) values(uuid_generate_v4(), 'https://wd.ingrad.ru/feeds/DC.xml', 'ГК ИНГРАД', 'gk-ingrad',null);
INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://www.otrada-kvartal.xyz/ContentOLD/xml/domClick/', 'Отрада Девелопмент', 'otrada-development',null);
INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://crm.mgcpn.ru:8050/Export.svc/To/DomClick', 'Центр инвест','center-invest', null);
INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'https://spb.yesapart.ru/apart_manager/get_feed/living/domclick', 'Yes','yes', 'apart');
INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'https://yesresidence.ru/apart_manager/get_feed/living/domclick', 'Yes', 'yes', 'residence');
INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'https://lesnaya.life/apart_manager/get_feed/living/domclick', 'Life', 'life','lesnaya');
INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'https://primorskiy.life/apart_manager/get_feed/living/domclick', 'Life', 'life','primorskiy');

TRUNCATE TABLE tmp_domclick_feed;

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_502.xml','ГК Донстрой','dmc_donstroy', '502');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_668.xml','ГК Донстрой','dmc_donstroy', '668');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_695.xml','ГК Донстрой','dmc_donstroy', '695');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_453.xml','ГК Донстрой','dmc_donstroy', '453');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_503.xml','ГК Донстрой','dmc_donstroy', '503');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_452.xml','ГК Донстрой','dmc_donstroy', '452');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_448.xml','ГК Донстрой','dmc_donstroy', '448');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_38.xml','ГК Донстрой','dmc_donstroy', '38');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_916.xml','ГК Донстрой','dmc_donstroy', '916');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_450.xml','ГК Донстрой','dmc_donstroy', '450');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_451.xml','ГК Донстрой','dmc_donstroy', '451');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_863.xml','ГК Донстрой','dmc_donstroy', '863');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_600.xml','ГК Донстрой','dmc_donstroy', '600');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_447.xml','ГК Донстрой','dmc_donstroy', '447');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_420.xml','ГК Донстрой','dmc_donstroy', '420');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_947.xml','ГК Донстрой','dmc_donstroy', '947');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_449.xml','ГК Донстрой','dmc_donstroy', '449');

INSERT INTO tmp_domclick_feed (id,url,name,code_supplier,code) values(uuid_generate_v4(), 'http://na100.pro/dmc_donstroy_421.xml','ГК Донстрой','dmc_donstroy', '421');


UPDATE tmp_domclick_feed SET name = 'ГК Донстрой'




INSERT INTO supplier (
id,
actual,
create_date,
version,
supplier_type,
code,
descript,
name,
statistic)
SELECT uuid_generate_v4(),
tt.* FROM (
SELECT DISTINCT
true,
current_date,
0,
1,
code_supplier,
"name",
name,
0
FROM tmp_domclick_feed d)tt


INSERT
INTO
    feed
    (
        id,
        actual,
        create_date,
        update_date,
        version,
        frequency,
        url,
        feed_handler_id,
        supplier_id,
        code,
        name,
        statistic,
        active,
        descript,
        status_id,
        upload_date
    )
    
    SELECT 
    uuid_generate_v4(),
    true,
        current_date,
        null,
        0,
        0,
        url,
        '278c929a-5913-f21c-1071-dc382eac4a5a',
        (SELECT id FROM supplier WHERE code=d.code_supplier),
        code_supplier||COALESCE('-'||code,'')||'-domclick',
        'ДомКлик '||d.name||COALESCE('-'||code,''),
        0,
        false,
        'ДомКлик '||d.name||COALESCE('-'||code,''),
        null,
        null
        
    FROM tmp_domclick_feed d;
    