--Дизактуализация зданий
UPDATE building b SET actual =false WHERE b.actual = true AND b.id IN (SELECT object_id FROM cross_identity_building WHERE feed_id='?');

--Дизактуализация адресов зданий
--UPDATE address SET actual=false WHERE actual = true AND address.type = 2;

--Дизактуализация связей банков и зданий
UPDATE bank_building b SET actual =false WHERE b.actual = true AND b.building_id IN (SELECT object_id FROM cross_identity_building WHERE feed_id='?');

--Дизактуализация статистики по зданиям
UPDATE building_statistic b SET actual =false WHERE b.actual = true AND b.building_id IN (SELECT object_id FROM cross_identity_building WHERE feed_id='?');

--Дизактуализация связей зданий с офисами продаж
DELETE FROM seller_building WHERE building_id IN (SELECT cr.object_id FROM cross_identity_building cr WHERE feed_id='?');

--Перемещение статистики по зданиям в историю
INSERT
INTO
    building_statistic_h
    (
        id,
        actual,
        create_date,
        update_date,
        remove_date,
        version,
        area_max_amount,
        area_min_amount,
        count_object,
        price_max_amount,
        price_min_amount,
        building_id,
        count_active_object,
        count_room_type,
        price_max_area,
        price_min_area
    )
   SELECT
           id,
        actual,
        create_date,
        update_date,
        now(),
        version,
        area_max_amount,
        area_min_amount,
        count_object,
        price_max_amount,
        price_min_amount,
        building_id,
        count_active_object,
        count_room_type,
        price_max_area,
        price_min_area
    FROM building_statistic
        WHERE building_statistic.actual=false;


  DELETE FROM building_statistic WHERE building_statistic.actual=false;


--Дизактуализация комплексов
UPDATE complex c SET actual =false WHERE c.actual = true AND c.id IN (SELECT object_id FROM cross_identity_complex WHERE feed_id='?');

DELETE FROM gis.complex WHERE gid IN (SELECT c.id FROM complex c WHERE c.id IN (SELECT object_id FROM cross_identity_complex WHERE feed_id='?'));

--Дизактуализация адресов комплексов
--UPDATE address a SET actual=false WHERE a.actual = true AND a.id IN (SELECT DISTINCT address_id FROM complex WHERE id IN (SELECT object_id FROM cross_identity_complex WHERE feed_id='1a238d2c-1508-ee78-cb14-d5b3bc8a1618'));

--Дизактуализация статистики по комплексам
UPDATE complex_statistic c SET actual =false WHERE c.actual = true AND c.id IN (SELECT complex_statistic_id FROM complex where id IN (SELECT object_id FROM cross_identity_complex WHERE feed_id='?'));


--Дизактуализация квартир
UPDATE flat f SET actual =false WHERE f.actual = true AND f.id IN (SELECT object_id FROM cross_identity_flat WHERE feed_id='?');

--Дизактуализация цен на квартиры
UPDATE price p SET actual =false WHERE p.actual = true AND p.id IN (SELECT price_id FROM flat WHERE id IN (SELECT object_id FROM cross_identity_flat WHERE feed_id='?'));

--Перемещение старых цен квартир в историю
INSERT
INTO
    price_h
    (
        id,
        actual,
        create_date,
        update_date,
        version,
        amount,
        amount_update_date,
        base_amount,
        min_amount,
        currency_type_id,
        flat_id,
        remove_date
    )
   SELECT
        p.id,
        p.actual,
        p.create_date,
        p.update_date,
        p.version,
        p.amount,
        p.amount_update_date,
        p.base_amount,
        p.min_amount,
        p.currency_type_id,
        f.id flat_id,
        p.create_date
    FROM price p
    JOIN flat f ON f.price_id=p.id
        WHERE p.actual=false
        AND p.min_amount != COALESCE((SELECT hh.min_amount FROM price_h hh WHERE hh.flat_id=f.id ORDER BY COALESCE(hh.update_date,hh.create_date) DESC LIMIT 1),999999999999);

--Удаление старых цен
UPDATE flat f SET price_id = NULL WHERE f.id IN (SELECT object_id FROM cross_identity_flat WHERE feed_id='?');
DELETE FROM price WHERE actual=false;

--Дизактуализация типов балконов
--UPDATE balcony_type SET actual =false WHERE actual = true;

--Дизактуализация районов
--UPDATE district SET actual =false WHERE actual = true;

--Дизактуализация банков
--UPDATE bank SET actual =false WHERE actual = true;

--Дизактуализация статусов квартир
--UPDATE status SET actual =false WHERE actual = true AND type='2';

--Дизактуализация материалов стен зданий
--UPDATE material_wall_type SET actual=false WHERE actual=true;

--Дизактуализация застройщиков
--UPDATE developer SET actual =false WHERE actual = true;

--Дизактуализация типов отделки
--UPDATE decoration_type SET actual =false WHERE actual = true;

--Дизактуализация типов зданий
--UPDATE building_type SET actual =false WHERE actual = true;