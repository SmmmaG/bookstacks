update region r set fias_code=(select a.AOGUID::uuid from fias.fias_addressobjects a
where a.aolevel=1 AND lower(r."name") like '%'||split_part(lower(a.formalname),' ',1)||'%' limit 1)
where r.fias_code is null;
