update fias.fias_addressobjects ad
set address = fias.fsfn_addressobjects_treeactualname(ad.aoguid),
    regionid = (select rtf_aoguid from fias.fstf_addressobjects_addressobjecttree(ad.aoguid) where rtf_aolevel=1),
    cityid = (select rtf_aoguid from fias.fstf_addressobjects_addressobjecttree(ad.aoguid) where rtf_aolevel in (4,6,35)
    ORDER BY rtf_aolevel DESC  LIMIT 1)
where  ad.aolevel = ?;