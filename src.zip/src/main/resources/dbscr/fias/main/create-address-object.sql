--DROP   TABLE IF EXISTS fias.fias_addressobjects_temp;
--DROP   TABLE IF EXISTS fias.fias_DeletedAddressObjects_temp;

/*CREATE   TABLE IF NOT EXISTS fias.fias_addressobjects_temp(
  AOID      VARCHAR(36) NOT NULL,
  PREVID   VARCHAR(36) NULL,
  NEXTID   VARCHAR(36) NULL,
  AOGUID   VARCHAR(36) NOT NULL,
  PARENTGUID   VARCHAR(36) NULL,
  FORMALNAME   VARCHAR(120) NULL,
  SHORTNAME   VARCHAR(10) NULL,
  OFFNAME      VARCHAR(120) NULL,
  POSTALCODE   VARCHAR(6) NULL,
  OKATO      VARCHAR(11) NULL,
  OKTMO      VARCHAR(11) NULL,
  AOLEVEL      INTEGER NULL,
  REGIONCODE   VARCHAR(2) NULL,
  AUTOCODE   VARCHAR(1) NULL,
  AREACODE   VARCHAR(3) NULL,
  CITYCODE   VARCHAR(3) NULL,
  CTARCODE   VARCHAR(3) NULL,
  PLACECODE   VARCHAR(3) NULL,
  STREETCODE   VARCHAR(4) NULL,
  EXTRCODE   VARCHAR(4) NULL,
  SEXTCODE   VARCHAR(3) NULL,
  CODE      VARCHAR(17) NULL,
  PLAINCODE   VARCHAR(15) NULL,
  CURRSTATUS   INTEGER NULL,
  IFNSFL   VARCHAR(4) NULL,
  TERRIFNSFL   VARCHAR(4) NULL,
  IFNSUL   VARCHAR(4) NULL,
  TERRIFNSUL   VARCHAR(4) NULL,
  ACTSTATUS   INTEGER NULL,
  CENTSTATUS   INTEGER NULL,
  STARTDATE   TIMESTAMP NULL,
  ENDDATE   TIMESTAMP NULL,
  UPDATEDATE   TIMESTAMP NULL,
  OPERSTATUS   INTEGER NULL,
  LIVESTATUS   INTEGER NULL,
  NORMDOC      VARCHAR(36) NULL,
CONSTRAINT XPKfias_addressobjects_temp PRIMARY KEY (AOID)) WITH (OIDS=False);


*/

DROP TABLE IF EXISTS fias.fias_addressobjects;
CREATE   TABLE IF NOT EXISTS fias.fias_addressobjects(
  AOID      VARCHAR(36) NOT NULL,
  PREVID   VARCHAR(36) NULL,
  NEXTID   VARCHAR(36) NULL,
  AOGUID   VARCHAR(36) NOT NULL,
  PARENTGUID   VARCHAR(36) NULL,
  FORMALNAME   VARCHAR(120) NULL,
  SHORTNAME   VARCHAR(10) NULL,
  OFFNAME      VARCHAR(120) NULL,
  POSTALCODE   VARCHAR(6) NULL,
  OKATO      VARCHAR(11) NULL,
  OKTMO      VARCHAR(11) NULL,
  AOLEVEL      INTEGER NULL,
  REGIONCODE   VARCHAR(2) NULL,
  AUTOCODE   VARCHAR(1) NULL,
  AREACODE   VARCHAR(3) NULL,
  CITYCODE   VARCHAR(3) NULL,
  CTARCODE   VARCHAR(3) NULL,
  PLACECODE   VARCHAR(3) NULL,
  STREETCODE   VARCHAR(4) NULL,
  EXTRCODE   VARCHAR(4) NULL,
  SEXTCODE   VARCHAR(3) NULL,
  CODE      VARCHAR(17) NULL,
  PLAINCODE   VARCHAR(15) NULL,
  CURRSTATUS   INTEGER NULL,
  IFNSFL   VARCHAR(4) NULL,
  TERRIFNSFL   VARCHAR(4) NULL,
  IFNSUL   VARCHAR(4) NULL,
  TERRIFNSUL   VARCHAR(4) NULL,
  ACTSTATUS   INTEGER NULL,
  CENTSTATUS   INTEGER NULL,
  STARTDATE   TIMESTAMP NULL,
  ENDDATE   TIMESTAMP NULL,
  UPDATEDATE   TIMESTAMP NULL,
  OPERSTATUS   INTEGER NULL,
  LIVESTATUS   INTEGER NULL,
  NORMDOC      VARCHAR(36) NULL,
  ADDRESS      VARCHAR(255),
  REGIONID    VARCHAR(40),
  CITYID      VARCHAR(40),
CONSTRAINT XPKfias_addressobjects PRIMARY KEY (AOID)) WITH (OIDS=False);

CREATE    INDEX XIE1fias_addressobjects ON fias.fias_addressobjects(AOGUID);
CREATE    INDEX XIE4fias_addressobjects ON fias.fias_addressobjects(AOLEVEL);
CREATE    INDEX XIE5fias_addressobjects ON fias.fias_addressobjects(REGIONCODE);
CREATE    INDEX XIE2fias_addressobjects ON fias.fias_addressobjects(PARENTGUID);
CREATE UNIQUE INDEX XAK1fias_addressobjects ON fias.fias_addressobjects(CODE);
CREATE   INDEX XIE3fias_addressobjects ON fias.fias_addressobjects(REGIONCODE,AUTOCODE,AREACODE,CITYCODE,CTARCODE,PLACECODE,STREETCODE,EXTRCODE,SEXTCODE);

COMMENT ON TABLE  fias.fias_addressobjects IS  'ADDROBJ (Object) содержит коды, наименования и типы адресообразующих элементов';
COMMENT ON COLUMN fias.fias_addressobjects.AOGUID IS 'Глобальный уникальный идентификатор адресообразующего элемента';
COMMENT ON COLUMN fias.fias_addressobjects.FORMALNAME IS 'Формализованное наименование';
COMMENT ON COLUMN fias.fias_addressobjects.REGIONCODE IS 'Код региона';
COMMENT ON COLUMN fias.fias_addressobjects.AUTOCODE IS 'Код автономии';
COMMENT ON COLUMN fias.fias_addressobjects.AREACODE IS 'Код района';
COMMENT ON COLUMN fias.fias_addressobjects.CITYCODE IS 'Код города';
COMMENT ON COLUMN fias.fias_addressobjects.CTARCODE IS 'Код внутригородского района';
COMMENT ON COLUMN fias.fias_addressobjects.PLACECODE IS 'Код населенного пункта';
COMMENT ON COLUMN fias.fias_addressobjects.STREETCODE IS 'Код улицы';
COMMENT ON COLUMN fias.fias_addressobjects.EXTRCODE IS 'Код дополнительного адресообразующего элемента';
COMMENT ON COLUMN fias.fias_addressobjects.SEXTCODE IS 'Код подчиненного дополнительного адресообразующего элемента';
COMMENT ON COLUMN fias.fias_addressobjects.OFFNAME IS 'Официальное наименование';
COMMENT ON COLUMN fias.fias_addressobjects.POSTALCODE IS 'Почтовый индекс';
COMMENT ON COLUMN fias.fias_addressobjects.IFNSFL IS 'Код ИФНС ФЛ';
COMMENT ON COLUMN fias.fias_addressobjects.TERRIFNSFL IS 'Код территориального участка ИФНС ФЛ';
COMMENT ON COLUMN fias.fias_addressobjects.IFNSUL IS 'Код ИФНС ЮЛ';
COMMENT ON COLUMN fias.fias_addressobjects.TERRIFNSUL IS 'Код территориального участка ИФНС ЮЛ';
COMMENT ON COLUMN fias.fias_addressobjects.OKATO IS 'ОКАТО';
COMMENT ON COLUMN fias.fias_addressobjects.OKTMO IS 'ОКТМО';
COMMENT ON COLUMN fias.fias_addressobjects.UPDATEDATE IS 'Дата  внесения (обновления) записи';
COMMENT ON COLUMN fias.fias_addressobjects.SHORTNAME IS 'Краткое наименование типа элемента';
COMMENT ON COLUMN fias.fias_addressobjects.AOLEVEL IS 'Уровень адресообразующего элемента ';
COMMENT ON COLUMN fias.fias_addressobjects.PARENTGUID IS 'Идентификатор элемента родительского элемента';
COMMENT ON COLUMN fias.fias_addressobjects.AOID IS 'Уникальный идентификатор записи. Ключевое поле';
COMMENT ON COLUMN fias.fias_addressobjects.PREVID IS 'Идентификатор записи связывания с предыдушей исторической записью';
COMMENT ON COLUMN fias.fias_addressobjects.NEXTID IS 'Идентификатор записи  связывания с последующей исторической записью';
COMMENT ON COLUMN fias.fias_addressobjects.CODE IS 'Код адресообразующего элемента одной строкой с признаком актуальности из КЛАДР 4.0.';
COMMENT ON COLUMN fias.fias_addressobjects.PLAINCODE IS 'Код адресообразующего элемента из КЛАДР 4.0 одной строкой без признака актуальности (последних двух цифр)';
COMMENT ON COLUMN fias.fias_addressobjects.ACTSTATUS IS 'Статус актуальности адресообразующего элемента ФИАС. Актуальный адрес на текущую дату. Обычно последняя запись об адресообразующем элементе. 0 – Не актуальный, 1 - Актуальный';
COMMENT ON COLUMN fias.fias_addressobjects.CENTSTATUS IS 'Статус центра';
COMMENT ON COLUMN fias.fias_addressobjects.OPERSTATUS IS 'Статус действия над записью – причина появления записи (см. описание таблицы OperationStatus)';
COMMENT ON COLUMN fias.fias_addressobjects.LIVESTATUS IS 'Признак действующего адресообразующего элемента: 0 – недействующий адресный элемент, 1 - действующий';
COMMENT ON COLUMN fias.fias_addressobjects.CURRSTATUS IS 'Статус актуальности КЛАДР 4 (последние две цифры в коде)';
COMMENT ON COLUMN fias.fias_addressobjects.STARTDATE IS 'Начало действия записи';
COMMENT ON COLUMN fias.fias_addressobjects.ENDDATE IS 'Окончание действия записи';
COMMENT ON COLUMN fias.fias_addressobjects.NORMDOC IS 'Внешний ключ на нормативный документ';



