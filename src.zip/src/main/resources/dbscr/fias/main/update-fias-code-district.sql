update district r set fias_code=(select a.AOGUID::uuid from fias.fias_addressobjects a join fias.fias_addressobjects ra on ra.regioncode=a.regioncode and ra.aolevel=1 join region rr on rr.fias_code=ra.aoguid::uuid
where a.aolevel IN (3) AND lower(split_part(r."name",' ',1)) = lower(a.formalname) and a.actstatus=1 and a.nextid is null and rr.id=r.region_id limit 1)
where r.fias_code is null;
