CREATE OR REPLACE FUNCTION "public"."rem_split_city_name_profitbase" (address character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	city varchar;
BEGIN

    SELECT (CASE WHEN address LIKE 'село %' THEN split_part(address,'село ',2)
                WHEN address LIKE 'с. %' THEN split_part(address,'с. ',2)
                WHEN address LIKE 'с.%' THEN split_part(address,'с.',2)
                WHEN address LIKE 'г. %' THEN split_part(address,'г. ',2)
                WHEN address LIKE 'г.%' THEN split_part(address,'г.',2)
                WHEN address LIKE 'город %' THEN split_part(address,'город ',2)
                WHEN address LIKE 'поселок %' THEN split_part(address,'поселок ',2)
                WHEN address LIKE 'п. %' THEN split_part(address,'п. ',2)
                WHEN address LIKE 'п.%' THEN split_part(address,'п.',2)
                WHEN address LIKE 'пос. %' THEN split_part(address,'пос. ',2)
                WHEN address LIKE 'пос.%' THEN split_part(address,'пос.',2)
                WHEN address LIKE 'поселение %' THEN split_part(address,'поселение ',2)
                WHEN address LIKE 'рабочий поселок %' THEN split_part(address,' рабочий поселок ',2)
                WHEN address LIKE 'рп. %' THEN split_part(address,'рп. ',2)
                WHEN address LIKE 'рп.%' THEN split_part(address,'рп.',2)
                WHEN address LIKE 'аул ' THEN split_part(address,'аул ',2)
                WHEN address LIKE 'поселок городского типа %' THEN split_part(address,'поселок городского типа ',2)
                WHEN address LIKE 'пгт %' THEN split_part(address,'пгт ',2)
                WHEN address LIKE 'пгт. %' THEN split_part(address,'пгт. ',2)
                WHEN address LIKE 'пгт.%' THEN split_part(address,'пгт.%',2)
                WHEN address LIKE 'деревня %' THEN split_part(address,'деревня ',2)
                WHEN address LIKE 'дер. %' THEN split_part(address,'дер. ',2)
                WHEN address LIKE 'дер.%' THEN split_part(address,'дер.',2)
                WHEN address LIKE 'д. %' THEN split_part(address,'д. ',2)
                WHEN address LIKE 'д.%' THEN split_part(address,'д.',2)
                ELSE address
                END) city INTO city;
    return city;
end
$dbvis$ LANGUAGE plpgsql