CREATE OR REPLACE FUNCTION "public"."rem_split_city_prefix_profitbase" (address character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	city varchar;
BEGIN

    SELECT (CASE WHEN (address LIKE 'село %') OR (address LIKE 'с. %') OR (address LIKE 'с.%')  THEN 'село'
                WHEN (address LIKE 'г. %') OR (address LIKE 'г.%')OR (address LIKE 'город %') THEN 'г.'
                WHEN (address LIKE 'поселок %') OR (address LIKE 'п. %') OR (address LIKE 'п.%') OR (address LIKE 'пос. %') OR (address LIKE 'пос.%') THEN 'пос.'
                WHEN (address LIKE 'поселение %') OR (address LIKE 'поселение %')  THEN 'п.'
                WHEN (address LIKE 'рабочий поселок %') OR (address LIKE 'рп. %') OR (address LIKE 'рп.%') THEN 'рп'
                WHEN address LIKE 'аул %' THEN 'аул'
                WHEN (address LIKE 'деревня %') OR (address LIKE 'дер. %') OR (address LIKE 'дер.%') OR (address LIKE 'д. %') OR (address LIKE 'д.%') THEN 'дер.'
                WHEN (address LIKE 'поселок городского типа %') OR (address LIKE 'пгт %') OR (address LIKE 'пгт. %') OR (address LIKE 'пгт.%')  THEN 'пгт.'
                ELSE 'г.'
                END) city INTO city;
    return city;
end
$dbvis$ LANGUAGE plpgsql