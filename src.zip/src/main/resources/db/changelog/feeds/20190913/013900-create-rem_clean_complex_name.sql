CREATE OR REPLACE FUNCTION "public"."rem_clean_complex_name" (name character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	complexname varchar;
BEGIN

    SELECT (
        TRIM(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(name, 
        '"', ''),
        '«', ''),
        '»', ''),
        'ЖК ', ''),
        'Жилой комплекс ',''),
        'жилой комплекс ','')
        )) complex_name INTO complexname;
    return complexname;
end
$dbvis$ LANGUAGE plpgsql