CREATE OR REPLACE FUNCTION "public"."rem_clean_building_name" (name character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	buildname varchar;
BEGIN

    SELECT (
        TRIM(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(
        REPLACE(name,
        '"', ''),
        '«', ''),
        '»', ''),
        'Корпус ', ''),
        'корпус ',''),
        'Корпус', ''),
        'корпус',''),
        'корп. ',''),
        'Корп. ',''),
        'корп.',''),
        'Корп.','')
        )) build_name INTO buildname;
    return buildname;
end
$dbvis$ LANGUAGE plpgsql