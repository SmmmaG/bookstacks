CREATE OR REPLACE FUNCTION "yandex"."split_city_name" (address character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	city varchar;
BEGIN

    SELECT (CASE WHEN address LIKE '% село' THEN split_part(address,' село',1)
                WHEN address LIKE '% село,%' THEN split_part(address,' село,',1)
                WHEN address LIKE '% г.%' THEN split_part(address,' г.',1)
                WHEN address LIKE '% г.' THEN split_part(address,' г.',1)
                WHEN address LIKE '% г' THEN regexp_replace(address,' г$','')
                WHEN address LIKE '% гор%' THEN split_part(address,' г.',1)
                WHEN address LIKE '% гор' THEN split_part(address,' г.',1)
                WHEN address LIKE '% гор.%' THEN split_part(address,' г.',1)
                WHEN address LIKE '% гор.' THEN split_part(address,' г.',1)
                WHEN address LIKE '% пос.%' THEN split_part(address,' пос.',1)
                WHEN address LIKE '% пос' THEN regexp_replace(address,' пос$','')
                WHEN address LIKE '% поселок%' THEN split_part(address,' пос.',1)
                WHEN address LIKE '% поселок' THEN split_part(address,' пос.',1)
                WHEN address LIKE '% п' THEN regexp_replace(address,' п$','')
                WHEN address LIKE '% п,%' THEN split_part(address,' пос.,',1)
                WHEN address LIKE '% рп' THEN regexp_replace(address,' рп$','')
                WHEN address LIKE '% рп,%' THEN split_part(address,' рп,',1)
                WHEN address LIKE '% аул' THEN regexp_replace(address,' аул$','')
                WHEN address LIKE '% аул,%' THEN split_part(address,' аул,',1)
                WHEN address LIKE '% дер.%' THEN split_part(address,' дер.',1)
                WHEN address LIKE '% дер' THEN regexp_replace(address,' дер$','')
                WHEN address LIKE '% дер.' THEN split_part(address,' дер.',1)
                WHEN address LIKE '% д' THEN regexp_replace(address,' д$','')
                WHEN address LIKE '% д.' THEN split_part(address,' д.',1)
                WHEN address LIKE '% пгт.%' THEN split_part(address,' пгт.',1)
                WHEN address LIKE '% пгт.' THEN split_part(address,' пгт.',1)
                WHEN address LIKE '% пгт' THEN regexp_replace(address,' пгт$','')
                ELSE address
                END) city INTO city;
    return city;
end
$dbvis$ LANGUAGE plpgsql