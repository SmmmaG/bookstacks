CREATE OR REPLACE FUNCTION "yandex"."split_city_prefix" (address character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	city varchar;
BEGIN

    SELECT (CASE WHEN (address LIKE '% село') OR (address LIKE '% село,%')  THEN 'село'
                WHEN (address LIKE '% г.%') OR (address LIKE '% г') OR (address LIKE '% гор.%') OR (address LIKE '% гор$') THEN 'г.'
                WHEN (address LIKE '% пос.%') OR (address LIKE '% пос') OR (address LIKE '% поселок') OR (address LIKE '% поселок%') OR (address LIKE '% п') OR (address LIKE '% п.') OR (address LIKE '% п,%') THEN 'пос.'

                WHEN (address LIKE '% рп') OR (address LIKE '% рп,%') THEN 'рп'
                WHEN (address LIKE '% аул') OR (address LIKE '% аул,%') THEN 'аул'
                WHEN (address LIKE '% дер.%') OR (address LIKE '% дер') OR (address LIKE '% д') THEN 'дер.'
                WHEN (address LIKE '% пгт.%') OR (address LIKE '% пгт') THEN 'пгт.'
                END) city INTO city;
    return city;
end
$dbvis$ LANGUAGE plpgsql