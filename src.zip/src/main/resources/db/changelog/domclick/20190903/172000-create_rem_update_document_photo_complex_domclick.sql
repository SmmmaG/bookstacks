CREATE OR REPLACE FUNCTION "public"."rem_update_document_photo_complex_domclick" ()  RETURNS integer
  VOLATILE
AS $dbvis$
declare
 r record;
 count integer;
 updated_count integer;
 remaining_count integer;
 photo_count integer;
begin
SELECT  INTO photo_count count(document_photo_id) FROM tmp_domclick_complex_document_photo;
 RAISE notice'document_photo_id count=%',photo_count ;
count=0;
updated_count=0;
  FOR r IN
        SELECT DISTINCT complex_id FROM tmp_domclick_complex_document_photo
    LOOP
        declare
          old_photo_uuid_array uuid[];
          records integer;
        begin
                count=count+1;
                RAISE notice'complex_id= % count=%',r.complex_id,count ;
                --Дизактуализация фотографий и наполнение списка старых фото
                declare
                    arraySize integer;
                    compldoc record;
                begin
                    arraySize=0;
                    FOR compldoc IN
                        SELECT * FROM public.complex_document_photo WHERE complex_id=r.complex_id
                        LOOP
                        arraySize=arraySize+1;
                        EXECUTE format('UPDATE public.document_photo SET actual=false WHERE id=$1;') using compldoc.document_photo_id;
                        old_photo_uuid_array[arraySize]=compldoc.document_photo_id;
                        RAISE notice'old complex_doc_photo_id= % arraysize=%',compldoc.document_photo_id, array_length(old_photo_uuid_array,1) ;
                    END LOOP;
                end;
                --обновление IDшникоф фотографий во временной таблице
                declare
                    tmprecord record;
                    tmprecordcounter integer;
                begin
                    tmprecordcounter=0;
                    FOR tmprecord IN
                        SELECT * FROM tmp_domclick_complex_document_photo WHERE complex_id=r.complex_id
                        LOOP
                        tmprecordcounter=tmprecordcounter+1;

                        IF old_photo_uuid_array[tmprecordcounter] IS NOT NULL
                        THEN
                                RAISE notice'обновление IDшникоф фотографий во временной таблице old_doc_photo_id= % new_doc_photo_id=%',old_photo_uuid_array[tmprecordcounter], tmprecord.document_photo_id;
                                EXECUTE format('UPDATE tmp_domclick_complex_document_photo SET document_photo_id=$1 WHERE document_photo_id=$2;') using tmprecord.document_photo_id, old_photo_uuid_array[tmprecordcounter] ;
                        ELSE EXIT;
                        END IF;
                    END LOOP;
                end;
        --обновление записей о фотографиях

                declare
                    tmprecord record;
                    tmprecordcounter integer;
                    updated_count_in_complex integer;
                begin
                tmprecordcounter=0;
                updated_count_in_complex=0;
                    FOR tmprecord IN
                        SELECT * FROM tmp_domclick_complex_document_photo WHERE complex_id=r.complex_id
                        LOOP
                        tmprecordcounter=tmprecordcounter+1;
                        IF old_photo_uuid_array[tmprecordcounter] IS NOT NULL
                        THEN
                                RAISE notice'обновление записей о фотографии % ',tmprecord.document_photo_id;
                                EXECUTE format('
                                        UPDATE public.document_photo ndp SET
                                        actual = true,
                                        descript = TT.description,
                                        update_date = now(),
                                        version=TT.version+1,
                                        state=''NEW'',
                                        url=TT.url,
                                        is_default=TT.is_default
                                        FROM (
                                               SELECT
                                            tnmp.description,
                                            odp.version as version,
                                            tnmp.url url,
                                            false is_default
                                        FROM
                                         (SELECT
                                        domclick_photo_id,
                                        document_photo_id,
                                        ''Comlex Domclick'' description,
                                        np.url
                                          FROM tmp_domclick_complex_document_photo tmp
                                          JOIN domclick.complexes_photos np
                                              ON np.id=tmp.domclick_photo_id) tnmp
                                         JOIN public.document_photo odp ON odp.id=tnmp.document_photo_id )TT
                                        WHERE ndp.id=$1') USING tmprecord.document_photo_id;
                                updated_count = updated_count+updated_count_in_complex;
                                EXECUTE format('DELETE FROM tmp_domclick_complex_document_photo WHERE document_photo_id=$1') using tmprecord.document_photo_id;
                        ELSE EXIT;
                        END IF;
                    END LOOP;
                end;
        end;
    END LOOP;
    SELECT count(document_photo_id) INTO remaining_count FROM tmp_domclick_complex_document_photo;
    RETURN photo_count-remaining_count;
end
$dbvis$ LANGUAGE plpgsql;
