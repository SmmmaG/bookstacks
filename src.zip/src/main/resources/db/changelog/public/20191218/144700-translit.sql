update public.country set code=rem_translit(name);
update public.city set code=rem_translit(name);
update public.region set code=rem_translit(name);
update public.district set code=rem_translit(name);
update public.complex set code=rem_translit(name);
