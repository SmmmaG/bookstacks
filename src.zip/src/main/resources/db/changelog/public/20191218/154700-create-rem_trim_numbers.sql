CREATE OR REPLACE FUNCTION rem_trim_numbers (txt character varying)  RETURNS character varying
  VOLATILE
AS $$
DECLARE
	res varchar;
BEGIN

    SELECT regexp_replace(rem_trim(replace(txt,' ','')),'[a-zA-Zа-яА-Я() \-\+\_]','','g') t INTO res;
    return CASE WHEN res='' THEN null ELSE res END;
end
$$ LANGUAGE plpgsql