CREATE OR REPLACE FUNCTION rem_translit(character varying)
RETURNS text AS $$
DECLARE
        r varchar;
        arr1 text[];
        arr2  text[];
BEGIN
    r=LOWER($1);
    SELECT regexp_replace(trim(regexp_replace(r,'[^[[:alnum:][:space:]_]-]*','', 'g')),'\s+',' ','g') INTO r;
    SELECT regexp_replace(r,'ый$','iy','g') INTO r;
    SELECT regexp_replace(r,'ый ','iy ','g') INTO r;
    SELECT regexp_replace(r,'ый-','iy-','g') INTO r;
    SELECT regexp_replace(r,'ый\.','iy.','g') INTO r;
    SELECT regexp_replace(r,'ый,','iy,','g') INTO r;


    arr1=ARRAY['а','б','в','г','д','е','ё', 'ж', 'з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х', 'ц', 'ч', 'ш', 'щ', 'ъ','ы','ь','э', 'ю','я', 'ъе',' '];
    arr2=ARRAY['a','b','v','g','d','e','yo','zh','z','i','y','k','l','m','n','o','p','r','s','t','u','f','kh','ts','ch','sh','sch','','y','', 'e','yu','ya','ye','-'];
    SELECT string_agg(coalesce(arr2[array_position(arr1, c)],c),'')
        INTO r
    FROM regexp_split_to_table(r,'') g(c);

    return r;
end
$$ LANGUAGE plpgsql;