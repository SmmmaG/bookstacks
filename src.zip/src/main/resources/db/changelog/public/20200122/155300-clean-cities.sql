UPDATE address a
SET city_id=(SELECT id FROM city WHERE lower(name) = lower((SELECT yandex.split_city_name((SELECT name FROM city WHERE id=a.city_id)))) AND a.region_id IS NOT NULL)
WHERE EXISTS ( SELECT 1 FROM city WHERE id=a.city_id AND (name like '% г' OR name like '% п' OR name IS NULL ));

delete
from city c
WHERE (c.name like '% г' OR c.name like '% п' OR c.name IS NULL)
  AND NOT EXISTS(select 1 from address where c.id = city_id);

delete
from city c
WHERE name like 'ул.%';
delete
from city c
WHERE name like '0';
delete
from city c
WHERE name like '1-я Мясниковская улица';
delete
from city c
WHERE name like '«Новая Деревня»';
delete
from city c
WHERE name like '№17-А';

delete
from city c
WHERE region_id is null
  AND EXISTS
    (select 1 from city c1 where c1.name = c.name and region_id is not null);