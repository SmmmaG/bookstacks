CREATE OR REPLACE FUNCTION "public"."rem_remove_html" (txt character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	res varchar;
BEGIN

    SELECT trim(regexp_replace(regexp_replace(regexp_replace(txt,E'<[^>]*>',' ', 'g'), E'&nbsp;',' ', 'g'), E'&ndash;',' ', 'g')) INTO res;
    return res;
end
$dbvis$ LANGUAGE plpgsql