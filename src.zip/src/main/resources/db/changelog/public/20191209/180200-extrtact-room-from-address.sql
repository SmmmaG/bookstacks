CREATE OR REPLACE FUNCTION "public"."rem_exclude_room_number_from_address" (dirtyaddress character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	address varchar;
BEGIN

    select rem_trim(
        regexp_replace(
                rem_trim(
                        (regexp_split_to_array(dirtyaddress,' [кК]в\.'))[1]
                )
        ,',$','')
       ) INTO address;
    return address;
end
$dbvis$ LANGUAGE plpgsql