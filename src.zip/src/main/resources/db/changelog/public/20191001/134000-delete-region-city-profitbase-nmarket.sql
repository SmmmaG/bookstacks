DROP table  IF EXISTS nmarket.region_city;
DROP table  IF EXISTS profitbase.region_city;
