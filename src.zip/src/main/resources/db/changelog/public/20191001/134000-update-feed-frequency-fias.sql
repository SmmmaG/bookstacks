update public.feed set frequency=720 where code='fias_main';
update public.feed set frequency=48 where code='fias_delta';