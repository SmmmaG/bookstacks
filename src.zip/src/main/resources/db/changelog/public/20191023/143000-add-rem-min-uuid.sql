 create aggregate min(uuid) (
      sfunc = rem_min_uuid,
      stype = uuid,
      combinefunc = rem_min_uuid,
      parallel = safe,
      sortop = operator (<)
    );