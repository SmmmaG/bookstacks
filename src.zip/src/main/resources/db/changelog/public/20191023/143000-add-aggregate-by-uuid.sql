CREATE OR REPLACE FUNCTION "public"."rem_min_uuid" (uuid, uuid)  RETURNS uuid
  VOLATILE
AS $dbvis$
BEGIN
        -- if they're both null, return null
        IF $2 IS NULL AND $1 IS NULL THEN
            RETURN NULL ;
        END IF;

        -- if just 1 is null, return the other
        IF $2 IS NULL THEN
            RETURN $1;
        END IF ;
        IF $1 IS NULL THEN
            RETURN $2;
          END IF;

        -- neither are null, return the smaller one
        IF $1 > $2 THEN
            RETURN $2;
        END IF;

        RETURN $1;
    END;
$dbvis$ LANGUAGE plpgsql


