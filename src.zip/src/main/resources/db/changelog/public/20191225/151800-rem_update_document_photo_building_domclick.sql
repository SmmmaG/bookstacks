CREATE OR REPLACE FUNCTION "public"."rem_update_document_photo_building_domclick" ()  RETURNS integer
  VOLATILE
AS $dbvis$
declare
 r record;
 count integer;
 updated_count integer;
 remaining_count integer;
 photo_count integer;
begin
SELECT  INTO photo_count count(document_photo_id) FROM tmp_domclick_building_document_photo;
 RAISE notice'document_photo_id count=%',photo_count ;
count=0;
updated_count=0;
  FOR r IN
        SELECT DISTINCT building_id FROM tmp_domclick_building_document_photo
    LOOP
        declare
          old_photo_uuid_array uuid[];
          records integer;
        begin
                count=count+1;
                RAISE notice'building_id= % count=%',r.building_id,count ;

                declare
                    arraySize integer;
                    builddoc record;
                begin
                    arraySize=0;
                    FOR builddoc IN
                        SELECT * FROM public.building_document_photo WHERE building_id=r.building_id
                        LOOP
                        arraySize=arraySize+1;
                        EXECUTE format('UPDATE public.document_photo SET actual=false WHERE id=$1;') using builddoc.document_photo_id;
                        old_photo_uuid_array[arraySize]=builddoc.document_photo_id;
                        RAISE notice'old building_doc_photo_id= % arraysize=%',builddoc.document_photo_id, array_length(old_photo_uuid_array,1) ;
                    END LOOP;
                end;

                declare
                    tmprecord record;
                    tmprecordcounter integer;
                    updated_count_in_building integer;
                begin
                tmprecordcounter=0;
                updated_count_in_building=0;
                    FOR tmprecord IN
                        SELECT * FROM tmp_domclick_building_document_photo WHERE building_id=r.building_id
                        LOOP
                        tmprecordcounter=tmprecordcounter+1;
                        IF old_photo_uuid_array[tmprecordcounter] IS NOT NULL
                        THEN
                                RAISE notice'обновление IDшникоф фотографий во временной таблице old_doc_photo_id= % new_doc_photo_id=%',old_photo_uuid_array[tmprecordcounter], tmprecord.document_photo_id;
                                EXECUTE format('UPDATE tmp_domclick_building_document_photo SET document_photo_id=$1 WHERE document_photo_id=$2;') using old_photo_uuid_array[tmprecordcounter], tmprecord.document_photo_id;

                                RAISE notice'обновление записей о фотографии % ',old_photo_uuid_array[tmprecordcounter];
                                EXECUTE format('
                                        UPDATE public.document_photo ndp SET
                                        actual = true,
                                        descript = TT.description,
                                        update_date = now(),
                                        version=TT.version+1,
                                        state=''NEW'',
                                        url=TT.url,
                                        is_default=TT.is_default
                                        FROM (
                                               SELECT
                                            tnmp.description,
                                            odp.version as version,
                                            tnmp.url url,
                                            false is_default
                                        FROM
                                         (SELECT
                                        domclick_photo_id,
                                        document_photo_id,
                                        ''Building Domclick'' description,
                                        np.url
                                          FROM tmp_domclick_building_document_photo tmp
                                          JOIN domclick.buildings_photos np
                                              ON np.id=tmp.domclick_photo_id) tnmp
                                         JOIN public.document_photo odp ON odp.id=tnmp.document_photo_id )TT
                                        WHERE ndp.id=$1') USING old_photo_uuid_array[tmprecordcounter];
                                updated_count = updated_count+updated_count_in_building;
                                EXECUTE format('DELETE FROM tmp_domclick_building_document_photo WHERE document_photo_id=$1') using old_photo_uuid_array[tmprecordcounter];
                        ELSE EXIT;
                        END IF;
                    END LOOP;
                end;
        end;
    END LOOP;
    SELECT count(document_photo_id) INTO remaining_count FROM tmp_domclick_building_document_photo;
    RETURN photo_count-remaining_count;
end
$dbvis$ LANGUAGE plpgsql