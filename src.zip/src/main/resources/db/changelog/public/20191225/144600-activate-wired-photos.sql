update document_photo SET actual=true where actual = false and id IN
(SELECT document_photo_id FROM complex_document_photo);

update document_photo SET actual=true where actual = false and id IN
(SELECT document_photo_id FROM building_document_photo);

update document_photo SET actual=true where actual = false and id IN
(SELECT document_photo_id FROM flat_document_photo);

update document_photo SET actual=true where actual = false and id IN
(SELECT plan_document_photo_id FROM flat);