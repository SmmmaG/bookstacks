CREATE OR REPLACE FUNCTION "public"."rem_trim_url" (txt character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	res varchar;
BEGIN

    SELECT CASE WHEN (rem_trim(txt) ~ '^http') THEN rem_trim(txt) ELSE null END INTO res;
    return res;
end
$dbvis$ LANGUAGE plpgsql