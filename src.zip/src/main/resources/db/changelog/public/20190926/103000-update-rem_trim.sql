CREATE OR REPLACE FUNCTION "public"."rem_trim" (txt character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	res varchar;
BEGIN

    SELECT trim(replace(txt,'
','')) t INTO res;
    return CASE WHEN res='' THEN null ELSE res END;
end
$dbvis$ LANGUAGE plpgsql