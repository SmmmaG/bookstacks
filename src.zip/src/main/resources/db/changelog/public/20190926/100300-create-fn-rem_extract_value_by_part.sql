CREATE OR REPLACE FUNCTION "public"."rem_extract_value_by_part" (content_value character varying, extract_prefix character varying)  RETURNS character varying
  RETURNS NULL ON NULL INPUT
 AS $$
 SELECT
                CASE WHEN
                          trim(split_part(content_value,extract_prefix ,1)) = '' THEN trim(split_part(content_value,extract_prefix,2))
                        ELSE
                          trim(split_part(content_value,extract_prefix,1))
                 END
 $$ LANGUAGE sql;
