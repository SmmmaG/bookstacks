CREATE OR REPLACE FUNCTION "public"."rem_get_position_before_by_street" (address character varying)  RETURNS integer
 RETURNS NULL ON NULL INPUT
 AS $$
 SELECT array_position(regexp_split_to_array(address,','),(SELECT part_content FROM (SELECT unnest(regexp_split_to_array(address,',')) part_content) gg
 WHERE
        part_content LIKE '%ул.%' OR
        part_content LIKE '%пр.%' OR
        part_content LIKE '%пл.%' OR
        part_content LIKE '%улица%' OR
        part_content LIKE '%проспект%' OR
        part_content LIKE '%площадь%' OR
        part_content LIKE '%бульвар%' OR
        part_content LIKE '%алея%' OR
        part_content LIKE '%переулок%' OR
        part_content LIKE '%проезд%'
  ))
   $$ LANGUAGE sql;
