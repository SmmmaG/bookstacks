CREATE OR REPLACE FUNCTION "public"."rem_extract_city" ( IN address character varying)  RETURNS TABLE (part_content varchar(100), prefix_type varchar(50))
  RETURNS NULL ON NULL INPUT
 AS $$
       SELECT part_content, prefix_type FROM (
               SELECT  DISTINCT
        CASE
           WHEN trim(part_content) LIKE '%г.%' THEN public.rem_extract_value_by_part(trim(part_content),'г.')
           WHEN trim(part_content) LIKE '%городское поселение%' THEN public.rem_extract_value_by_part(trim(part_content),'городское поселение')
           WHEN trim(part_content) LIKE '%пос.%' THEN public.rem_extract_value_by_part(trim(part_content),'пос.')
           WHEN trim(part_content) LIKE '%дер.%' THEN public.rem_extract_value_by_part(trim(part_content),'дер.')
           WHEN trim(part_content) LIKE '%село%' THEN public.rem_extract_value_by_part(trim(part_content),'село')
           WHEN trim(part_content) LIKE '%пгт.%' THEN public.rem_extract_value_by_part(trim(part_content),'пгт.')
           WHEN trim(part_content) LIKE '%в районе микрорайона%' THEN public.rem_extract_value_by_part(trim(part_content),'в районе микрорайона')
           WHEN trim(part_content) LIKE '%микрорайон%' THEN public.rem_extract_value_by_part(trim(part_content),'микрорайон')
           WHEN trim(part_content) LIKE '%мкр.%' THEN public.rem_extract_value_by_part(trim(part_content),'мкр.')
           WHEN trim(part_content) LIKE '% п%' THEN public.rem_extract_value_by_part(trim(part_content),'п')
           WHEN trim(part_content) LIKE '% п,%' THEN public.rem_extract_value_by_part(trim(part_content),'п,')
           WHEN trim(part_content) LIKE '% рп%' THEN public.rem_extract_value_by_part(trim(part_content),'рп')
           WHEN trim(part_content) LIKE '% рп,%' THEN public.rem_extract_value_by_part(trim(part_content),'рп,')
           WHEN trim(part_content) LIKE '% аул%' THEN public.rem_extract_value_by_part(trim(part_content),'аул')
           WHEN trim(part_content) LIKE '% аул,%' THEN public.rem_extract_value_by_part(trim(part_content),'аул,')
           ELSE
             trim(part_content)
          END as part_content,
        CASE
           WHEN trim(part_content) LIKE '%г.%' THEN 'г.'
           WHEN trim(part_content) LIKE '%городское поселение%' THEN 'городское поселение'
           WHEN trim(part_content) LIKE '%пос.%' THEN 'пос.'
           WHEN trim(part_content) LIKE '%дер.%' THEN 'дер.'
           WHEN trim(part_content) LIKE '%село%' THEN 'село'
           WHEN trim(part_content) LIKE '%пгт.%' THEN 'пгт.'
           WHEN trim(part_content) LIKE '%в районе микрорайона%' THEN 'микрорайон'
           WHEN trim(part_content) LIKE '%микрорайон%' THEN 'микрорайон'
           WHEN trim(part_content) LIKE '%мкр.%' THEN 'микрорайон'
           WHEN trim(part_content) LIKE '% п%' THEN 'п'
           WHEN trim(part_content) LIKE '% п,%' THEN 'п'
           WHEN trim(part_content) LIKE '% рп%' THEN 'рп'
           WHEN trim(part_content) LIKE '% рп,%' THEN 'рп'
           WHEN trim(part_content) LIKE '% аул%' THEN 'аул'
           WHEN trim(part_content) LIKE '% аул,%' THEN 'аул'
           ELSE ''
          END as prefix_type

          FROM (
                SELECT part_content FROM (
                  SELECT part_content FROM (
                  SELECT unnest(regexp_split_to_array(address,',')) part_content) tt
                WHERE
                        tt.part_content LIKE '%г.%' OR
                        tt.part_content LIKE '%городское поселение%' OR
                        tt.part_content LIKE '%микрорайон%' OR
                        tt.part_content LIKE '%мкр.%' OR
                        tt.part_content LIKE '%пос.%' OR
                        tt.part_content LIKE '% п'OR
                        tt.part_content LIKE '% п,%' OR
                        tt.part_content LIKE '% рп' OR
                        tt.part_content LIKE '% рп,%' OR
                        tt.part_content LIKE '% аул' OR
                        tt.part_content LIKE '% аул,%' OR
                        tt.part_content LIKE '%дер.%' OR
                        tt.part_content LIKE '%село%' OR
                        tt.part_content  LIKE '%пгт.%' OR
                        tt.part_content  LIKE '%в районе микрорайона%'
                UNION ALL
                SELECT CASE WHEN split_part(address,',',1) NOT LIKE '%область%' AND
                         split_part(address,',',1) NOT LIKE '%край%' AND
                         split_part(address,',',1) NOT LIKE '%республика%'
                         THEN trim(split_part(address,',',1)) ELSE
                                 CASE WHEN public.rem_get_position_before_by_street(address) IS NOT NULL
                                        THEN
                                            trim(split_part(address,',', public.rem_get_position_before_by_street(address)-1))
                                END
                       END part_content
                         ) ttt) tttt) ttttt WHERE part_content <>'' OR  prefix_type <>''

 $$ LANGUAGE sql;