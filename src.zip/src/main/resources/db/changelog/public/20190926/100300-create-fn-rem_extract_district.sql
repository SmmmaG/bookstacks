CREATE OR REPLACE FUNCTION "public"."rem_extract_district" (address character varying)  RETURNS character varying
   RETURNS NULL ON NULL INPUT
 AS $$
 SELECT
                CASE
                WHEN part_content  LIKE '% муниципальный район%' THEN  trim("public".rem_extract_value_by_part(part_content ,'муниципальный район'))
                WHEN part_content  LIKE '% район%' THEN  trim("public".rem_extract_value_by_part(part_content ,' район'))
                END
         FROM (
        SELECT unnest(regexp_split_to_array(address,',')) part_content) tt
        WHERE
        tt.part_content LIKE '% район%' OR
        tt.part_content LIKE '% административный округ%' OR
        tt.part_content LIKE '% городской округ%' OR
        tt.part_content LIKE '% муниципальный район%'
 $$ LANGUAGE sql;