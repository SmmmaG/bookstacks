CREATE OR REPLACE FUNCTION "public"."rem_trim" (txt character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	res varchar;
BEGIN

    SELECT trim(replace(txt,'
','')) t INTO res;
    return res;
end
$dbvis$ LANGUAGE plpgsql