INSERT INTO public.feed_log_status (id,actual,create_date,update_date,"version",code,descript,"name",statistic) VALUES
('44b96ca9-6bf8-ad1d-c458-2673c83991cd',true,'2019-06-03 14:12:16.176',NULL,1,'OK','Загрузка прошла успешно','Done',NULL)
,('3e804f62-2ed4-18f9-6701-6f8c6976e20e',true,'2019-06-03 14:12:16.338',NULL,1,'ERROR','Ошибка при загрузке','Error',NULL)
,('7f22ea61-6f55-6237-527b-45a806cc890b',true,'2019-06-03 14:12:16.665',NULL,1,'DISABLE','Отключено','Disable',NULL)
,('dca721ae-6390-430e-b377-dc44ec19de17',true,'2019-06-03 15:22:23.653',NULL,0,'PROGRESS','Работает','Progress',NULL)
,('84314780-eb60-99e8-a6a6-c77b7a27aeeb',true,'2019-06-03 14:12:16.601',NULL,1,'WAIT','Ожидание загрузки','Wait',NULL) ON CONFLICT(name) DO NOTHING
;