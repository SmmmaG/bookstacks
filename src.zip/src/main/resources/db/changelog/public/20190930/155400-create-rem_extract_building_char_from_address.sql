CREATE OR REPLACE FUNCTION "public"."rem_extract_building_char_from_address" (address character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	building_char varchar;
BEGIN

    SELECT CASE
        WHEN address ~* 'дом [0-9]+[а-я]?' THEN substring(address,'дом [0-9]+[а-я]?.*')
        WHEN address ~* 'д\.[0-9]+' THEN substring(address,'д\.[0-9]+[а-я]?.*')
        WHEN address ~* 'д\. [0-9]+' THEN substring(address,'д\. [0-9]+[а-я]?.*')
        WHEN address ~* 'д[0-9]+' THEN substring(address,'д[0-9]+[а-я]?.*')
        WHEN address ~* 'д [0-9]+' THEN substring(address,'д [0-9]+[а-я]?.*')
        WHEN address ~* 'корпус [0-9]+[а-я]?$' THEN substring(address,'корпус [0-9]+[а-я]?')
        WHEN address ~* 'к\.[0-9]+[а-я]?$' THEN substring(address,'к\.[0-9]+[а-я]?')
        WHEN address ~* 'к\. [0-9]+[а-я]?$' THEN substring(address,'к\. [0-9]+[а-я]?')
        WHEN address ~* 'к[0-9]+[а-я]?$' THEN substring(address,'к[0-9]+[а-я]?')
        WHEN address ~* 'к [0-9]+[а-я]?$' THEN substring(address,'к [0-9]+[а-я]?')
        WHEN address ~* 'строение [0-9]+[а-я]?$' THEN substring(address,'строение [0-9]+[а-я]?')
        WHEN address ~* 'стр\.[0-9]+[а-я]?$' THEN substring(address,'стр\.[0-9]+[а-я]?')
        WHEN address ~* 'стр\. [0-9]+[а-я]?$' THEN substring(address,'стр\. [0-9]+[а-я]?')
        WHEN address ~* 'стр[0-9]+[а-я]?$' THEN substring(address,'стр[0-9]+[а-я]?')
        WHEN address ~* 'стр [0-9]+[а-я]?$' THEN substring(address,'стр [0-9]+[а-я]?')
        WHEN address ~* ', [0-9]+[а-я]?$' THEN substring(address,'[0-9]+[а-я]?$')
        WHEN address ~* '. [0-9]+[а-я]?$' THEN substring(address,'[0-9]+[а-я]?$')
        ELSE null END INTO building_char;
    return building_char;
end
$dbvis$ LANGUAGE plpgsql