INSERT INTO public.status ("type",id,actual,create_date,update_date,"version",code,"name",statistic,descript) VALUES
('2','b7721ba9-45ea-f874-e246-5bee898b790d',true,'2019-05-07 09:47:32.415','2019-06-26 15:41:00.186',163,'reserved','Reserved',0,NULL)
,('2','f6fc9f37-3681-0c80-1d68-667f79505565',true,'2019-04-30 14:44:03.302','2019-06-26 15:41:00.186',305,'available','Available',0,'Доступно')
,('2','39773ec0-912f-4597-ad5b-844f79f7667b',true,'2019-08-21 17:40:00.000',NULL,0,'booked','Booked',0,'Забронировано')
,('2','33e61661-50f1-4d10-bb2f-165a2143ec80',true,'2019-08-21 17:40:00.000',NULL,0,'sold','Sold',0,'Продано')
,('2','95247958-eb0a-4f50-9c03-d107b9e0b7a7',true,'2019-08-21 17:40:00.000',NULL,0,'execution','Execution',0,'Оформление') on CONFLICT(name) do nothing
;