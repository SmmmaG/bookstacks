UPDATE parking_type set name = trim(name);
update public.building set parking_type_id=(SELECT id from public.parking_type WHERE name='Нет')
WHERE building.parking_type_id=(SELECT id from public.parking_type WHERE name='нет');
update public.building set parking_type_id=(SELECT id from public.parking_type WHERE name='Наземная')
WHERE building.parking_type_id=(SELECT id from public.parking_type WHERE name='наземная');
update public.building set parking_type_id=(SELECT id from public.parking_type WHERE name='Подземная')
WHERE building.parking_type_id=(SELECT id from public.parking_type WHERE name='подземная');
delete from parking_type where name='подземная' OR name='наземная' OR name='нет'