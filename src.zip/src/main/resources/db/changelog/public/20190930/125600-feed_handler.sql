INSERT INTO public.feed_handler (id,actual,create_date,update_date,"version",code,descript,"name",statistic,scheme) VALUES
('1cffc7ae-fc59-6ca0-6ea4-d8d2be7054c0',true,NULL,NULL,0,'nmarket',NULL,'Нмаркет',NULL,NULL)
,('278c929a-5913-f21c-1071-dc382eac4a5a',true,NULL,NULL,2,'domclick',NULL,'ДомКлик',NULL, NULL)
,('01babed4-fb2c-4b09-a64a-c03bc81d654b',true,NULL,NULL,0,'yandex',NULL,'Яндекс',NULL,NULL)
,('66b71103-9616-4059-b963-808bc0f59c3b',true,NULL,NULL,0,'profitbase',NULL,'Профитбейс',NULL,NULL)
,('b54c2845-2b56-4af0-9ac5-5ae4f0284aff',true,NULL,NULL,0,'fias',NULL,'Загрузчик данных ФИАС',NULL,NULL) ON CONFLICT(name) DO NOTHING
;