CREATE OR REPLACE FUNCTION "public"."rem_remove_html" (txt character varying)  RETURNS character varying
  VOLATILE
AS $dbvis$
DECLARE
	res varchar;
BEGIN

   SELECT trim(regexp_replace(txt,E'<[^>]*>|&raquo;|&laquo;|&quot;|&amp;|&lt;|&gt;|&OElig;|&oelig;|&Scaron;|&tilde;|&ensp;|&emsp;|&thinsp;|&zwnj;|&zwj;|&lrm;|&rlm;|&ndash;|&mdash;|&lsquo;|&rsquo;|&sbquo;|&ldquo;|&rdquo;|&bdquo;|&dagger;|&Dagger;|&permil;|&lsaquo;|&rsaquo;|&euro;',' ', 'g')) INTO res;
    return res;
end
$dbvis$ LANGUAGE plpgsql


