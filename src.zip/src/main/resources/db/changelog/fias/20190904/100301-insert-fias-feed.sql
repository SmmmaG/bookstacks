insert into feed
(id, actual, create_date, "version", url, feed_handler_id, code, "name", active, descript, supplier_id)
values (uuid_generate_v4(), true, now(), 0, 'http://data.nalog.ru/Public/Downloads/',
(select id from feed_handler where code ='fias'), 'fias_delta', 'ФИАС - дельта', true, 'ФИАС - обновление базы',(select id from supplier where code ='fns')) ON CONFLICT(name) DO NOTHING;

insert into feed
(id, actual, create_date, "version", url, feed_handler_id, code, "name", active, descript, supplier_id)
values ( uuid_generate_v4(), true, now(), 0, 'http://data.nalog.ru/Public/Downloads/',
(select id from feed_handler where code ='fias'), 'fias_main', 'ФИАС - начальная загрузка', true, 'ФИАС - начальная загрузка',(select id from supplier where code ='fns')) ON CONFLICT(name) DO NOTHING;
