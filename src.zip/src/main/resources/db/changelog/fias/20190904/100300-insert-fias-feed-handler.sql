insert into feed_handler (id, actual, "version", code, "name") values ( uuid_generate_v4(), true, 0, 'fias', 'Загрузчик данных ФИАС');

INSERT INTO public.supplier (id,actual,create_date,update_date,"version",supplier_type,code,descript,"name",statistic) VALUES
(uuid_generate_v4(),true,'2019-08-15 00:00:26.000',NULL,0,1,'fns',NULL,'ФНС',NULL) ON CONFLICT(name) DO NOTHING;