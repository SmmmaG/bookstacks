CREATE OR REPLACE FUNCTION fias.fsfn_addressobjects_treeactualname(a_aoguid character varying DEFAULT NULL::character varying, a_maskarray character varying[] DEFAULT '{TM,TP,LM,LP,ST}'::character varying[])
 RETURNS character varying
 LANGUAGE plpgsql
AS $function$
DECLARE
   c_CountryGroupValue      CONSTANT VARCHAR(50):='Country';
   c_RegionGroupValue      CONSTANT VARCHAR(50):='Region';
   c_CityGroupValue      CONSTANT VARCHAR(50):='City';
   c_TerritoryGroupValue      CONSTANT VARCHAR(50):='Territory';
   c_LocalityGroupValue      CONSTANT VARCHAR(50):='Locality';
   c_MotorRoadValue      CONSTANT VARCHAR(50):='MotorRoad';
   c_RailWayObjectValue      CONSTANT VARCHAR(50):='RailWayObject';
   c_VillageCouncilValue      CONSTANT VARCHAR(50):='VillageCouncil';
   c_StreetGroupValue      CONSTANT VARCHAR(50):='Street';
   c_AddlTerritoryValue      CONSTANT VARCHAR(50):='AddlTerritory';
   c_PartAddlTerritoryValue   CONSTANT VARCHAR(50):='PartAddlTerritory';
   c_StreetMask       CONSTANT  VARCHAR(2)[1] :='{ST}';
   c_PostIndexMask      CONSTANT  VARCHAR(2)[1] :='{ZC}';
   c_DistrictMask      CONSTANT  VARCHAR(2)[1] :='{DT}';
   c_PartLocalityMask   CONSTANT  VARCHAR(2)[1] :='{LP}';
   c_MainLocalityMask   CONSTANT  VARCHAR(2)[1] :='{LM}';
   c_PartTerritoryMask   CONSTANT  VARCHAR(2)[1] :='{TP}';
   c_MainTerritoryMask   CONSTANT  VARCHAR(2)[1] :='{TM}';
   c_CountryMask      CONSTANT  VARCHAR(2)[1] :='{CY}';
   v_ShortTypeName      VARCHAR(10);
   v_AddressObjectName   VARCHAR(500);
   v_AOLevel      INTEGER;
   v_MinCurrStatus      INTEGER;
   v_TreeAddressObjectName   VARCHAR(1000);
   v_ObjectGroup      VARCHAR(50);
   v_TreeLeverCount   INTEGER;
   v_Return_Error_i    Integer := 0;
   cursor_AddressObjectTree RefCURSOR;
   v_Return_Error      Integer :=0;
 BEGIN
   SELECT INTO v_MinCurrStatus   MIN(addrobj.currstatus) FROM fias.fias_addressobjects addrobj     WHERE aoguid=a_AOGUID;
   OPEN cursor_AddressObjectTree FOR SELECT rtf_ShortTypeName,REPLACE(rtf_AddressObjectName,'  ',' '),
                     rtf_AOLevel,fias.fsfn_addressobjects_objectgroup(rtf_AOGUID )
                  FROM fias.fstf_addressobjects_addressobjecttree(a_AOGUID) ORDER BY rtf_AOLevel;

   v_TreeLeverCount:=0;
   v_TreeAddressObjectName:='';
   FETCH FIRST FROM cursor_AddressObjectTree INTO v_ShortTypeName,v_AddressObjectName,v_AOLevel,v_ObjectGroup;
   WHILE FOUND
   LOOP
      v_TreeLeverCount:=v_TreeLeverCount+1;
RAISE INFO 'v_ShortTypeName=%,v_AddressObjectName=%,v_AOLevel=%,v_ObjectGroup=% ?=%',v_ShortTypeName,v_AddressObjectName,v_AOLevel,v_ObjectGroup,UPPER(v_ShortTypeName) LIKE UPPER('%Респ%');

      IF v_ObjectGroup=c_CountryGroupValue AND c_CountryMask <@ a_MaskArray AND v_AOLevel =0 THEN
         v_TreeAddressObjectName:=v_TreeAddressObjectName||CASE WHEN v_TreeAddressObjectName='' THEN '' ELSE ', ' END ||
                        v_AddressObjectName||' '||v_ShortTypeName;
      ELSIF v_ObjectGroup=c_CityGroupValue AND v_AOLevel=1 THEN
         v_TreeAddressObjectName:=v_TreeAddressObjectName||CASE WHEN v_TreeAddressObjectName='' THEN '' ELSE ', ' END ||
                        v_ShortTypeName||'. '||v_AddressObjectName;
      ELSIF v_ObjectGroup=c_RegionGroupValue AND c_MainTerritoryMask <@ a_MaskArray  AND v_AOLevel <=2 THEN
         v_TreeAddressObjectName:=v_TreeAddressObjectName||CASE WHEN v_TreeAddressObjectName='' THEN '' ELSE ', ' END ||
                        CASE WHEN UPPER(v_ShortTypeName) LIKE UPPER('%Респ%') THEN 'Республика ' ||
                                                v_AddressObjectName
                           ELSE v_AddressObjectName||' '||v_ShortTypeName END;
      ELSIF v_ObjectGroup=c_TerritoryGroupValue AND c_PartTerritoryMask <@ a_MaskArray AND v_AOLevel =3 THEN
         v_TreeAddressObjectName:=v_TreeAddressObjectName||CASE WHEN v_TreeAddressObjectName='' THEN '' ELSE ', ' END ||
                              v_AddressObjectName||' '||v_ShortTypeName;
      ELSIF v_ObjectGroup=c_CityGroupValue AND c_MainLocalityMask <@ a_MaskArray AND v_AOLevel =4 THEN
         v_TreeAddressObjectName:=v_TreeAddressObjectName||CASE WHEN v_TreeAddressObjectName='' THEN '' ELSE ', ' END ||
                              CASE WHEN UPPER(LEFT(v_AddressObjectName,6+LENGTH(v_ShortTypeName)))
                                       ='ЗАТО '||UPPER(TRIM(v_ShortTypeName))||'.'
                                    THEN v_AddressObjectName
                                    ELSE v_ShortTypeName ||CASE WHEN LENGTH(v_ShortTypeName)<4 THEN '.' ELSE '' end||' '|| v_AddressObjectName END;
      ELSIF v_ObjectGroup=c_LocalityGroupValue AND c_DistrictMask <@ a_MaskArray AND v_AOLevel =5 THEN
         v_TreeAddressObjectName:=v_TreeAddressObjectName||CASE WHEN v_TreeAddressObjectName='' THEN '' ELSE ', ' END ||
                              v_AddressObjectName||' '||v_ShortTypeName ;
      ELSIF (v_ObjectGroup=c_LocalityGroupValue or v_ObjectGroup=c_AddlTerritoryValue) AND c_PartLocalityMask <@ a_MaskArray AND v_AOLevel =6 THEN
         v_TreeAddressObjectName:=v_TreeAddressObjectName||CASE WHEN v_TreeAddressObjectName='' THEN '' ELSE ', ' END ||
                              v_ShortTypeName ||CASE WHEN LENGTH(v_ShortTypeName)<4 THEN '.' ELSE '' end||' '|| v_AddressObjectName;
      ELSIF v_ObjectGroup=c_StreetGroupValue AND c_StreetMask <@ a_MaskArray AND v_AOLevel =7  THEN
         v_TreeAddressObjectName:=v_TreeAddressObjectName||CASE WHEN v_TreeAddressObjectName='' THEN '' ELSE ', ' END ||
                              v_ShortTypeName ||CASE WHEN LENGTH(v_ShortTypeName)<4 THEN '.' ELSE '' end||' '|| v_AddressObjectName;
      END IF;
      FETCH NEXT  FROM cursor_AddressObjectTree INTO v_ShortTypeName,v_AddressObjectName,v_AOLevel,v_ObjectGroup;
   END LOOP;
   CLOSE cursor_AddressObjectTree;
    RETURN    v_TreeAddressObjectName;
  END;
  $function$
;

COMMENT ON FUNCTION fias.fsfn_addressobjects_treeactualname(varchar,_varchar) IS 'Возвращает  строку с полным названием адресообразующего элемента';
