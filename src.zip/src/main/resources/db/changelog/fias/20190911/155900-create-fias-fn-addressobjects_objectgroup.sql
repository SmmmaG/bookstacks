BEGIN TRANSACTION;
DROP   FUNCTION IF EXISTS fias.sfn_addressobjects_objectgroup(a_AOGUID VARCHAR(36),a_CurrStatus INTEGER);
CREATE OR REPLACE FUNCTION fias.fsfn_addressobjects_objectgroup(
      a_AOGUID   VARCHAR(36),
      a_CurrStatus   INTEGER default NULL

)
RETURNS VARCHAR(50)
AS
$BODY$
DECLARE
   c_CountryGroupValue      CONSTANT VARCHAR(50):='Country';
   c_RegionGroupValue      CONSTANT VARCHAR(50):='Region';
   c_CityGroupValue      CONSTANT VARCHAR(50):='City';
   c_TerritoryGroupValue      CONSTANT VARCHAR(50):='Territory';
   c_LocalityGroupValue      CONSTANT VARCHAR(50):='Locality';
   c_MotorRoadValue      CONSTANT VARCHAR(50):='MotorRoad';
   c_RailWayObjectValue      CONSTANT VARCHAR(50):='RailWayObject';
   c_VillageCouncilValue      CONSTANT VARCHAR(50):='VillageCouncil';
   c_StreetGroupValue      CONSTANT VARCHAR(50):='Street';
   c_AddlTerritoryValue      CONSTANT VARCHAR(50):='AddlTerritory';
   c_PartAddlTerritoryValue   CONSTANT VARCHAR(50):='PartAddlTerritory';

   v_ShortTypeName      VARCHAR(10);
   v_AddressObjectName   VARCHAR(500);
   v_AOLevel      INTEGER;
   v_CurrStatus      INTEGER;
   v_ObjectGroup      VARCHAR(50);
    v_Return_Error      Integer :=0;
 BEGIN
    SELECT INTO v_CurrStatus COALESCE(a_CurrStatus,MIN(addrobj.currstatus)) FROM fias.fias_addressobjects addrobj WHERE addrobj.AOGUID=a_AOGUID;
   SELECT INTO v_ShortTypeName,v_AddressObjectName,v_AOLevel ShortName,FormalName,AOLevel FROM fias.fias_addressobjects addrobj
                  WHERE addrobj.AOGUID=a_AOGUID AND addrobj.currstatus = v_CurrStatus
                  LIMIT 1;
   IF v_AOLevel = 1 AND UPPER(v_ShortTypeName) <> 'Г' THEN
      v_ObjectGroup:=c_RegionGroupValue;
   ELSIF v_AOLevel = 1 AND UPPER(v_ShortTypeName) =  'Г' THEN
      v_ObjectGroup:=c_CityGroupValue;
   ELSIF v_AOLevel = 3  THEN
      v_ObjectGroup:=c_TerritoryGroupValue;
   ELSIF (v_AOLevel = 4 AND UPPER(v_ShortTypeName) NOT IN ('С/С','С/А','С/О','С/МО'))  OR (v_AOLevel = 1 AND UPPER(v_ShortTypeName) <> 'Г') THEN
      v_ObjectGroup:=c_CityGroupValue;
   ELSIF v_AOLevel IN (4,6)  AND UPPER(v_ShortTypeName) IN ('С/С','С/А','С/О','С/МО') AND UPPER(v_ShortTypeName) NOT LIKE ('Ж/Д%') THEN
      v_ObjectGroup:=c_VillageCouncilValue;
   ELSIF v_AOLevel = 6 AND UPPER(v_ShortTypeName) NOT IN ('С/С','С/А','С/О','С/МО','САД','СНТ','ТЕР','АВТОДОРОГА','ПРОМЗОНА','ДП','МКР')
            AND UPPER(v_ShortTypeName) NOT LIKE ('Ж/Д%') THEN
      v_ObjectGroup:=c_LocalityGroupValue;
   ELSIF  UPPER(v_ShortTypeName) IN ('АВТОДОРОГА') THEN
      v_ObjectGroup:=c_MotorRoadValue;
   ELSIF  v_AOLevel IN (6,7) AND UPPER(v_ShortTypeName) LIKE ('Ж/Д%') THEN
      v_ObjectGroup:=c_RailWayObjectValue;
   ELSIF v_AOLevel = 7 AND UPPER(v_ShortTypeName) NOT LIKE ('Ж/Д%') AND UPPER(v_ShortTypeName) NOT IN ('УЧ-К','ГСК','ПЛ-КА','СНТ','ТЕР')
         OR (v_AOLevel = 6 AND UPPER(v_ShortTypeName) IN ('МКР') )  THEN
      v_ObjectGroup:=c_StreetGroupValue;
   ELSIF v_AOLevel = 90 OR v_AOLevel = 6 AND UPPER(v_ShortTypeName) IN ('САД','СНТ','ТЕР','ПРОМЗОНА','ДП')
      OR v_AOLevel = 7 AND UPPER(v_ShortTypeName) IN ('УЧ-К','ГСК','ПЛ-КА','СНТ','ТЕР')  THEN
      v_ObjectGroup:=c_AddlTerritoryValue;
   ELSIF v_AOLevel = 91 THEN
      v_ObjectGroup:=c_PartAddlTerritoryValue;
   END IF;

   RETURN v_ObjectGroup;
  END;
  $BODY$
 LANGUAGE plpgsql;
COMMENT ON FUNCTION fias.fsfn_addressobjects_objectgroup(a_AOGUID VARCHAR(36),a_CurrStatus INTEGER)
               IS 'Возвращает  признак группы адресного объекта по его идентификатору в таблице fias.fias_addressobjects';


--ROLLBACK TRANSACTION;
COMMIT TRANSACTION;