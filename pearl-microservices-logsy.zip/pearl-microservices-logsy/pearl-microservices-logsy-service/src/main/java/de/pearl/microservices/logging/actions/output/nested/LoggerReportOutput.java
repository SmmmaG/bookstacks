package de.pearl.microservices.logging.actions.output.nested;

import lombok.Value;

@Value
public class LoggerReportOutput {

    private boolean reportSent;
}
