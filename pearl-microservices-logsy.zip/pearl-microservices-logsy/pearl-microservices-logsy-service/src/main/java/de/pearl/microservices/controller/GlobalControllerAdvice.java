package de.pearl.microservices.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import de.pearl.microservices.errors.*;
import de.pearl.microservices.model.InventoryCheckEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import de.pearl.microservices.commons.client.feign.AdaptiveErrorHelper;
import de.pearl.microservices.model.CodeCheckEntity;

@ControllerAdvice
public class GlobalControllerAdvice {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalControllerAdvice.class);

    @ExceptionHandler(CodeCheckException.class)
    @ResponseBody
    public ResponseEntity<?> onError(CodeCheckException error) {
        CodeCheckEntity entity = new CodeCheckEntity();
        entity.setMessage(error.getMessage());
        entity.setType(error.getType());

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(entity);
    }

    @ExceptionHandler(InventoryCheckException.class)
    @ResponseBody
    public ResponseEntity<?> onError(InventoryCheckException error) {
        InventoryCheckEntity entity = InventoryCheckEntity.builder()
                .exception(error.getClass().getName())
                .message(error.getMessage())
                .path(error.getEndpoint())
                .build();

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(entity);
    }

    @ExceptionHandler(WwsConnectionException.class)
    @ResponseBody
    public ResponseEntity<?> onError(WwsConnectionException error) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorBody(error));
    }

    @ExceptionHandler(LoginException.class)
    @ResponseBody
    public ResponseEntity<?> onError(LoginException error) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorBody(error));
    }

    @ExceptionHandler(PickerValidationFailed.class)
    @ResponseBody
    public ResponseEntity<?> onError(PickerValidationFailed error) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error.getStageResponse());
    }

    @ExceptionHandler(Throwable.class)
    @ResponseBody
    public ResponseEntity<?> onError(Throwable error, HttpServletRequest request) {
        String requestAsString = null;

        if (request != null) {
            requestAsString = requestAsString(request);
        }

        String logMessage = "cannot do request '{}', cause:";

        if (error instanceof NullPointerException) {
            LOGGER.error(logMessage, requestAsString, error);
        } else {
            LOGGER.debug(logMessage, requestAsString, error);
        }

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorBody(error));
    }

    // -- private methods

    private String requestAsString(HttpServletRequest request) {
        StringBuffer buffer = new StringBuffer();

        buffer.append(request.getMethod()).append(": ").append(request.getRequestURL());

        if (!request.getParameterMap().isEmpty()) {
            // collect HTTP parameters

            List<String> params = request.getParameterMap()
                    .entrySet()
                    .stream()
                    .map(p -> p.getKey() + "=" + p.getValue())
                    .collect(Collectors.toList());
            buffer.append(" | parameters: {").append(String.join(", ", params)).append("}");
        }

        return buffer.toString();
    }

    private Map<String, Object> errorBody(Throwable error) {
        Map<String, Object> errorBody = new HashMap<>();

        if (error instanceof Exception) {
            Map<String, Object> exceptionMap = AdaptiveErrorHelper.encode((Exception) error);

            if (!exceptionMap.isEmpty()) {
                errorBody.putAll(exceptionMap);
            } else {
                errorBody.put(AdaptiveErrorHelper.MAP_MESSAGE, error.toString());
            }
        } else {
            errorBody.put(AdaptiveErrorHelper.MAP_MESSAGE, error.toString());
        }

        return errorBody;
    }

}
