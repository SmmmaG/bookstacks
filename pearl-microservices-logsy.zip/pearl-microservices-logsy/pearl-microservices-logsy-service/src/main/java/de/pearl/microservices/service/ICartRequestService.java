package de.pearl.microservices.service;

import de.pearl.microservices.model.Session;
import de.pearl.microservices.persistence.entities.CartContext;

public interface ICartRequestService {

    CartContext getCartContextResult(final String userId);

    void callGetCartForUser(final String userId, final Session session, final String vzCode);

    boolean isTaskExistForUser(final String userId);
    
    boolean isTaskFinishedForUser(final String userId);

}
