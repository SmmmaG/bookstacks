package de.pearl.microservices.service;

import java.util.List;

import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.WwsConnectionException;
import de.pearl.microservices.model.Session;
import de.pearl.microservices.model.User;

/**
 * User login service
 * 
 * @author Ismakaev
 *
 */
public interface ILoginService {
    /**
     * Get user privilegies
     * 
     * @param session
     *            users session
     * @return list of roles names
     * @throws LoginException
     *             exception when user isnt logged in
     * @throws ParseException
     *             parse WWS response exception
     * @throws WwsConnectionException
     *             WWS connection exception
     * @throws IOException
     */
    List<String> getUserPrivileges(Session session) throws LoginException, WwsConnectionException;

    /**
     * Login user to microservice with username and password
     * 
     * @param username
     *            username
     * @param password
     *            password
     * @return Logged user object
     * @throws IOException
     *             errors on login in WWS
     */
    User login(String username, String password);

    /**
     * Logout user and remove his data from microservice
     * 
     * @param user
     *            user
     */
    void logout(User user);

}