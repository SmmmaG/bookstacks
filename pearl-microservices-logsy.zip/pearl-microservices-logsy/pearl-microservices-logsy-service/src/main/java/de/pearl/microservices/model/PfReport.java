package de.pearl.microservices.model;

import lombok.Data;

@Data
public class PfReport {

    public static final Long PRODUCT_MISSED = 3L;
    public static final Long WRONG_QTY = 5L;
    public static final Long WRONG_EAN = 6L;

    private String source;
    private Long pfFlag;
    private UserDetails userDetails;
    private Job job;
    private VzInfo vzId;
}
