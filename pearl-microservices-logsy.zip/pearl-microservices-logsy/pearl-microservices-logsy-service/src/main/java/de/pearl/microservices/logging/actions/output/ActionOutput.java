package de.pearl.microservices.logging.actions.output;

import de.pearl.microservices.logging.LogProduct;
import de.pearl.microservices.logging.actions.output.nested.*;
import de.pearl.microservices.model.Job;
import de.pearl.microservices.model.Stock;
import lombok.Getter;
import lombok.val;

import java.util.List;

@Getter
public class ActionOutput {
    private LoginResponse loginResponse;
    private LoggerError error;
    private Job job;
    private LogStock stock;
    private LoggerReportOutput reportOutput;
    private LogsyProductDetails productDetails;

    private ActionOutput() {

    }

    public static ActionOutput forSuccessLoginLog(String name,
                                                  LogSession session,
                                                  List<String> privileges) {
        val result = new ActionOutput();
        result.loginResponse = new LoginResponse(name, session, privileges);

        return result;
    }

    public static ActionOutput forErrorLog(String errorMessage) {
        val result = new ActionOutput();
        result.error = new LoggerError(errorMessage);

        return result;
    }

    public static ActionOutput forJobInfoLog(Job job) {
        val result = new ActionOutput();
        result.job = job;

        return result;
    }

    public static ActionOutput forStockLog(Stock stock, LogProduct product) {
        val result = new ActionOutput();
        result.stock = new LogStock();
        result.stock.setBarcode(stock.getCode());
        result.stock.setProduct(product);
        result.stock.setQuantity(stock.getQuantity());


        return result;
    }

    public static ActionOutput forReportOutputLog(boolean isReportSent) {
        val result = new ActionOutput();
        result.reportOutput = new LoggerReportOutput(isReportSent);

        return result;
    }

    public static ActionOutput forProductDetailsLog(LogProduct logProduct) {
        val result = new ActionOutput();
        result.productDetails = new LogsyProductDetails(logProduct);

        return result;
    }
}
