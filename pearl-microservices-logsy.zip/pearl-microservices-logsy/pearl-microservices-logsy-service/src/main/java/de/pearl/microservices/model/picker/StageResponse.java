package de.pearl.microservices.model.picker;

import lombok.Data;

@Data
public class StageResponse {
    private PickJob pickerJob;
    private StageResult result;
    private PickerStage stage;
    private String message;
    private Integer scenario;
    private int totalJobs;
    private int totalQty;
}
