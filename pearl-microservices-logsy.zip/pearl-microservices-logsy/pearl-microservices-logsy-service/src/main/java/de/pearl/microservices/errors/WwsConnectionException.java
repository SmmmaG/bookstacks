package de.pearl.microservices.errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class WwsConnectionException extends RuntimeException {

    private String endpoint;

    public WwsConnectionException(String message , String endpoint) {
        super(message);
        this.endpoint = endpoint;
    }
}
