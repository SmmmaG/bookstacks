package de.pearl.microservices.model;

import lombok.Data;

@Data
public class NewJobRequest {
    private boolean heartBeat;
    private String jobType;
    private UserDetails userDetails;
}
