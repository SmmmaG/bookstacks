package de.pearl.microservices.persistence.entities.dto.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import de.pearl.microservices.persistence.entities.PutTask;
import de.pearl.microservices.persistence.entities.dto.DTO;
import de.pearl.microservices.persistence.enums.TaskStatus;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder @ToString()
@JsonIgnoreProperties(ignoreUnknown = true)
public class PutTaskDTO implements DTO<PutTask> {
    private Long compartmentId;
    private Short puttQuantity;
    private String compartmentLabelValue;

    @Override
    public PutTask toEntity() {
        PutTask newPut = new PutTask();
        newPut.setCompartmentId(this.getCompartmentId());
        newPut.setCompartmentLabelValue(this.getCompartmentLabelValue());
        newPut.setQuantity(this.getPuttQuantity());
        newPut.setStatus(TaskStatus.TO_DO);
        return newPut;
    }
}
