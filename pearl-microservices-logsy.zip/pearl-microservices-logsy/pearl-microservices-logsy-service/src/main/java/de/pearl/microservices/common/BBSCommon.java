package de.pearl.microservices.common;

public class BBSCommon {

    public static int assignLabelType(String as_label) {
        String ls_tmp = as_label.trim();
        if (ls_tmp.length() >= 3) {
            if (isLabelHF(ls_tmp)) {
                return 2;
            } else if (isLabelFS(ls_tmp)) {
                return 1;
            } else if (isLabelCB(ls_tmp)) {
                return 5;
            } else if (isLabelSB(ls_tmp)) {
                return 10;
            } else if (isLabelSG(ls_tmp)) {
                return 12;
            } else if (isLabelPD(ls_tmp)) {
                return 3;
            } else if (isLabelPDWithoutNUM(ls_tmp)) {
                return 7;
            } else if (isLabelEAN_PA(ls_tmp)) {
                return 8;
            } else if (isLabelGutGeld(ls_tmp)) {
                return 6;
            } else {
                return isLabelEAN(ls_tmp) ? 6 : 0;
            }
        } else {
            return 0;
        }
    }

    private static boolean isLabelHF(String as_label) {
        return (as_label.length() == 10 || as_label.length() == 11) && as_label.charAt(4) == '-' && as_label.charAt(7) == '-';
    }


    private static boolean isLabelFS(String as_label) {
        return as_label.length() == 13 && as_label.charAt(4) == '-' && as_label.charAt(7) == '-' && as_label.charAt(10) == '-';
    }

    private static boolean isLabelCB(String as_label) {
        return as_label.length() == 12 && as_label.charAt(3) == '-' && as_label.charAt(6) == '-' && as_label.charAt(9) == '-';
    }

    private static boolean isLabelSB(String as_label) {
        return as_label.length() == 15 && as_label.charAt(4) == '-' && as_label.charAt(7) == '-' && as_label.charAt(12) == '-';
    }

    private static boolean isLabelSG(String as_label) {
        return as_label.length() == 9 && as_label.charAt(3) == '-' && as_label.charAt(6) == '-';
    }

    private static boolean isLabelPD(String as_label) {
        if (as_label.length() < 3) {
            return false;
        } else {
            int li_idx = as_label.indexOf(45);
            if (li_idx == -1) {
                return false;
            } else {
                try {
                    Long.parseLong(as_label.substring(li_idx + 1));
                } catch (NumberFormatException var3) {
                    return false;
                }

                return as_label.charAt(0) >= 'A';
            }
        }
    }


    private static boolean isLabelPDWithoutNUM(String as_label) {
        if (as_label.length() < 2) {
            return false;
        } else if (as_label.indexOf(45) != -1) {
            return false;
        } else {
            return as_label.charAt(0) >= 'A';
        }
    }

    private static boolean isLabelEAN_PA(String as_label) {
        if (as_label.length() < 3) {
            return false;
        } else if (as_label.charAt(0) != '0') {
            return false;
        } else {
            int pointPos = as_label.indexOf(46);
            if (pointPos == -1) {
                return false;
            } else {
                try {
                    int dashPos = as_label.indexOf(45, pointPos);
                    if (dashPos == -1) {
                        Long.parseLong(as_label.substring(pointPos + 1));
                    } else {
                        Long.parseLong(as_label.substring(pointPos + 1, dashPos));
                    }

                    return true;
                } catch (NumberFormatException var3) {
                    return false;
                }
            }
        }
    }

    private static boolean isLabelGutGeld(String as_label) {
        if (as_label != null && as_label.length() >= 10) {
            if (as_label.charAt(0) == '1' && as_label.charAt(1) == '.') {
                try {
                    Long.parseLong(as_label.substring(2));
                    return true;
                } catch (NumberFormatException var2) {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private static boolean isLabelEAN(String as_label) {
        String regex = "\\d+";
        if(as_label.matches(regex)) {
            return as_label.length() > 4 && as_label.length() < 21;
        }
        return false;
    }
}
