package de.pearl.microservices.controller;

import de.pearl.microservices.model.*;
import de.pearl.microservices.model.picker.StageResponse;
import de.pearl.microservices.model.picker.StageResult;
import de.pearl.microservices.service.IDeviceService;
import de.pearl.microservices.service.IPickerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/logsy")
public class DeviceController {

    private final String confirmString = "Roger";
    private final String validationStock = "Validation Before Action";
    private final String infoStock = "Getting Stock information";
    private final IDeviceService deviceService;
    private final IPickerService pickerService;

    @Autowired
    public DeviceController(IDeviceService service, IPickerService pickerService) {
        this.deviceService = service;
        this.pickerService = pickerService;
    }

    @GetMapping("/testConnection/{testData}")
    public ResponseEntity<String> testConnection(@PathVariable(name = "testData") String testData) {
        return ResponseEntity.ok(confirmString);
    }

    @GetMapping("/device/checkQuantity/{quantity}")
    public ResponseEntity<String> checkQuantity(@PathVariable(name = "quantity") Long quantity) {
        if (quantity > 0) {
            return ResponseEntity.ok("success");
        }

        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @PostMapping("device/pfReport")
    public ResponseEntity<StageResponse> sendPfReport(@RequestBody PfReport report) {
        StageResponse result = pickerService.sendProblemFlag(report);

        if (result.getResult() == StageResult.FAIL) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        return ResponseEntity.ok(result);
    }

    @PostMapping("device/sendreport/{jobType}")
    public ResponseEntity<String> sendReport(@PathVariable(name = "jobType") String jobType, @RequestBody Report report) {
        if (jobType.equals("moving")) {
            ReportResult result = deviceService.sendMovingReport(report.getUserDetails(), report, jobType);
            if (result.getResult() == StageResult.FAIL) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            return ResponseEntity.ok("success");
        }

        if (jobType.equals("storing") || jobType.equals("picking")) {
            ReportResult result = deviceService.sendMovingReport(report.getUserDetails(), report, jobType);
            if (result.getResult() == StageResult.FAIL) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            return ResponseEntity.ok("success");
        }

        if (jobType.equals("correction")) {
            ReportResult result = deviceService.sendCorrectionReport(report.getUserDetails(), report);
            if (result.getResult() == StageResult.FAIL) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
            return ResponseEntity.ok("success");
        }

        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @PostMapping("device/{jobType}/checkStock/source/{scanCode:.+}")
    public ResponseEntity<Stock> checkSource(@RequestBody JobRequest jobRequest, @PathVariable(name = "jobType") String jobType,
            @PathVariable(name = "scanCode") String scanCode) {
        Stock stock = deviceService.checkStock(validationStock, jobRequest, jobType, scanCode, false);

        if (stock != null) {
            return ResponseEntity.ok(stock);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("device/{jobType}/checkStock/target/{scanCode:.+}")
    public ResponseEntity<Stock> checkTarget(@RequestBody JobRequest jobRequest, @PathVariable(name = "jobType") String jobType,
            @PathVariable(name = "scanCode") String scanCode) {
        Stock stock = deviceService.checkStock(validationStock, jobRequest, jobType, scanCode, true);

        if (stock != null) {
            return ResponseEntity.ok(stock);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/device/{jobType}/inventory/source/{scanCode:.+}")
    public ResponseEntity<Stock> checkInventory(@RequestBody JobRequest jobRequest, @PathVariable(name = "jobType") String jobType,
            @PathVariable(name = "scanCode") String scanCode) {
        Stock stock = deviceService.inventoryStock(validationStock, jobRequest, jobType, scanCode);

        if (stock != null) {
            return ResponseEntity.ok(stock);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("device/product/loadcamimage/{scanCode:.+}")
    public ResponseEntity<ProductImage> loadCamProductImage(@RequestBody JobRequest jobRequest, @PathVariable(name = "scanCode") String scanCode) {
        return ResponseEntity.ok(deviceService.loadImage(scanCode, jobRequest.getUserDetails().getSession()));
    }

    @PostMapping("device/checkProduct/{scanCode:.+}")
    public ResponseEntity<Product> checkProduct(@RequestBody JobRequest jobRequest, @PathVariable(name = "scanCode") String scanCode) {
        return ResponseEntity.ok(deviceService.checkProduct(jobRequest, scanCode));
    }

    @PostMapping("device/stock/{scanCode:.+}")
    public ResponseEntity<Stock> getStock(@RequestBody JobRequest jobRequest, @PathVariable(name = "scanCode") String scanCode) {
        Stock stock = deviceService.getStock(infoStock, jobRequest, scanCode);

        if (stock != null) {
            return ResponseEntity.ok(stock);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("device/heartBeat")
    public ResponseEntity<Job> heartBeat(@RequestBody NewJobRequest newJobRequest) {
        Job job = deviceService.makeHeartBeat(newJobRequest);

        if (job != null) {
            return ResponseEntity.ok(job);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("device/vzcenter/{qrCode:.+}")
    public ResponseEntity<VzInfo> getVzInfo(@RequestBody VzRequest vzRequest, @PathVariable(name = "qrCode") String qrCode) {
        VzInfo result = deviceService.getVz(vzRequest.getUserDetails(), qrCode);
        return ResponseEntity.ok(result);
    }
}
