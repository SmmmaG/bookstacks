package de.pearl.microservices.model.picker;

import lombok.Data;

import java.util.List;

@Data
public class Slot {
    private String pickId;
    private String source;
    private String pdid;
    private Long pdnum;
    private Long quantity;
    private String putId;
    private String target;
    private Short targetQuantity;
    private String targetId;
    private Long compartmentId;
    //only for response
    private List<PutJob> putJobs;
}
