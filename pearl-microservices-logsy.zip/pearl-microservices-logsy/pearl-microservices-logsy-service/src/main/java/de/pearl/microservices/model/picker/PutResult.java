package de.pearl.microservices.model.picker;

public enum PutResult {
    NONE,
    SUCCESS,
    FAILED;
}
