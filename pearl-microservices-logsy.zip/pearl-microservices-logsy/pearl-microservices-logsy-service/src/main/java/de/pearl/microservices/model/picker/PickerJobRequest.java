package de.pearl.microservices.model.picker;

import de.pearl.microservices.model.UserDetails;
import lombok.Data;

@Data
public class PickerJobRequest {
    private PickerJob job;
    private UserDetails userDetails;
}
