package de.pearl.microservices.model.picker;

import lombok.Data;

@Data
public class PickerRequest {
    PickerJobRequest job;
    StageRequest request;
}
