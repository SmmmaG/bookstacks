package de.pearl.microservices.model.picker;

public enum StageResult {
    FAIL,
    SUCCESS,
    EMPTY
}
