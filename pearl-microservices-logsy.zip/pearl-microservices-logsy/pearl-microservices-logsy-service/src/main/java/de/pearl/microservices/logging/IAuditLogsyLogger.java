package de.pearl.microservices.logging;

import de.pearl.microservices.model.Job;
import de.pearl.microservices.model.PfReport;
import de.pearl.microservices.model.Product;
import de.pearl.microservices.model.Report;
import de.pearl.microservices.model.Stock;
import de.pearl.microservices.model.User;
import de.pearl.microservices.model.UserDetails;

public interface IAuditLogsyLogger {

    String UNAVAILABLE_SESSION = "nouserdetailsavaliable";
    String LOGIN_OPERATION = "Login attempt";
    String STOCK_VALIDATION_OPERATION = "Validation.Stock";
    String PRODUCT_VALIDATION_OPERATION = "Validation.Product";
    String GET_NEXT_CART_OPERATION = "Validation.Product";
    String GET_NEXT_CART = "Cart.Get";
    String SCAN_CART = "Cart.Scan";
    String REPORT_SEND_OPERATION = "Report";
    String REPORT_PF_SEND_OPERATION = "Pf flag Report";
    String HEART_BEAT_OPEARTION = "Heartbeat";
    String JOB_TYPE_OPERATION = "Job.Start";
    String PICKER_GET_CART = "Picker.Cart.Ask";
    String PICKER_SCAN_CART = "Picker.Cart.Scan";
    String PICKER_PICK_PRODUCTS = "Picker.Product.Pick";
    String PICKER_PUT_PRODUCTS = "Picker.Product.Put";
    String PICKER_PARK_CART = "Picker.Cart.Park";
    String PICKER_PROBLEM_FLAG = "Picker.Set.PFlag";
    String PICKER_EPOS = "Picker.EPos";
    String PICKER_MPOS = "Picker.MPos";
    String FAIL_RESULT = "FAIL";
    String SUCCESS_RESULT = "SUCCESS";
    String AUTHORITY = "WWS";

    void logsuccessLogin(String url, User user);

    void logerrorLogin(String url, String userName);

    void logerrorLogin(String url, String userName, String errorMessage);

    void logerrorLogin(String actionType, String trigger, LogUser user, Stock stock, String errorMessage);

    void logerrorLogin(String barCode, String trigger, LogUser user, Product wProduct, String errorMessage);

    void logerrorLogin(String jobType, String trigger, LogUser user, Report report, String errorMessage);

    void logerrorLogin(String jobType, String trigger, LogUser user, PfReport report, String errorMessage);

    void logSuccessJobStart(String trigger, LogUser user, Job job);

    void logErrorJobStart(String trigger, LogUser user, Job job, String errorMessage);

    void logsucessHeartBeat(String trigger, LogUser user, String url);

    void logErrorHeartBeat(String trigger, LogUser user, String url, String errorMessage);

    void logsuccessStockCheck(String actionType, String trigger, LogUser user, Stock stock);

    void logerrorStockCheck(String actionType, String trigger, LogUser user, Stock stock, String errorMessage);

    void logsuccessProductCheck(String code, String trigger, LogUser user, Product wProduct);

    void logPickerAction(String action, String barcode, String vzid, UserDetails user, String errorMessage, String result);

    void logErrorGetNextCart(String action, String vzid, LogUser user, String ip, String message);

    void logSuccessGetNextCart(String action, String vzid, LogUser user);

    void logerrorProductCheck(String code, String trigger, LogUser user, Product wProduct, String errorMessage);

    void logsuccessReportSend(String jobType, String trigger, LogUser user, PfReport report);

    void logerrorReportSend(String jobType, String trigger, LogUser user, PfReport report, String errorMessage);

    void logsuccessReportSend(String jobType, String trigger, LogUser user, Report report);

    void logerrorReportSend(String jobType, String trigger, LogUser user, Report report, String errorMessage);

}