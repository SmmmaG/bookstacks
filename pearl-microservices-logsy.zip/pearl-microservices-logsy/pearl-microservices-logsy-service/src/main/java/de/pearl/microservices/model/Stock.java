package de.pearl.microservices.model;

import java.util.Date;

import lombok.Data;

@Data
public class Stock {
    private String code; // code to compare for identity
    private String codeToShow; // code to show on UI for user
    private String pdid;
    private Long pdnum;
    private Long quantity;
    private Long stockType;
    private Long shelfUnit;
    private Long section;
    private Long row;
    private Long shelf;
    private Long pfFlag;
    private String pickMessage;
    private Date createDate;
    private Date updateDate;
    private boolean emptySlot;
    private Long errorCode;
    private String errorMessage;
}
