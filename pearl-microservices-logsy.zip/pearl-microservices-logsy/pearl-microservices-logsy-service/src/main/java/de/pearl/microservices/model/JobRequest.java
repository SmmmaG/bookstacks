package de.pearl.microservices.model;

import lombok.Data;

@Data
public class JobRequest {
    private Job job;
    private UserDetails userDetails;
}
