package de.pearl.microservices.errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CodeCheckException extends RuntimeException {

    private InvalidCodeType type;

    public CodeCheckException(String message, InvalidCodeType type) {
        super(message);
        this.type = type;
    }
}
