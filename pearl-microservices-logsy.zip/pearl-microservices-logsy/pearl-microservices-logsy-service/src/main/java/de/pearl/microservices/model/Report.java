package de.pearl.microservices.model;
import lombok.Data;

@Data
public class Report {
    private String source;
    private String pdid;
    private Long pdnum;
    private Short quantity;
    private String target;
    private UserDetails userDetails;
    private Job job;
}
