package de.pearl.microservices.persistence.entities.dto.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder @ToString()
@JsonIgnoreProperties(ignoreUnknown = true)
public class StockPlacePKDTO {
    private Short stockType;
    private Short row;
    private Long section;
    private Long shelf;
    private Long shelfUnit;
}
