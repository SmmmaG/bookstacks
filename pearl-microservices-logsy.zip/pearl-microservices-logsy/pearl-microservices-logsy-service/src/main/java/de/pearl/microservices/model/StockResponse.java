package de.pearl.microservices.model;

import java.util.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class StockResponse {
    private Data data;
    private Error error;

    @Getter
    @Setter
    public static class Data {
        private Id id;
        private Long pflag;
        private String labelValue; // label to compare (code)
        private String labelCaption; // label to show (codeToShow)
        private String pdId;
        private Long pdNum;
        private Long inventory;
        private String pickMessage;
        private Date createDate;
        private Date updateDate;
    }

    @Getter
    @Setter
    public static class Id {
        private Long stockType;
        private Long shelfUnit;
        private Long section;
        private Long row;
        private Long shelf;
    }

    @Getter
    @Setter
    public static class Error {
        private String message;
    }

    public Stock toStock() {
        Stock stock = new Stock();
        stock.setCode(data.getLabelValue());
        stock.setCodeToShow(data.getLabelCaption());
        stock.setPdid(data.getPdId());
        stock.setPdnum(data.getPdNum());
        stock.setQuantity(data.getInventory());
        stock.setCreateDate(data.getCreateDate());
        stock.setUpdateDate(data.getUpdateDate());
        stock.setPickMessage(data.getPickMessage());
        stock.setPfFlag(data.getPflag());

        stock.setRow(data.id.getRow());
        stock.setSection(data.id.getSection());
        stock.setShelf(data.id.getShelf());
        stock.setShelfUnit(data.id.getShelfUnit());
        stock.setStockType(data.id.getStockType());

        return stock;
    }
}
