package de.pearl.microservices.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.PickerValidationFailed;
import de.pearl.microservices.errors.WwsConnectionException;
import de.pearl.microservices.model.picker.PickerRequest;
import de.pearl.microservices.model.picker.PickerStage;
import de.pearl.microservices.model.picker.StageResponse;
import de.pearl.microservices.model.picker.StageResult;
import de.pearl.microservices.service.IPickerService;
import de.pearl.microservices.service.IStateMachineService;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StateMachineService implements IStateMachineService {
    private ObjectMapper jacksonMapper = new ObjectMapper();
    private IPickerService pickerService;

    @Autowired
    public void setPickerService(final IPickerService pickerService) {
        this.pickerService = pickerService;
    }

    @Override
    public StageResponse cancelStage(final PickerRequest request) {
        StageResponse response = new StageResponse();
        response.setStage(request.getRequest().getStage().leave());
        response.setResult(StageResult.SUCCESS);
        return response;
    }

    @Override
    public StageResponse nextStage(final PickerRequest request) {
        StageResponse response = new StageResponse();
        PickerStage stage = request.getRequest().getStage();
        if (stage != null) {
            response.setStage(stage.next());
        }
        // else {
        // response.setStage(PickerStage.GETTINGTGTTASK);
        // }
        log.debug("request is: {}", request);
        response.setResult(StageResult.SUCCESS);
        return response;
    }

    @Override
    public StageResponse processTask(final PickerRequest request) throws LoginException, WwsConnectionException, PickerValidationFailed {
        try {
            if (log.isInfoEnabled()) {
                try {
                    log.info("request: cart = {}; stage = {} ", request.getJob().getJob().getTrolley(), request.getRequest().getStage());
                } catch (Exception ignored) {
                }
            }
            if (log.isTraceEnabled()) {
                try {
                    log.trace("REQUEST!!! {}", jacksonMapper.writer().withDefaultPrettyPrinter().writeValueAsString(request));
                } catch (Exception ignored) {
                }
            }
            switch (request.getRequest().getStage()) {
                case GETTINGTROLLEY:
                    return pickerService.getTrolley(request.getRequest(), request.getJob());
                case SCANNINGTROLLEY:
                    return pickerService.scanTrolley(request.getRequest(), request.getJob());
                case GETTINGTGTTASK:
                    return pickerService.getTask(request.getRequest(), request.getJob());
                case SCANNINGTGTSLOT:
                    return pickerService.scanSource(request.getRequest(), request.getJob());
                case SCANNINGTGTPRODUCT:
                    return pickerService.scanProduct(request.getRequest(), request.getJob());
                case CHECKINGTGTQTY:
                    if (request.getJob().getJob().getScenario() == 11) { // epos
                        return pickerService.sendReportEpos(request);
                    }
                    return pickerService.checkQuantity(request.getRequest(), request.getJob());
                case GETTINGDESTTASK:
                    return nextStage(request);
                case SCANINGDESTSLOT:
                    return pickerService.scanTarget(request.getRequest(), request.getJob());
                case CHECKINGDESTQTY:
                    return pickerService.checkTargetQty(request.getRequest(), request.getJob());
                case SENDREPORT:
                    return pickerService.sendReport(request.getRequest(), request.getJob());
                case PARKTROLLEY:
                    // TODO: handle response
                    // request.getRequest().setStage(GETTINGTROLLEY);
                    return pickerService.getParkingPlace(request);
                // return getTrolley(request.getRequest(), request.getJob());
                // case SCANPARKPLACE:
                // return getTrolley(request.getRequest(), request.getJob());
                default:
                    return null;
            }
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                try {
                    log.error("EXCEPTION!!! request = {}", jacksonMapper.writer().withDefaultPrettyPrinter().writeValueAsString(request));
                } catch (Exception ex) {
                }
                log.error("EXCEPTION!!!", e);
            }
            throw new PickerValidationFailed(request.getRequest(), e.getMessage());
        }
    }
}
