package de.pearl.microservices.persistence.entities.dto.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import de.pearl.microservices.persistence.entities.CartContext;
import de.pearl.microservices.persistence.entities.PickTask;
import de.pearl.microservices.persistence.entities.dto.DTO;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Data @NoArgsConstructor @AllArgsConstructor @Builder @ToString()
@JsonIgnoreProperties(ignoreUnknown = true)
public class CartContextDTO implements DTO<CartContext> {
    private CartDTO cart;
    private List<PickTaskDTO> picks;
    private boolean singlePos;

    @Override
    public CartContext toEntity() {
        CartContext newCart = new CartContext();
        newCart.setCartId(cart.getLabelValue());
        List<PickTask> newPickList = new ArrayList<>();
        for (PickTaskDTO pick : picks) {
            newPickList.add(pick.toEntity());
        }
        newCart.addPickTasks(newPickList);
        newCart.setScenarioType(isSinglePos() ? 11 : 0);
        return newCart;
    }
}
