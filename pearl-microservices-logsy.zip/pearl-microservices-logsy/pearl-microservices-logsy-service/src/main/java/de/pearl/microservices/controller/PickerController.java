package de.pearl.microservices.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import de.pearl.microservices.model.picker.PickerRequest;
import de.pearl.microservices.model.picker.StageResponse;
import de.pearl.microservices.model.picker.StageResult;
import de.pearl.microservices.service.IStateMachineService;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping(value = "/logsy")
public class PickerController {

    private IStateMachineService stateMachineService;

    @Autowired
    public void setStateMashineService(IStateMachineService stateMashineService) {
        this.stateMachineService = stateMashineService;
    }

    @PostMapping("picker/processstage")
    public ResponseEntity<StageResponse> processStage(@RequestBody PickerRequest request) {
        return ResponseEntity.ok(stateMachineService.processTask(request));
    }

    @PostMapping("picker/trolley")
    public ResponseEntity<StageResponse> getTrolley(@RequestBody PickerRequest request) {
        StageResponse result;
        try {
            result = stateMachineService.processTask(request);
            if (StageResult.SUCCESS.equals(result.getResult())) {
                return ResponseEntity.ok(result);
            }
        } catch (Exception e) {
            log.error("process task error", e);
            result = new StageResponse();
            result.setResult(StageResult.FAIL);
            result.setMessage(e.getMessage());
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
    }

    @PostMapping("picker/skipstage")
    public ResponseEntity<StageResponse> skipStage(@RequestBody PickerRequest request) {
        return ResponseEntity.ok(stateMachineService.cancelStage(request));
    }

    @PostMapping("picker/nextstage")
    public ResponseEntity<StageResponse> nextStage(@RequestBody PickerRequest request) {
        return ResponseEntity.ok(stateMachineService.nextStage(request));
    }

}
