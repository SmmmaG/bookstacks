package de.pearl.microservices.model;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class RigthsResponse {
    private List<String> rights;
    private String error;
    private String userId;
    private Date timestamp;
}