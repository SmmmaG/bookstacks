package de.pearl.microservices.persistence.repositories;

import de.pearl.microservices.persistence.entities.UserSession;
import org.springframework.data.repository.CrudRepository;

public interface UserSessionRepository extends CrudRepository<UserSession, Long> {
    /**
     * Because userId column is not unique "Top1" keyword limitation has to be used.<br>
     * TODO: need unit test for case when the table has several rows with the same userId
     * <br>
     * @param userId
     * @return last added UserSession
     */
    UserSession findTop1ByUserIdOrderByIdDesc(Long userId);
}
