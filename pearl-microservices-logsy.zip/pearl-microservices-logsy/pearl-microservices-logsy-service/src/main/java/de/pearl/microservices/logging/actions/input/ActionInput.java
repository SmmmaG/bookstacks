package de.pearl.microservices.logging.actions.input;

import de.pearl.microservices.logging.LogProduct;
import de.pearl.microservices.logging.actions.input.nested.*;
import lombok.Getter;
import lombok.val;

@Getter
public class ActionInput {
    private LoginRequest loginRequest;

    private String jobName;

    private LoggerHeartBeat heartBeat;

    private LogBarcodeInput barcode;

    private LogPfReport pfReport;

    private LogReport report;

    private ActionInput() {

    }

    public static ActionInput forLogLogin(String authorityType,
                                          String userName,
                                          String url) {
        ActionInput result = new ActionInput();
        result.loginRequest = new LoginRequest(authorityType, userName, url);

        return result;
    }

    public static ActionInput forLogJobStart(String jobName) {
        ActionInput result = new ActionInput();
        result.jobName = jobName;

        return result;
    }

    public static ActionInput forLogHeartBeat(String wwsUrl) {
        ActionInput result = new ActionInput();
        result.heartBeat = new LoggerHeartBeat(wwsUrl);

        return result;
    }

    public static ActionInput forLogBarcode(String barcode) {
        ActionInput result = new ActionInput();
        result.barcode = new LogBarcodeInput(barcode);

        return result;
    }

    public static ActionInput forLogLogPfReport(String source, Long pfFlag) {
        ActionInput result = new ActionInput();
        result.pfReport = new LogPfReport(source, pfFlag);

        return result;
    }

    public static ActionInput forLogReportSend(String source,
                                               LogProduct product,
                                               Short quantity,
                                               String target) {
        val result = new ActionInput();
        result.report = new LogReport();
        result.report.setSource(source);
        result.report.setProduct(product);
        result.report.setQuantity(quantity);
        result.report.setTarget(target);


        return result;
    }
}
