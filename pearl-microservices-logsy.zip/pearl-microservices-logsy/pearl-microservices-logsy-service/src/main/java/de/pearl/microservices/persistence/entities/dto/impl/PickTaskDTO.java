package de.pearl.microservices.persistence.entities.dto.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import de.pearl.microservices.persistence.entities.PickTask;
import de.pearl.microservices.persistence.entities.PutTask;
import de.pearl.microservices.persistence.entities.dto.DTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString()
@Slf4j
@JsonIgnoreProperties(ignoreUnknown = true)
public class PickTaskDTO implements DTO<PickTask> {
    private Integer id;
    private Integer cartId;
    private StockPlaceDTO pickStockPlace;
    private Integer pickQuantity;
    private List<PutTaskDTO> putts;
    private Integer sortIndex;
    private String labelValue;
    private String productLabelValue;

    @Override
    public PickTask toEntity() {
        PickTask newTask = new PickTask();
        // newTask.setCartContext();
        newTask.setPdId(pickStockPlace.getPdId());
        newTask.setPdLabel(productLabelValue);
        newTask.setPdNum(pickStockPlace.getPdNum());
        List<PutTask> puts = new ArrayList<>();
        AtomicInteger index = new AtomicInteger();
        putts.forEach((put) -> {
            PutTask newPut = put.toEntity();
            newPut.setPickTask(newTask);
            newPut.setPickTaskId(newTask.getId());
            newPut.setRank(index.getAndIncrement());
            puts.add(newPut);
        });
        index.set(0);
        newTask.addPutTasks(puts);
        newTask.setQuantity(pickQuantity);
        newTask.setRank(sortIndex);
        newTask.setSource(pickStockPlace.getLabelValue());
        newTask.updateStatus();
        log.trace("Update pick(pdid = {} sources = {} qty ={}  status = {}) ", newTask.getPdId(), newTask.getSource(), newTask.getQuantity(),
                newTask.getStatus().toString());
        return newTask;
    }
}
