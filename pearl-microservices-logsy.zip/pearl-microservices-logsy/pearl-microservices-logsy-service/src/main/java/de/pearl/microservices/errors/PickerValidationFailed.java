package de.pearl.microservices.errors;

import de.pearl.microservices.model.picker.StageRequest;
import de.pearl.microservices.model.picker.StageResponse;
import de.pearl.microservices.model.picker.StageResult;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class PickerValidationFailed extends RuntimeException {

    private StageResponse stageResponse;

    public PickerValidationFailed(final StageRequest request, final String message) {
        super(message);
        stageResponse = new StageResponse();
        stageResponse.setStage(request.getStage());
        stageResponse.setResult(StageResult.FAIL);
        stageResponse.setMessage(message);
    }

    public PickerValidationFailed(final StageRequest request, final String message, final Throwable cause) {
        super(message, cause);
        stageResponse = new StageResponse();
        stageResponse.setStage(request.getStage());
        stageResponse.setResult(StageResult.FAIL);
        stageResponse.setMessage(message);
    }
}
