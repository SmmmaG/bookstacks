package de.pearl.microservices.persistence.repositories;

import de.pearl.microservices.persistence.entities.CartContext;
import de.pearl.microservices.persistence.entities.UserSession;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CartContextRepository extends CrudRepository<CartContext, Long> {
    @Query(value = "select \n" +
        "  cart.*\n" +
        "from\n" +
        "  warehouse_terminal.user_session usession, \n" +
        "  warehouse_terminal.cart_context cart\n" +
        "where cart.user_session_id = usession.id\n" +
        "  and usession.user_id = :userName\n" +
        "  and cart.cart_id = :cartId\n"
        , nativeQuery = true)
    List<CartContext> findByUserIdAndCartId(@Param("userName") Long userName, @Param("cartId")String cartId);

    List<CartContext> findAllByUserSession(UserSession session);

    @Query(value = "select \n" +
        "  cart.*\n" +
        "from\n" +
        "  warehouse_terminal.user_session usession, \n" +
        "  warehouse_terminal.cart_context cart\n" +
        "where cart.user_session_id = usession.id\n" +
        "  and usession.user_id = :userName\n" +
        "order by cart.id\n" +
        "limit 1"
        , nativeQuery = true)
    CartContext findTop1ByUserIdOrderById(@Param("userName") Long userName);
}
