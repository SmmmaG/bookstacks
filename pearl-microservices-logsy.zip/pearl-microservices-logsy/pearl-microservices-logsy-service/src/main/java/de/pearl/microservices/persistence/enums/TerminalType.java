package de.pearl.microservices.persistence.enums;

public enum TerminalType {
    PORTABLE
}
