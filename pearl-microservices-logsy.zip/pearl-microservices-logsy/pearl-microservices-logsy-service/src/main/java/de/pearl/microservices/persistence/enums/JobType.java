package de.pearl.microservices.persistence.enums;

public enum JobType {
    STORING,
    PICKING,
    MOVING,
    INFO,
    INVENTORY,
    CORRECTION
}
