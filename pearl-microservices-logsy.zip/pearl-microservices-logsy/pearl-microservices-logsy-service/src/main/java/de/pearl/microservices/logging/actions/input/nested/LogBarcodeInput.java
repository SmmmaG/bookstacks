package de.pearl.microservices.logging.actions.input.nested;

import lombok.Value;

@Value
public class LogBarcodeInput {

    private String barcode;
}
