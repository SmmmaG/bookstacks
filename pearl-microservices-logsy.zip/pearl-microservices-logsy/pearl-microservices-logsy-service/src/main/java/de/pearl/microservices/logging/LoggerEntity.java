package de.pearl.microservices.logging;

import lombok.Data;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Data
public class LoggerEntity {
    private static final String ID_FIELD = "id";
    private static final String TIMESTAMP_FIELD = "timestamp";
    private static final String VZ_ID_FIELD = "vzId";
    private static final String USER_FIELD = "user";
    private static final String ACTION_FIELD = "action";
    private static final String OBJECT_FIELD = "object";
    private static final String RESULT_FIELD = "result";

    private Map<String, Object> appends = new HashMap<>();
    private String id;
    private String timestamp;
    private String vzId;
    private LogUser user;
    private LogAction action;
    private LoggerObject object;
    private String result;

    public LoggerEntity(String id, String vzId, LogUser user, LogAction action, LoggerObject object, String result) {
        this.id = id;
        Instant instant = Instant.now();
        this.timestamp = "" + instant.toEpochMilli();
        this.vzId = vzId;
        this.user = user;
        this.action = action;
        this.object = object;
        this.result = result;
        this.buildAppends();
    }

    private void buildAppends() {
        appends.put(ID_FIELD, this.id);
        appends.put(TIMESTAMP_FIELD, this.timestamp);
        appends.put(VZ_ID_FIELD, this.vzId);
        appends.put(USER_FIELD, this.user);
        appends.put(ACTION_FIELD, this.action);
        appends.put(OBJECT_FIELD, this.object);
        appends.put(RESULT_FIELD, this.result);
    }
}
