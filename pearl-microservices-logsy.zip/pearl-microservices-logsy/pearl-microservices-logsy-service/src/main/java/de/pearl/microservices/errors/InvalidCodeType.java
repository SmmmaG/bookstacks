package de.pearl.microservices.errors;

public enum InvalidCodeType{
    BadCode,
    WWS
}
