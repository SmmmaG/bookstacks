package de.pearl.microservices.service.impl;

import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.WwsConnectionException;
import de.pearl.microservices.logging.IAuditLogsyLogger;
import de.pearl.microservices.model.LoginDetails;
import de.pearl.microservices.model.Session;
import de.pearl.microservices.model.User;
import de.pearl.microservices.persistence.entities.CartContext;
import de.pearl.microservices.persistence.entities.UserSession;
import de.pearl.microservices.persistence.enums.events.UserSessionEvents;
import de.pearl.microservices.persistence.repositories.CartContextRepository;
import de.pearl.microservices.persistence.repositories.UserSessionRepository;
import de.pearl.microservices.service.ILoginService;
import de.pearl.microservices.service.IWwsEndpointService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
public class LoginService implements ILoginService {

    private String serverAddress;

    private UserSessionRepository userSessionRepository;

    private CartContextRepository cartContextRepository;

    private IAuditLogsyLogger logsyLogger;

    private IWwsEndpointService wwsEndpointService;

    @Autowired
    public LoginService(UserSessionRepository userSessionRepository, CartContextRepository cartContextRepository, IAuditLogsyLogger logsyLogger, IWwsEndpointService wwsEndpointService)
            throws UnknownHostException {
        this.userSessionRepository = userSessionRepository;
        this.cartContextRepository = cartContextRepository;
        this.logsyLogger = logsyLogger;
        this.wwsEndpointService = wwsEndpointService;

        serverAddress = InetAddress.getLocalHost().getHostAddress();
    }

    @Override
    public List<String> getUserPrivileges(Session session) throws LoginException, WwsConnectionException {
        // Create connection
        List<String> rights = wwsEndpointService.getRights(session);
        if (log.isInfoEnabled()) {
            log.info("user session: {} got privileges: {}", session.getId(), rights);
        }
        return rights;

    }

    @Override
    public User login(String username, String password) {
        User user = new User();
        try {
            if (log.isInfoEnabled()) {
                log.info("try to login user {} with password *****", username);
            }
            LoginDetails loginDetails = wwsEndpointService.login(username, password);
            UUID id = UUID.randomUUID();
            String[] sessionCookies = loginDetails.getCookies().get(0).split(";");
            String sessName = sessionCookies[0];
            String sessPath = sessionCookies[1];
            String sessionId = sessName.substring(sessName.indexOf('=') + 1);
            String sessionName = sessName.substring(0, sessName.indexOf('='));
            String sessionPath = sessPath.substring(sessPath.indexOf('=') + 1);
            Session session = new Session();
            session.setSessionId(sessionId);
            session.setSessionName(sessionName);
            session.setPath(sessionPath);
            session.setDomain(loginDetails.getHost());
            session.setId(id.toString());
            user.setName(username);
            user.setSession(session);

            UserSession uSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(username));
            if (uSession != null) {
                if (log.isInfoEnabled()) {
                    log.info("restore session {} for user {} ", uSession.getId(), username);
                }
                userSessionRepository.save(uSession);
                uSession.updateUserSessionStatus(UserSessionEvents.LOGGING_IN);
            } else {
                if (log.isInfoEnabled()) {
                    log.info("create session for user {} ", username);
                }
                uSession = new UserSession();
                uSession.setUserId(Long.parseLong(username));
                uSession.updateUserSessionStatus(UserSessionEvents.LOGGING_IN);
                userSessionRepository.save(uSession);
            }
        } catch (LoginException e) {
            if (log.isInfoEnabled()) {
                log.info("not login user {} with password ***** cause {}", username, e.getMessage());
            }
            logsyLogger.logerrorLogin(e.getEndpoint(), username, e.getMessage());
            throw e;
        }
        log.info("user {} logged in on server {}", user.getName(), serverAddress);
        return user;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void logout(User user) {
        UserSession sessionToLogout = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(user.getName()));
        if (sessionToLogout != null) {
            if (log.isInfoEnabled()) {
                log.info(" delete user {} session id {}", user.getName(), sessionToLogout.getId());
            }
            List<CartContext> usersCarts = cartContextRepository.findAllByUserSession(sessionToLogout);
            for (CartContext cart : usersCarts) {
                wwsEndpointService.parkTrolley(cart.getCartId(), sessionToLogout.getSite(), user.getSession());
            }
            userSessionRepository.delete(sessionToLogout);
        }
        if (log.isInfoEnabled()) {
            log.info("user {} logout", user.getName());
        }
    }
}
