package de.pearl.microservices.model;

import lombok.Builder;
import lombok.Data;

@Data @Builder
public class InventoryCheckEntity {
    private String exception;
    private String message;
    private String path;
}
