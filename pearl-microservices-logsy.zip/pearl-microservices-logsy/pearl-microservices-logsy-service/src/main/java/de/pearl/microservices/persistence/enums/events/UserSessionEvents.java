package de.pearl.microservices.persistence.enums.events;

public enum UserSessionEvents {
    LOGGING_IN,
    SCAN_QR,
    GET_CART,
    GET_CART_REQ,
    GET_CART_RESP,
    RELEASE_CART
}
