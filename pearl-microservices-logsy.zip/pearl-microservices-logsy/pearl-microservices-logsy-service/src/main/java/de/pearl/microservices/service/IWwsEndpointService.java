package de.pearl.microservices.service;

import java.util.List;

import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.WwsConnectionException;
import de.pearl.microservices.model.CheckStockResponse;
import de.pearl.microservices.model.LoginDetails;
import de.pearl.microservices.model.ProductImage;
import de.pearl.microservices.model.ProductResponse;
import de.pearl.microservices.model.Session;
import de.pearl.microservices.model.StockResponse;
import de.pearl.microservices.model.WwsReportResponse;

public interface IWwsEndpointService {

    static final String SET_COOKIE_NAME = "Set-Cookie";
    static final String UTF_8 = "utf-8";
    static final String CHARSET_NAME = "charset";
    static final String CONTENT_TYPE_VALUE = "application/x-www-form-urlencoded";
    static final String CONTENT_LENGTH_NAME = "Content-Length";
    static final String CONTENT_TYPE_NAME = "Content-Type";
    static final String ACCEPT_JSON = "application/json, application/xml, text/plain, text/html, *.*";
    static final String ACCEPT_VALUE = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8";
    static final String ACCEPT_LANGUAGE_VALUE = "en-US,en;q=0.9,la;q=0.8";
    static final String LANGUAGE_FULL = "en-US,en;q=0.9,la;q=0.8";
    static final String REMOTE_ADDR = "REMOTE_ADDR";
    static final String COOKIE = "Cookie";
    static final String ACCEPT = "Accept";
    static final String ACCEPT_ENCODING = "Accept-Encoding";
    static final String ACCEPT_LANGUAGE = "Accept-Language";

    static final String NO_CACHE = "no-cache";

    static final String USER_RIGHTS_ENDPOINT = "/bbs/pda/logistics/user/user_privileges.jsp";
    static final String LOGIN_ENDPOINT = "/bbs/wi/bo/login.jsp";
    static final String WWS_HEARTBEAT_ENDPOINT = "/bbs/wi/bo/session.jsp";
    static final String STOCK_LOCATION_ENDPOINT = "{0}/bbs/pda/logistics/stock/stocklocation_data.jsp?label={1}";
    static final String PRODUCT_CODE_ENDPOINT = "{0}/bbs/pda/logistics/product/productbarcode_data.jsp?label={1}";
    static final String RELEASE_CART_ENDPOINT = "{0}/bbs/pda/logistics/pick/pickListApi.jsp?action=ReleaseCart&cartId={1}&vzid={2}";
    static final String GET_TROLLEY_WWS_URL = "/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}";
    static final String PICK_AND_PUT_TASK_WWS_URL = "/bbs/pda/logistics/stock/picker_action.jsp?action_code=pick_and_putt_task_report&cart_id={0}&pdid={1}&pdnum={2}&quantity={3}&slot_code={4}";
    static final String PUT_ENDPOINT = "/bbs/pda/logistics/stock/picker_action.jsp?action_code=put_task_report&compartmentId={0}&target_slot={1}&cart_id={2}&pdid={3}&pdnum={4}&quantity={5}";
    static final String PICK_ENDPOINT = "/bbs/pda/logistics/stock/picker_action.jsp?action_code=pick_task_report&cart_id={0}&pdid={1}&pdnum={2}&quantity={3}&slot_code={4}";
    static final String NEXT_INVENTORY_SLOT = "{0}/bbs/pda/logistics/stock/next_inventory_slot.jsp?label={1}";
    static final String PROBLEM_FLAG_ENDPOINT = "/bbs/pda/logistics/stock/problemflag_action.jsp?pflag={0}&label={1}";

    static final String LOGIN_BODY = "f_login={0}&f_password={1}&url_redirect_disabled=1&submit=Anmelden";
    static final String WWS_PING_RESPONSE_FAIL_BODY = "notloggedin";

    // ERORRS messages
    static final String ERROR = "Error";
    static final String CONNECTION_TO_WWS_LOST_STRING = "Connection to wws lost";

    List<String> getRights(final Session session) throws LoginException, WwsConnectionException;

    LoginDetails login(final String username, final String password) throws LoginException;

    WwsReportResponse sendReport(final String endpoint, final Session session) throws WwsConnectionException;

    ProductImage loadImage(final String endpoint, final Session session) throws WwsConnectionException;

    ProductResponse sendProduct(final String endpoint, final Session session) throws WwsConnectionException;

    StockResponse sendStock(final String endpoint, final Session session) throws WwsConnectionException;

    CheckStockResponse sendCheckStock(final String endpoint, final Session session) throws WwsConnectionException;

    String makeHeartBeatRequestToWWS(final Session session) throws WwsConnectionException;

    void parkTrolley(final String cartId, final Integer vzid, final Session session) throws WwsConnectionException;

    StockResponse getInventoryStock(final String barcode, final Session session);
}
