package de.pearl.microservices.service.impl;

import de.pearl.microservices.errors.InventoryCheckException;
import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.WwsConnectionException;
import de.pearl.microservices.model.*;
import de.pearl.microservices.service.IWwsEndpointService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.HttpCookie;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

@Slf4j
@Service
public class WwsEndpointService implements IWwsEndpointService {
    // TODO: extract property value or remove
    public static final String HTTPS_MICROSITES_PEARL_DE_I_04_PX4848_0_JPG = "https://microsites.pearl.de/i/04/px4848_0.jpg";

    @Value("${wws.endpoint}")
    private String wwsEndpoint;

    private RestTemplate restTemplate = new RestTemplate();

    @Override
    public List<String> getRights(final Session session) throws WwsConnectionException {
        log.info("WwsEndpointService.getRights(session: {})", session.getSessionId());
        List<String> rights = null;
        try {
            ResponseEntity<RigthsResponse> response = restTemplate.exchange(wwsEndpoint + USER_RIGHTS_ENDPOINT, HttpMethod.GET,
                    new HttpEntity<String>(createHttpHeaders(session, null)), RigthsResponse.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                rights = response.getBody().getRights();
                if (rights == null) {
                    rights = new ArrayList<>();
                }
                log.debug("\tresponse: {}", response);

            } else if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.error("Connection to wws lost");
                throw new WwsConnectionException("", wwsEndpoint);
            }
        } catch (RestClientException ex) {
            log.error("Get rights error ", ex);
            throw new WwsConnectionException("", wwsEndpoint);
        }
        return rights;
    }

    @Override
    public LoginDetails login(final String username, final String password) throws LoginException {
        log.debug("try to login user: {} password : ******", username);
        LoginDetails loginDetails = new LoginDetails();
        String urlParameters = MessageFormat.format(LOGIN_BODY, username, password);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setAccept(
                Arrays.asList(MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.TEXT_PLAIN, MediaType.TEXT_HTML, MediaType.ALL));
        headers.setCacheControl("no-cache");
        try {
            HttpEntity<String> requestEntity = new HttpEntity<>(urlParameters, headers);
            ResponseEntity<Void> entity = restTemplate.exchange(wwsEndpoint + LOGIN_ENDPOINT, HttpMethod.POST, requestEntity, Void.class);
            if (entity.getStatusCode() == HttpStatus.OK) {
                log.debug("try to login user: {} wasn't login", username);
                throw new LoginException(wwsEndpoint, "Login error");
            }
            List<String> cookies = entity.getHeaders().get("Set-Cookie");
            loginDetails.setCookies(cookies);
            loginDetails.setHost(wwsEndpoint);
            loginDetails.setUsername(username);
            log.debug("logged in user: {} password : ******", username);
        } catch (HttpClientErrorException e) {
            log.error("login Error", e);
            throw new LoginException(wwsEndpoint, "Login error");
        } catch (RestClientException ex) {
            log.error("login Error", ex);
            throw new LoginException(wwsEndpoint, "Login error");
        }
        log.debug("success login user: {} password : ******", username);
        return loginDetails;
    }

    @Override
    public WwsReportResponse sendReport(final String endpoint, final Session session) throws WwsConnectionException {
        try {
            ResponseEntity<WwsReportResponse> response = restTemplate.exchange(wwsEndpoint + endpoint, HttpMethod.GET,
                    new HttpEntity<>(createHttpHeaders(session, null)), WwsReportResponse.class);
            return response.getBody();
        } catch (RestClientException e) {
            log.error("send report error " + endpoint, e);
            throw new WwsConnectionException("CheckProduct exception", endpoint);
        }
    }

    @Override
    public String makeHeartBeatRequestToWWS(final Session session) throws WwsConnectionException {
        String url = wwsEndpoint + WWS_HEARTBEAT_ENDPOINT;
        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(createHttpHeaders(session, null)),
                    String.class);
            return response.getBody();
        } catch (RestClientException e) {
            log.error("send report error  " + url, e);
            throw new WwsConnectionException("MakeHeartBeat", url);
        }
    }

    @Override
    public ProductResponse sendProduct(String barcode, Session session) {
        String endpoint = MessageFormat.format(PRODUCT_CODE_ENDPOINT, wwsEndpoint, barcode);
        try {
            ResponseEntity<ProductResponse> response = restTemplate.exchange(endpoint, HttpMethod.GET,
                    new HttpEntity<>(createHttpHeaders(session, null)), ProductResponse.class);
            return response.getBody();
        } catch (RestClientException e) {
            log.error("send report error " + endpoint, e);
            throw new WwsConnectionException("CheckProduct exception", endpoint);
        }
    }

    @Override
    public StockResponse sendStock(String barcode, Session session) {
        String endpoint = MessageFormat.format(STOCK_LOCATION_ENDPOINT, wwsEndpoint, barcode);
        try {
            ResponseEntity<StockResponse> response = restTemplate.exchange(endpoint, HttpMethod.GET,
                    new HttpEntity<>(createHttpHeaders(session, null)), StockResponse.class);
            return response.getBody();
        } catch (RestClientException e) {
            log.error("send report error " + endpoint, e);
            throw new WwsConnectionException("StockResponse exception", endpoint);
        }
    }

    @Override
    public CheckStockResponse sendCheckStock(String barcode, Session session) {
        String endpoint = MessageFormat.format(STOCK_LOCATION_ENDPOINT, wwsEndpoint, barcode);
        try {
            ResponseEntity<CheckStockResponse> response = restTemplate.exchange(endpoint, HttpMethod.GET,
                    new HttpEntity<>(createHttpHeaders(session, null)), CheckStockResponse.class);
            return response.getBody();
        } catch (RestClientException e) {
            log.error("send report error " + endpoint, e);
            throw new WwsConnectionException("StockResponse exception", endpoint);
        }
    }

    @Override
    public ProductImage loadImage(final String endpoint, final Session session) throws WwsConnectionException {
        String fullEndpoint = wwsEndpoint + endpoint;
        log.info("start WwsEndpointService.loadImage(endpoint: {})", fullEndpoint);
        ProductImage productImage = new ProductImage();
        try {
            ResponseEntity<byte[]> image = restTemplate.exchange(fullEndpoint, HttpMethod.GET,
                    new HttpEntity<String>(createHttpHeaders(session, null)), byte[].class);
            byte[] encoded = Base64.getEncoder().encode(image.getBody());
            productImage.setCamImage(new String(encoded));
            String catalog = loadCatalog();
            productImage.setProductImage(catalog);
        } catch (RestClientException e) {
            log.error("Error during load img {}", e);
        }
        log.info("end WwsEndpointService.loadImage()");
        return productImage;
    }

    @Override
    public void parkTrolley(final String cartId, final Integer vzid, final Session session) throws WwsConnectionException {
        String endpoint = MessageFormat.format(RELEASE_CART_ENDPOINT, wwsEndpoint, cartId, vzid);
        try {
            restTemplate.exchange(endpoint, HttpMethod.GET, new HttpEntity<>(createHttpHeaders(session, null)), Void.class);
        } catch (RestClientException e) {
            log.error("send report error " + endpoint, e);
            throw new WwsConnectionException("ParkTrolley exception", endpoint);
        }

    }

    @Override
    public StockResponse getInventoryStock(String barcode, Session session) {
        String endpoint = MessageFormat.format(NEXT_INVENTORY_SLOT, wwsEndpoint, barcode);
        try {
            ResponseEntity<StockResponse> response = restTemplate.exchange(endpoint, HttpMethod.GET,
                new HttpEntity<>(createHttpHeaders(session, null)), StockResponse.class);
            return response.getBody();
        } catch (RestClientException e) {
            log.error("send report error " + endpoint, e);
            throw new InventoryCheckException(e.getMessage(), endpoint);
        }
    }

    private String loadCatalog() throws WwsConnectionException {
        String url = HTTPS_MICROSITES_PEARL_DE_I_04_PX4848_0_JPG;
        log.debug("loadCatalog:Start load img; endpoint = {}", url);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(ACCEPT_LANGUAGE, ACCEPT_LANGUAGE_VALUE);
            headers.add(ACCEPT, ACCEPT_VALUE);
            headers.setCacheControl(NO_CACHE);

            ResponseEntity<byte[]> image = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<String>(headers), byte[].class);
            byte[] encoded = Base64.getEncoder().encode(image.getBody());
            log.debug("loadCatalog:End load img; endpoint = {}", url);
            return new String(encoded);
        } catch (RestClientException e) {
            log.debug("loadCatalog Error during load cat {}", e);
            throw new WwsConnectionException("", url);
        }
    }

    private HttpHeaders createHttpHeaders(final Session session, final String stationIp) {
        HttpCookie cookie = new HttpCookie(session.getSessionName(), session.getSessionId());
        cookie.setDomain(session.getDomain());
        cookie.setPath(session.getPath());
        HttpHeaders headers = new HttpHeaders();
        headers.add(COOKIE, cookie.toString());
        headers.add(ACCEPT_LANGUAGE, ACCEPT_LANGUAGE_VALUE);
        headers.add(ACCEPT, ACCEPT_JSON);
        headers.setCacheControl(NO_CACHE);
        if (StringUtils.isNotEmpty(stationIp)) {
            headers.add(REMOTE_ADDR, stationIp);
        }
        return headers;
    }

}
