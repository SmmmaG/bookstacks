package de.pearl.microservices.logging;

import com.fasterxml.jackson.annotation.JsonRootName;
import de.pearl.microservices.logging.actions.output.nested.LogSession;
import lombok.Data;

@Data
@JsonRootName(value = "user")
public class LogUser {

    private String authorityType = "WWS";

    private String userName;

    private LogSession session;

}
