package de.pearl.microservices.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class ProductResponse {
    private Data data;
    private Error error;

    @Getter
    @Setter
    public static class Data {
        private Id id;
    }

    @Getter
    @Setter
    public static class Id {
        private String productId;
        private Long pdNum;
    }

    @Getter
    @Setter
    public static class Error {
        private String message;
    }
}
