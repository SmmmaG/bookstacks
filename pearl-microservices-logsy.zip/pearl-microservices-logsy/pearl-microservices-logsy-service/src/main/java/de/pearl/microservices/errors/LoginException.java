package de.pearl.microservices.errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LoginException extends RuntimeException {

    private String endpoint;

    public LoginException(String message, String endpoint) {
        super(message);
        this.endpoint = endpoint;
    }
}
