package de.pearl.microservices.persistence.enums;

public enum UserSessionStatus {
    NEW,
    LOGGED_IN,
    SITE_ASSIGNED,
    JOB_SELECTED,
    CART_BOOKING,
    CART_BOOKED,
    CRITICAL_SECTION,
    CART_RELEASING,
    LOGGED_OUT
}
