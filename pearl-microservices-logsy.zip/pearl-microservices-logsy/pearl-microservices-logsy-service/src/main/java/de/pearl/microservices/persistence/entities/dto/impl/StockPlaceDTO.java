package de.pearl.microservices.persistence.entities.dto.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder @ToString()
@JsonIgnoreProperties(ignoreUnknown = true)
public class StockPlaceDTO {
    private StockPlacePKDTO id;
    private String pdId;
    private Short pdNum;
    private Long stationId;
    private Long inventory;
    private String pickMessage;
    private Long actCount;
    private Long minimumInventory;
    private Long fullInventory;
    private Long quantityInCase;
    private Long paletteHeight;
    private Long createDate;
    private Long pflag;
    private Long updateUser;
    private Long updateDate;
    private Long reserved;
    private String labelValue;
}
