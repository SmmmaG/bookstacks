package de.pearl.microservices.model.picker;

public enum PickerStage {

    GETTINGTROLLEY, 
    SCANNINGTROLLEY {
        @Override
        public PickerStage leave() {
            return GETTINGTROLLEY;
        }
    },
    GETTINGPICKLISTSUM {
        @Override
        public PickerStage leave() {
            return PARKTROLLEY;
        }
    },
    GETTINGTGTTASK {
        @Override
        public PickerStage leave() {
            return GETTINGPICKLISTSUM;
        }
    },
    SCANNINGTGTSLOT {
        @Override
        public PickerStage leave() {
            return GETTINGPICKLISTSUM;
        }
    },
    SCANNINGTGTPRODUCT {
        @Override
        public PickerStage leave() {
            return GETTINGPICKLISTSUM;
        }
    },
    CHECKINGTGTQTY {
        @Override
        public PickerStage leave() {
            return GETTINGPICKLISTSUM;
        }
    },
    GETTINGDESTTASK {
        @Override
        public PickerStage leave() {
            return GETTINGPICKLISTSUM;
        }
    },
    SCANINGDESTSLOT {
        @Override
        public PickerStage leave() {
            return GETTINGDESTTASK;
        }
    },
    CHECKINGDESTQTY {
        @Override
        public PickerStage leave() {
            return GETTINGDESTTASK;
        }
    },
    SENDREPORT {
        @Override
        public PickerStage next() {
            return GETTINGDESTTASK;
        }

        @Override
        public PickerStage leave() {
            return this.next();
        }
    },
    PARKTROLLEY {
        @Override
        public PickerStage next() {
            return GETTINGTROLLEY;
        }

        @Override
        public PickerStage leave() {
            return this.next();
        }
    };

    public boolean isPutJobStages() {
        PickerStage firstPutJobStage = SCANINGDESTSLOT;

        return (this.ordinal() >= firstPutJobStage.ordinal() && this != PARKTROLLEY);
    }

    public boolean isPickJobStage() {
        PickerStage firstPickJobStage = SCANNINGTGTSLOT;
        PickerStage lastPickJobStage = CHECKINGTGTQTY;

        return (this.ordinal() >= firstPickJobStage.ordinal() && this.ordinal() <= lastPickJobStage.ordinal());
    }

    public PickerStage back() {
        return values()[ordinal() - 1];
    }

    public PickerStage next() {
        return values()[ordinal() + 1];
    }

    public PickerStage leave() {
        return PickerStage.GETTINGTROLLEY;
    }

}
