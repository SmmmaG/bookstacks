package de.pearl.microservices.controller;

import de.pearl.microservices.model.User;
import de.pearl.microservices.service.ILoginService;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/logsy/logout")
public class LogoutController {

    private final ILoginService loginService;

    public LogoutController(ILoginService loginService) {
        this.loginService = loginService;
    }

    @PostMapping("/")
    public void logout(@RequestBody User user) {
        loginService.logout(user);
    }

}
