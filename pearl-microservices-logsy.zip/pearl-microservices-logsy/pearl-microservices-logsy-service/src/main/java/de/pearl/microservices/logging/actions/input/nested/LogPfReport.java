package de.pearl.microservices.logging.actions.input.nested;

import lombok.Value;

@Value
public class LogPfReport {

    private String source;

    private Long pfFlag;
}
