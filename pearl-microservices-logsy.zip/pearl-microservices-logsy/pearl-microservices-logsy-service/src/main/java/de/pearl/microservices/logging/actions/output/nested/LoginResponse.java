package de.pearl.microservices.logging.actions.output.nested;

import lombok.Value;

import java.util.List;

@Value
public class LoginResponse {

    private String name;

    private LogSession session;

    private List<String> privileges;
}
