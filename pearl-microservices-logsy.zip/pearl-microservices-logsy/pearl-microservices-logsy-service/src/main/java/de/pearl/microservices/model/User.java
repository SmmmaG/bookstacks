package de.pearl.microservices.model;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

import java.util.List;

@Data
@JsonRootName(value = "user")
public class User {
    private String name;
    private Session session;
    private List<String> privileges;
}
