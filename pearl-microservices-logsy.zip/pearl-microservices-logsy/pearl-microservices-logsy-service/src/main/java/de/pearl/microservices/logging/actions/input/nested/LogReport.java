package de.pearl.microservices.logging.actions.input.nested;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.pearl.microservices.logging.LogProduct;
import lombok.Data;

@Data
@JsonRootName("report")
public class LogReport {
    private String source;

    private LogProduct product;

    private Short quantity;

    private String target;

    public String toJson() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(JsonGenerator.Feature.QUOTE_FIELD_NAMES, false);
        mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
    }
}
