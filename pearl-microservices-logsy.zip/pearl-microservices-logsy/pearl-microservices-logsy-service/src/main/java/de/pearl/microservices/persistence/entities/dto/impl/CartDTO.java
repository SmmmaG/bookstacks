package de.pearl.microservices.persistence.entities.dto.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder @ToString()
@JsonIgnoreProperties(ignoreUnknown = true)
public class CartDTO {
    private Short id; // cart id
    private Short typeDictionaryType;
    private Short type;
    private Short status;
    private Long maximumWeight;
    private Integer numberOfCartsInStation;
    private Long updateDate;
    private Long areaId;
    private Long placeId;
    private Short logisticsCenterId;
    private Short segmentId;
    private Short configurationId;
    private String labelValue;
}
