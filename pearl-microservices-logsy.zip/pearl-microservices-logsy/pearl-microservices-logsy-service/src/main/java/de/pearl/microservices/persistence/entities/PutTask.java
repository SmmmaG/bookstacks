package de.pearl.microservices.persistence.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import de.pearl.microservices.persistence.enums.TaskStatus;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A PutTask.
 */
@Entity
@Table(name = "put_task", schema = "warehouse_terminal")
public class PutTask implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "putTaskIdSeq", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "putTaskIdSeq", sequenceName = "warehouse_terminal.put_task_id_seq", allocationSize = 51)
    private Long id;

    @NotNull
    @Column(name = "pick_task_id", nullable = false, insertable = false,
        updatable = false)
    private Long pickTaskId;

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "status", nullable = false)
    private TaskStatus status = TaskStatus.TO_DO;

    @NotNull
    @Column(name = "rank", nullable = false)
    private Integer rank;

    @NotNull
    @Column(name = "compartment_id", nullable = false)
    private Long compartmentId;

    @NotNull
    @Column(name = "compartment_label_value", nullable = false)
    private String compartmentLabelValue;

    @NotNull
    @Column(name = "quantity", nullable = false)
    private Short quantity;

    @ManyToOne
    @JsonIgnoreProperties("putTasks")
    private PickTask pickTask;


    public String getCompartmentLabelValue() {
        return compartmentLabelValue;
    }

    public void setCompartmentLabelValue(String compartmentLabelValue) {
        this.compartmentLabelValue = compartmentLabelValue;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPickTaskId() {
        return pickTaskId;
    }

    public void setPickTaskId(Long pickTaskId) {
        this.pickTaskId = pickTaskId;
    }

    public PutTask pickTaskId(Long pickTaskId) {
        this.pickTaskId = pickTaskId;
        return this;
    }

    public TaskStatus getStatus() {
        return status;
    }

    public void setStatus(TaskStatus status) {
        this.status = status;
    }

    public PutTask status(TaskStatus status) {
        this.status = status;
        return this;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public PutTask rank(Integer rank) {
        this.rank = rank;
        return this;
    }

    public Long getCompartmentId() {
        return compartmentId;
    }

    public void setCompartmentId(Long compartmentId) {
        this.compartmentId = compartmentId;
    }

    public PutTask compartmentId(Long compartmentId) {
        this.compartmentId = compartmentId;
        return this;
    }

    public Short getQuantity() {
        return quantity;
    }

    public void setQuantity(Short quantity) {
        this.quantity = quantity;
    }

    public PutTask quantity(Short quantity) {
        this.quantity = quantity;
        return this;
    }

    public PickTask getPickTask() {
        return pickTask;
    }

    public void setPickTask(PickTask pickTask) {
        this.pickTask = pickTask;
    }

    public PutTask pickTask(PickTask pickTask) {
        this.pickTask = pickTask;
        return this;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PutTask putTask = (PutTask) o;
        if (putTask.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), putTask.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PutTask{" +
            "id=" + getId() +
            ", pickTaskId=" + getPickTaskId() +
            ", status='" + getStatus() + "'" +
            ", rank=" + getRank() +
            ", compartmentId=" + getCompartmentId() +
            ", quantity=" + getQuantity() +
            "}";
    }
}
