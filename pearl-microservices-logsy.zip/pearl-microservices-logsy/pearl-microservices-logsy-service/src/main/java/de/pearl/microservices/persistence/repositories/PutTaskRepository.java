package de.pearl.microservices.persistence.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import de.pearl.microservices.persistence.entities.PutTask;

public interface PutTaskRepository extends CrudRepository<PutTask, Long> {
    @Query(value = "select \n" +
        "  put.*\n" +
        "from\n" +
        "  warehouse_terminal.put_task put, \n" +
        "  warehouse_terminal.pick_task pick\n" +
        "where put.pick_task_id = pick.id\n" +
        "  and pick.source like :source \n" +
        "  and put.compartment_label_value like :target \n" +
        "  and put.quantity = :quantity"
        , nativeQuery = true)
    PutTask findFirstByCompartmentLabelValueQuantityPickTaskSource(@Param("target")String target, @Param("quantity")Short quantity, @Param("source")String source);
    
    @Query(value = "select \n" +
            "  put.*\n" +
            "from\n" +
            "  warehouse_terminal.put_task put, \n" +
            "  warehouse_terminal.pick_task pick\n" +
            "where put.pick_task_id = pick.id\n" +
            "  and pick.source like :source \n" +
            "  and put.compartment_label_value like :target \n" +
            "  and put.quantity = :quantity"
            , nativeQuery = true)
    List<PutTask> findByCompartmentLabelValueQuantityPickTaskSource(@Param("target")String target, @Param("quantity")Short quantity, @Param("source")String source);

    
    List<PutTask> findAllByPickTaskIdIn(List<Long> allByCartContextIn);
}
