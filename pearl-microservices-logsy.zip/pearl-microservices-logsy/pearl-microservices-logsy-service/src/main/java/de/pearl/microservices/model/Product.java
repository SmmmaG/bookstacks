package de.pearl.microservices.model;
import lombok.Data;

@Data
public class Product {
    private String code;
    private String pdid;
    private String product;
    private Long pdnum;
    public String toString() {
        return "PDID: '" + this.pdid + "', PDNUM: '" + this.pdnum + "'";
    }

}
