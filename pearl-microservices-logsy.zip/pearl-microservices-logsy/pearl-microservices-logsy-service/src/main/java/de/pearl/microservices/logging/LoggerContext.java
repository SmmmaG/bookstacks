package de.pearl.microservices.logging;

import lombok.Data;

@Data
public class LoggerContext {

    private String contextType;
}
