package de.pearl.microservices.service;

import java.io.IOException;

import de.pearl.microservices.model.PfReport;
import de.pearl.microservices.model.picker.PickerJobRequest;
import de.pearl.microservices.model.picker.PickerRequest;
import de.pearl.microservices.model.picker.StageRequest;
import de.pearl.microservices.model.picker.StageResponse;
import de.pearl.microservices.errors.CodeCheckException;
import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.PickerValidationFailed;
import de.pearl.microservices.errors.WwsConnectionException;

/**
 * Picker service
 * 
 * @author Ismakaev
 *
 */
public interface IPickerService {
    StageResponse getTask(final StageRequest request, final PickerJobRequest jobRequest) throws LoginException, WwsConnectionException;

    /**
     * get next free cart on current segment and VZ for the user with calculated List<PickTask> for the cart
     *
     * @param jobRequest
     * @return
     * @throws WwsConnectionException
     * @throws LoginException
     */
    StageResponse getTrolley(final StageRequest request, final PickerJobRequest jobRequest) throws WwsConnectionException, LoginException;

    /**
     * Send information about picked and put jobs
     * 
     * @param request
     *            request from logsy device
     * @return stage changing state
     * @throws LoginException
     *             session exception
     * @throws IOException
     *             IO exception
     * @throws WwsConnectionException
     *             wws connection exception
     * @throws CodeCheckException
     * @throws PickerValidationFailed
     */
    StageResponse sendReportEpos(final PickerRequest request) throws LoginException, WwsConnectionException, PickerValidationFailed;

    /**
     * Send direct problem flag from client
     * 
     * @param pfReport
     *            problem flag report
     * @return stage change data
     */
    StageResponse sendProblemFlag(final PfReport pfReport) throws WwsConnectionException;

    StageResponse sendReport(final StageRequest request, final PickerJobRequest jobRequest)
            throws WwsConnectionException, LoginException, CodeCheckException, PickerValidationFailed;

    StageResponse checkQuantity(final StageRequest request, final PickerJobRequest jobRequest)
            throws LoginException, WwsConnectionException, PickerValidationFailed;

    StageResponse checkTargetQty(final StageRequest request, final PickerJobRequest jobRequest) throws PickerValidationFailed;

    StageResponse getParkingPlace(final PickerRequest request) throws LoginException, WwsConnectionException;

    StageResponse scanProduct(final StageRequest request, final PickerJobRequest jobRequest)
            throws PickerValidationFailed, LoginException, WwsConnectionException, CodeCheckException;

    StageResponse scanSource(final StageRequest request, final PickerJobRequest jobRequest)
            throws PickerValidationFailed, LoginException, WwsConnectionException, CodeCheckException;

    StageResponse scanTarget(final StageRequest request, final PickerJobRequest jobRequest)
            throws PickerValidationFailed, LoginException, WwsConnectionException, CodeCheckException;

    StageResponse scanTrolley(final StageRequest request, final PickerJobRequest jobRequest) throws PickerValidationFailed;

}
