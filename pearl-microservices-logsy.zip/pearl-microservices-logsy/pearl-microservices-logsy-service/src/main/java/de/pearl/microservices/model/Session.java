package de.pearl.microservices.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
public class Session {
    @JsonIgnore
    String id;
    String sessionName;
    String sessionId;
    String domain;
    String path;

}
