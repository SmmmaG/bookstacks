package de.pearl.microservices.logging;

import lombok.Data;

@Data
public class LoggerResult {

    private String resultType;

    private Object resultDetails;
}
