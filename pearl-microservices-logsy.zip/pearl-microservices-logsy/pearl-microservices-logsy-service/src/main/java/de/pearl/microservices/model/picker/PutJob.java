package de.pearl.microservices.model.picker;

import lombok.Data;

@Data
public class PutJob {
    private String id;
    private String target;
    private Long targetQuantity;
    private PutResult putResult;
    private Long compartmentId;
}
