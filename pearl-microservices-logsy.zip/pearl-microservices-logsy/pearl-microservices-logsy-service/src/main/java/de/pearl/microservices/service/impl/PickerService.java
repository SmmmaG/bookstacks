package de.pearl.microservices.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import de.pearl.microservices.errors.CodeCheckException;
import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.PickerValidationFailed;
import de.pearl.microservices.errors.WwsConnectionException;
import de.pearl.microservices.logging.IAuditLogsyLogger;
import de.pearl.microservices.logging.LogUser;
import de.pearl.microservices.model.*;
import de.pearl.microservices.model.picker.*;
import de.pearl.microservices.persistence.entities.CartContext;
import de.pearl.microservices.persistence.entities.PickTask;
import de.pearl.microservices.persistence.entities.PutTask;
import de.pearl.microservices.persistence.entities.UserSession;
import de.pearl.microservices.persistence.enums.TaskStatus;
import de.pearl.microservices.persistence.enums.events.UserSessionEvents;
import de.pearl.microservices.persistence.repositories.CartContextRepository;
import de.pearl.microservices.persistence.repositories.PickTaskRepository;
import de.pearl.microservices.persistence.repositories.PutTaskRepository;
import de.pearl.microservices.persistence.repositories.UserSessionRepository;
import de.pearl.microservices.service.ICartRequestService;
import de.pearl.microservices.service.IDeviceService;
import de.pearl.microservices.service.IPickerService;
import de.pearl.microservices.service.IWwsEndpointService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;

import static de.pearl.microservices.model.picker.PickerStage.GETTINGDESTTASK;
import static de.pearl.microservices.persistence.enums.TaskStatus.*;
import static de.pearl.microservices.service.IWwsEndpointService.PICK_AND_PUT_TASK_WWS_URL;
import static de.pearl.microservices.service.IWwsEndpointService.PUT_ENDPOINT;
import static de.pearl.microservices.service.IWwsEndpointService.PICK_ENDPOINT;

@Service
@Slf4j
public class PickerService implements IPickerService {
    public static final String RELEASE_CART_WWS_ACTION = "ReleaseCart";
    public static final String GET_TROLLEY_WWS_ACTION = "GetNextCart";
    private final String validationPick = "Validation of put job";

    @Value("${wws.endpoint}")
    private String wwsEndpoint;
    private String serverAddress;
    private ObjectMapper jacksonMapper = new ObjectMapper();
    /*
     * Services
     */
    private IAuditLogsyLogger logsyLogger;
    private IDeviceService deviceService;
    private IWwsEndpointService wwsEndpointService;
    private ICartRequestService cartRequestService;
    /*
     * Repositories
     */
    private UserSessionRepository userSessionRepository;
    private CartContextRepository cartContextRepository;
    private PickTaskRepository pickTaskRepository;
    private PutTaskRepository putTaskRepository;

    public PickerService() throws UnknownHostException {
        serverAddress = InetAddress.getLocalHost().getHostAddress();
    }

    @Autowired
    public void setCartRequestService(final ICartRequestService cartRequestService) {
        this.cartRequestService = cartRequestService;
    }

    @Autowired
    public void setLogsyLogger(final IAuditLogsyLogger logsyLogger) {
        this.logsyLogger = logsyLogger;
    }

    @Autowired
    public void setDeviceService(final IDeviceService deviceService) {
        this.deviceService = deviceService;
    }

    @Autowired
    public void setWwsEndpointService(final IWwsEndpointService wwsEndpointService) {
        this.wwsEndpointService = wwsEndpointService;
    }

    @Autowired
    public void setUserSessionRepository(final UserSessionRepository userSessionRepository) {
        this.userSessionRepository = userSessionRepository;
    }

    @Autowired
    public void setCartContextRepository(final CartContextRepository cartContextRepository) {
        this.cartContextRepository = cartContextRepository;
    }

    @Autowired
    public void setPickTaskRepository(final PickTaskRepository pickTaskRepository) {
        this.pickTaskRepository = pickTaskRepository;
    }

    @Autowired
    public void setPutTaskRepository(final PutTaskRepository putTaskRepository) {
        this.putTaskRepository = putTaskRepository;
    }

    @Override
    public StageResponse getParkingPlace(final PickerRequest request) throws LoginException, WwsConnectionException {
        UserSession session = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(request.getJob().getUserDetails().getUserName()));
        log.info("cart parking");
        log.info("\tip {}", serverAddress);
        // TODO: we can add an error handling here if it could be need
        wwsEndpointService.parkTrolley(request.getJob().getJob().getTrolley(), session.getSite(), request.getJob().getUserDetails().getSession());

        session.updateUserSessionStatus(UserSessionEvents.RELEASE_CART);

        // todo don't touch me
        StageResponse response = new StageResponse();
        // PARKTROLLEY //SCANPARKPLACE
        response.setStage(request.getRequest().getStage().next());
        response.setResult(StageResult.SUCCESS);

        log.info("\tstart delete data");
        cartContextRepository.delete(cartContextRepository.findByUserIdAndCartId(Long.parseLong(request.getJob().getUserDetails().getUserName()),
                request.getJob().getJob().getTrolley()));
        log.info("\tend delete data");

        return response;
    }

    @Override
    public StageResponse sendReportEpos(final PickerRequest request)
            throws LoginException, WwsConnectionException, CodeCheckException, PickerValidationFailed {
        if (log.isInfoEnabled()) {
            log.info("Send report epos scenario. user session: {}", request.getJob().getUserDetails().getSession());
        }

        Long userId = Long.valueOf(request.getJob().getUserDetails().getUserName());
        String cartId = request.getJob().getJob().getTrolley();
        if (log.isTraceEnabled()) {
            log.trace("\tSend report epos scenario. user session: {} . Cart #{}, user #{}", request.getJob().getUserDetails().getSession(), cartId,
                    userId);
        }
        UserSession userSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(userId);

        CartContext cartContext = userSession.getCartContexts()
                .stream()
                .filter(cc -> cc.getCartId().equals(cartId))
                .findFirst()
                .orElseThrow(RuntimeException::new);
        if (log.isTraceEnabled()) {
            log.trace("\tSend report epos scenario. user session: {} . Pick tasks size =  {}", request.getJob().getUserDetails().getSession(),
                    cartContext.getPickTasks().size());
        }
        PickTask pickTask = cartContext.getPickTasks()
                .stream()
                .filter(pt -> pt.getStatus() == IN_PROGRESS)
                .min(Comparator.comparing(PickTask::getRank))
                .orElseThrow(RuntimeException::new);
        if (log.isTraceEnabled()) {
            log.trace("\tSend report epos scenario. user session: {} . Put tasks count = {}", request.getJob().getUserDetails().getSession(),
                    pickTask.getPutTasks().size());
        }
        List<PutTask> putTasks = pickTask.getPutTasks().stream().sorted(Comparator.comparing(PutTask::getCompartmentId)).collect(Collectors.toList());

        if (log.isInfoEnabled()) {
            log.info("\tSend report epos scenario. user session: {}. quantity: picklist {} request {}",
                    request.getJob().getUserDetails().getSession(), pickTask.getQuantity(), request.getRequest().getQuantity());
        }

        if (pickTask.getQuantity() < request.getRequest().getQuantity()) {
            throw new PickerValidationFailed(request.getRequest(), "Falsche Stückzahl. Maximum ist " + pickTask.getQuantity());
        }

        if (request.getRequest().getQuantity() < 0) {
            throw new PickerValidationFailed(request.getRequest(), "Falsche Stückzahl. Minimum ist 0");
        }

        String endpointPickPuts = MessageFormat.format(PICK_AND_PUT_TASK_WWS_URL, cartId, pickTask.getPdId(), pickTask.getPdNum(),
                request.getRequest().getQuantity(), pickTask.getSource());
        if (log.isTraceEnabled()) {
            log.trace("Send report epos scenario to {} . user session: {}", request.getJob().getUserDetails().getSession(), endpointPickPuts);
        }
        // send report to wws
        WwsReportResponse response = wwsEndpointService.sendReport(endpointPickPuts, request.getJob().getUserDetails().getSession());
        StageResponse putStageResponse = new StageResponse();
        if (response.isData()) {
            saveEPOSDataResponsInDB(request, pickTask, putTasks, putStageResponse);
        } else {
            putStageResponse.setStage(request.getRequest().getStage());
            putStageResponse.setResult(StageResult.FAIL);
            if (response.getError().getMessage() != null) {
                putStageResponse.setMessage(response.getError().getMessage());
            }
            if (log.isInfoEnabled()) {
                log.info("\tFAIL Sent report EPos scenario. user session: {}", request.getJob().getUserDetails().getSession());
            }
        }
        if (pickTaskRepository.findLastPickTaskForCartContext(cartContext.getId(), pickTask.getRank())) {
            putStageResponse.setStage(PickerStage.GETTINGPICKLISTSUM);
        }
        return putStageResponse;
    }

    private void saveEPOSDataResponsInDB(final PickerRequest request, final PickTask pickTask, final List<PutTask> putTasks,
            final StageResponse putStageResponse) {
        if (log.isInfoEnabled()) {
            log.info("\tSUCCESS Sended report epos scenario. user session: {} ", request.getJob().getUserDetails().getSession());
        }

        if (request.getRequest().getQuantity() < request.getRequest().getTask().getQuantity()) {
            PfReport pfReport = new PfReport();
            pfReport.setJob(request.getJob().getJob());
            pfReport.setPfFlag(5L); // wrong qty
            pfReport.setSource(request.getRequest().getTask().getSource());
            pfReport.setUserDetails(request.getJob().getUserDetails());
            deviceService.sendPfReport(pfReport);
        }

        // save info about pick task and put task
        // TODO: hotfix! must squash put task in one on picklist get
        for (PutTask putTask : putTasks) {
            List<PutTask> founds = putTaskRepository.findByCompartmentLabelValueQuantityPickTaskSource(putTask.getCompartmentLabelValue(),
                    putTask.getQuantity(), pickTask.getSource());
            if (!founds.isEmpty()) {
                for (PutTask found : founds) {
                    if (log.isTraceEnabled()) {
                        log.trace("\tSend report epos scenario . user session: {}. Update pick(id = {}) and put (id = {}) tasks in DB",
                                request.getJob().getUserDetails().getSession(), found.getId(), found.getPickTaskId());
                    }
                    if (log.isTraceEnabled()) {
                        log.trace(
                                "\tSend report epos scenario . user session: {}. Update pick(id = {} status = {}) and put (id = {}  status = {}) tasks in DB",
                                request.getJob().getUserDetails().getSession(), found.getId(), found.getStatus().toString(), found.getPickTaskId(),
                                found.getPickTask().getStatus().toString());
                    }
                    found.setStatus(TaskStatus.DONE);
                    found.getPickTask().updateStatus();
                    if (log.isTraceEnabled()) {
                        log.trace(
                                "\tSend report epos scenario . user session: {}. Update pick(id = {} status = {}) and put (id = {}  status = {}) tasks in DB",
                                request.getJob().getUserDetails().getSession(), found.getId(), found.getStatus().toString(), found.getPickTaskId(),
                                found.getPickTask().getStatus().toString());
                    }
                    putTaskRepository.save(found);
                    pickTaskRepository.save(found.getPickTask());
                }
            }
        }
        putStageResponse.setStage(GETTINGDESTTASK);
        putStageResponse.setResult(StageResult.SUCCESS);
        // TODO: write success audit log
        if (log.isInfoEnabled()) {
            log.info("\tSUCCESS Sent report epos scenario. user session: {}, and success saved all changes ",
                    request.getJob().getUserDetails().getSession());
        }
    }

    private StageResponse sendPfReport(final PfReport pfReport) {
        ReportResult reportResult = deviceService.sendPfReport(pfReport);
        Report report = new Report();
        PickTask found = pickTaskRepository.findDistinctBySourceAndUserId(pfReport.getSource(),
                Integer.parseInt(pfReport.getUserDetails().getUserName()));
        report.setSource(found.getSource());
        report.setTarget(found.getPutTasks().iterator().next().getCompartmentLabelValue());
        report.setQuantity(found.getQuantity().shortValue());
        updatePutTaskStatus(report, TaskStatus.DONE);
        logsyLogger.logPickerAction(IAuditLogsyLogger.PICKER_PROBLEM_FLAG, pfReport.getSource(), pfReport.getVzId().getCenter().toString(),
                pfReport.getUserDetails(), "pFlag set: " + pfReport.getPfFlag(), IAuditLogsyLogger.SUCCESS_RESULT);
        StageResponse result = new StageResponse();
        result.setResult(reportResult.getResult());
        return result;
    }

    @Override
    public StageResponse sendProblemFlag(final PfReport pfReport) {
        StageResponse stageResponse = sendPfReport(pfReport);
        stageResponse.setStage(PickerStage.GETTINGTGTTASK);
        return stageResponse;
    }

    @Override
    public StageResponse getTrolley(final StageRequest request, final PickerJobRequest jobRequest) throws WwsConnectionException, LoginException {
        log.info("get cart request on server address: {}, user session: {}", serverAddress, jobRequest.getUserDetails().getSession());
        StageResponse stageResponse = new StageResponse();

        CartContext result = null;
        LogUser user = jacksonMapper.convertValue(jobRequest.getUserDetails(), LogUser.class);
        try {
            String userId = jobRequest.getUserDetails().getUserName();
            if (!cartRequestService.isTaskExistForUser(userId)) {
                log.debug("call wws");
                cartRequestService.callGetCartForUser(userId, jobRequest.getUserDetails().getSession(),
                        jobRequest.getJob().getVzId().getCenter().toString());
            }
            boolean isTaskFinished = cartRequestService.isTaskFinishedForUser(userId);
            if (cartRequestService.isTaskExistForUser(userId)) {
                log.debug("get result from worker");
                result = cartRequestService.getCartContextResult(userId);
            }
            if (isTaskFinished) {
                if (result != null) {
                    log.debug("get trolley from worker");
                    logsyLogger.logSuccessGetNextCart(GET_TROLLEY_WWS_ACTION, jobRequest.getJob().getVzIdAsString(), user);
                    stageResponse.setStage(request.getStage().next());
                    stageResponse.setResult(StageResult.SUCCESS);
                    stageResponse.setMessage(result.getCartId());
                    stageResponse.setTotalJobs(result.getPickTasks().size());
                    stageResponse.setTotalQty(result.getPickTasks().stream().mapToInt(PickTask::getQuantity).sum());
                    stageResponse.setScenario(result.getScenarioType());
                    return stageResponse;
                } else {
                    log.debug("no result or exception was throw");
                    stageResponse.setResult(StageResult.FAIL);
                }
            } else {
                log.debug("wait result");
                stageResponse.setResult(StageResult.EMPTY);
            }
            log.info("\tthere is no free cart for user: {}", jobRequest.getUserDetails().getUserName());
            stageResponse.setStage(PickerStage.GETTINGTROLLEY);
        } catch (WwsConnectionException e) {
            logsyLogger.logErrorGetNextCart(GET_TROLLEY_WWS_ACTION, jobRequest.getJob().getVzIdAsString(), user, jobRequest.getJob().getIp(),
                    e.getMessage());
            throw new WwsConnectionException(e.getMessage(), "");
        } catch (LoginException e) {
            logsyLogger.logerrorLogin("", jobRequest.getUserDetails().getUserName(), e.getMessage());
            throw new LoginException(e.getMessage(), "");
        }
        return stageResponse;
    }

    @Override
    public StageResponse scanTrolley(final StageRequest request, final PickerJobRequest jobRequest) throws PickerValidationFailed {
        StageResponse stageResponse;
        if (request.getBarCode().equals(jobRequest.getJob().getTrolley())) {
            stageResponse = new StageResponse();
            stageResponse.setStage(request.getStage().next());
            stageResponse.setResult(StageResult.SUCCESS);
        } else {
            logsyLogger.logPickerAction(IAuditLogsyLogger.PICKER_GET_CART, jobRequest.getJob().getTrolley(), jobRequest.getJob().getVzIdAsString(),
                    jobRequest.getUserDetails(), "", IAuditLogsyLogger.FAIL_RESULT);
            throw new PickerValidationFailed(request, "Trolley is invalid");
        }

        UserSession session = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(jobRequest.getUserDetails().getUserName()));
        session.updateUserSessionStatus(UserSessionEvents.GET_CART_RESP);
        userSessionRepository.save(session);
        logsyLogger.logPickerAction(IAuditLogsyLogger.PICKER_GET_CART, jobRequest.getJob().getTrolley(), jobRequest.getJob().getVzIdAsString(),
                jobRequest.getUserDetails(), "", IAuditLogsyLogger.SUCCESS_RESULT);
        return stageResponse;
    }

    @Override
    @Transactional
    public StageResponse getTask(final StageRequest request, final PickerJobRequest jobRequest) throws LoginException, WwsConnectionException {
        log.info("get task request on server address: {}", serverAddress);
        StageResponse stageResponse = new StageResponse();

        Long userId = Long.valueOf(jobRequest.getUserDetails().getUserName());
        String cartId = jobRequest.getJob().getTrolley();
        if (log.isInfoEnabled()) {
            log.info("\tgetTask. user session: {}, Cart id = {}", jobRequest.getUserDetails().getSession(), cartId);
        }
        UserSession userSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(userId);
        if (log.isTraceEnabled()) {
            log.trace("\tgetTask. user session: {}, Cart id = {}, session context {}", jobRequest.getUserDetails().getSession(), cartId,
                    userSession.getId());
        }
        CartContext cartContext = userSession.getCartContexts()
                .stream()
                .filter(cc -> cc.getCartId().equals(cartId))
                .findFirst()
                .orElseThrow(RuntimeException::new);
        if (log.isTraceEnabled()) {
            log.trace("\tgetTask. user session: {}, Cart id = {}, cart context {}", jobRequest.getUserDetails().getSession(), cartId,
                    cartContext.getId());
        }

        PickTask pickTask = getActualPickTask(jobRequest, cartContext);

        if (pickTask == null && jobRequest.getJob().getScenario() == 11) {
            log.info("\tpickTask is null, get stage.back()");
            stageResponse.setStage(request.getStage().back());
            return stageResponse;
            // throw new RuntimeException();
        }
        if (log.isTraceEnabled()) {
            log.trace("\tgetTask . user session: {}, Cart id = {}, next pick task id =  {}", jobRequest.getUserDetails().getSession(), cartId,
                    pickTask.getId());
        }
        pickTask.setStatus(IN_PROGRESS);
        endOpenTasks(cartContext, pickTask);

        UUID id1 = UUID.randomUUID();
        PickJob nextPickJob = new PickJob();
        nextPickJob.setId(id1.toString());
        List<PutJob> putJobs = new ArrayList<>();

        nextPickJob.setQuantity(Long.valueOf(pickTask.getQuantity()));
        nextPickJob.setSource(pickTask.getSource());
        nextPickJob.setPdid(pickTask.getPdId());
        nextPickJob.setPdLabel(pickTask.getPdLabel());
        nextPickJob.setPdnum((long) pickTask.getPdNum());

        List<PutTask> putTasks = new ArrayList<>(pickTask.getPutTasks());

        for (PutTask putTask : putTasks) {
            UUID id2 = UUID.randomUUID();
            PutJob putJob = new PutJob();

            // TODO: how convert?
            putJob.setTarget(putTask.getCompartmentLabelValue());
            putJob.setTargetQuantity(Long.valueOf(putTask.getQuantity()));
            putJob.setCompartmentId(putTask.getCompartmentId());
            putJob.setId(id2.toString());
            putJobs.add(putJob);
        }
        nextPickJob.setPutJobs(putJobs);

        if (jobRequest.getJob().getScenario() == 11) {
            nextPickJob.setPutJobs(ImmutableList.of(nextPickJob.getPutJobs().get(0)));
        }

        if (nextPickJob.getQuantity() == 0) {
            if (log.isInfoEnabled()) {
                log.info("\tgetTask . Empty PickJob id = {} . user session: {} ", nextPickJob.getId(), jobRequest.getUserDetails().getSession());
            }
            pickTask.setStatus(DONE);
            stageResponse.setStage(request.getStage().leave());
            stageResponse.setResult(StageResult.EMPTY);
        } else {
            if (log.isInfoEnabled()) {
                log.info("\tgetTask . Get next PickJob id = {} . user session: {} ", nextPickJob.getId(), jobRequest.getUserDetails().getSession());
            }
            stageResponse.setStage(request.getStage().next());
            stageResponse.setResult(StageResult.SUCCESS);
            stageResponse.setPickerJob(nextPickJob);
        }
        userSession.updateUserSessionStatus(UserSessionEvents.GET_CART_RESP);
        pickTaskRepository.save(pickTask);
        userSessionRepository.save(userSession);

        logsyLogger.logPickerAction("GET_TASK_" + jobRequest.getJob().getJobName(), request.getBarCode(), jobRequest.getJob().getVzIdAsString(),
                jobRequest.getUserDetails(), null, IAuditLogsyLogger.SUCCESS_RESULT);
        return stageResponse;
    }

    /**
     *
     * @param jobRequest
     *            need for {@link #getActualPickTask(PickerJobRequest, CartContext)}
     * @param cartContext
     *            cart we are filtering and getting actual pick task for
     * @return actual pick task in status TO_TO and without any pFlag > 0 (or null)
     */
    private PickTask getActualPickTask(final PickerJobRequest jobRequest, final CartContext cartContext) {
        List<PickTask> picks = new ArrayList<>(cartContext.getPickTasks());
        Iterator<PickTask> iterator = picks.stream().filter(pt -> pt.getStatus() == TO_DO).sorted(Comparator.comparing(PickTask::getRank)).iterator();
        // PickTask pickTask;
        while (iterator.hasNext()) {
            PickTask pick = iterator.next();
            if (checkSourcePFlag(jobRequest, pick.getSource())) {
                log.info("\tpick task source: {}, pdid-pdnum: {}-{} was deleted cause of pFlag marker on source", pick.getSource(), pick.getPdId(),
                        pick.getPdNum());
                pickTaskRepository.delete(pick);
                // iterator.remove();
            } else {
                return pick;
            }
        }
        return null;
    }

    /**
     * Check the stock place if there is a pFlag marker on it
     *
     *
     * @param barcode
     *            the stock place we need to check
     * @return true if there is a pFlag > 0
     */
    private boolean checkSourcePFlag(final PickerJobRequest jobRequest, final String barcode) {
        JobRequest request = new JobRequest();
        request.setJob(jobRequest.getJob());
        request.setUserDetails(jobRequest.getUserDetails());
        Stock stock = deviceService.checkStock("checknect pick", request, "moving", barcode, true);
        return stock.getPfFlag() > 0;
    }

    /**
     * HOT FIX changing stage for all tasks in progress to done
     * 
     * @param cartContext
     * @param excludedPickTask
     */
    private void endOpenTasks(final CartContext cartContext, final PickTask excludedPickTask) {
        List<PickTask> coll = cartContext.getPickTasks()
                .stream()
                .filter(pt -> (pt.getStatus() == IN_PROGRESS && !pt.getId().equals(excludedPickTask.getId())))
                .collect(Collectors.toList());
        if (log.isInfoEnabled()) {
            log.info("update status for cart context id = {} pick tasks count = {}", cartContext.getId(), coll.size());
        }
        if (!coll.isEmpty()) {
            final List<PutTask> putTasks = new ArrayList<>();
            coll.forEach(pt -> {
                if (log.isTraceEnabled()) {
                    log.trace("\t\tendOpenTasks.  Update pick(id = {} status = {}) tasks in DB", pt.getId(), pt.getStatus());
                }
                pt.setStatus(DONE);
                if (log.isTraceEnabled()) {
                    log.trace("\t\tendOpenTasks.  Updated pick(id = {} status = {}) tasks in DB", pt.getId(), pt.getStatus());
                }
                putTasks.addAll(pt.getPutTasks());
            });
            putTasks.forEach(pt -> pt.setStatus(DONE));
            pickTaskRepository.save(coll);
            putTaskRepository.save(putTasks);
        }

    }

    @Override
    public StageResponse scanSource(final StageRequest request, final PickerJobRequest jobRequest)
            throws PickerValidationFailed, LoginException, WwsConnectionException, CodeCheckException {
        log.info("scan source request on server address: {}", serverAddress);
        StageResponse stageResponse = new StageResponse();

        JobRequest devJobRequest = new JobRequest();

        devJobRequest.setUserDetails(jobRequest.getUserDetails());
        devJobRequest.setJob(jobRequest.getJob());

        Stock stock = deviceService.checkStock(validationPick, devJobRequest, "picking", request.getBarCode(), false);

        if (stock.getCode().equals(request.getTask().getSource())) {
            stageResponse.setStage(request.getStage().next());
            stageResponse.setResult(StageResult.SUCCESS);
            // stageResponse.setSlot(request.getTask());
        } else {
            throw new PickerValidationFailed(request, "Source is invalid");
        }
        logsyLogger.logPickerAction(IAuditLogsyLogger.PICKER_PUT_PRODUCTS, request.getBarCode(), jobRequest.getJob().getVzIdAsString(),
                jobRequest.getUserDetails(), null, IAuditLogsyLogger.SUCCESS_RESULT);
        return stageResponse;
    }

    @Override
    public StageResponse scanProduct(final StageRequest request, final PickerJobRequest jobRequest)
            throws PickerValidationFailed, LoginException, WwsConnectionException, CodeCheckException {
        log.info("\tscan product request on server address: {}", serverAddress);
        StageResponse stageResponse = new StageResponse();

        JobRequest devJobRequest = new JobRequest();

        devJobRequest.setUserDetails(jobRequest.getUserDetails());
        devJobRequest.setJob(jobRequest.getJob());

        CartContext cartContext = cartContextRepository
                .findByUserIdAndCartId(Long.parseLong(jobRequest.getUserDetails().getUserName()), jobRequest.getJob().getTrolley())
                .get(0);
        PickTask currentPickTask = cartContext.getPickTasks()
                .stream()
                .filter(pickTask -> pickTask.getPdLabel().equals(request.getBarCode()))
                .findFirst()
                .orElseThrow(() -> new PickerValidationFailed(request, "Product is invalid"));

        if (!currentPickTask.getPdLabel().equals(request.getBarCode())) {
            throw new PickerValidationFailed(request, "Product is invalid");
        }

        request.setBarCode(currentPickTask.getPdId() + "-" + currentPickTask.getPdNum());

        Product product = deviceService.checkProduct(devJobRequest, request.getBarCode());

        if (Objects.equals(product.getPdnum(), request.getTask().getPdnum()) && product.getPdid().equals(request.getTask().getPdid())) {
            stageResponse.setStage(request.getStage().next());
            stageResponse.setResult(StageResult.SUCCESS);

            // stageResponse.setSlot(request.getTask());
        } else {
            throw new PickerValidationFailed(request, "Product is invalid");
        }
        return stageResponse;
    }

    /**
     * MPos Scenario check quantity for pick task
     *
     * @param request
     *            - payload for request data
     * @param jobRequest
     *            - main request data
     * @return
     * @throws LoginException
     * @throws IOException
     * @throws WwsConnectionException
     * @throws PickerValidationFailed
     */
    @Override
    public StageResponse checkQuantity(StageRequest request, PickerJobRequest jobRequest)
            throws LoginException, WwsConnectionException, PickerValidationFailed {
        StageResponse stageResponse = new StageResponse();
        try {

            stageResponse.setStage(request.getStage().next());
            stageResponse.setResult(StageResult.SUCCESS);

            String cartId = jobRequest.getJob().getTrolley();
            String pdId = request.getTask().getPdid();
            String pdNum = request.getTask().getPdnum().toString();
            if (request.getQuantity() == null || request.getQuantity() < 0) {
                log.error("User used wrong quantity");
                logsyLogger.logPickerAction(IAuditLogsyLogger.PICKER_PICK_PRODUCTS, request.getBarCode(), jobRequest.getJob().getVzIdAsString(),
                        jobRequest.getUserDetails(), "Check quantity fails for compartment id: " + request.getTask().getCompartmentId(),
                        IAuditLogsyLogger.FAIL_RESULT);
                stageResponse.setStage(request.getStage());
                throw new PickerValidationFailed(request, "User used wrong quantity");
            }
            String quantity = request.getQuantity().toString();
            String sourceSlot = request.getTask().getSource();
            String endpoint = MessageFormat.format(PICK_ENDPOINT, cartId, pdId, pdNum, quantity, sourceSlot);
            WwsReportResponse response = wwsEndpointService.sendReport(endpoint, jobRequest.getUserDetails().getSession());

            if (response.isData()) {
                if (request.getQuantity() < request.getTask().getQuantity()) {
                    PfReport pfReport = new PfReport();
                    pfReport.setPfFlag(PfReport.WRONG_QTY);
                    pfReport.setJob(jobRequest.getJob());
                    pfReport.setSource(request.getBarCode());
                    deviceService.sendPfReport(pfReport);
                    logsyLogger.logPickerAction(IAuditLogsyLogger.PICKER_PICK_PRODUCTS, request.getBarCode(), jobRequest.getJob().getVzIdAsString(),
                            jobRequest.getUserDetails(), null, IAuditLogsyLogger.SUCCESS_RESULT);
                }
                stageResponse.setStage(request.getStage().next());
                stageResponse.setResult(StageResult.SUCCESS);
            } else {
                stageResponse.setStage(request.getStage());
                stageResponse.setResult(StageResult.FAIL);
                stageResponse.setMessage((String) response.getError().getMessage());
            }
            // stageResponse.setSlot(slot);
        } catch (Exception e) {
            log.error("Exception: ", e);
            throw e;
        }
        return stageResponse;
    }

    @Override
    public StageResponse scanTarget(StageRequest request, PickerJobRequest jobRequest)
            throws PickerValidationFailed, LoginException, WwsConnectionException, CodeCheckException {
        log.info("scan target request on server address: {}", serverAddress);

        StageResponse stageResponse = new StageResponse();
        Slot slot = request.getTask();

        JobRequest devJobRequest = new JobRequest();

        devJobRequest.setUserDetails(jobRequest.getUserDetails());
        devJobRequest.setJob(jobRequest.getJob());

        if (request.getBarCode().equals(slot.getTarget())) {
            stageResponse.setStage(request.getStage().next());
            stageResponse.setResult(StageResult.SUCCESS);
        } else {
            throw new PickerValidationFailed(request, "Target is invalid");
        }
        return stageResponse;
    }

    @Override
    public StageResponse checkTargetQty(StageRequest request, PickerJobRequest jobRequest) throws PickerValidationFailed {
        StageResponse stageResponse = new StageResponse();
        if (request.getQuantity() == null || request.getQuantity() < 0) {
            log.error("User used wrong quantity");
            stageResponse.setStage(request.getStage());
            throw new PickerValidationFailed(request, "User used wrong quantity");
        }

        if (request.getQuantity() <= request.getTask().getTargetQuantity()) {
            stageResponse.setStage(request.getStage().next());
            stageResponse.setResult(StageResult.SUCCESS);
            log.info("\t\tSuccess checkTargetQty(source:{})", request.getBarCode());
        } else {
            logsyLogger.logPickerAction(IAuditLogsyLogger.PICKER_PUT_PRODUCTS, request.getBarCode(), jobRequest.getJob().getVzIdAsString(),
                    jobRequest.getUserDetails(), null, IAuditLogsyLogger.FAIL_RESULT);
            throw new PickerValidationFailed(request, "Quantity is not correct");
        }
        logsyLogger.logPickerAction(IAuditLogsyLogger.PICKER_PUT_PRODUCTS, request.getBarCode(), jobRequest.getJob().getVzIdAsString(),
                jobRequest.getUserDetails(), null, IAuditLogsyLogger.SUCCESS_RESULT);
        return stageResponse;
    }

    @Override
    public StageResponse sendReport(StageRequest request, PickerJobRequest jobRequest)
            throws WwsConnectionException, LoginException, CodeCheckException, PickerValidationFailed {
        log.info("Send report request on server address: {}", serverAddress);

        StageResponse stageResponse = new StageResponse();

        JobRequest devJobRequest = new JobRequest();
        devJobRequest.setUserDetails(jobRequest.getUserDetails());
        devJobRequest.setJob(jobRequest.getJob());

        Report report = new Report();

        report.setJob(jobRequest.getJob());
        report.setUserDetails(jobRequest.getUserDetails());
        report.setPdid(request.getTask().getPdid());
        report.setPdnum(request.getTask().getPdnum());
        report.setSource(request.getTask().getSource());
        report.setTarget(request.getTask().getTarget());
        report.setQuantity(request.getTask().getTargetQuantity());

        // ReportResult result = deviceService.sendMovingReport(jobRequest.getUserDetails(), report, "picking");

        // if(result.getResult() == StageResult.SUCCESS) {
        // Long doneQuantity = request.getSummary().getDoneQuantity() + request.getTask().getTargetQuantity();
        // request.getSummary().setDoneQuantity(doneQuantity);

        String cartId = jobRequest.getJob().getTrolley();
        String pdId = request.getTask().getPdid();
        String pdNum = request.getTask().getPdnum().toString();
        String quantity = request.getTask().getTargetQuantity().toString();
        String compartmentId = request.getTask().getCompartmentId().toString();

        String endpoint = MessageFormat.format(PUT_ENDPOINT, compartmentId, compartmentId, cartId, pdId, pdNum, quantity);

        WwsReportResponse response = wwsEndpointService.sendReport(endpoint, jobRequest.getUserDetails().getSession());

        if (response.isData()) {
            updatePutTaskStatus(report, TaskStatus.DONE);

            stageResponse.setStage(request.getStage().next());
            stageResponse.setResult(StageResult.SUCCESS);
        } else {
            logsyLogger.logPickerAction(IAuditLogsyLogger.REPORT_SEND_OPERATION, jobRequest.getJob().getJobName(),
                    jobRequest.getJob().getVzIdAsString(), jobRequest.getUserDetails(), null, IAuditLogsyLogger.FAIL_RESULT);
            throw new PickerValidationFailed(request, "Failed to send report");
        }
        logsyLogger.logPickerAction(IAuditLogsyLogger.REPORT_SEND_OPERATION, jobRequest.getJob().getJobName(), jobRequest.getJob().getVzIdAsString(),
                jobRequest.getUserDetails(), null, IAuditLogsyLogger.SUCCESS_RESULT);
        return stageResponse;
    }

    private void updatePutTaskStatus(Report report, TaskStatus newStatus) {
        PutTask found = putTaskRepository.findFirstByCompartmentLabelValueQuantityPickTaskSource(report.getTarget(), report.getQuantity(),
                report.getSource());
        if (found != null) {
            found.setStatus(newStatus);
            found.getPickTask().updateStatus();
            putTaskRepository.save(found);
            pickTaskRepository.save(found.getPickTask());
        }
    }
}
