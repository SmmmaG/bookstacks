package de.pearl.microservices.service;

import de.pearl.microservices.errors.CodeCheckException;
import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.WwsConnectionException;
import de.pearl.microservices.model.Job;
import de.pearl.microservices.model.JobRequest;
import de.pearl.microservices.model.NewJobRequest;
import de.pearl.microservices.model.PfReport;
import de.pearl.microservices.model.Product;
import de.pearl.microservices.model.ProductImage;
import de.pearl.microservices.model.Report;
import de.pearl.microservices.model.ReportResult;
import de.pearl.microservices.model.Session;
import de.pearl.microservices.model.Stock;
import de.pearl.microservices.model.UserDetails;
import de.pearl.microservices.model.VzInfo;

public interface IDeviceService {

    ReportResult sendMovingReport(UserDetails userDetails, Report report, String jobType)
            throws LoginException, WwsConnectionException, CodeCheckException;

    ReportResult sendPfReport(PfReport report) throws LoginException, WwsConnectionException;

    ReportResult sendCorrectionReport(UserDetails userDetails, Report report) throws WwsConnectionException;

    Stock checkStock(String actionType, JobRequest jobRequest, String jobType, String barcode, boolean target)
            throws CodeCheckException, WwsConnectionException;

    Stock getStock(String actionType, JobRequest jobRequest, String barcode) throws LoginException, CodeCheckException, WwsConnectionException;

    Job makeHeartBeat(NewJobRequest newJobRequest) throws WwsConnectionException, LoginException;

    ProductImage loadImage(String pdid, Session session) throws WwsConnectionException;

    Product checkProduct(JobRequest jobRequest, String barcode) throws LoginException, CodeCheckException, WwsConnectionException;

    VzInfo getVz(UserDetails userDetails, String qrCode);

    Stock inventoryStock(String validationStock, JobRequest jobRequest, String jobType, String scanCode);
}
