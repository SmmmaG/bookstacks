package de.pearl.microservices.logging;

import de.pearl.microservices.logging.actions.details.ActionDetails;
import de.pearl.microservices.logging.actions.input.ActionInput;
import de.pearl.microservices.logging.actions.output.ActionOutput;
import lombok.Data;

@Data
public class LogAction {

    private String action;

    private ActionInput actionInput;

    private ActionOutput actionOutput;

    private ActionDetails actionDetails;
}
