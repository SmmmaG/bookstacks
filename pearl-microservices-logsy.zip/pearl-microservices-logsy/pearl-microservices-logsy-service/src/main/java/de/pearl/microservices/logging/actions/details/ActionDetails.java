package de.pearl.microservices.logging.actions.details;

import de.pearl.microservices.logging.actions.details.nested.LoggerActionDetails;
import de.pearl.microservices.logging.actions.details.nested.LoggerJobType;
import lombok.Getter;

@Getter
public class ActionDetails {
    private LoggerActionDetails actionDetails;
    private LoggerJobType jobType;

    private ActionDetails() {

    }

    public static ActionDetails forActionDetailsLog(String actionType) {
        ActionDetails result = new ActionDetails();
        result.actionDetails = new LoggerActionDetails(actionType);

        return result;
    }

    public static ActionDetails forJobTypeLog(String jobType) {
        ActionDetails result = new ActionDetails();
        result.jobType = new LoggerJobType(jobType);

        return result;
    }
}
