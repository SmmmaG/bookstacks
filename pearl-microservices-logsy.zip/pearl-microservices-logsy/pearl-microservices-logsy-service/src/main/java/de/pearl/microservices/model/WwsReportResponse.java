package de.pearl.microservices.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class WwsReportResponse {

    private boolean data;
    private Error error;

    @Getter
    @Setter
    public static class Error {
        private String message;

    }
}
