package de.pearl.microservices.model;

import de.pearl.microservices.errors.InvalidCodeType;
import lombok.Data;

@Data
public class CodeCheckEntity {
    private String message;
    private InvalidCodeType type;
}
