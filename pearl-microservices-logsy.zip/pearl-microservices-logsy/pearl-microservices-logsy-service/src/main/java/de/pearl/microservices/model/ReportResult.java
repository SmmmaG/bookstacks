package de.pearl.microservices.model;

import de.pearl.microservices.model.picker.StageResult;
import lombok.Data;

@Data
public class ReportResult {

    private StageResult result;
    private String errorMessage;

}
