package de.pearl.microservices.service.impl;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.pearl.microservices.common.BBSCommon;
import de.pearl.microservices.errors.*;
import de.pearl.microservices.logging.IAuditLogsyLogger;
import de.pearl.microservices.logging.LogUser;
import de.pearl.microservices.model.*;
import de.pearl.microservices.model.picker.StageResult;
import de.pearl.microservices.persistence.entities.UserSession;
import de.pearl.microservices.persistence.enums.events.UserSessionEvents;
import de.pearl.microservices.persistence.repositories.UserSessionRepository;
import de.pearl.microservices.service.IDeviceService;
import de.pearl.microservices.service.IWwsEndpointService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.UUID;

@Slf4j
@Service
public class DeviceService implements IDeviceService {
    private final String validationAfter = "Validation After Action";

    private IAuditLogsyLogger logsyLogger;
    private IWwsEndpointService wwsEndpointService;
    private UserSessionRepository userSessionRepository;

    private ObjectMapper objectMapper;

    @Autowired
    public DeviceService(IAuditLogsyLogger logsyLogger, IWwsEndpointService wwsEndpointService, UserSessionRepository userSessionRepository) {
        this.logsyLogger = logsyLogger;
        this.wwsEndpointService = wwsEndpointService;
        this.userSessionRepository = userSessionRepository;
        objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    private ReportResult prepareSuccessReport() {
        ReportResult reportResult = new ReportResult();
        reportResult.setResult(StageResult.SUCCESS);
        return reportResult;
    }

    private ReportResult prepareErrorReport(String errorMessage) {
        ReportResult reportResult = new ReportResult();
        reportResult.setResult(StageResult.FAIL);
        reportResult.setErrorMessage(errorMessage);
        return reportResult;
    }

    @Override
    public ReportResult sendMovingReport(UserDetails userDetails, Report report, String jobType)
            throws LoginException, WwsConnectionException, CodeCheckException {
        LogUser user = objectMapper.convertValue(userDetails, LogUser.class);
        try {
            String endpoint = "/bbs/pda/logistics/stock/relocate_action.jsp?" + "source=" + report.getSource() + "&destination=" + report.getTarget()
                    + "&item=" + report.getPdid() + "-" + report.getPdnum() + "&qty=" + report.getQuantity();

            WwsReportResponse response = wwsEndpointService.sendReport(endpoint, userDetails.getSession());
            if (!response.isData()) {
                logsyLogger.logerrorReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report, response.getError().getMessage());
                return prepareErrorReport(response.getError().getMessage());
            }
        } catch (LoginException e) {
            logsyLogger.logerrorLogin(report.getJob().getJobName(), report.getJob().getId(), user, report, e.getMessage());
            throw e;
        } catch (Exception e) {
            logsyLogger.logerrorReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report, e.getMessage());
        }
        logsyLogger.logsuccessReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report);

        JobRequest jobRequest = new JobRequest();

        jobRequest.setJob(report.getJob());
        jobRequest.setUserDetails(report.getUserDetails());
        checkStock(validationAfter, jobRequest, jobType, report.getSource(), false);
        checkStock(validationAfter, jobRequest, jobType, report.getTarget(), true);
        return prepareSuccessReport();
    }

    @Override
    public ReportResult sendPfReport(PfReport report) throws LoginException, WwsConnectionException {
        LogUser user = objectMapper.convertValue(report.getUserDetails(), LogUser.class);
        try {
            String endpoint = MessageFormat.format(IWwsEndpointService.PROBLEM_FLAG_ENDPOINT, report.getPfFlag(), report.getSource());
            WwsReportResponse response = wwsEndpointService.sendReport(endpoint, report.getUserDetails().getSession());
            if (!response.isData()) {
                logsyLogger.logerrorReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report, response.getError().getMessage());
                return prepareErrorReport(response.getError().getMessage());
            }

        } catch (LoginException e) {
            logsyLogger.logerrorLogin(report.getJob().getJobName(), report.getJob().getId(), user, report, e.getMessage());
            return prepareErrorReport(e.getMessage());
        } catch (Exception e) {
            logsyLogger.logerrorReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report, e.getMessage());
            return prepareErrorReport(e.getMessage());
        }
        logsyLogger.logsuccessReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report);

        JobRequest jobRequest = new JobRequest();

        jobRequest.setJob(report.getJob());
        jobRequest.setUserDetails(report.getUserDetails());
        if (log.isInfoEnabled()) {
            log.info("DeviceService.sendPfReport. source: {}, pflag: {}", report.getSource(), report.getPfFlag());
        }
        return prepareSuccessReport();
    }

    @Override
    public ReportResult sendCorrectionReport(UserDetails userDetails, Report report) throws WwsConnectionException {
        LogUser user = objectMapper.convertValue(userDetails, LogUser.class);
        try {
            // Create connection

            String endpoint = "/bbs/pda/logistics/stock/correction_action.jsp?" + "destination=" + report.getSource() + "&item=" + report.getPdid()
                    + "-" + report.getPdnum() + "&qty=" + report.getQuantity();

            WwsReportResponse response = wwsEndpointService.sendReport(endpoint, userDetails.getSession());
            if (!response.isData()) {
                logsyLogger.logerrorReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report, response.getError().getMessage());
                return prepareErrorReport(response.getError().getMessage());
            }

        } catch (LoginException e) {
            logsyLogger.logerrorLogin(report.getJob().getJobName(), report.getJob().getId(), user, report, e.getMessage());
            throw e;
        } catch (Exception e) {
            logsyLogger.logerrorReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report, e.getMessage());
            return prepareErrorReport(e.getMessage());
        }

        logsyLogger.logsuccessReportSend(report.getJob().getJobName(), report.getJob().getId(), user, report);

        JobRequest jobRequest = new JobRequest();

        jobRequest.setJob(report.getJob());
        jobRequest.setUserDetails(report.getUserDetails());

        checkStock(validationAfter, jobRequest, "correction", report.getSource(), false);
        if (log.isInfoEnabled()) {
            log.info("DeviceService.sendCorrectionReport. source: {}", report.getSource());
        }
        return prepareSuccessReport();
    }

    @Override
    public Stock checkStock(String actionType, JobRequest jobRequest, String jobType, String barcode, boolean target)
            throws CodeCheckException, WwsConnectionException {
        Stock stock = new Stock();
        stock.setCode(barcode);
        LogUser user = objectMapper.convertValue(jobRequest.getUserDetails(), LogUser.class);
        try {
            if (!isBarCodeValid(jobType, barcode, target)) {
                String errorMessage = "Code is not valid";
                logsyLogger.logerrorStockCheck(actionType, jobRequest.getJob().getId(), user, stock, errorMessage);
                throw new CodeCheckException(errorMessage, InvalidCodeType.BadCode);
            }
            CheckStockResponse response = wwsEndpointService.sendCheckStock(barcode, jobRequest.getUserDetails().getSession());

            if (response.getData() == null) {
                CheckStockResponse.Error error = response.getError();
                if (target) {
                    stock.setErrorCode(error.getCode());
                    stock.setErrorMessage(error.getMessage());
                    stock.setCode(barcode);
                    logsyLogger.logerrorStockCheck(actionType, jobRequest.getJob().getId(), user, stock, error.getMessage());
                } else {
                    logsyLogger.logerrorStockCheck(actionType, jobRequest.getJob().getId(), user, stock, error.getMessage());
                    throw new CodeCheckException(error.getMessage(), InvalidCodeType.WWS);
                }
            } else {
                CheckStockResponse.Data data = response.getData();
                stock.setCode(data.getLabelValue());
                stock.setCodeToShow(data.getLabelCaption());
                stock.setPdid(data.getPdId());
                stock.setPdnum(data.getPdNum());
                stock.setQuantity(data.getInventory());
                stock.setPfFlag(data.getPflag());
                logsyLogger.logsuccessStockCheck(actionType, jobRequest.getJob().getId(), user, stock);
            }
        } catch (Exception e) {
            logsyLogger.logerrorStockCheck(actionType, jobRequest.getJob().getId(), user, stock, e.getMessage());
            throw e;
        }
        return stock;
    }

    @Override
    public Stock getStock(String actionType, JobRequest jobRequest, String barcode)
            throws LoginException, CodeCheckException, WwsConnectionException {
        Stock stock = new Stock();
        stock.setCode(barcode);
        LogUser user = objectMapper.convertValue(jobRequest.getUserDetails(), LogUser.class);
        try {

            StockResponse response = wwsEndpointService.sendStock(barcode, jobRequest.getUserDetails().getSession());
            if (response.getData() == null) {
                throw new CodeCheckException(response.getError().getMessage(), InvalidCodeType.WWS);
            } else {
                stock = response.toStock();
            }

        } catch (WwsConnectionException e) {
            logsyLogger.logerrorStockCheck(actionType, jobRequest.getJob().getId(), user, stock, e.getMessage());
            throw e;
        } catch (LoginException e) {
            logsyLogger.logerrorLogin(actionType, jobRequest.getJob().getId(), user, stock, e.getMessage());
            throw e;
        } catch (Exception e) {
            logsyLogger.logerrorStockCheck(actionType, jobRequest.getJob().getId(), user, stock, e.getMessage());
            throw new CodeCheckException(barcode, InvalidCodeType.WWS);
        }

        logsyLogger.logsuccessStockCheck(actionType, jobRequest.getJob().getId(), user, stock);
        return stock;
    }

    @Override
    public Job makeHeartBeat(NewJobRequest newJobRequest) throws WwsConnectionException, LoginException {
        Job job = new Job();
        UUID jobId = UUID.randomUUID();
        job.setId(jobId.toString());
        job.setJobName(newJobRequest.getJobType());
        LogUser user = objectMapper.convertValue(newJobRequest.getUserDetails(), LogUser.class);
        try {
            String response = wwsEndpointService.makeHeartBeatRequestToWWS(newJobRequest.getUserDetails().getSession());
            if (IWwsEndpointService.WWS_PING_RESPONSE_FAIL_BODY.equals(response)) {
                throw new LoginException("MakeHeartBeat", IWwsEndpointService.WWS_HEARTBEAT_ENDPOINT);
            }
        } catch (WwsConnectionException e) {
            if (newJobRequest.isHeartBeat()) {
                logsyLogger.logErrorHeartBeat(newJobRequest.getUserDetails().getSession().getId(), user, e.getEndpoint(), e.getMessage());
            } else {
                logsyLogger.logErrorJobStart(newJobRequest.getUserDetails().getSession().getId(), user, job, e.getMessage());
            }
            throw e;
        }
        return job;
    }

    @Override
    public ProductImage loadImage(String pdid, Session session) throws WwsConnectionException {
        String endpoint = "/bbs/wi/bo/ip-cam/test.jsp?imagedefid=910&imageid=1";
        return wwsEndpointService.loadImage(endpoint, session);
    }

    @Override
    public Product checkProduct(final JobRequest jobRequest, final String barcode) throws LoginException, CodeCheckException, WwsConnectionException {
        Product product = new Product();
        LogUser user = objectMapper.convertValue(jobRequest.getUserDetails(), LogUser.class);
        product.setCode(barcode);
        try {
            ProductResponse response = wwsEndpointService.sendProduct(barcode, jobRequest.getUserDetails().getSession());

            if (response.getData() == null) {
                throw new CodeCheckException(response.getError().getMessage(), InvalidCodeType.WWS);
            } else {
                String pdid = response.getData().getId().getProductId();
                Long pdnum = response.getData().getId().getPdNum();
                product.setCode(barcode);
                product.setPdid(pdid);
                product.setPdnum(pdnum);
            }

        } catch (WwsConnectionException | CodeCheckException e) {
            logsyLogger.logerrorProductCheck(barcode, jobRequest.getJob().getId(), user, product, e.getMessage());
            throw e;
        } catch (Exception e) {
            logsyLogger.logerrorProductCheck(barcode, jobRequest.getJob().getId(), user, product, e.getMessage());
            throw e;
        }

        logsyLogger.logsuccessProductCheck(barcode, jobRequest.getJob().getId(), user, product);
        return product;
    }

    @Override
    public VzInfo getVz(UserDetails userDetails, String qrCode) {
        try {
            UserSession uSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(userDetails.getUserName()));
            if (uSession != null) {
                uSession.updateUserSessionStatus(UserSessionEvents.SCAN_QR);
            } else {
                // todo: throw access error (?)
            }
            String[] vzData = qrCode.split(":");
            VzInfo vzInfo = new VzInfo();
            vzInfo.setPlace(vzData[0]);
            vzInfo.setCountry(vzData[1]);
            vzInfo.setCenter(Long.parseLong(vzData[2]));

            if (uSession != null) {
                uSession.setSite(Integer.parseInt(vzData[2]));
                userSessionRepository.save(uSession);
            }

            return vzInfo;
        } catch (Exception e) {
            throw e;
        }
    }

    @Override
    public Stock inventoryStock(String actionType, JobRequest jobRequest, String jobType, String barcode) {
        Stock stock = new Stock();
        stock.setCode(barcode);
        LogUser user = objectMapper.convertValue(jobRequest.getUserDetails(), LogUser.class);
        try {
            if (!isBarCodeValid(jobType, barcode, true)) {
                String errorMessage = "Code is not valid";
                logsyLogger.logerrorStockCheck(actionType, jobRequest.getJob().getId(), user, stock, errorMessage);
                throw new CodeCheckException(errorMessage, InvalidCodeType.BadCode);
            }
            StockResponse response = wwsEndpointService.getInventoryStock(barcode, jobRequest.getUserDetails().getSession());

            if (response.getData() == null) {
                throw new InventoryCheckException(response.getError().getMessage(), jobRequest.getUserDetails().getSession().getPath());
            } else {
                stock = response.toStock();
            }
        } catch (LoginException e) {
            logsyLogger.logerrorLogin(actionType, jobRequest.getJob().getId(), user, stock, e.getMessage());
            throw e;
        }
        return stock;
    }

    private boolean isBarCodeValid(String jobType, String barcode, boolean target) {
        int labelType = BBSCommon.assignLabelType(barcode);
        if (labelType == 0) {
            return false;
        }

        switch (jobType) {
            case "moving":
                /*
                 * if(labelType != 1){
                 * return false;
                 * }
                 */
                return true;
            case "storing":
                if (!target && labelType != 2) {
                    return false;
                }
                if (target && labelType == 2) {
                    return false;
                }
                break;
            case "picking":
                /*
                 * if(!target && labelType ==2){
                 * return false;
                 * }
                 * if(target && labelType != 2) {
                 * return false;
                 * }
                 * break;
                 */
                return true;

            default:
                return true;

        }
        return true;
    }
}
