package de.pearl.microservices.model.picker;

import de.pearl.microservices.model.Job;
import de.pearl.microservices.model.VzInfo;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class PickerJob extends Job {
    private String trolley;
    private Short scenario;

    private VzInfo vzId;
    private String ip;

    public String getVzIdAsString() {
        if (vzId == null) {
            return "";
        }
        return this.vzId.getCenter().toString();
    }
}
