package de.pearl.microservices.model.picker;

import lombok.Data;

@Data
public class StageRequest {
    private String barCode;
    private Long quantity;
    private Slot task;
    private PickerStage stage;
}
