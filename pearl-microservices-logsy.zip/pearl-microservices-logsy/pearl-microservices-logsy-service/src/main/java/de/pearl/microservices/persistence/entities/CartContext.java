package de.pearl.microservices.persistence.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * A CartContext.
 */
@Entity
@Table(name = "cart_context", schema = "warehouse_terminal")
public class CartContext implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "cartContextIdSeq", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "cartContextIdSeq", sequenceName = "warehouse_terminal.cart_context_id_seq", allocationSize = 51)
    private Long id;

    @NotNull
    @Column(name = "cart_id", nullable = false)
    private String cartId;

    @NotNull
    @Column(name = "scenario_type", nullable = false, columnDefinition = "-1")
    private Integer scenarioType;

    @OneToMany(mappedBy = "cartContext", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private Set<PickTask> pickTasks = new HashSet<>();
    @ManyToOne
    @JsonIgnoreProperties("cartContexts")
    private UserSession userSession;

    public Integer getScenarioType() {
        return scenarioType;
    }

    public CartContext setScenarioType(Integer scenarioType) {
        this.scenarioType = scenarioType;
        return this;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCartId() {
        return cartId;
    }

    public void setCartId(String cartId) {
        this.cartId = cartId;
    }

    public CartContext cartId(String cartId) {
        this.cartId = cartId;
        return this;
    }

    public Set<PickTask> getPickTasks() {
        return pickTasks;
    }

    public void setPickTasks(Set<PickTask> pickTasks) {
        this.pickTasks = pickTasks;
    }

    public CartContext pickTasks(Set<PickTask> pickTasks) {
        this.pickTasks = pickTasks;
        return this;
    }

    public void addPickTasks(List<PickTask> pickTasks) {
        pickTasks.forEach(pt -> {
            this.pickTasks.add(pt);
            pt.setCartContext(this);
        });
    }

    public CartContext removePickTasks(PickTask pickTask) {
        this.pickTasks.remove(pickTask);
        pickTask.setCartContext(null);
        return this;
    }

    public UserSession getUserSession() {
        return userSession;
    }

    public void setUserSession(UserSession userSession) {
        this.userSession = userSession;
    }

    public CartContext userSession(UserSession userSession) {
        this.userSession = userSession;
        return this;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CartContext cartContext = (CartContext) o;
        if (cartContext.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), cartContext.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CartContext{" +
            "id=" + getId() +
            ", cartId=" + getCartId() +
            "}";
    }
}
