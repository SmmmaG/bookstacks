package de.pearl.microservices.persistence.enums;

public enum TaskStatus {
    TO_DO,
    IN_PROGRESS,
    DONE
}
