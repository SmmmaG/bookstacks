package de.pearl.microservices.persistence.repositories;

import de.pearl.microservices.persistence.entities.CartContext;
import de.pearl.microservices.persistence.entities.PickTask;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface PickTaskRepository extends CrudRepository<PickTask, Long> {
    List<PickTask> findAllByCartContextIn(List<CartContext> context);

    PickTask findByPdLabel(String pdLabel);

    PickTask findDistinctBySource(String source);

    @Query(nativeQuery = true, value =
            "select pick.* \n" +
            "from\n" +
            "  warehouse_terminal.pick_task pick,\n" +
            "  warehouse_terminal.user_session user_s,\n" +
            "  warehouse_terminal.cart_context cart\n" +
            "where pick.cart_context_id = cart.id\n" +
            "  and cart.user_session_id = user_s.id\n" +
            "  and pick.source = :source\n" +
            "  and user_s.user_id = :user_id")
    PickTask findDistinctBySourceAndUserId(@Param("source")String source, @Param("user_id")Integer userId);

    @Query(nativeQuery = true, value = "" +
        "select \n" +
        "  (pick.rank = MAX(max_pick.rank)) as isTaskLast\n" +
        "from\n" +
        "  warehouse_terminal.pick_task pick,\n" +
        "  warehouse_terminal.pick_task max_pick\n" +
        "where pick.cart_context_id = :cart_context_id\n" +
        "  and pick.rank = :pick_task_rank\n" +
        "group by pick.rank")
    boolean findLastPickTaskForCartContext(@Param("cart_context_id")Long cartContextId, @Param("pick_task_rank")Integer pickTaskRank);
}
