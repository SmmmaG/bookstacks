package de.pearl.microservices.model;

import lombok.Data;

@Data
public class UserDetails {
    private String userName;
    private Session session;
}
