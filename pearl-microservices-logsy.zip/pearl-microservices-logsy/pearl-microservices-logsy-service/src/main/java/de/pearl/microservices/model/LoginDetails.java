package de.pearl.microservices.model;

import lombok.Data;

import java.util.List;

@Data
public class LoginDetails {
  private List<String> cookies;
  private String host;
  private String username;
}
