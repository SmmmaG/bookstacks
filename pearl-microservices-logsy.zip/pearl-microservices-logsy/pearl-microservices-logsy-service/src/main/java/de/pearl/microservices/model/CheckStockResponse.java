package de.pearl.microservices.model;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class CheckStockResponse {
    private Data data;
    private Error error;

    @Getter
    @Setter
    public static class Data {
        private String labelValue; // label to compare (code)
        private String labelCaption; // label to show (codeToShow)
        private String pdId;
        private Long pdNum;
        private Long inventory;
        private Long pflag;
    }

    @Getter
    @Setter
    public static class Error {
        private String message;
        private Long code;
    }
}
