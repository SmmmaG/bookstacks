package de.pearl.microservices.logging.actions.output.nested;

import de.pearl.microservices.logging.LogProduct;
import lombok.Value;

@Value
public class LogsyProductDetails {

    private LogProduct product;
}
