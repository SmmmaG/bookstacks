package de.pearl.microservices.service;

import de.pearl.microservices.errors.LoginException;
import de.pearl.microservices.errors.PickerValidationFailed;
import de.pearl.microservices.errors.WwsConnectionException;
import de.pearl.microservices.model.picker.PickerRequest;
import de.pearl.microservices.model.picker.StageResponse;

public interface IStateMachineService {
    
    StageResponse cancelStage(final PickerRequest request);

    StageResponse nextStage(final PickerRequest request);

    StageResponse processTask(final PickerRequest request) throws LoginException, WwsConnectionException, PickerValidationFailed;

}
