package de.pearl.microservices.logging.actions.output.nested;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.pearl.microservices.logging.LogProduct;
import lombok.Data;

@Data
public class LogStock {

    private String barcode;

    private LogProduct product;

    private Long quantity;

    public String toJson() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(JsonGenerator.Feature.QUOTE_FIELD_NAMES, false);
        mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(this);
    }
}
