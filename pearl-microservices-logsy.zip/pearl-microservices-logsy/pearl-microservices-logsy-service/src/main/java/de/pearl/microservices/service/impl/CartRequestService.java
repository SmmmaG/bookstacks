package de.pearl.microservices.service.impl;

import de.pearl.microservices.model.Session;
import de.pearl.microservices.persistence.entities.CartContext;
import de.pearl.microservices.persistence.entities.PickTask;
import de.pearl.microservices.persistence.entities.PutTask;
import de.pearl.microservices.persistence.entities.UserSession;
import de.pearl.microservices.persistence.entities.dto.impl.CartContextDTO;
import de.pearl.microservices.persistence.enums.JobType;
import de.pearl.microservices.persistence.enums.TerminalType;
import de.pearl.microservices.persistence.enums.UserSessionStatus;
import de.pearl.microservices.persistence.repositories.CartContextRepository;
import de.pearl.microservices.persistence.repositories.PickTaskRepository;
import de.pearl.microservices.persistence.repositories.PutTaskRepository;
import de.pearl.microservices.persistence.repositories.UserSessionRepository;
import de.pearl.microservices.service.ICartRequestService;
import de.pearl.microservices.service.IWwsEndpointService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.HttpCookie;
import java.text.MessageFormat;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static de.pearl.microservices.service.IWwsEndpointService.*;

@Service
@EnableAsync
@Slf4j
@Transactional
public class CartRequestService implements ICartRequestService {
    private static final Map<String, GetTrolleyRequestFuture> pool = new ConcurrentHashMap<>();
    @Autowired
    private RestTemplateBuilder restTemplateBuilder;
    @Value("${wws.endpoint}")
    private String wwsEndpoint;
    @Value("${wws.gettrolley}")
    private int timeout;

    @Autowired
    private UserSessionRepository userSessionRepository;
    @Autowired
    private CartContextRepository cartContextRepository;
    @Autowired
    private PickTaskRepository pickTaskRepository;
    @Autowired
    private PutTaskRepository putTaskRepository;

    private RestTemplate restTemplate = null;

    @Async("threadPoolTaskExecutor")
    @Override
    public void callGetCartForUser(final String userId, final Session session, final String vzCode) {
        if (TaskState.NOT_EXIST.equals(checkReadyStatusUserGetCartTaskStatus(userId))) {
            executeRequest(userId, session, vzCode);
        }
    }

    @Override
    public boolean isTaskFinishedForUser(String userId) {
        TaskState state = checkReadyStatusUserGetCartTaskStatus(userId);
        return TaskState.SUCCESS.equals(state) || TaskState.FAIL.equals(state);
    }

    @Override
    public CartContext getCartContextResult(final String userId) {
        TaskState state = checkReadyStatusUserGetCartTaskStatus(userId);
        CartContext cartContext = null;
        if (TaskState.SUCCESS.equals(state)) {
            cartContext = pool.get(userId).getCartContext().toEntity();
            if (cartContext == null) {
                cartContext = cartContextRepository.findTop1ByUserIdOrderById(Long.parseLong(userId));
            }
        }
        if (!TaskState.WORKING.equals(state) && !TaskState.NOT_EXIST.equals(state)) {
            pool.remove(userId);
            UserSession userSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(userId));
            userSession.setStatus(UserSessionStatus.CRITICAL_SECTION);
            userSessionRepository.save(userSession);
        }
        return cartContext;
    }

    @Override
    public boolean isTaskExistForUser(final String userId) {
        TaskState state = checkReadyStatusUserGetCartTaskStatus(userId);
        return !TaskState.NOT_EXIST.equals(state);
    }

    /**
     * Check task worker status
     */
    private TaskState checkReadyStatusUserGetCartTaskStatus(final String userId) {
        if (pool.containsKey(userId)) {
            GetTrolleyRequestFuture feature = pool.get(userId);
            return userId.equals(feature.getUserId()) ? feature.getState() : TaskState.NOT_EXIST;
        } else {
            UserSession userSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(userId));
            if (userSession.getStatus().equals(UserSessionStatus.CART_BOOKING)) {
                return TaskState.WORKING;
            }
            if (userSession.getStatus().equals(UserSessionStatus.CART_BOOKED)) {
                return TaskState.SUCCESS;
            }
        }
        return TaskState.NOT_EXIST;
    }

    /**
     * make async call wws for getting task with rest template creation
     */
    private void executeRequest(final String userId, final Session session, final String vzCode) {
        if (restTemplate == null) {
            restTemplateBuilder.setConnectTimeout(timeout).setReadTimeout(timeout);
            restTemplate = restTemplateBuilder.build();
        }
        GetTrolleyRequestFuture getTrolleyRequestFuture = new GetTrolleyRequestFuture(restTemplate, userId);
        pool.put(userId, getTrolleyRequestFuture);

        UserSession userSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(userId));
        userSession.setStatus(UserSessionStatus.CART_BOOKING);
        userSessionRepository.save(userSession);

        getTrolleyRequestFuture.doExecute(session, vzCode);
    }

    /**
     * Create http headers for request
     */
    private HttpHeaders createHttpHeaders(final Session session) {
        HttpCookie cookie = new HttpCookie(session.getSessionName(), session.getSessionId());
        cookie.setDomain(session.getDomain());
        cookie.setPath(session.getPath());

        HttpHeaders headers = new HttpHeaders();
        headers.add(COOKIE, cookie.toString());
        headers.add(ACCEPT_LANGUAGE, ACCEPT_LANGUAGE_VALUE);
        headers.add(ACCEPT, ACCEPT_JSON);
        headers.setCacheControl(NO_CACHE);
        return headers;
    }

    /**
     * Worker status enumerator
     * 
     * @author Ismakaev
     *
     */
    private enum TaskState {
        NEW, WORKING, SUCCESS, FAIL, NOT_EXIST
    }

    /**
     * Async task worker
     * 
     * @author Ismakaev
     *
     */
    public class GetTrolleyRequestFuture {
        private RestTemplate restTemplate;
        private String userId;
        private TaskState taskState;
        private CartContextDTO cartContextDTO;

        GetTrolleyRequestFuture(final RestTemplate restTemplate, final String userId) {
            this.setRestTemplate(restTemplate);
            this.userId = userId;
            taskState = TaskState.NEW;
            cartContextDTO = null;
        }

        void setRestTemplate(RestTemplate restTemplate) {
            this.restTemplate = restTemplate;
        }

        TaskState getState() {
            return taskState;
        }

        public String getUserId() {
            return this.userId;
        }

        CartContextDTO getCartContext() {
            if (!TaskState.SUCCESS.equals(taskState)) {
                return null;
            }
            return cartContextDTO;
        }

        void doExecute(final Session session, final String vzCode) {
            taskState = TaskState.WORKING;
            log.debug("start async call for {} in versamzentrum {}", session.getSessionName(), vzCode);
            try {
                String endpoint = MessageFormat.format(IWwsEndpointService.GET_TROLLEY_WWS_URL, vzCode);
                ResponseEntity<CartContextDTO> response = restTemplate.exchange(wwsEndpoint + endpoint, HttpMethod.GET,
                        new HttpEntity<>(createHttpHeaders(session)), CartContextDTO.class);
                UserSession userSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(userId));
                if (userSession == null) {
                    log.error("user logged out while getting data from PickListGenerator");
                    pool.remove(userId);
                    taskState = TaskState.FAIL;
                } else if (response == null || response.getBody() == null) {
                    taskState = TaskState.FAIL;
                } else {
                    taskState = TaskState.SUCCESS;
                    cartContextDTO = response.getBody();
                    CartContext cartContext;
                    List<CartContext> cartContexts = cartContextRepository.findAllByUserSession(userSession);
                    if (cartContexts != null && !cartContexts.isEmpty()) {
                        cartContextRepository.delete(cartContexts);
                    }
                    cartContext = cartContextDTO.toEntity().userSession(userSession);

                    userSession.addCartContexts(cartContext)
                            .jobType(JobType.PICKING)
                            .terminalType(TerminalType.PORTABLE)
                            .setStatus(UserSessionStatus.CART_BOOKED);

                    userSessionRepository.save(userSession);
                    cartContextRepository.save(cartContext);
                    pickTaskRepository.save(cartContext.getPickTasks());
                    for (PickTask pick : cartContext.getPickTasks()) {
                        // squash put tasks for EPOS
                        if (cartContextDTO.isSinglePos()) {
                            int sum = pick.getPutTasks().stream().mapToInt(PutTask::getQuantity).sum();
                            PutTask oldTask = pick.getPutTasks().iterator().next();
                            PutTask putTask = new PutTask();
                            putTask.setQuantity((short) sum);
                            putTask.setCompartmentId(oldTask.getCompartmentId());
                            putTask.setCompartmentLabelValue(oldTask.getCompartmentLabelValue());
                            putTask.setRank(oldTask.getRank());
                            pick.getPutTasks().clear();
                            pick.addPutTasks(Collections.singletonList(putTask));
                        }
                        pick.getPutTasks().forEach(put -> put.pickTask(pick).pickTaskId(pick.getId()));
                        putTaskRepository.save(pick.getPutTasks());
                    }
                }
            } catch (RestClientException ex) {
                log.error("async worker", ex);
                taskState = TaskState.FAIL;
                UserSession userSession = userSessionRepository.findTop1ByUserIdOrderByIdDesc(Long.parseLong(userId));
                if (userSession != null) {
                    userSession.setStatus(UserSessionStatus.SITE_ASSIGNED).setJob(null);
                    userSessionRepository.save(userSession);
                }
            }
            log.debug("end async call for {} in versamzentrum {}", session.getSessionName(), vzCode);
        }
    }

}
