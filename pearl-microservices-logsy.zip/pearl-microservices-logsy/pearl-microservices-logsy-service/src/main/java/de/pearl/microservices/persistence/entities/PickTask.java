package de.pearl.microservices.persistence.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import de.pearl.microservices.persistence.enums.TaskStatus;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * A PickTask.
 */
@Entity
@Table(name = "pick_task", schema = "warehouse_terminal")
public class PickTask implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "pickTaskIdSeq", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "pickTaskIdSeq", sequenceName = "warehouse_terminal.pick_task_id_seq", allocationSize = 51)
    private Long id;

    @NotNull
    @Enumerated(EnumType.ORDINAL)
    @Column(name = "status", nullable = false)
    private TaskStatus status;

    @NotNull
    @Column(name = "rank", nullable = false)
    private Integer rank;

    @NotNull
    @Column(name = "quantity", nullable = false)
    private Integer quantity;

    @NotNull
    @Column(name = "pd_id", nullable = false)
    private String pdId;

    @NotNull
    @Column(name = "pd_label", nullable = false)
    private String pdLabel;

    @NotNull
    @Column(name = "pd_num", nullable = false)
    private short pdNum;

    @NotNull
    @Column(name = "source", nullable = false)
    private String source;

    @OneToMany(mappedBy = "pickTask", cascade = CascadeType.REMOVE, orphanRemoval = true)
    private Set<PutTask> putTasks = new HashSet<>();
    @ManyToOne
    @JsonIgnoreProperties("pickTasks")
    private CartContext cartContext;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TaskStatus getStatus() {
        return status;
    }

    /**
     * use this instead of {@link #setStatus(TaskStatus)} or {@link #status(TaskStatus)}
     *
     * TO_DO, IN_PROGRESS, DONE
     * 
     * @return actual status
     */
    public TaskStatus updateStatus() {
        Set<TaskStatus> putStatuses = new HashSet<>();
        for (PutTask put : putTasks) {
            putStatuses.add(put.getStatus());
        }
        if (putStatuses.contains(TaskStatus.IN_PROGRESS) || (!putStatuses.contains(TaskStatus.IN_PROGRESS) && putStatuses.contains(TaskStatus.TO_DO)
                && putStatuses.contains(TaskStatus.DONE))) {
            this.status = TaskStatus.IN_PROGRESS;
            return this.status;
        } else if (!putStatuses.contains(TaskStatus.IN_PROGRESS) && !putStatuses.contains(TaskStatus.DONE)) {
            this.status = TaskStatus.TO_DO;
            return this.status;
        } else {
            this.status = TaskStatus.DONE;
            return this.status;
        }
    }

    public void setStatus(TaskStatus status) {
        this.status = status;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public PickTask rank(Integer rank) {
        this.rank = rank;
        return this;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public PickTask quantity(Integer quantity) {
        this.quantity = quantity;
        return this;
    }

    public String getPdId() {
        return pdId;
    }

    public void setPdId(String pdId) {
        this.pdId = pdId;
    }

    public PickTask pdId(String pdId) {
        this.pdId = pdId;
        return this;
    }

    public String getPdLabel() {
        return pdLabel;
    }

    public void setPdLabel(String pdLabel) {
        this.pdLabel = pdLabel;
    }

    public short getPdNum() {
        return pdNum;
    }

    public void setPdNum(short pdNum) {
        this.pdNum = pdNum;
    }

    public PickTask pdNum(short pdNum) {
        this.pdNum = pdNum;
        return this;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public PickTask source(String source) {
        this.source = source;
        return this;
    }

    public CartContext getCartContext() {
        return cartContext;
    }

    public void setCartContext(CartContext cartContext) {
        this.cartContext = cartContext;
    }

    public Set<PutTask> getPutTasks() {
        return putTasks;
    }

    public void setPutTasks(Set<PutTask> putTasks) {
        this.putTasks = putTasks;
    }

    public PickTask putTasks(Set<PutTask> putTasks) {
        this.putTasks = putTasks;
        return this;
    }

    public void addPutTasks(List<PutTask> putTasks) {
        putTasks.forEach(pt -> {
            this.putTasks.add(pt);
            pt.setPickTask(this);
        });
    }

    public PickTask removePutTasks(PutTask putTask) {
        this.putTasks.remove(putTask);
        putTask.setPickTask(null);
        return this;
    }

    public PickTask cartContext(CartContext cartContext) {
        this.cartContext = cartContext;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PickTask pickTask = (PickTask) o;
        if (pickTask.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), pickTask.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PickTask{" + "id=" + getId() + ", status='" + getStatus() + "'" + ", rank=" + getRank() + ", quantity=" + getQuantity() + ", pdId='"
                + getPdId() + "'" + ", pdNum=" + getPdNum() + ", source='" + getSource() + "'" + "}";
    }
}
