package de.pearl.microservices.model;

import lombok.Data;

@Data
public class VzInfo {
    private String place;
    private String country;
    private Long center;
}
