package de.pearl.microservices.logging;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.pearl.microservices.logging.actions.details.ActionDetails;
import de.pearl.microservices.logging.actions.input.ActionInput;
import de.pearl.microservices.logging.actions.output.ActionOutput;
import de.pearl.microservices.logging.actions.output.nested.LogSession;
import de.pearl.microservices.model.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Slf4j
@Service
public class LogsyLogger implements IAuditLogsyLogger {
    // es 6.5
    @Value("${elasticsearch6_5.url}")
    String elasticsearch6_5Url;
    @Value("${elasticsearch6_5.port}")
    Integer elasticsearch6_5Port;
    @Value("${elasticsearch6_5.cluster}")
    String elasticsearch6_5Cluster;
    @Value("${elasticsearch6_5.audit.index.name}")
    private String elasticsearch6_5IndexName;
    @Value("${elasticsearch6_5.audit.index.type}")
    private String elasticsearch6_5IndexType;
    @Value("${elasticsearch6_5.contentType}")
    private String elasticsearch6_5ContentType;

    private ObjectMapper mapper = new ObjectMapper();

    private static final String DISABLED = "disabled";

    @Override
    public void logsuccessLogin(String url, User user) {
        LogSession logSession = mapper.convertValue(user.getSession(), LogSession.class);
        LogAction logAction = new LogAction();
        logAction.setAction(LOGIN_OPERATION);
        logAction.setActionInput(ActionInput.forLogLogin(AUTHORITY, user.getName(), url));
        logAction.setActionOutput(ActionOutput.forSuccessLoginLog(user.getName(), logSession, user.getPrivileges()));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        LoggerEntity loggerEntity = new LoggerEntity(null, null, null, logAction, loggerObject, SUCCESS_RESULT);
        logSuccessInfo(user.getSession().getId(), loggerEntity);
    }

    @Override
    public void logerrorLogin(String url, String userName) {
        LogAction logAction = new LogAction();
        logAction.setAction(LOGIN_OPERATION);
        logAction.setActionInput(ActionInput.forLogLogin(AUTHORITY, userName, url));
        logAction.setActionOutput(ActionOutput.forErrorLog("Invalid credentials"));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), null, null, logAction, loggerObject, FAIL_RESULT);
        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logerrorLogin(String url, String userName, String errorMessage) {
        LogAction logAction = new LogAction();
        logAction.setAction(LOGIN_OPERATION);
        logAction.setActionInput(ActionInput.forLogLogin(AUTHORITY, userName, url));
        logAction.setActionOutput(ActionOutput.forErrorLog(errorMessage));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), null, null, logAction, loggerObject, FAIL_RESULT);
        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logerrorLogin(String actionType, String trigger, LogUser user, Stock stock, String errorMessage) {
        logerrorStockCheck(actionType, trigger, user, stock, errorMessage);
    }

    @Override
    public void logerrorLogin(String barCode, String trigger, LogUser user, Product wProduct, String errorMessage) {
        logerrorProductCheck(barCode, trigger, user, wProduct, errorMessage);
    }

    @Override
    public void logerrorLogin(String jobType, String trigger, LogUser user, Report report, String errorMessage) {
        logerrorReportSend(jobType, trigger, user, report, errorMessage);
    }

    @Override
    public void logerrorLogin(String jobType, String trigger, LogUser user, PfReport report, String errorMessage) {
        logerrorReportSend(jobType, trigger, user, report, errorMessage);
    }

    @Override
    public void logSuccessJobStart(String trigger, LogUser user, Job job) {
        LogAction logAction = new LogAction();
        logAction.setAction(JOB_TYPE_OPERATION);
        logAction.setActionInput(ActionInput.forLogJobStart(job.getJobName()));
        logAction.setActionOutput(ActionOutput.forJobInfoLog(job));
        logAction.setActionDetails(ActionDetails.forActionDetailsLog(job.getJobName()));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        LoggerEntity loggerEntity = new LoggerEntity(null, trigger, user, logAction, loggerObject, SUCCESS_RESULT);
        logSuccessInfo(job.getId(), loggerEntity);
    }

    @Override
    public void logErrorJobStart(String trigger, LogUser user, Job job, String errorMessage) {
        LogAction logAction = new LogAction();
        logAction.setAction(JOB_TYPE_OPERATION);
        logAction.setActionInput(ActionInput.forLogJobStart(job.getJobName()));
        logAction.setActionOutput(ActionOutput.forErrorLog(errorMessage));
        logAction.setActionDetails(ActionDetails.forActionDetailsLog(job.getJobName()));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, FAIL_RESULT);
        logAction(loggerEntity);
    }

    @Override
    public void logsucessHeartBeat(String trigger, LogUser user, String url) {
        LogAction logAction = new LogAction();
        logAction.setAction(HEART_BEAT_OPEARTION);
        logAction.setActionInput(ActionInput.forLogHeartBeat(url));
        logAction.setActionOutput(null);
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, SUCCESS_RESULT);
        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logErrorHeartBeat(String trigger, LogUser user, String url, String errorMessage) {
        LogAction logAction = new LogAction();
        logAction.setAction(HEART_BEAT_OPEARTION);
        logAction.setActionInput(ActionInput.forLogHeartBeat(url));
        logAction.setActionOutput(ActionOutput.forErrorLog(errorMessage));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, FAIL_RESULT);
        logAction(loggerEntity);
    }

    @Override
    public void logsuccessStockCheck(String actionType, String trigger, LogUser user, Stock stock) {
        LogAction logAction = new LogAction();
        logAction.setAction(STOCK_VALIDATION_OPERATION);
        logAction.setActionInput(ActionInput.forLogBarcode(stock.getCode()));

        LogProduct product = new LogProduct();
        product.setPdid(stock.getPdid());
        product.setPdnum(stock.getPdnum());
        product.setProduct(stock.getPdid() + "-" + stock.getPdnum());
        logAction.setActionOutput(ActionOutput.forStockLog(stock, product));
        logAction.setActionDetails(ActionDetails.forActionDetailsLog(actionType));

        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, SUCCESS_RESULT);
        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logerrorStockCheck(String actionType, String trigger, LogUser user, Stock stock, String errorMessage) {
        LogAction logAction = new LogAction();
        logAction.setAction(STOCK_VALIDATION_OPERATION);
        logAction.setActionInput(ActionInput.forLogBarcode(stock.getCode()));
        logAction.setActionOutput(ActionOutput.forErrorLog(errorMessage));
        logAction.setActionDetails(ActionDetails.forActionDetailsLog(actionType));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, FAIL_RESULT);
        logAction(loggerEntity);
    }

    @Override
    public void logsuccessProductCheck(String code, String trigger, LogUser user, Product wProduct) {
        LogAction logAction = new LogAction();
        logAction.setAction(PRODUCT_VALIDATION_OPERATION);
        logAction.setActionInput(ActionInput.forLogBarcode(code));

        LogProduct logProduct = new LogProduct();
        logProduct.setPdid(wProduct.getPdid());
        logProduct.setPdnum(wProduct.getPdnum());
        logProduct.setProduct(wProduct.getPdid() + "-" + wProduct.getPdnum());
        logAction.setActionOutput(ActionOutput.forProductDetailsLog(logProduct));

        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, SUCCESS_RESULT);
        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logPickerAction(String action, String barcode, String vzid, UserDetails user, String errorMessage, String result) {
        LogAction logAction = new LogAction();
        logAction.setAction(action);
        logAction.setActionInput(ActionInput.forLogBarcode(barcode));
        logAction.setActionOutput(ActionOutput.forErrorLog(errorMessage));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("LogSy-2");
        LogUser lUser = new LogUser();
        lUser.setAuthorityType("WWS");
        lUser.setSession(new LogSession(user.getSession().getSessionName(), user.getSession().getSessionId(), user.getSession().getDomain(),
                user.getSession().getDomain()));
        lUser.setUserName(user.getUserName());
        UUID uuid = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(uuid.toString(), vzid, lUser, logAction, loggerObject, result);
        logAction(loggerEntity);
    }

    @Override
    public void logErrorGetNextCart(String action, String vzid, LogUser user, String ip, String message) {
        LogAction logAction = new LogAction();
        logAction.setAction(GET_NEXT_CART_OPERATION);
        logAction.setActionInput(ActionInput.forLogBarcode(action));
        logAction.setActionOutput(ActionOutput.forErrorLog(message));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        LoggerEntity loggerEntity = new LoggerEntity(ip, vzid, user, logAction, loggerObject, FAIL_RESULT);
        logSuccessInfo(ip, loggerEntity);
    }

    @Override
    public void logSuccessGetNextCart(String action, String vzid, LogUser user) {
        LogAction logAction = new LogAction();
        logAction.setAction(GET_NEXT_CART);
        logAction.setActionInput(ActionInput.forLogBarcode(action));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), vzid, user, logAction, loggerObject, SUCCESS_RESULT);
        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logerrorProductCheck(String code, String trigger, LogUser user, Product wProduct, String errorMessage) {
        LogAction logAction = new LogAction();
        logAction.setAction(PRODUCT_VALIDATION_OPERATION);
        logAction.setActionInput(ActionInput.forLogBarcode(code));
        logAction.setActionOutput(ActionOutput.forErrorLog(errorMessage));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, FAIL_RESULT);
        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logsuccessReportSend(String jobType, String trigger, LogUser user, PfReport report) {
        LogAction logAction = new LogAction();
        logAction.setAction(REPORT_PF_SEND_OPERATION);
        logAction.setActionDetails(ActionDetails.forJobTypeLog(jobType));
        logAction.setActionInput(ActionInput.forLogLogPfReport(report.getSource(), report.getPfFlag()));
        logAction.setActionOutput(ActionOutput.forReportOutputLog(true));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, SUCCESS_RESULT);
        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logerrorReportSend(String jobType, String trigger, LogUser user, PfReport report, String errorMessage) {
        LogAction logAction = new LogAction();
        logAction.setActionDetails(ActionDetails.forJobTypeLog(jobType));
        logAction.setAction(REPORT_PF_SEND_OPERATION);
        logAction.setActionInput(ActionInput.forLogLogPfReport(report.getSource(), report.getPfFlag()));
        logAction.setActionOutput(ActionOutput.forErrorLog(errorMessage));
        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, FAIL_RESULT);
        logAction(loggerEntity);
    }

    @Override
    public void logsuccessReportSend(String jobType, String trigger, LogUser user, Report report) {
        LogAction logAction = new LogAction();
        logAction.setActionDetails(ActionDetails.forJobTypeLog(jobType));
        logAction.setAction(REPORT_SEND_OPERATION);

        LogProduct product = new LogProduct();
        product.setPdid(report.getPdid());
        product.setPdnum(report.getPdnum());
        product.setProduct(report.getPdid() + "-" + report.getPdnum());
        logAction.setActionInput(ActionInput.forLogReportSend(report.getSource(), product, report.getQuantity(), report.getTarget()));
        logAction.setActionOutput(ActionOutput.forReportOutputLog(true));

        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, SUCCESS_RESULT);

        logSuccessInfo(id.toString(), loggerEntity);
    }

    @Override
    public void logerrorReportSend(String jobType, String trigger, LogUser user, Report report, String errorMessage) {
        LogAction logAction = new LogAction();
        logAction.setActionDetails(ActionDetails.forJobTypeLog(jobType));
        logAction.setAction(REPORT_SEND_OPERATION);

        LogProduct product = new LogProduct();
        product.setPdid(report.getPdid());
        product.setPdnum(report.getPdnum());
        product.setProduct(report.getPdid() + "-" + report.getPdnum());
        logAction.setActionInput(ActionInput.forLogReportSend(report.getSource(), product, report.getQuantity(), report.getTarget()));
        logAction.setActionOutput(ActionOutput.forErrorLog(errorMessage));

        LoggerObject loggerObject = new LoggerObject();
        loggerObject.setObject("Logsy Device");
        UUID id = UUID.randomUUID();
        LoggerEntity loggerEntity = new LoggerEntity(id.toString(), trigger, user, logAction, loggerObject, FAIL_RESULT);
        logAction(loggerEntity);
    }

    private void logSuccessInfo(String id, LoggerEntity entity) {
        PushIndex(entity, elasticsearch6_5Url, elasticsearch6_5Port, elasticsearch6_5IndexName, elasticsearch6_5IndexType,
                elasticsearch6_5ContentType);
    }

    private void logAction(LoggerEntity entity) {
        PushIndex(entity, elasticsearch6_5Url, elasticsearch6_5Port, elasticsearch6_5IndexName, elasticsearch6_5IndexType,
                elasticsearch6_5ContentType);
    }

    private void PushIndex(LoggerEntity entity, String elasticsearchUrl, Integer elasticsearchPort, String elasticsearchIndexName,
            String elasticsearchIndexType, String elasticsearchContentType) {

        if (isDisabled(elasticsearchUrl)) {
            return;
        }

        try {
            HttpClient httpClient = HttpClientBuilder.create().build();
            String urlString = String.format("http://%s:%s/%s/%s", elasticsearchUrl, elasticsearchPort, elasticsearchIndexName,
                    elasticsearchIndexType);
            HttpPost request = new HttpPost(urlString);

            StringEntity params = new StringEntity(mapper.writeValueAsString(entity.getAppends()));

            request.addHeader("content-type", elasticsearchContentType);
            request.setEntity(params);
            HttpResponse response = httpClient.execute(request);

            if (response.getStatusLine().getStatusCode() != 201) {
                log.error("Error during sent index: {} to elasticsearch", entity);
            }
        } catch (Exception e) {
            log.error("Error during sent index: {} to elasticsearch {}", entity, e.getMessage());
        }
    }

    private boolean isDisabled(String elasticsearchUrl) {
        if (DISABLED.equalsIgnoreCase(elasticsearchUrl)) {
            log.debug("elasticsearch log is disabled");
            return true;
        } else {
            return false;
        }
    }

}
