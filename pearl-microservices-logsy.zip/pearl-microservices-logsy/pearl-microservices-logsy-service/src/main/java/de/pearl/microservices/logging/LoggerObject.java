package de.pearl.microservices.logging;

import lombok.Data;

@Data
public class LoggerObject {

    private String object;

    private Object objectDetails;
}
