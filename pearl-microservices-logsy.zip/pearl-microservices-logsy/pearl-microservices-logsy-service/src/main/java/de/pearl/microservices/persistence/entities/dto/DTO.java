package de.pearl.microservices.persistence.entities.dto;

public interface DTO<T> {
    T toEntity();
}
