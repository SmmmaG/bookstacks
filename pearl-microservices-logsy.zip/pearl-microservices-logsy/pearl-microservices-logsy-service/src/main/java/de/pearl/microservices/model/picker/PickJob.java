package de.pearl.microservices.model.picker;

import lombok.Data;

import java.util.List;

@Data
public class PickJob {
    private String id;
    private String source;
    private String pdid;
    private String pdLabel;
    private Long pdnum;
    private Long quantity;
    List<PutJob> putJobs;
}
