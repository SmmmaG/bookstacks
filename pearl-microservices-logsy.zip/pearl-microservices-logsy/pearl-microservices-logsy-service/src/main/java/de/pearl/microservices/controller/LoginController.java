package de.pearl.microservices.controller;

import de.pearl.microservices.logging.IAuditLogsyLogger;
import de.pearl.microservices.model.Credentials;
import de.pearl.microservices.model.User;
import de.pearl.microservices.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/logsy/login")
public class LoginController {

    private final ILoginService service;
    private final IAuditLogsyLogger logsyLogger;

    @Value("${wws.endpoint}")
    String wwsEndpoint;

    @Autowired
    public LoginController(ILoginService service, IAuditLogsyLogger logsyLogger) {

        this.service = service;
        this.logsyLogger = logsyLogger;
    }

    @PostMapping("/")
    public ResponseEntity<User> login(@RequestBody Credentials credentials) {
        User user = service.login(credentials.getUserName(), credentials.getPassword());
        List<String> userRights = service.getUserPrivileges(user.getSession());
        if (userRights != null) {
            user.setPrivileges(userRights);
        } else {
            user.setPrivileges(new ArrayList<>());
        }

        logsyLogger.logsuccessLogin(wwsEndpoint, user);
        return ResponseEntity.ok(user);
    }

    @GetMapping("/test")
    public ResponseEntity<String> checkConnection() {
        return ResponseEntity.ok("ok");
    }
}
