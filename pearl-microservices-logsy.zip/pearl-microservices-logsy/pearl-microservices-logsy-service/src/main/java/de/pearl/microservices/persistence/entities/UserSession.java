package de.pearl.microservices.persistence.entities;

import de.pearl.microservices.persistence.enums.*;
import de.pearl.microservices.persistence.enums.events.UserSessionEvents;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A UserSession.
 */
@Entity
@Table(schema = "warehouse_terminal", name = "user_session")
public class UserSession implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "userSessionIdSeq", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "userSessionIdSeq", sequenceName = "warehouse_terminal.user_session_id_seq", allocationSize = 51)
    private Long id;

    @NotNull
    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "site")
    private Integer site;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "status")
    private UserSessionStatus status = UserSessionStatus.NEW;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "job")
    private JobType job;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "terminal_type")
    private TerminalType terminal;

    @OneToMany(mappedBy = "userSession", cascade = CascadeType.REMOVE, orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<CartContext> cartContexts = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public UserSession userId(Long userId) {
        this.userId = userId;
        return this;
    }

    public Integer getSite() {
        return site;
    }

    public void setSite(Integer site) {
        this.site = site;
    }

    public UserSessionStatus getStatus() {
        return status;
    }

    public UserSession setStatus(UserSessionStatus status) {
        this.status = status;
        return this;
    }

    /**
     *
     * NEW, LOGGED_IN, SITE_ASSIGNED, JOB_SELECTED, CART_BOOKING, CRITICAL_SECTION, CART_RELEASING, LOGGED_OUT
     *
     * @return actual status
     */
    public UserSessionStatus updateUserSessionStatus(UserSessionEvents event) {
        if (event == null) { // no event for logging out
            this.status = UserSessionStatus.LOGGED_OUT;
        } else if (event.equals(UserSessionEvents.LOGGING_IN)) {
            this.status = UserSessionStatus.LOGGED_IN;
        } else if (status.equals(UserSessionStatus.LOGGED_IN) && event.equals(UserSessionEvents.SCAN_QR)) {
            this.status = UserSessionStatus.SITE_ASSIGNED;
        } else if (status.equals(UserSessionStatus.SITE_ASSIGNED) && event.equals(UserSessionEvents.GET_CART_REQ)) {
            this.status = UserSessionStatus.JOB_SELECTED;
            //todo check if we need a UserSessionStatus.CART_BOOKING status in the system now
        } else if (status.equals(UserSessionStatus.JOB_SELECTED) && event.equals(UserSessionEvents.GET_CART_RESP) ) {
            this.status = UserSessionStatus.CRITICAL_SECTION;
        } else if (status.equals(UserSessionStatus.CRITICAL_SECTION) && event.equals(UserSessionEvents.RELEASE_CART)) {
            this.status = UserSessionStatus.CART_RELEASING;
        }
        return this.status;
    }

    public JobType getJob() {
        return job;
    }

    public void setJob(JobType job) {
        this.job = job;
    }

    public UserSession jobType(JobType jobType) {
        this.job = jobType;
        return this;
    }

    public TerminalType getTerminal() {
        return terminal;
    }

    public void setTerminal(TerminalType terminal) {
        this.terminal = terminal;
    }

    public UserSession terminalType(TerminalType terminalType) {
        this.terminal = terminalType;
        return this;
    }

    public Set<CartContext> getCartContexts() {
        return cartContexts;
    }

    public void setCartContexts(Set<CartContext> cartContexts) {
        this.cartContexts = cartContexts;
    }

    public UserSession cartContexts(Set<CartContext> cartContexts) {
        this.cartContexts = cartContexts;
        return this;
    }

    public UserSession addCartContexts(CartContext cartContext) {
        if (this.cartContexts == null) {
            cartContexts = new HashSet<>();
        }
        this.cartContexts.add(cartContext);
        cartContext.setUserSession(this);
        return this;
    }

    public UserSession removeCartContexts(CartContext cartContext) {
        this.cartContexts.remove(cartContext);
        cartContext.setUserSession(null);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        UserSession userSession = (UserSession) o;
        if (userSession.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), userSession.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "UserSession{" +
            "id=" + getId() +
            ", userId=" + getUserId() +
            ", site='" + getSite() + "'" +
            ", status='" + getStatus() + "'" +
            ", job='" + getJob() + "'" +
            ", terminal='" + getTerminal() + "'" +
            "}";
    }
}

