package de.pearl.microservices.errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class InventoryCheckException extends RuntimeException {

    private String endpoint;

    public InventoryCheckException(String message, String endpoint) {
        super(message);
        this.endpoint = endpoint;
    }
}
