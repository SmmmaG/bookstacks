package de.pearl.microservices.logging.actions.details.nested;

import lombok.Value;

@Value
public class LoggerJobType {

    private String jobType;

}
