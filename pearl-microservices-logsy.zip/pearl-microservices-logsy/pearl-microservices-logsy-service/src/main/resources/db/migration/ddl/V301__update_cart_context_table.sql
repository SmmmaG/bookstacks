ALTER TABLE warehouse_terminal.cart_context
  ADD COLUMN scenario_type integer DEFAULT '-1'::integer;
