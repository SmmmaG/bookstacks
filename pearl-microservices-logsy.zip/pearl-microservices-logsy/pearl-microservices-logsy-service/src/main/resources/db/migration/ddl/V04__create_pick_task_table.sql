CREATE TABLE IF NOT EXISTS warehouse_terminal.pick_task
(
  id              bigserial   not null
    constraint pick_task_pkey primary key,
  cart_context_id bigint      not null,
  status          integer     not null,
  rank            integer     not null,

  quantity        integer     not null,
  pd_id           varchar(16) not null,
  pd_num          smallint    not null,

  source          varchar(32) not null,

  FOREIGN KEY (cart_context_id) REFERENCES warehouse_terminal.cart_context (id)
);
