CREATE TABLE IF NOT EXISTS warehouse_terminal.user_session
(
  id            bigserial not null
    constraint user_session_pkey primary key,

  user_id       bigint    not null,
  site          integer   null,
  status        integer   null,
  job           integer   null,
  terminal_type integer   null
);
