CREATE TABLE IF NOT EXISTS warehouse_terminal.put_task
(
  id                      bigserial   not null
    constraint put_task_pkey primary key,

  pick_task_id            bigint      not null,
  status                  integer     null,
  rank                    integer     not null,

  compartment_id          bigint      not null,
  quantity                smallint    not null,
  compartment_label_value varchar(16) not null,

  FOREIGN KEY (pick_task_id) REFERENCES warehouse_terminal.pick_task (id)
);
