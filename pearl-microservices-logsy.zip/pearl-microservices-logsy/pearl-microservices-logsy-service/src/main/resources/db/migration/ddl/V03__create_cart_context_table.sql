CREATE TABLE IF NOT EXISTS warehouse_terminal.cart_context
(
  id              bigserial   not null
    constraint cart_context_pkey primary key,
  user_session_id bigint      not null,
  cart_id         varchar(32) not null,

  FOREIGN KEY (user_session_id) REFERENCES warehouse_terminal.user_session (id)
);
