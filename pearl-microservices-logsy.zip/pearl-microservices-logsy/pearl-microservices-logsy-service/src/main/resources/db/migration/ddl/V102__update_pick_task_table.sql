ALTER TABLE warehouse_terminal.pick_task
  ADD COLUMN pd_label VARCHAR(32) not null default '';
