create schema warehouse_terminal;
