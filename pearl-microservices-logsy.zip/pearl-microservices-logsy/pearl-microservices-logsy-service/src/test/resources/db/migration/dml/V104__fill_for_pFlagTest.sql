insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (80231, 80231, 2, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (333, 80231, 333);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_num, source)
values (333, 333, 1, 0, 2, 'pdId1', 1, '0101-02-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (333, 1, 0, 11, 2, '0101-02-03-09');



insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (80232, 80232, 2, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (335, 80232, 335);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_num, source)
values (335, 335, 1, 0, 3, 'pdId2', 11, '0201-02-03-09');

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_num, source)
values (336, 335, 0, 1, 2, 'pdId34', 14, '0111-02-03-09');


insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (335, 1, 0, 11, 3, '0201-02-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (336, 0, 1, 11, 22, '0111-02-03-09');



insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (80233, 80233, 2, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (337, 80233, 337);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_num, source)
values (337, 337, 1, 0, 3, 'pdId3', 13, '0301-02-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (337, 1, 0, 11, 3, '0301-02-03-09');

