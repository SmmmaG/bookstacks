insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (11843, 11843, 2, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (11843, 11843, 11843);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (11843, 11843, 0, 0, 2, 'pdId11843','pdId11843', 11, '1184-03-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (11843, 0, 0, 11, 2, '1184-03-03-09');



insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (11432, 11432, 2, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (11432, 11432, 11432);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (11432, 11432, 0, 0, 3, 'pdId11432','pdId11432', 11, '1143-02-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (11432, 0, 0, 11, 3, '1143-02-03-09');


