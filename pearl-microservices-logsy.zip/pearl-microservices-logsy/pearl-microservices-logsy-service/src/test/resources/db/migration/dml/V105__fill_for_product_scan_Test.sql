insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (80666, 80666, 2, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (666, 80666, 7451);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (666, 666, 0, 0, 3, 'SD334', 'SD334-1', 334, '0206-02-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (666, 1, 0, 11, 3, '0206-02-03-09');

