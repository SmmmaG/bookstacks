insert into warehouse_terminal.user_session (user_id, site, status, job, terminal_type)
values (1, 0, 0, 0, 0);

insert into warehouse_terminal.user_session (user_id, site, status, job, terminal_type)
values (1, 0, 0, 0, 0);

insert into warehouse_terminal.cart_context (user_session_id, cart_id)
VALUES (2, 111);

insert into warehouse_terminal.pick_task (cart_context_id, status, rank, quantity, pd_id, pd_num, source)
values (1, 0, 0, 2, 'pdId1', 11, '1111');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (1, 0, 0, 11, 2, '030-00-00');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (1, 0, 0, 111, 1, '030-00-01');

