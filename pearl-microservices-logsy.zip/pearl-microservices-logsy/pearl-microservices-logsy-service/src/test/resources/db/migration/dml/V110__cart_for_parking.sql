insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (60110, 60110, 6, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (6160, 60110, 6160);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (6160, 6160, 0, 0, 2, 'pdId6160','pdId6160', 37, '1137-03-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (6160, 0, 0, 11, 2, '1137-03-03-09');



insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (60111, 60111, 6, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (6161, 60111, 6161);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (6161, 6161, 0, 0, 2, 'pdId6161','pdId6161', 37, '1137-03-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (6161, 0, 0, 11, 2, '1137-03-03-09');



