insert into warehouse_terminal.user_session (user_id, site, status, job, terminal_type)
values (80217, 3, 0, 0, 0);
insert into warehouse_terminal.user_session (user_id, site, status, job, terminal_type)
values (80218, 3, 0, 0, 0);