insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (80431, 80431, 2, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (433, 80431, 433);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (433, 433, 1, 0, 2, 'pdId433','pdId433', 11, '4401-02-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (433, 1, 0, 11, 2, '4401-02-03-09');



insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (80432, 80432, 2, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (435, 80432, 435);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (435, 435, 1, 0, 3, 'pdId2','pdId2', 11, '4201-02-03-09');

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (436, 435, 0, 1, 2, 'pdId34','pdId34', 14, '4111-02-03-09');


insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (435, 1, 0, 11, 3, '4201-02-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (436, 0, 1, 11, 22, '4111-02-03-09');


