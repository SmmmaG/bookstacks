insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (50112, 50112, 6, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (50112, 50112, 50112);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (50112, 50112, 0, 0, 2, 'pdId50112','pdId50112', 37, '1137-03-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (50112, 0, 0, 11, 2, '1137-03-03-09');



insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (50110, 50110, 7, 0, 0, 0);



