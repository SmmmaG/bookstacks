insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (11373, 11373, 6, 0, 0, 0);

insert into warehouse_terminal.cart_context (id, user_session_id, cart_id)
VALUES (11373, 11373, 11373);

insert into warehouse_terminal.pick_task (id, cart_context_id, status, rank, quantity, pd_id, pd_label, pd_num, source)
values (11373, 11373, 0, 0, 2, 'pdId11373','pdId11373', 37, '1137-03-03-09');

insert into warehouse_terminal.put_task (pick_task_id, status, rank, compartment_id, quantity, compartment_label_value)
values (11373, 0, 0, 11, 2, '1137-03-03-09');



insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (21373, 21373, 7, 0, 0, 0);

insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (31373, 31373, 7, 0, 0, 0);

insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (41373, 41373, 7, 0, 0, 0);

insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (51373, 51373, 7, 0, 0, 0);

insert into warehouse_terminal.user_session (id, user_id, site, status, job, terminal_type)
values (61373, 61373, 7, 0, 0, 0);




