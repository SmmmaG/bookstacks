import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;

public class Main {
    public static void main(String[] args) {
        List<List<String>> strings = Arrays.asList(Arrays.asList("", " "),null,  Arrays.asList("r", "s", "d"));
        System.out.println(strings.stream().anyMatch(e -> { return e != null && e.size()>17;}));
        long res = strings.stream().filter(e -> e != null).mapToLong(e -> e.size()).sum();
        System.out.println(res);
        BiFunction<Integer, Long, String> sumToString = (intValue, longValue) ->  new StringBuilder().append(longValue.longValue()+intValue.longValue()).toString();
        System.out.println(sumToString.apply(11, 12L));
    }
}
