package de.pearl.microservices;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest(properties = { "spring.cloud.config.enabled = false" })
@ActiveProfiles({ "test" })
@AutoConfigureMockMvc
public abstract class AbstractIntegrationTest {
    @Autowired
    public MockMvc mockMvc;

    protected static String readResourceAsString(String resourcePath) throws IOException {
        ClassLoader loader = AbstractWireMockIntegrationTest.class.getClassLoader();
        InputStream inpstream = loader.getResourceAsStream(resourcePath);
        return IOUtils.toString(inpstream, "UTF-8");
    }

    protected static <T> T readResourceAsObjectFromJson(String resourcePath, Class<T> clazz)
            throws JsonParseException, JsonMappingException, IOException {
        ClassLoader loader = AbstractWireMockIntegrationTest.class.getClassLoader();
        InputStream inpstream = loader.getResourceAsStream(resourcePath);
        ObjectMapper objectMapper = new ObjectMapper();
        return (T) objectMapper.readValue(inpstream, clazz);
    }
}
