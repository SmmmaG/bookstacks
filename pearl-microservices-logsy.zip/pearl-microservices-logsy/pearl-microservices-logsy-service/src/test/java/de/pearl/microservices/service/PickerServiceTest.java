package de.pearl.microservices.service;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.text.MessageFormat;

import org.flywaydb.test.annotation.FlywayTest;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.model.picker.PickerJobRequest;
import de.pearl.microservices.model.picker.PickerStage;
import de.pearl.microservices.model.picker.StageRequest;
import de.pearl.microservices.model.picker.StageResponse;
import de.pearl.microservices.model.picker.StageResult;
import de.pearl.microservices.persistence.entities.CartContext;
import de.pearl.microservices.persistence.entities.PickTask;
import de.pearl.microservices.persistence.repositories.CartContextRepository;

@SpringBootTest
public class PickerServiceTest extends AbstractWireMockIntegrationTest {
    private static final String GET_TROLLEY_JOB_JSON = "./testJson/getTrolleyJob.json";
    private static final String GET_TROLLEY_JOB_JSON_1 = "./testJson/getTrolleyJob1.json";
    private static final String GET_TROLLEY_REQUEST_JSON = "./testJson/getTrolleyRequest.json";
    private static final String GET_TROLLEY_REQUEST_JSON_1 = "./testJson/getTrolleyRequest1.json";
    @Autowired
    private CartContextRepository cartContextRepository;
    @Autowired
    private IPickerService pickerService;

    @Test
    @FlywayTest
    @Transactional
    public void getTrolley_EPOS_with_squashing() throws JsonParseException, JsonMappingException, IOException {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "4")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/getPickListExtraPutsEPOSJsonResponse.json"))));
        // prepare data
        StageRequest request = readResourceAsObjectFromJson(GET_TROLLEY_REQUEST_JSON_1, StageRequest.class);
        assertEquals(PickerStage.GETTINGTROLLEY, request.getStage());
        PickerJobRequest jobRequest = readResourceAsObjectFromJson(GET_TROLLEY_JOB_JSON_1, PickerJobRequest.class);
        // tested method
        StageResponse response = pickerService.getTrolley(request, jobRequest);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        response = pickerService.getTrolley(request, jobRequest);
        // assertions
        assertEquals(StageResult.SUCCESS, response.getResult());
        assertEquals(PickerStage.SCANNINGTROLLEY, response.getStage());

        CartContext cartcontext = cartContextRepository
                .findByUserIdAndCartId(Long.parseLong(jobRequest.getUserDetails().getUserName()), response.getMessage())
                .get(0);
        for (PickTask pickTask : cartcontext.getPickTasks()) {
            assertEquals(1, pickTask.getPutTasks().size());
        }
    }

    @Test
    @FlywayTest
    @Transactional
    public void getTrolley_EPOS_wo_squashing() throws JsonParseException, JsonMappingException, IOException {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "5")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/getPickListEPOSJsonResponse.json"))));
        // prepare data
        StageRequest request = readResourceAsObjectFromJson(GET_TROLLEY_REQUEST_JSON, StageRequest.class);
        assertEquals(PickerStage.GETTINGTROLLEY, request.getStage());
        PickerJobRequest jobRequest = readResourceAsObjectFromJson(GET_TROLLEY_JOB_JSON, PickerJobRequest.class);
        // tested method
        StageResponse response = pickerService.getTrolley(request, jobRequest);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        response = pickerService.getTrolley(request, jobRequest);
        // assertions
        assertEquals(StageResult.SUCCESS, response.getResult());
        assertEquals(PickerStage.SCANNINGTROLLEY, response.getStage());

        CartContext cartcontext = cartContextRepository
                .findByUserIdAndCartId(Long.parseLong(jobRequest.getUserDetails().getUserName()), response.getMessage())
                .get(0);
        for (PickTask pickTask : cartcontext.getPickTasks()) {
            assertEquals(1, pickTask.getPutTasks().size());
        }
    }
}
