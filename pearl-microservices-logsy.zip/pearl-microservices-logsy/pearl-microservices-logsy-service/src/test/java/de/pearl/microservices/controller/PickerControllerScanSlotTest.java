package de.pearl.microservices.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import de.pearl.microservices.AbstractIntegrationTest;

@SpringBootTest
public class PickerControllerScanSlotTest extends AbstractIntegrationTest {
    @Test
    public void scanSlot_success() throws Exception {
        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_slot/request_ui_success.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/scan_slot/response_ui_success.json")));
    }

    @Test
    public void scanSlot_fail() throws Exception {
        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_slot/request_ui_fail.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/scan_slot/response_ui_fail.json")));
    }

}
