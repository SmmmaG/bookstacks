package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class PickerControllerGetCartTest extends AbstractWireMockIntegrationTest {
    @Test
    @Transactional
    public void getCart_success() throws Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "7")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/get_cart/response_wws_success.json"))));

        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_wait.json")));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_success.json")))
                .andExpect(status().is(200))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_success.json")));

        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "7"))));
    }

    @Test
    @Transactional
    public void getCart_success_w_delay() throws Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "11")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withFixedDelay(7000)
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/get_cart/response_wws_success_w_delay.json"))));

        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_success_w_delay.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_wait.json")));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_success_w_delay.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_wait.json")));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_success_w_delay.json")))
                .andExpect(status().is(200))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_success_w_delay.json")));

        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "11"))));
    }

    @Test
    @Transactional
    public void getCart_no_cart() throws Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "12")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")));

        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_no_cart.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_wait.json")));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_no_cart.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_no_cart.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "12"))));

    }

    @Test
    @Transactional
    public void getCart_no_cart_w_delay() throws Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "13")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withFixedDelay(7000).withStatus(200).withHeader("Content-Type", "application/json")));

        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_no_cart_w_delay.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_wait.json")));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_no_cart_w_delay.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_wait.json")));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_no_cart_w_delay.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_no_cart.json")));

        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "13"))));
    }

    @Test
    @Transactional
    public void getCart_fail() throws Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "14")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(400).withHeader("Content-Type", "application/json")));

        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_fail.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_wait.json")));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_fail.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_fail.json")));

        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "14"))));
    }
    @Ignore
    @Test
    @Transactional
    public void getCart_no_wws() throws Exception {
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_fail_no_wws.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_wait.json")));
        try {
            // bigger than ${wws.gettrolley}
            Thread.sleep(85000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        mockMvc.perform(post("/logsy/picker/trolley").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/get_cart/request_ui_fail_no_wws.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/get_cart/response_ui_fail.json")));

        verify(0, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/pick/pickListApi.jsp?action=GetNextCart&vzid={0}", "13"))));
    }
}
