package de.pearl.microservices.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import de.pearl.microservices.AbstractIntegrationTest;

@SpringBootTest
public class DeviceControllerVzInfoTest extends AbstractIntegrationTest {

    @Test
    public void testCheckInventory_success() throws Exception {
        mockMvc.perform(post("/logsy/device/vzcenter/lc:de:02").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/vz_code/request_ui_success.json")))
                .andExpect(status().isOk())
                .andExpect(content().json("{\"place\":\"lc\",\"country\":\"de\",\"center\":2}"));

    }

    @Test
    public void testCheckInventory_wrong_parts_count() throws Exception {
        mockMvc.perform(post("/logsy/device/vzcenter/lc:de").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/vz_code/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(
                        "{\"message\":\"2\",\"class\":\"java.lang.ArrayIndexOutOfBoundsException\",\"object\":\"{\\\"detailMessage\\\":\\\"2\\\"}\"}"));
    }

    @Test
    public void testCheckInventory_wrong_parts_content() throws Exception {
        mockMvc.perform(post("/logsy/device/vzcenter/lc:de:de").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/vz_code/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(
                        "{\"message\":\"For input string: \\\"de\\\"\",\"class\":\"java.lang.NumberFormatException\",\"object\":\"{\\\"detailMessage\\\":\\\"For input string: \\\\\\\"de\\\\\\\"\\\"}\"}"));
    }

    @Test
    public void testCheckInventory_wrong_code() throws Exception {
        mockMvc.perform(post("/logsy/device/vzcenter/777789").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/vz_code/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(
                        "{\"message\":\"1\",\"class\":\"java.lang.ArrayIndexOutOfBoundsException\",\"object\":\"{\\\"detailMessage\\\":\\\"1\\\"}\"}"));
    }
}
