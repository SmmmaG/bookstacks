package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class LogoutControllerTest extends AbstractWireMockIntegrationTest {
    private static final String PARK_CART_ENDPOINT = "/bbs/pda/logistics/pick/pickListApi.jsp?action=ReleaseCart&cartId={0}&vzid={1}";

    @Test
    public void logoutUserWithTrolley() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(PARK_CART_ENDPOINT, "50112", 6)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)));
        mockMvc.perform(post("/logsy/logout/").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/logout/request_ui_w_cart.json"))).andExpect(status().is(200));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(PARK_CART_ENDPOINT, "50112", 6))));
    }

    @Test
    public void logoutUserWithOutTrolley() throws Exception {
        mockMvc.perform(post("/logsy/logout/").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/logout/request_ui_wo_cart.json"))).andExpect(status().is(200));

    }

    @Test
    public void logoutUserLoggedOff() throws Exception {
        mockMvc.perform(post("/logsy/logout/").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/logout/request_ui_no_user.json"))).andExpect(status().is(200));

    }
}
