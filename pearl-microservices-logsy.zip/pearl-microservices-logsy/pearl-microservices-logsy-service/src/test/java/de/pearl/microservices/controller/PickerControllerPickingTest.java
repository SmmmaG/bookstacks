package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.flywaydb.test.annotation.FlywayTest;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class PickerControllerPickingTest extends AbstractWireMockIntegrationTest {

    private static final String URL_VALIDATE_PRODUCT_WWS = "/bbs/pda/logistics/product/productbarcode_data.jsp?label={0}";

    @Test
    @FlywayTest
    @Transactional
    public void pickProductTest_success() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(URL_VALIDATE_PRODUCT_WWS, "SD334-334")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/scan_product/response_wws_success.json"))));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_product/request_ui_success.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/scan_product/response_ui_success.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(URL_VALIDATE_PRODUCT_WWS, "SD334-334"))));
    }

    @Test    
    @FlywayTest
    @Transactional
    public void pickProductTest_fail() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(URL_VALIDATE_PRODUCT_WWS, "SD334-334")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/scan_product/response_wws_fail.json"))));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_product/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/scan_product/response_ui_fail.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(URL_VALIDATE_PRODUCT_WWS, "SD334-334"))));
    }
    
    @Test
    @FlywayTest
    @Transactional
    public void pickProductTest_fail_wrong_product_scan() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(URL_VALIDATE_PRODUCT_WWS, "SD334-334")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/scan_product/response_wws_fail.json"))));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_product/request_ui_fail.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/scan_product/response_ui_fail.json")));
        verify(0, getRequestedFor(urlEqualTo(MessageFormat.format(URL_VALIDATE_PRODUCT_WWS, "SD334-334"))));
    }
    
    @Test
    @FlywayTest
    @Transactional
    public void pickProductTest_wrong_product() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(URL_VALIDATE_PRODUCT_WWS, "SD334-334")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/scan_product/response_wws_success_wrong_product.json"))));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_product/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/scan_product/response_ui_fail.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(URL_VALIDATE_PRODUCT_WWS, "SD334-334"))));
    }
}
