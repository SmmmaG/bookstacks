package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import com.github.tomakehurst.wiremock.client.WireMock;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class LoginControllerTest extends AbstractWireMockIntegrationTest {

    private static final String COOKIE = "JSESSIONID_SAS5_TEST=\"DB5013C3219E4DD63C608FE998CC8A1B\";$Path=\"/bbs\";$Domain=\"http://dev-wws01.pearl.de:8081\"";

    @Test
    public void login_success_w_priveleges() throws Exception {
        stubFor(WireMock.post(urlEqualTo(IWwsEndpointService.LOGIN_ENDPOINT))
                .withRequestBody(containing(readResourceAsString("./testJson/login/request_wws_login_success.json")))
                .willReturn(aResponse().withStatus(203).withHeader("Set-Cookie", COOKIE)));

        stubFor(get(urlEqualTo(IWwsEndpointService.USER_RIGHTS_ENDPOINT))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/login/request_wws_priveliges.json"))));

        mockMvc.perform(post("/logsy/login/").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/login/request_ui_success.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/login/response_ui_success.json")));

        verify(1, postRequestedFor(urlEqualTo(IWwsEndpointService.LOGIN_ENDPOINT)));
        verify(1, getRequestedFor(urlEqualTo(IWwsEndpointService.USER_RIGHTS_ENDPOINT)));
    }

    @Test
    public void login_success_wo_priveleges() throws Exception {
        stubFor(WireMock.post(urlEqualTo(IWwsEndpointService.LOGIN_ENDPOINT))
                .withRequestBody(containing(readResourceAsString("./testJson/login/request_wws_login_success.json")))
                .willReturn(aResponse().withStatus(203).withHeader("Set-Cookie", COOKIE)));

        stubFor(get(urlEqualTo(IWwsEndpointService.USER_RIGHTS_ENDPOINT))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/login/request_wws_no_priveliges.json"))));

        mockMvc.perform(post("/logsy/login/").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/login/request_ui_success.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/login/response_ui_no_priveliges.json")));

        verify(1, postRequestedFor(urlEqualTo(IWwsEndpointService.LOGIN_ENDPOINT)));
        verify(1, getRequestedFor(urlEqualTo(IWwsEndpointService.USER_RIGHTS_ENDPOINT)));
    }

    @Test
    public void login_success_priveleges_fail() throws Exception {
        stubFor(WireMock.post(urlEqualTo(IWwsEndpointService.LOGIN_ENDPOINT))
                .withRequestBody(containing(readResourceAsString("./testJson/login/request_wws_login_success.json")))
                .willReturn(aResponse().withStatus(203).withHeader("Set-Cookie", COOKIE)));

        stubFor(get(urlEqualTo(IWwsEndpointService.USER_RIGHTS_ENDPOINT))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(400)));

        mockMvc.perform(post("/logsy/login/").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/login/request_ui_success.json")))
                .andExpect(status().is(404));

        verify(1, postRequestedFor(urlEqualTo(IWwsEndpointService.LOGIN_ENDPOINT)));
        verify(1, getRequestedFor(urlEqualTo(IWwsEndpointService.USER_RIGHTS_ENDPOINT)));
    }

    @Test
    public void login_fail() throws Exception {
        stubFor(WireMock.post(urlEqualTo(IWwsEndpointService.LOGIN_ENDPOINT))
                .withRequestBody(containing(readResourceAsString("./testJson/login/request_wws_login_success.json")))
                .willReturn(aResponse().withStatus(200).withHeader("Set-Cookie", COOKIE)));

        mockMvc.perform(post("/logsy/login/").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/login/request_ui_success.json")))
                .andExpect(status().is(401))
                .andExpect(content().json(readResourceAsString("./testJson/login/response_ui_fail.json")));

        verify(1, postRequestedFor(urlEqualTo(IWwsEndpointService.LOGIN_ENDPOINT)));
        verify(0, getRequestedFor(urlEqualTo(IWwsEndpointService.USER_RIGHTS_ENDPOINT)));
    }

    @Test
    public void login_wws_down() throws Exception {
        mockMvc.perform(post("/logsy/login/").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/login/request_ui_success.json")))
                .andExpect(status().is(401))
                .andExpect(content().json(readResourceAsString("./testJson/login/response_ui_fail.json")));
    }
}
