package de.pearl.microservices.persistence.repositories;

import com.google.common.collect.ImmutableList;
import de.pearl.microservices.AbstractIntegrationTest;
import de.pearl.microservices.persistence.entities.CartContext;
import de.pearl.microservices.persistence.entities.PickTask;
import de.pearl.microservices.persistence.entities.UserSession;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class UserSessionRepositoryTest extends AbstractIntegrationTest {
    @Autowired
    private UserSessionRepository userSessionRepository;

    @Transactional
    @Test
    public void verifyThatEmptyPositionsIsEmptyCollection() {
        UserSession userSession = userSessionRepository.findOne(1L);
        assertThat(userSession.getCartContexts()).isEmpty();
    }

    @Transactional
    @Test
    public void verifyThatAllInnerEntitiesIsExist() {

//        UserSession userSession = userSessionRepository.findOne(2L);
//        Set<CartContext> cartContexts = userSession.getCartContexts();
//        List<PickTask> pickTasks = cartContexts. get(0).getPickTasks();
//
//        assertThat(cartContexts).hasSize(1);
//        assertThat(pickTasks).hasSize(1);
//        assertThat(pickTasks.get(0).getPutTasks()).hasSize(2);
    }

    @Transactional
    @Test
    public void verifySaveWithNesterEntities() {
        Long userId = 1_111L;

        PickTask pickTask1 = new PickTask();
        PickTask pickTask2 = new PickTask();

        CartContext cartContext1 = new CartContext();
        cartContext1.addPickTasks(ImmutableList.of(pickTask1, pickTask2));

        CartContext cartContext2 = new CartContext();

//        CartContext savedCartContext1 = cartContextRepository.save(cartContext1);
//        CartContext savedCartContext2 = cartContextRepository.save(cartContext2);

        UserSession userSession = new UserSession().userId(userId).addCartContexts(cartContext1).addCartContexts(cartContext2);


        userSessionRepository.save(userSession);

        List<UserSession> userSessions = (List<UserSession>) userSessionRepository.findAll();
        Optional<UserSession> foundSavedUserSession = userSessions.stream().filter(us -> us.getUserId().equals(userId)).findFirst();
        assertThat(foundSavedUserSession).isPresent();
        assertThat(foundSavedUserSession.get().getCartContexts()).hasSize(2);
    }
}
