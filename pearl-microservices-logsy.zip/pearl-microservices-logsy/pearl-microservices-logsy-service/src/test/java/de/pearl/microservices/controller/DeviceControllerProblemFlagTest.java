package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.text.MessageFormat;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import com.github.tomakehurst.wiremock.http.Fault;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class DeviceControllerProblemFlagTest extends AbstractWireMockIntegrationTest {

    private String endpointTemplatePflag = "/bbs/pda/logistics/stock/problemflag_action.jsp?pflag={0}&label={1}";

    @Test
    public void testPf3_success() throws Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 3, "0101-02-03-09")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/pf/response_wws_pf_3.json"))));

        mockMvc.perform(post("/logsy/device/pfReport").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/pf/request_ui_pf_3.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/pf/response_ui_pf_3.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 3, "0101-02-03-09"))));

    }

    @Test
    public void testPf6_success() throws IOException, Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 6, "0101-02-03-09")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/pf/response_wws_pf_6.json"))));

        mockMvc.perform(post("/logsy/device/pfReport").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/pf/request_ui_pf_6.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/pf/response_ui_pf_6.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 6, "0101-02-03-09"))));

    }

    @Test
    public void testPf3_except() throws IOException, Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 3, "0101-02-03-07")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withFault(Fault.EMPTY_RESPONSE)));

        mockMvc.perform(post("/logsy/device/pfReport").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/pf/request_ui_pf_3_1.json"))).andExpect(status().is(400));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 3, "0101-02-03-07"))));

    }

    @Test
    public void testPf6_except() throws IOException, Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 6, "0107-02-03-08")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withFault(Fault.EMPTY_RESPONSE)));

        mockMvc.perform(post("/logsy/device/pfReport").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/pf/request_ui_pf_6_1.json"))).andExpect(status().is(400));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 6, "0107-02-03-08"))));
    }

    @Test
    public void testPf3_fail() throws IOException, Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 3, "0101-02-03-09")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/pf/response_wws_pf_3_fail.json"))));

        mockMvc.perform(post("/logsy/device/pfReport").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/pf/request_ui_pf_3.json"))).andExpect(status().is(400));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 3, "0101-02-03-09"))));
    }

    @Test
    public void testPf6_fail() throws IOException, Exception {
        // prepare wws stub
        stubFor(get(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 6, "0101-02-03-09")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/pf/response_wws_pf_6_fail.json"))));

        mockMvc.perform(post("/logsy/device/pfReport").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/pf/request_ui_pf_6.json"))).andExpect(status().is(400));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(endpointTemplatePflag, 6, "0101-02-03-09"))));

    }

}
