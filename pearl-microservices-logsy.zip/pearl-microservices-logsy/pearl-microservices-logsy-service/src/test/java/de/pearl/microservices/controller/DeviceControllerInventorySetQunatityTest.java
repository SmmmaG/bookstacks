package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class DeviceControllerInventorySetQunatityTest extends AbstractWireMockIntegrationTest {
    private static final String WWS_ENDPOINT = "/bbs/pda/logistics/stock/correction_action.jsp?destination={0}&item={1}&qty={2}";
    private static final String STOCK_LOCATION_ENDPOINT = "/bbs/pda/logistics/stock/stocklocation_data.jsp?label={0}";

    private static final String stockNumber = "7000-01-02-03";
    private static final String itemId = "SD13-1";
    private static final String qty = "1231";

    @Test
    public void setQuantityTest_success() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/set_quantity/response_wws_success.json"))));

        stubFor(get(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, stockNumber)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/set_quantity/response_wws_check_stock_success.json"))));

        mockMvc.perform(post("/logsy/device/sendreport/correction").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/set_quantity/request_ui_success.json")))
                .andExpect(status().isOk())
                .andExpect(content().string("success"));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty))));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty))));
    }

    @Test
    public void setQuantityTest_fail_stock() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, stockNumber)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/set_quantity/response_wws_check_stock_fail.json"))));

        stubFor(get(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/set_quantity/response_wws_fail.json"))));

        mockMvc.perform(post("/logsy/device/sendreport/correction").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/set_quantity/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/inventory/set_quantity/response_ui_no_wws.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, stockNumber))));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty))));
    }

    @Test
    public void setQuantityTest_fail_setQty() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, stockNumber)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/set_quantity/response_wws_check_stock_success.json"))));

        stubFor(get(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/set_quantity/response_wws_fail.json"))));

        mockMvc.perform(post("/logsy/device/sendreport/correction").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/set_quantity/request_ui_success.json")))
                .andExpect(status().is(200))
                .andExpect(content().string("success"));

        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, stockNumber))));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty))));
    }

    @Test
    public void setQuantityTest_no_wws() throws Exception {
        mockMvc.perform(post("/logsy/device/sendreport/correction").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/set_quantity/request_ui_success.json"))).andExpect(status().is(400));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty))));
    }

    @Test
    public void setQuantityTest_no_wws1() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, stockNumber)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/set_quantity/response_wws_check_stock_success.json"))));

        mockMvc.perform(post("/logsy/device/sendreport/correction").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/set_quantity/request_ui_success.json"))).andExpect(status().is(400));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, stockNumber, itemId, qty))));
    }
}
