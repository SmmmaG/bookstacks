package de.pearl.microservices.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

import de.pearl.microservices.AbstractIntegrationTest;

@SpringBootTest
public class PickerControllerScanCartTest extends AbstractIntegrationTest {
    @Test
    @Transactional
    public void scanCart_success() throws Exception {
        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_cart/request_ui_success.json")))
                .andExpect(status().is(200))
                .andExpect(content().json(readResourceAsString("./testJson/scan_cart/response_ui_success.json")));
    }

    @Test
    @Transactional
    public void scanCart_fail() throws Exception {
        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_cart/request_ui_fail.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/scan_cart/response_ui_fail.json")));
    }
}
