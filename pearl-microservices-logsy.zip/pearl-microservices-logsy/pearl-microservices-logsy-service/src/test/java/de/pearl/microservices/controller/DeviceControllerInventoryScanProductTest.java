package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class DeviceControllerInventoryScanProductTest extends AbstractWireMockIntegrationTest {
    private static final String WWS_ENDPOINT = "/bbs/pda/logistics/product/productbarcode_data.jsp?label={0}";

    @Test
    public void scanProductTest_success() throws Exception {
        String pdId = "SD13";
        stubFor(get(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, pdId)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/scan_product/response_wws_success.json"))));

        mockMvc.perform(post("/logsy/device/checkProduct/" + pdId).contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/scan_product/request_ui_success.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/inventory/scan_product/response_ui_success.json")));

        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, pdId))));
    }

    @Test
    public void scanProductTest_fail() throws Exception {
        String pdId = "SD13";
        stubFor(get(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, pdId)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(500)));

        mockMvc.perform(post("/logsy/device/checkProduct/" + pdId).contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/scan_product/request_ui_success.json")))
                .andExpect(status().is(404))
                .andExpect(content().json(readResourceAsString("./testJson/inventory/scan_product/response_ui_fail.json")));

        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, pdId))));
    }

    @Test
    public void scanProductTest_no_wws() throws Exception {
        String pdId = "SD13";
        mockMvc.perform(post("/logsy/device/checkProduct/" + pdId).contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/scan_product/request_ui_success.json")))
                .andExpect(status().is(404))
                .andExpect(content().json(readResourceAsString("./testJson/inventory/scan_product/response_ui_no_wws.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(WWS_ENDPOINT, pdId))));
    }
}
