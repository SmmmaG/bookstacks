package de.pearl.microservices.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

import de.pearl.microservices.AbstractWireMockIntegrationTest;

@SpringBootTest
public class PickerControllerStartPickenTest extends AbstractWireMockIntegrationTest {

    @Test
    @Transactional
    public void scanStartPicken_success() throws Exception {
        mockMvc.perform(post("/logsy/picker/nextstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/start_picken/request_ui_success.json")))
                .andExpect(status().is(200))
                .andExpect(content().json(readResourceAsString("./testJson/start_picken/response_ui_success.json")));
    }

    @Test
    @Transactional
    public void scanStartPicken_fail() throws Exception {
        mockMvc.perform(post("/logsy/picker/nextstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/start_picken/request_ui_fail.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/start_picken/response_ui_fail.json")));
    }

}
