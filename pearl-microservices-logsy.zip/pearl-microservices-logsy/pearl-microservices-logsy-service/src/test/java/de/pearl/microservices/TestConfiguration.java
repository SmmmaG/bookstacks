package de.pearl.microservices;

import com.opentable.db.postgres.embedded.EmbeddedPostgres;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import javax.annotation.PreDestroy;
import javax.sql.DataSource;
import java.io.IOException;

@Configuration
@Profile("test")
public class TestConfiguration {
    @Autowired
    EmbeddedPostgres embeddedPostgres;

    @Bean
    public EmbeddedPostgres getEmbeddedPostgres() throws IOException {
        return EmbeddedPostgres.builder().start();
    }

    @Bean
    public DataSource getDataSource() {
        return embeddedPostgres.getPostgresDatabase();
    }

    @PreDestroy
    public void destroy() throws IOException {
        embeddedPostgres.close();
    }

}
