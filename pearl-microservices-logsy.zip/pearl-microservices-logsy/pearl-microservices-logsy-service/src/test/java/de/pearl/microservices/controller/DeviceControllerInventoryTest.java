package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class DeviceControllerInventoryTest extends AbstractWireMockIntegrationTest {
    private String endpointTemplateInventory = "/bbs/pda/logistics/stock/next_inventory_slot.jsp?label={0}";

    @Test
    public void testCheckInventory_success() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(endpointTemplateInventory, "0401-01-01-01")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("testJson/inventory/wws/response-next_inventory_slot-success.json"))));

        mockMvc.perform(post("/logsy/device/correction/inventory/source/0401-01-01-01").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("testJson/inventory/ui/request-next_inventory_slot.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("testJson/inventory/ui/response-next_inventory_slot-success.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(endpointTemplateInventory, "0401-01-01-01"))));

    }

    @Test
    public void testCheckInventory_fail() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(endpointTemplateInventory, "0301-01-01-01")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("testJson/inventory/wws/response-next_inventory_slot-fail.json"))));

        mockMvc.perform(post("/logsy/device/correction/inventory/source/0301-01-01-01").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("testJson/inventory/ui/request-next_inventory_slot.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("testJson/inventory/ui/response-next_inventory_slot-fail.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(endpointTemplateInventory, "0301-01-01-01"))));

    }
}
