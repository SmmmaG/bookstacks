package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.flywaydb.test.annotation.FlywayTest;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class PickerControllerProblemFlagTest extends AbstractWireMockIntegrationTest {
    /*
     * Problem flag tests
     */
    @Test
    @FlywayTest
    @Transactional
    public void pickWithWrongQuantityLastEPOS_success() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(IWwsEndpointService.PROBLEM_FLAG_ENDPOINT, 5, "0301-02-03-09")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/pf/response_wws_pf_5_last.json"))));

        stubFor(get(urlEqualTo(MessageFormat.format(IWwsEndpointService.PICK_AND_PUT_TASK_WWS_URL, 337, "pdId3", 13, 1, "0301-02-03-09")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/pf/response_wws_pf_5_last_pick_and_put.json"))));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/pf/request_ui_pf_5_last.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/pf/response_ui_pf_5_last.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(IWwsEndpointService.PROBLEM_FLAG_ENDPOINT, 5, "0301-02-03-09"))));
        verify(1, getRequestedFor(
                urlEqualTo(MessageFormat.format(IWwsEndpointService.PICK_AND_PUT_TASK_WWS_URL, 337, "pdId3", 13, 1, "0301-02-03-09"))));
    }

    @Test
    @FlywayTest
    @Transactional
    public void pickWithWrongQuantityEPOS_success() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(IWwsEndpointService.PROBLEM_FLAG_ENDPOINT, 5, "0201-02-03-09")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/pf/response_wws_pf_5.json"))));

        stubFor(get(urlEqualTo(MessageFormat.format(IWwsEndpointService.PICK_AND_PUT_TASK_WWS_URL, 335, "pdId2", 11, 1, "0201-02-03-09")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/pf/response_wws_pf_5_pick_and_put.json"))));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/pf/request_ui_pf_5.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/pf/response_ui_pf_5.json")));
    }

}
