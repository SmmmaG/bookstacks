package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class DeviceControllerInventoryFindStockTest extends AbstractWireMockIntegrationTest {
    @Test
    public void findStockTest_success() throws Exception {
        String stockNumber = "0401-01-01-01";
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/stock/next_inventory_slot.jsp?label={0}", stockNumber)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/find_stock/response_wws_success.json"))));

        mockMvc.perform(post("/logsy/device/correction/inventory/source/" + stockNumber).contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/find_stock/request_ui_success.json")))
                .andExpect(status().isOk())
                .andExpect(content().json(readResourceAsString("./testJson/inventory/find_stock/response_ui_success.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/stock/next_inventory_slot.jsp?label={0}", stockNumber))));
    }

    @Test
    public void findStockTest_fail() throws Exception {
        String stockNumber = "0501-01-01-01";
        stubFor(get(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/stock/next_inventory_slot.jsp?label={0}", stockNumber)))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/inventory/find_stock/response_wws_fail.json"))));

        mockMvc.perform(post("/logsy/device/correction/inventory/source/" + stockNumber).contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/find_stock/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/inventory/find_stock/response_ui_fail.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/stock/next_inventory_slot.jsp?label={0}", stockNumber))));
    }

    @Test
    public void findStockTest_no_wws() throws Exception {
        String stockNumber = "0601-01-01-01";
        mockMvc.perform(post("/logsy/device/correction/inventory/source/" + stockNumber).contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/inventory/find_stock/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/inventory/find_stock/response_ui_no_wws.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format("/bbs/pda/logistics/stock/next_inventory_slot.jsp?label={0}", stockNumber))));
    }
}
