/**
 * 
 */
package de.pearl.microservices;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;

import org.junit.Rule;

import com.github.tomakehurst.wiremock.junit.WireMockRule;

/**
 * Added mocking requests to WWS rule with wiremock
 * 
 * @author Ismakaev
 *
 */
public abstract class AbstractWireMockIntegrationTest extends AbstractIntegrationTest {
    @Rule
    public WireMockRule mockRuleGetTrolley = new WireMockRule(wireMockConfig().port(8181).httpsPort(8484), false);

}
