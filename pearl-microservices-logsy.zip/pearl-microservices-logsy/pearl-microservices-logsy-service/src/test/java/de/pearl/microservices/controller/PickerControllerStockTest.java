package de.pearl.microservices.controller;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.verify;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.MessageFormat;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.Transactional;

import de.pearl.microservices.AbstractWireMockIntegrationTest;
import de.pearl.microservices.service.IWwsEndpointService;

@SpringBootTest
public class PickerControllerStockTest extends AbstractWireMockIntegrationTest {
    private static final String STOCK_LOCATION_ENDPOINT = "/bbs/pda/logistics/stock/stocklocation_data.jsp?label={0}";

    @Test
    @Transactional
    public void scanStock_success() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, "0701-01-02-03")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/scan_stock/response_wws_success.json"))));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_stock/request_ui_success.json")))
                .andExpect(status().is(200))
                .andExpect(content().json(readResourceAsString("./testJson/scan_stock/response_ui_success.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, "0701-01-02-03"))));
    }

    @Test
    @Transactional
    public void scanStock_fail() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, "0701-01-02-03")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(readResourceAsString("./testJson/scan_stock/response_wws_fail.json"))));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_stock/request_ui_success.json")))
                .andExpect(status().is(400))
                .andExpect(content().json(readResourceAsString("./testJson/scan_stock/response_ui_fail.json")));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, "0701-01-02-03"))));
    }

    @Test
    @Transactional
    public void scanStock_wws_404() throws Exception {
        stubFor(get(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, "0701-01-02-03")))
                .withHeader(IWwsEndpointService.ACCEPT, equalTo(IWwsEndpointService.ACCEPT_JSON))
                .willReturn(aResponse().withStatus(404)));

        mockMvc.perform(post("/logsy/picker/processstage").contentType(MediaType.APPLICATION_JSON)
                .content(readResourceAsString("./testJson/scan_stock/request_ui_success.json"))).andExpect(status().is(400));
        verify(1, getRequestedFor(urlEqualTo(MessageFormat.format(STOCK_LOCATION_ENDPOINT, "0701-01-02-03"))));
    }

}
